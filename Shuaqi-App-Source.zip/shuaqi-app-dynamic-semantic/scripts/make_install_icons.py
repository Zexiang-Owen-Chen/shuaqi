"""Generate placeholder SHUAQI icons. Replace with the real logo when design supplies one."""
import sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

BRAND = (249, 115, 22)  # brand-500 #f97316
WHITE = (255, 255, 255)
FONT = "/usr/share/fonts/opentype/inter/InterDisplay-Bold.otf"
out = Path(sys.argv[1])
out.mkdir(parents=True, exist_ok=True)


def icon(size, *, maskable=False, rounded=True):
    scale = 4
    s = size * scale
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    if maskable or not rounded:
        d.rectangle([0, 0, s, s], fill=BRAND)
    else:
        d.rounded_rectangle([0, 0, s - 1, s - 1], radius=int(s * 0.22), fill=BRAND)
    # Maskable icons must keep content inside the central 80% safe zone.
    glyph = 0.42 if maskable else 0.6
    font = ImageFont.truetype(FONT, int(s * glyph))
    d.text((s / 2, s / 2), "S", font=font, fill=WHITE, anchor="mm")
    return img.resize((size, size), Image.LANCZOS)


icon(192).save(out / "icon-192.png")
icon(512).save(out / "icon-512.png")
icon(512, maskable=True).save(out / "icon-512-maskable.png")
# iOS ignores transparency and rounds corners itself, so use a full square.
icon(180, rounded=False).convert("RGB").save(out / "apple-touch-icon.png")
