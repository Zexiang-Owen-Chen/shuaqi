<script setup lang="ts">
import type { FlagKey } from '~/composables/useFeatureFlags'

const route = useRoute()
const { isOn } = useFeatureFlags()
const allTabs: { to: string; label: string; icon: string; flag?: FlagKey }[] = [
  { to: '/', label: '发现', icon: '🔍' },
  { to: '/buddy', label: '找搭子', icon: '🤝', flag: 'intents' },
  { to: '/create', label: '发布', icon: '➕' },
  { to: '/my-events', label: '我的活动', icon: '📅' },
  { to: '/me', label: '我的', icon: '👤' },
]
const tabs = computed(() => allTabs.filter((t) => !t.flag || isOn(t.flag)))
const active = (to: string) => (to === '/' ? route.path === '/' : route.path.startsWith(to))

// Unread chat messages show as a badge on 我的 (the 消息 entry lives there).
const user = useSupabaseUser()
const { unread, refresh: refreshUnread } = useChatUnread()
watch(() => route.path, () => refreshUnread(), { immediate: true })
let stop: (() => void) | null = null
function listen() {
  stop?.()
  stop = null
  const me = currentUid(user.value)
  if (!me || !isOn('chat')) return
  stop = subscribeToMessages('unread-badge', (m) => { if (m.sender_id !== me) refreshUnread(true) })
}
onMounted(listen)
watch(() => currentUid(user.value), () => { refreshUnread(true); listen() })
onBeforeUnmount(() => stop?.())
</script>

<template>
  <div class="mx-auto min-h-dvh max-w-lg pb-20">
    <slot />
    <nav class="fixed inset-x-0 bottom-0 z-20 border-t border-stone-200 bg-white/95 backdrop-blur"
         style="padding-bottom: env(safe-area-inset-bottom)">
      <ul class="mx-auto grid max-w-lg" :class="tabs.length === 5 ? 'grid-cols-5' : 'grid-cols-4'">
        <li v-for="t in tabs" :key="t.to">
          <NuxtLink :to="t.to" class="flex flex-col items-center gap-0.5 py-2 text-[11px]"
                    :class="active(t.to) ? 'text-brand-600' : 'text-stone-500'">
            <span class="relative text-lg leading-none" aria-hidden="true">{{ t.icon }}<span
              v-if="t.to === '/me' && unread" class="absolute -right-3 -top-1 min-w-4 rounded-full bg-red-500 px-1 text-[10px] font-medium leading-4 text-white"
            >{{ unreadLabel(unread) }}</span></span>{{ t.label }}
          </NuxtLink>
        </li>
      </ul>
    </nav>
  </div>
</template>
