<template>
  <div class="mx-auto min-h-dvh max-w-lg"><slot /></div>
</template>
