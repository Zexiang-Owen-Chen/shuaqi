<script setup lang="ts">
import type { Database } from '~/types/database.types'
import { currentUserId, formatDateTime } from '~/components/organiser/-format'

definePageMeta({ layout: false })
useHead({ title: '主办方后台 · SHUAQI' })

type EventRow = Database['public']['Tables']['events']['Row']
interface EventStats { going: number, selfChecked: number, confirmed: number }

const supabase = useSupabaseClient<Database>()
const user = useSupabaseUser()
const rpc = useRpc()

const orgs = ref<{ org_id: string, name: string, role: string }[]>([])
const events = ref<EventRow[]>([])
const stats = ref<Record<string, EventStats>>({})
const loading = ref(true)
const error = ref<string | null>(null)
const tab = ref<'upcoming' | 'past'>('upcoming')

const ROLE_TEXT: Record<string, string> = { owner: '负责人', organiser: '组织者', staff: '工作人员' }

async function load() {
  loading.value = true
  error.value = null
  try {
    const uid = currentUserId(user.value as never)
    if (!uid) throw new Error('请先登录')
    orgs.value = await rpc('my_organisations')
    const orgIds = orgs.value.map(o => o.org_id)
    let q = supabase.from('events').select('*').order('starts_at', { ascending: false }).limit(200)
    q = orgIds.length ? q.or(`host_user_id.eq.${uid},org_id.in.(${orgIds.join(',')})`) : q.eq('host_user_id', uid)
    const { data, error: e } = await q
    if (e) throw new Error(messageFor(e))
    events.value = data ?? []
    await loadStats(events.value.map(e => e.id))
  } catch (e) {
    error.value = (e as Error).message
  } finally {
    loading.value = false
  }
}

async function loadStats(ids: string[]) {
  const s: Record<string, EventStats> = Object.fromEntries(ids.map(id => [id, { going: 0, selfChecked: 0, confirmed: 0 }]))
  if (!ids.length) { stats.value = s; return }
  const [r, ev] = await Promise.all([
    supabase.from('event_rsvps').select('event_id').in('event_id', ids).eq('status', 'going'),
    supabase.from('participation_evidence').select('event_id, type, verification_status')
      .in('event_id', ids).neq('verification_status', 'revoked'),
  ])
  for (const row of r.data ?? []) s[row.event_id]!.going++
  for (const row of ev.data ?? []) {
    const t = s[row.event_id!]
    if (!t) continue
    if (row.type === 'self_reported_presence' && row.verification_status === 'geo_verified') t.selfChecked++
    if (row.type === 'organiser_confirmed_attendance' && row.verification_status === 'verified') t.confirmed++
  }
  stats.value = s
}

const now = Date.now()
const isPast = (e: EventRow) => e.status === 'ended' || e.status === 'cancelled'
  || new Date(e.ends_at ?? e.starts_at).getTime() < now - 6 * 3600_000
const shown = computed(() => {
  const list = events.value.filter(e => (tab.value === 'past') === isPast(e))
  return tab.value === 'upcoming' ? [...list].reverse() : list
})
const orgName = (id: string | null) => (id ? orgs.value.find(o => o.org_id === id)?.name ?? '组织活动' : '个人发起')

onMounted(load)
</script>

<template>
  <OrganiserShell title="我的活动">
    <template #actions>
      <NuxtLink to="/organiser/events/new" class="btn-primary">＋ 创建活动</NuxtLink>
    </template>

    <div v-if="orgs.length" class="mb-4 flex flex-wrap gap-2">
      <NuxtLink v-for="o in orgs" :key="o.org_id" :to="`/organiser/orgs/${o.org_id}`" class="chip hover:bg-stone-200">
        {{ o.name }} · {{ ROLE_TEXT[o.role] ?? o.role }}
      </NuxtLink>
    </div>

    <div class="mb-3 flex gap-1 text-sm">
      <button v-for="t in ([['upcoming', '进行中和即将开始'], ['past', '已结束']] as const)" :key="t[0]"
              class="rounded-lg px-3 py-1.5" :class="tab === t[0] ? 'bg-stone-800 text-white' : 'bg-stone-100 text-stone-600'"
              @click="tab = t[0]">{{ t[1] }}</button>
    </div>

    <OrganiserState :loading="loading" :error="error" :empty="!shown.length"
                    :empty-text="tab === 'upcoming' ? '还没有即将开始的活动，点右上角创建一个吧' : '没有已结束的活动'"
                    @retry="load">
      <ul class="grid gap-3 sm:grid-cols-2">
        <li v-for="e in shown" :key="e.id">
          <NuxtLink :to="`/organiser/events/${e.id}`" class="card block space-y-2 hover:ring-brand-500">
            <div class="flex items-start gap-2">
              <h2 class="font-medium leading-snug">{{ e.title }}</h2>
              <OrganiserStatusBadge class="ml-auto" kind="event" :value="e.status" />
            </div>
            <p class="text-xs text-stone-500">{{ formatDateTime(e.starts_at) }} · {{ e.location_text || '未填写地点' }}</p>
            <p class="text-xs text-stone-500">{{ orgName(e.org_id) }}</p>
            <div class="flex gap-4 pt-1 text-sm">
              <span>报名 <b>{{ stats[e.id]?.going ?? 0 }}</b><template v-if="e.capacity"> / {{ e.capacity }}</template></span>
              <span>定位签到 <b>{{ stats[e.id]?.selfChecked ?? 0 }}</b></span>
              <span>已确认 <b>{{ stats[e.id]?.confirmed ?? 0 }}</b></span>
            </div>
          </NuxtLink>
        </li>
      </ul>
    </OrganiserState>
  </OrganiserShell>
</template>
