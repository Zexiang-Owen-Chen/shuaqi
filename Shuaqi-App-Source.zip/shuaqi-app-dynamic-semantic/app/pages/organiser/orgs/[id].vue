<script setup lang="ts">
import type { Database } from '~/types/database.types'
import { formatDateTime } from '~/components/organiser/-format'

definePageMeta({ layout: false })

interface Member { user_id: string, display_name: string, avatar_url: string | null, email: string | null, role: string, joined_at: string }
type OrgRole = Database['public']['Enums']['org_role']

const route = useRoute()
const id = route.params.id as string
const supabase = useSupabaseClient<Database>()
const rpc = useRpc()

const org = ref<{ id: string, name: string, verified: boolean } | null>(null)
const members = ref<Member[]>([])
const myRole = ref<string | null>(null)
const isAdmin = ref(false)
const loading = ref(true)
const error = ref<string | null>(null)
const msg = ref<{ ok: boolean, text: string } | null>(null)
const email = ref('')
const role = ref<OrgRole>('staff')
const adding = ref(false)

const ROLE_TEXT: Record<string, string> = { owner: '负责人', organiser: '组织者', staff: '工作人员' }
const canManage = computed(() => isAdmin.value || myRole.value === 'owner')

useHead(() => ({ title: `${org.value?.name ?? '组织'} · SHUAQI 后台` }))

async function load() {
  loading.value = true
  error.value = null
  try {
    const [o, mine, admin] = await Promise.all([
      supabase.from('organisations').select('id, name, verified').eq('id', id).maybeSingle(),
      rpc('my_organisations'),
      rpc('is_admin'),
    ])
    if (o.error) throw new Error(messageFor(o.error))
    if (!o.data) throw new Error('组织不存在')
    org.value = o.data
    myRole.value = mine.find(m => m.org_id === id)?.role ?? null
    isAdmin.value = admin
    // list_org_members 来自 supabase/migrations/20261020000100_org_member_list.sql，类型重新生成前先绕过类型检查
    const { data, error: e } = await (supabase.rpc as unknown as (n: string, a: object) => Promise<{ data: Member[] | null, error: { message: string } | null }>)('list_org_members', { p_org: id })
    if (e) throw new Error(messageFor(e))
    members.value = data ?? []
  } catch (err) {
    error.value = (err as Error).message
  } finally {
    loading.value = false
  }
}
onMounted(load)

async function add() {
  if (!email.value.trim()) return
  adding.value = true
  msg.value = null
  try {
    await rpc('add_org_member', { p_org: id, p_email: email.value.trim(), p_role: role.value })
    msg.value = { ok: true, text: `已添加 ${email.value.trim()}` }
    email.value = ''
    await load()
  } catch (e) {
    msg.value = { ok: false, text: (e as Error).message }
  } finally {
    adding.value = false
  }
}

async function changeRole(m: Member, r: OrgRole) {
  if (!m.email) return
  if (m.role === 'owner' && r !== 'owner' && members.value.filter(x => x.role === 'owner').length === 1) {
    msg.value = { ok: false, text: '组织至少要保留一位负责人，请先添加新的负责人' }
    await load()
    return
  }
  msg.value = null
  try {
    await rpc('add_org_member', { p_org: id, p_email: m.email, p_role: r })
    m.role = r
  } catch (e) {
    msg.value = { ok: false, text: (e as Error).message }
  }
}

async function remove(m: Member) {
  if (m.role === 'owner' && members.value.filter(x => x.role === 'owner').length === 1) {
    msg.value = { ok: false, text: '组织至少要保留一位负责人，请先添加新的负责人' }
    return
  }
  if (!window.confirm(`把「${m.display_name || m.email || '该成员'}」移出组织？`)) return
  msg.value = null
  try {
    await rpc('remove_org_member', { p_org: id, p_user: m.user_id })
    members.value = members.value.filter(x => x.user_id !== m.user_id)
  } catch (e) {
    msg.value = { ok: false, text: (e as Error).message }
  }
}
</script>

<template>
  <OrganiserShell :title="org?.name ?? '组织'" :back="isAdmin && !myRole ? '/admin/orgs' : '/organiser'">
    <OrganiserState :loading="loading" :error="error" @retry="load">
      <div class="space-y-4">
        <p class="text-sm text-stone-500">
          <span v-if="org?.verified" class="chip mr-2 bg-green-50 text-green-700">已认证组织</span>
          负责人可以添加成员；组织者可以以组织名义发起和管理活动；工作人员只能查看名单、协助现场确认到场。
        </p>

        <section v-if="canManage" class="card space-y-2">
          <h2 class="font-medium">添加成员</h2>
          <div class="flex flex-wrap gap-2">
            <input v-model="email" type="email" class="input max-w-72" placeholder="对方注册 SHUAQI 用的邮箱" @keydown.enter.prevent="add">
            <select v-model="role" class="input w-32">
              <option value="staff">工作人员</option>
              <option value="organiser">组织者</option>
              <option value="owner">负责人</option>
            </select>
            <button class="btn-primary" :disabled="adding || !email.trim()" @click="add">{{ adding ? '添加中…' : '添加' }}</button>
          </div>
          <p class="text-xs text-stone-500">对方需要先用学校邮箱登录过一次 SHUAQI。</p>
        </section>

        <p v-if="msg" class="text-sm" :class="msg.ok ? 'text-green-700' : 'text-red-700'">{{ msg.text }}</p>

        <OrganiserState :empty="!members.length" empty-text="还没有成员">
          <ul class="divide-y divide-stone-100 overflow-hidden rounded-2xl bg-white ring-1 ring-stone-100">
            <li v-for="m in members" :key="m.user_id" class="flex flex-wrap items-center gap-3 px-4 py-3">
              <div class="min-w-0 flex-1">
                <p class="font-medium">{{ m.display_name || '未填写昵称' }}</p>
                <p class="text-xs text-stone-500"><template v-if="m.email">{{ m.email }} · </template>{{ formatDateTime(m.joined_at) }} 加入</p>
              </div>
              <select v-if="canManage && m.email" :value="m.role" class="input w-32 py-1.5"
                      @change="changeRole(m, ($event.target as HTMLSelectElement).value as OrgRole)">
                <option value="staff">工作人员</option>
                <option value="organiser">组织者</option>
                <option value="owner">负责人</option>
              </select>
              <span v-else class="chip">{{ ROLE_TEXT[m.role] ?? m.role }}</span>
              <button v-if="canManage" class="btn-danger py-1.5" @click="remove(m)">移出</button>
            </li>
          </ul>
        </OrganiserState>
      </div>
    </OrganiserState>
  </OrganiserShell>
</template>
