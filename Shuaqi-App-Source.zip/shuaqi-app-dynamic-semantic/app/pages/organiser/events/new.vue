<script setup lang="ts">
import type { Database } from '~/types/database.types'
import { currentUserId } from '~/components/organiser/-format'

definePageMeta({ layout: false })
useHead({ title: '创建活动 · SHUAQI 后台' })

type EventInsert = Database['public']['Tables']['events']['Insert']
type EventStatus = Database['public']['Enums']['event_status']

const supabase = useSupabaseClient<Database>()
const user = useSupabaseUser()
const rpc = useRpc()

const orgs = ref<{ org_id: string, name: string, role: string }[]>([])
const loading = ref(true)
const loadError = ref<string | null>(null)
const saving = ref(false)
const saveError = ref<string | null>(null)

async function load() {
  loading.value = true
  loadError.value = null
  try { orgs.value = await rpc('my_organisations') } catch (e) { loadError.value = (e as Error).message } finally { loading.value = false }
}
onMounted(load)

async function create(payload: Omit<EventInsert, 'host_user_id'> & { status?: EventStatus }) {
  saving.value = true
  saveError.value = null
  try {
    const uid = currentUserId(user.value as never)
    if (!uid) throw new Error('请先登录')
    const { status, ...fields } = payload
    // 新建时数据库不接受 status 字段（默认已发布），选“草稿”时建好后立即改为草稿
    const { data, error } = await supabase.from('events').insert({ ...fields, host_user_id: uid }).select('id').single()
    if (error) throw new Error(messageFor(error))
    if (status === 'draft') {
      const { error: e2 } = await supabase.from('events').update({ status: 'draft' }).eq('id', data.id)
      if (e2) throw new Error(messageFor(e2))
    }
    await navigateTo(`/organiser/events/${data.id}`, { replace: true })
  } catch (e) {
    saveError.value = (e as Error).message
  } finally {
    saving.value = false
  }
}
</script>

<template>
  <OrganiserShell title="创建活动" back="/organiser">
    <OrganiserState :loading="loading" :error="loadError" @retry="load">
      <p v-if="saveError" class="card mb-3 text-sm text-red-700">{{ saveError }}</p>
      <OrganiserEventForm :orgs="orgs" :saving="saving" submit-label="创建活动" @submit="create" />
    </OrganiserState>
  </OrganiserShell>
</template>
