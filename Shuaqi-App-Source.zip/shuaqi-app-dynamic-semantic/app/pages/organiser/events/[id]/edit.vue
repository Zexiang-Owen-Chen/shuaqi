<script setup lang="ts">
import type { Database } from '~/types/database.types'

definePageMeta({ layout: false })
useHead({ title: '编辑活动 · SHUAQI 后台' })

type EventRow = Database['public']['Tables']['events']['Row']
type EventUpdate = Database['public']['Tables']['events']['Update']

const route = useRoute()
const id = route.params.id as string
const supabase = useSupabaseClient<Database>()
const rpc = useRpc()

const event = ref<EventRow | null>(null)
const loading = ref(true)
const loadError = ref<string | null>(null)
const saving = ref(false)
const saveError = ref<string | null>(null)

async function load() {
  loading.value = true
  loadError.value = null
  try {
    const [{ data, error }, manager] = await Promise.all([
      supabase.from('events').select('*').eq('id', id).maybeSingle(),
      rpc('is_event_manager', { p_event: id }),
    ])
    if (error) throw new Error(messageFor(error))
    if (!data) throw new Error(errorText.event_not_found)
    if (!manager) throw new Error('只有活动发起人或组织的负责人、组织者可以编辑活动')
    event.value = data
  } catch (e) {
    loadError.value = (e as Error).message
  } finally {
    loading.value = false
  }
}
onMounted(load)

async function save(payload: EventUpdate) {
  saving.value = true
  saveError.value = null
  try {
    const { org_id: _o, type: _t, host_user_id: _h, ...fields } = payload
    // 已取消的活动不能改状态（用“取消活动”按钮处理），状态未变化时不发送，避免多写审计
    if (fields.status === event.value?.status || event.value?.status === 'cancelled') delete fields.status
    const { data, error } = await supabase.from('events').update(fields).eq('id', id).select('*').single()
    if (error) throw new Error(messageFor(error))
    event.value = data
    await navigateTo(`/organiser/events/${id}`)
  } catch (e) {
    saveError.value = (e as Error).message
  } finally {
    saving.value = false
  }
}
</script>

<template>
  <OrganiserShell title="编辑活动" :back="`/organiser/events/${id}`">
    <OrganiserState :loading="loading" :error="loadError" @retry="load">
      <p v-if="saveError" class="card mb-3 text-sm text-red-700">{{ saveError }}</p>
      <OrganiserEventForm v-if="event" :event="event" :orgs="[]" :saving="saving" submit-label="保存修改" @submit="save" />
    </OrganiserState>
  </OrganiserShell>
</template>
