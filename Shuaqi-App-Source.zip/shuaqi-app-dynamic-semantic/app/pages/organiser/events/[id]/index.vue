<script setup lang="ts">
import type { Database } from '~/types/database.types'
import { formatDateTime } from '~/components/organiser/-format'

definePageMeta({ layout: false })

type EventRow = Database['public']['Tables']['events']['Row']

const route = useRoute()
const id = route.params.id as string
const supabase = useSupabaseClient<Database>()
const rpc = useRpc()

const event = ref<EventRow | null>(null)
const orgName = ref<string | null>(null)
const isManager = ref(false)
const isStaff = ref(false)
const loading = ref(true)
const error = ref<string | null>(null)
const actionMsg = ref<{ ok: boolean, text: string } | null>(null)
const stats = ref({ going: 0, selfChecked: 0, confirmed: 0, absent: 0 })

useHead(() => ({ title: `${event.value?.title ?? '活动'} · SHUAQI 后台` }))

async function load() {
  loading.value = true
  error.value = null
  try {
    const [{ data, error: e }, manager, staff, admin] = await Promise.all([
      supabase.from('events').select('*, organisations(name)').eq('id', id).maybeSingle(),
      rpc('is_event_manager', { p_event: id }),
      rpc('is_event_staff', { p_event: id }),
      rpc('is_admin'),
    ])
    if (e) throw new Error(messageFor(e))
    if (!data) throw new Error(errorText.event_not_found)
    if (!staff && !admin) throw new Error('你不是这个活动的发起人或工作人员')
    const { organisations, ...row } = data as EventRow & { organisations: { name: string } | null }
    event.value = row
    orgName.value = organisations?.name ?? null
    isManager.value = manager
    isStaff.value = staff
  } catch (err) {
    error.value = (err as Error).message
  } finally {
    loading.value = false
  }
}
onMounted(load)

async function rotate() {
  if (!window.confirm('重置后，已经打印或投屏的旧二维码会立即失效，需要重新展示新码。确定重置？')) return
  actionMsg.value = null
  try {
    await rpc('rotate_checkin_code', { p_event: id })
    actionMsg.value = { ok: true, text: '签到码已重置，请重新打开“展示签到码”页面' }
  } catch (e) {
    actionMsg.value = { ok: false, text: (e as Error).message }
  }
}

async function setStatus(status: 'published' | 'ended' | 'draft') {
  actionMsg.value = null
  const { data, error: e } = await supabase.from('events').update({ status }).eq('id', id).select('*').single()
  if (e) { actionMsg.value = { ok: false, text: messageFor(e) }; return }
  event.value = data
}

async function cancel() {
  if (!window.confirm('取消后用户将无法报名和签到，且不能恢复。确定取消这个活动？')) return
  actionMsg.value = null
  try {
    await rpc('cancel_event', { p_event: id })
    event.value = { ...event.value!, status: 'cancelled' }
  } catch (e) {
    actionMsg.value = { ok: false, text: (e as Error).message }
  }
}

const MODE_TEXT = { qr_geo: '扫码 + 定位', manual: '仅手动确认', none: '不签到' } as const
const checkinWindow = computed(() => {
  const e = event.value
  if (!e) return ''
  const opens = e.checkin_opens_at ?? new Date(new Date(e.starts_at).getTime() - 3600_000).toISOString()
  const closes = e.checkin_closes_at ?? e.ends_at ?? new Date(new Date(e.starts_at).getTime() + 6 * 3600_000).toISOString()
  return `${formatDateTime(opens)} – ${formatDateTime(closes)}`
})
</script>

<template>
  <OrganiserShell :title="event?.title ?? '活动'" back="/organiser">
    <template v-if="event" #actions>
      <NuxtLink v-if="event.checkin_mode === 'qr_geo' && event.status === 'published'" :to="`/events/${id}/checkin-qr`" class="btn-primary">展示签到码</NuxtLink>
      <NuxtLink v-if="isManager && event.status !== 'cancelled'" :to="`/organiser/events/${id}/edit`" class="btn-secondary">编辑</NuxtLink>
      <NuxtLink :to="`/events/${id}`" class="btn-secondary">用户端查看</NuxtLink>
    </template>

    <OrganiserState :loading="loading" :error="error" @retry="load">
      <template v-if="event">
        <div class="grid gap-3 lg:grid-cols-3">
          <section class="card space-y-2 text-sm lg:col-span-2">
            <div class="flex flex-wrap items-center gap-2">
              <OrganiserStatusBadge kind="event" :value="event.status" />
              <span class="chip">{{ orgName ?? '个人发起' }}</span>
              <span class="chip">{{ event.visibility === 'school' ? '仅同校可见' : '所有用户可见' }}</span>
            </div>
            <p>🕒 {{ formatDateTime(event.starts_at) }}<template v-if="event.ends_at"> – {{ formatDateTime(event.ends_at) }}</template></p>
            <p>📍 {{ event.location_text || '未填写地点' }}</p>
            <p>✅ 签到方式：{{ MODE_TEXT[event.checkin_mode] }}<template v-if="event.checkin_mode === 'qr_geo'">，半径 {{ event.checkin_radius_m }} 米</template></p>
            <p v-if="event.checkin_mode !== 'none'" class="text-stone-500">签到时间：{{ checkinWindow }}</p>
            <p v-if="event.checkin_mode === 'qr_geo' && event.status !== 'published'" class="text-amber-700">活动发布后才能扫码签到。</p>
          </section>

          <section class="grid grid-cols-2 gap-3">
            <div class="card"><p class="text-xs text-stone-500">报名</p><p class="text-2xl font-semibold">{{ stats.going }}<span v-if="event.capacity" class="text-sm font-normal text-stone-400"> / {{ event.capacity }}</span></p></div>
            <div class="card"><p class="text-xs text-stone-500">主办方已确认</p><p class="text-2xl font-semibold text-green-700">{{ stats.confirmed }}</p></div>
            <div class="card"><p class="text-xs text-stone-500">定位签到</p><p class="text-2xl font-semibold text-sky-700">{{ stats.selfChecked }}</p></div>
            <div class="card"><p class="text-xs text-stone-500">尚未签到</p><p class="text-2xl font-semibold text-stone-500">{{ stats.absent }}</p></div>
          </section>
        </div>

        <p v-if="actionMsg" class="mt-3 text-sm" :class="actionMsg.ok ? 'text-green-700' : 'text-red-700'">{{ actionMsg.text }}</p>

        <div class="mt-5">
          <OrganiserRoster :event-id="id" :event-title="event.title" :can-confirm="isStaff" :capacity="event.capacity" @stats="stats = $event" />
        </div>

        <section v-if="isManager && event.status !== 'cancelled'" class="card mt-5 space-y-3">
          <h2 class="font-medium">活动管理</h2>
          <div class="flex flex-wrap gap-2">
            <button v-if="event.status === 'draft'" class="btn-primary" @click="setStatus('published')">发布活动</button>
            <button v-if="event.status === 'published'" class="btn-secondary" @click="setStatus('ended')">标记为已结束</button>
            <button v-if="event.status === 'ended'" class="btn-secondary" @click="setStatus('published')">重新开放</button>
            <button v-if="event.checkin_mode === 'qr_geo'" class="btn-secondary" @click="rotate">重置签到码</button>
            <button class="btn-danger" @click="cancel">取消活动</button>
          </div>
          <p class="text-xs text-stone-500">
            现场定位普遍失败时，可在“编辑”里把签到方式改为“仅手动确认”，由工作人员在上方名单逐个确认；也可以导出 CSV 打印纸质名单兜底。
          </p>
        </section>
      </template>
    </OrganiserState>
  </OrganiserShell>
</template>
