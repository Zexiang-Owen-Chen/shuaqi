<script setup lang="ts">
// S13: install guide. Detects the device and shows the steps that actually
// work there; the other devices' steps stay available below.
import type { PwaGuideKind } from '~/composables/useInstallPrompt'

useHead({ title: '把 SHUAQI 放到桌面' })

const route = useRoute()
const { kind, canPrompt, standalone, installed, install, guide } = useInstallPrompt()

// Detection is client-only; render after mount to avoid a hydration mismatch.
const mounted = ref(false)
onMounted(() => { mounted.value = true })

// Only follow internal paths, never another site.
const next = computed(() => {
  const r = route.query.redirect
  return typeof r === 'string' && r.startsWith('/') && !r.startsWith('//') ? r : '/'
})

type GuideKey = Exclude<PwaGuideKind, 'installed'>
const current = computed<GuideKey | null>(() => (kind.value && kind.value !== 'installed' ? kind.value : null))
const others = computed(() => (['ios', 'android', 'wechat'] as GuideKey[]).filter(k => k !== current.value))

const result = ref<'dismissed' | 'unavailable' | null>(null)
async function onInstall() {
  const outcome = await install()
  result.value = outcome === 'accepted' ? null : outcome
}

// Desktop: QR code to open this page on a phone.
const qr = ref<string | null>(null)
watch([mounted, current], async ([m, c]) => {
  if (!m || c !== 'desktop' || qr.value) return
  const { toDataURL } = await import('qrcode')
  qr.value = await toDataURL(`${location.origin}/install`, { margin: 1, width: 200 })
}, { immediate: true })
</script>

<template>
  <div class="px-4 pb-8 pt-6">
    <p class="text-sm font-semibold tracking-wide text-brand-600">SHUAQI</p>
    <h1 class="mt-2 text-2xl font-bold text-stone-900">把 SHUAQI 放到桌面</h1>
    <p class="mt-1 text-sm text-stone-500">不安装也能直接用网页，所有功能都一样。</p>

    <div v-if="!mounted" class="card mt-6 h-40 animate-pulse" aria-busy="true" />

    <template v-else>
      <!-- Already running from the home screen -->
      <section v-if="standalone" class="card mt-6">
        <h2 class="font-semibold text-stone-900">已经装好了</h2>
        <p class="mt-1 text-sm text-stone-600">你现在用的就是桌面上的 SHUAQI。</p>
      </section>
      <PushOptIn v-if="standalone" class="mt-4" />
      <section v-else-if="installed" class="card mt-6">
        <h2 class="font-semibold text-stone-900">安装成功</h2>
        <p class="mt-1 text-sm text-stone-600">可以在手机桌面找到 SHUAQI 了，也可以继续在这里用。</p>
      </section>

      <template v-else-if="current">
        <InstallSteps :guide="guide(current)" current class="mt-6">
          <div v-if="current === 'android' || current === 'desktop'" class="mt-4">
            <button v-if="canPrompt" type="button" class="btn-primary w-full" @click="onInstall">安装 SHUAQI</button>
            <p v-else-if="result === 'dismissed'" class="text-sm text-stone-500">已取消。想装的时候按上面的菜单步骤操作即可。</p>
          </div>
          <img v-if="current === 'desktop' && qr" :src="qr" alt="用手机扫码打开 SHUAQI" class="mt-4 size-40 rounded-lg ring-1 ring-stone-100">
        </InstallSteps>

        <details class="mt-6">
          <summary class="cursor-pointer text-sm font-medium text-stone-600">其他设备怎么装</summary>
          <div class="mt-3 space-y-3">
            <InstallSteps v-for="k in others" :key="k" :guide="guide(k)" />
          </div>
        </details>
      </template>

      <p class="mt-6 text-xs leading-relaxed text-stone-400">
        网页不能替你安装，最后一步需要你在手机上确认。安装后不占多少空间，随时可以像普通 App 一样删除。
      </p>
    </template>

    <NuxtLink :to="next" class="btn-primary mt-6 w-full py-3 text-base">{{ mounted && standalone ? '进入 SHUAQI' : mounted && installed ? '继续使用' : '先直接使用 Web App' }}</NuxtLink>
  </div>
</template>
