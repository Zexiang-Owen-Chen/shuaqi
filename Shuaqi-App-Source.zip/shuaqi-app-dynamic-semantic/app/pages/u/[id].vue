<script setup lang="ts">
const route = useRoute()
const rpc = useRpc()
const id = route.params.id as string
const { data: card, pending, error } = await useAsyncData(`card-${id}`, () => rpc('get_profile_card', { p_target: id, p_context: 'general' }))
const c = computed(() => card.value as Record<string, any> | null)
const msg = ref('')
const { isOn } = useFeatureFlags()

async function block() {
  if (!confirm('拉黑后你们将互相看不到，也无法发送请求。确定吗？')) return
  try { await rpc('block_user', { p_target: id }); msg.value = '已拉黑'; navigateTo('/me') } catch (e) { msg.value = (e as Error).message }
}
</script>

<template>
  <main class="space-y-4 px-4 py-6">
    <p v-if="pending" class="text-sm text-stone-500">加载中…</p>
    <p v-else-if="error || !c" class="text-sm text-stone-500">无法查看这位用户的资料。</p>
    <template v-else>
      <section class="card">
        <ProfilePersonCard :card="c as any" />
        <div v-if="c.photos?.length" class="mt-3 grid grid-cols-3 gap-2">
          <img v-for="p in c.photos" :key="p" :src="publicUrl('photos', p)" alt="" class="aspect-square rounded-xl object-cover">
        </div>
      </section>
      <NuxtLink v-if="c.connected && isOn('chat')" :to="`/messages/${id}`" class="btn-primary w-full">发消息</NuxtLink>
      <ProfileTrustCard :user-id="id" />
      <div v-if="!c.is_me" class="flex items-center justify-between">
        <ProfileReportButton target-type="user" :target-id="id" />
        <button class="text-xs text-red-600 underline" @click="block">拉黑</button>
      </div>
      <p v-if="msg" class="text-sm">{{ msg }}</p>
    </template>
  </main>
</template>
