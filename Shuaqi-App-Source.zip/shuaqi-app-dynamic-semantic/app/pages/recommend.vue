<script setup lang="ts">
import type { Database } from '~/types/database.types'

useHead({ title: '为你推荐 · SHUAQI 耍起' })

interface Result {
  event: { id: string; title: string; category: string; starts_at: string; ends_at: string | null; location_text: string; status: 'published'; capacity: number | null }
  score: number
  reasons: string[]
}
interface Response {
  request_id: string
  algorithm_version: string
  parsed: { keywords: string[]; categories: string[]; exclude: string[]; timeLabel: string | null; place: string | null; maxDistanceKm: number | null }
  results: Result[]
  diagnostics: { llm: 'off' | 'used' | 'failed' | 'over_quota'; semantic: boolean; dropped: string[] }
}

const ERRORS: Record<string, string> = {
  rate_limited: '搜索太频繁了，请稍等一分钟再试',
  not_authenticated: '请先登录',
  invalid_request: '搜索内容最多 200 字',
}
const PLACE_LABEL: Record<string, string> = { imperial: '帝国理工', ucl: 'UCL', lse: 'LSE', oxford: '牛津', cambridge: '剑桥', campus: '学校' }

const supabase = useSupabaseClient<Database>()
const route = useRoute()
const q = ref(typeof route.query.q === 'string' ? route.query.q : '')
const category = ref<string>('')
const location = ref<{ lat: number; lng: number } | null>(null)
const locating = ref(false)
const loading = ref(false)
const error = ref<string | null>(null)
const off = ref(false)
const data = ref<Response | null>(null)

async function search() {
  loading.value = true
  error.value = null
  try {
    data.value = await $fetch<Response>('/api/recommendations', {
      method: 'POST',
      body: { query: q.value.trim(), category: category.value || undefined, location: location.value ?? undefined },
    })
  } catch (e) {
    const code = (e as { data?: { data?: { error?: string } } }).data?.data?.error ?? ''
    if (code === 'feature_disabled') off.value = true
    else error.value = ERRORS[code] ?? '推荐暂时不可用，请稍后再试'
  } finally {
    loading.value = false
  }
}
onMounted(search)

async function useMyLocation() {
  locating.value = true
  try {
    const p = await getPosition(10000)
    location.value = { lat: p.lat, lng: p.lng }
    await search()
  } catch (e) {
    error.value = (e as Error).message
  } finally {
    locating.value = false
  }
}

function pickCategory(c: string) {
  category.value = category.value === c ? '' : c
  search()
}

// Interaction events feed the next recommendations; failures never block the user.
function record(eventId: string, kind: 'click' | 'dismiss', position: number) {
  if (!data.value) return Promise.resolve()
  return supabase.from('recommendation_events').insert({
    event_id: eventId, kind, position, request_id: data.value.request_id, algorithm_version: data.value.algorithm_version,
  }).then(() => undefined, () => undefined)
}

async function dismiss(r: Result, i: number) {
  if (!data.value) return
  data.value.results = data.value.results.filter((x) => x !== r)
  await record(r.event.id, 'dismiss', i)
}

const understood = computed(() => {
  const p = data.value?.parsed
  if (!p || !q.value.trim()) return []
  return [
    p.timeLabel,
    ...p.categories,
    p.place ? `${PLACE_LABEL[p.place] ?? p.place}附近` : null,
    p.maxDistanceKm ? `${p.maxDistanceKm} 公里内` : null,
    ...p.exclude.map((x) => `不要 ${x}`),
  ].filter(Boolean) as string[]
})
</script>

<template>
  <div class="px-4 pt-4">
    <header class="mb-3 flex items-center gap-2">
      <NuxtLink to="/" class="text-stone-500" aria-label="返回">←</NuxtLink>
      <h1 class="text-xl font-bold">✨ 为你推荐</h1>
    </header>

    <FeatureOff v-if="off" />

    <template v-else>
      <form class="flex gap-2" @submit.prevent="search">
        <input v-model="q" type="search" class="input flex-1" maxlength="200" aria-label="说说你想做什么"
               placeholder="说说你想做什么，比如：这周末在学校附近打羽毛球">
        <button class="btn-primary !px-4" :disabled="loading">{{ loading ? '…' : '找' }}</button>
      </form>

      <div class="-mx-4 mt-2 flex gap-2 overflow-x-auto px-4 pb-1 [scrollbar-width:none]">
        <button type="button" class="chip shrink-0" :disabled="locating" @click="useMyLocation">
          📍 {{ location ? '已用我的位置' : locating ? '定位中…' : '用我的位置' }}
        </button>
        <button v-for="c in EVENT_CATEGORIES" :key="c" type="button" class="chip shrink-0"
                :class="category === c ? '!bg-brand-500 !text-white' : ''" @click="pickCategory(c)">{{ c }}</button>
      </div>

      <p v-if="understood.length" class="mt-2 text-xs text-stone-500">
        已理解：{{ understood.join(' · ') }}
      </p>
      <p v-if="data?.diagnostics.llm === 'failed' || data?.diagnostics.llm === 'over_quota'" class="mt-1 text-xs text-amber-700">
        AI 理解暂时不可用，已按关键词为你查找
      </p>

      <p v-if="error" class="card mt-3 text-sm text-red-700">{{ error }}</p>

      <div v-if="loading && !data" class="mt-3 space-y-3">
        <div v-for="i in 4" :key="i" class="card h-28 animate-pulse bg-stone-100" />
      </div>

      <div v-else-if="data && !data.results.length" class="py-16 text-center text-sm text-stone-500">
        <p class="mb-1 text-3xl" aria-hidden="true">🔍</p>
        <p>没有找到合适的活动，换个说法试试</p>
        <NuxtLink to="/create" class="btn-primary mt-4">自己发起一个</NuxtLink>
      </div>

      <ul v-else-if="data" class="mt-3 space-y-3" :class="loading ? 'opacity-60' : ''">
        <li v-for="(r, i) in data.results" :key="r.event.id" class="space-y-1">
          <div @click.capture="record(r.event.id, 'click', i)">
            <EventCard :event="r.event" />
          </div>
          <div class="flex items-start justify-between gap-2 px-1">
            <p class="text-xs text-stone-500">{{ r.reasons.join(' · ') }}</p>
            <button type="button" class="shrink-0 text-xs text-stone-400 underline" @click="dismiss(r, i)">不感兴趣</button>
          </div>
        </li>
      </ul>
    </template>
  </div>
</template>
