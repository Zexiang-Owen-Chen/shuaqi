<script setup lang="ts">
const supabase = useSupabaseClient()
const user = useSupabaseUser()
const rpc = useRpc()
const { data, pending, error, refresh } = await useAsyncData('history', () => rpc('my_participation_history'))

const typeLabel: Record<string, string> = {
  self_reported_presence: '扫码签到',
  organiser_confirmed_attendance: '主办方核验到场',
  mutually_reported_interaction: '双方确认的见面',
}
const statusLabel: Record<string, { text: string; cls: string }> = {
  verified: { text: '已核验', cls: 'bg-emerald-50 text-emerald-700' },
  geo_verified: { text: '定位核验', cls: 'bg-sky-50 text-sky-700' },
  unverified: { text: '未核验', cls: 'bg-stone-100 text-stone-600' },
  disputed: { text: '核查中', cls: 'bg-amber-50 text-amber-700' },
  revoked: { text: '已撤销', cls: 'bg-red-50 text-red-700' },
}
const correcting = ref<string | null>(null)
const reason = ref('')
const msg = ref('')

async function submitCorrection() {
  if (!reason.value.trim()) return
  const { error: e } = await supabase.from('evidence_corrections').insert({
    evidence_id: correcting.value!, requested_by: user.value!.sub ?? user.value!.id, reason: reason.value.trim(),
  })
  msg.value = e ? messageFor(e) : '更正申请已提交，管理员处理后会更新记录'
  correcting.value = null; reason.value = ''
  refresh()
}
</script>

<template>
  <main class="space-y-3 px-4 py-6">
    <h1 class="text-xl font-semibold">参与记录</h1>
    <p class="text-xs text-stone-400">每条记录都标明了来源和核验状态。如果记录有误，可以申请更正。</p>
    <p v-if="msg" class="rounded-xl bg-stone-100 p-3 text-sm">{{ msg }}</p>
    <p v-if="pending" class="text-sm text-stone-500">加载中…</p>
    <p v-else-if="error" class="text-sm text-red-700">加载失败，<button class="underline" @click="refresh()">重试</button></p>
    <p v-else-if="!data?.length" class="text-sm text-stone-400">还没有记录。参加活动并在现场扫码签到后会出现在这里。</p>
    <div v-for="h in data" :key="h.evidence_id" class="card">
      <div class="flex items-start justify-between gap-2">
        <div>
          <p class="font-medium">{{ h.event_title ?? '找搭子计划' }}</p>
          <p class="text-xs text-stone-500">{{ typeLabel[h.type] }} · {{ new Date(h.occurred_at).toLocaleString('zh-CN', { timeZone: 'Europe/London' }) }}</p>
        </div>
        <span class="chip" :class="statusLabel[h.verification_status]?.cls">{{ statusLabel[h.verification_status]?.text }}</span>
      </div>
      <p v-if="h.correction_status === 'pending'" class="mt-2 text-xs text-amber-700">更正申请处理中</p>
      <button v-else-if="correcting !== h.evidence_id" class="mt-2 text-xs text-stone-500 underline" @click="correcting = h.evidence_id">申请更正</button>
      <form v-else class="mt-2 space-y-2" @submit.prevent="submitCorrection">
        <textarea v-model="reason" class="input min-h-16" maxlength="1000" placeholder="请说明哪里不对" />
        <div class="flex gap-2">
          <button type="button" class="btn-secondary flex-1 py-2" @click="correcting = null">取消</button>
          <button class="btn-primary flex-1 py-2">提交</button>
        </div>
      </form>
    </div>
  </main>
</template>
