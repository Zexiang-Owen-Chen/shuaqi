<script setup lang="ts">
const rpc = useRpc()
const { data, pending, error, refresh } = await useAsyncData('connections', () => rpc('list_my_connections'))
const list = computed(() => (data.value ?? []).filter(c => c.card))
const msg = ref('')
const { isOn } = useFeatureFlags()

async function remove(id: string, block: boolean) {
  if (!confirm(block ? '拉黑后对方将无法再看到你或向你发送请求，确定吗？' : '确定删除这位好友吗？')) return
  try {
    await rpc(block ? 'block_user' : 'remove_connection', block ? { p_target: id } : { p_other: id } as never)
    msg.value = block ? '已拉黑' : '已删除'
    await refresh()
  } catch (e) { msg.value = (e as Error).message }
}
</script>

<template>
  <main class="space-y-3 px-4 py-6">
    <div class="flex items-center justify-between gap-2">
      <h1 class="text-xl font-semibold">我的好友</h1>
      <NuxtLink v-if="isOn('nearby')" to="/nearby" class="btn-primary px-3 py-1.5 text-sm">＋ 加附近的人</NuxtLink>
    </div>
    <p class="text-xs text-stone-400">成为好友只代表双方同意认识，不代表已经线下见过面。</p>
    <p v-if="msg" class="rounded-xl bg-stone-100 p-3 text-sm">{{ msg }}</p>
    <p v-if="pending" class="text-sm text-stone-500">加载中…</p>
    <p v-else-if="error" class="text-sm text-red-700">加载失败，<button class="underline" @click="refresh()">重试</button></p>
    <p v-else-if="!list.length" class="text-sm text-stone-400">还没有好友。去活动里认识新朋友吧。</p>
    <div v-for="c in list" :key="(c.card as any).id" class="card">
      <ProfilePersonCard :card="c.card as any">
        <div class="mt-2 flex items-center gap-3 text-xs">
          <NuxtLink v-if="isOn('chat')" :to="`/messages/${(c.card as any).id}`" class="btn-primary px-3 py-1 text-xs">发消息</NuxtLink>
          <button class="text-stone-500 underline" @click="remove((c.card as any).id, false)">删除好友</button>
          <button class="text-red-600 underline" @click="remove((c.card as any).id, true)">拉黑</button>
        </div>
      </ProfilePersonCard>
    </div>
  </main>
</template>
