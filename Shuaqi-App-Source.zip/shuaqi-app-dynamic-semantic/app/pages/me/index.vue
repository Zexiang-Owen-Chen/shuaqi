<script setup lang="ts">
const supabase = useSupabaseClient()
const rpc = useRpc()
const { isOn } = useFeatureFlags()
const { profile, refresh } = useProfile()
const { available: pushAvailable, disable: disablePush } = usePush()
await refresh()

const { data: orgs } = await useAsyncData('my-orgs', () => rpc('my_organisations'))
const { data: requests } = await useAsyncData('my-requests-count', () => rpc('list_my_requests'))
const { unread, refresh: refreshUnread } = useChatUnread()
onMounted(() => refreshUnread(true))
const incoming = computed(() => (requests.value ?? []).filter(r => r.direction === 'incoming').length)
const age = computed(() => profile.value?.birth_year ? new Date().getFullYear() - profile.value.birth_year : null)

async function logout() {
  // The next person to sign in on this device should not get this account's notifications.
  await disablePush().catch(() => {})
  await supabase.auth.signOut()
  profile.value = null
  navigateTo('/login')
}
</script>

<template>
  <main v-if="profile" class="space-y-4 px-4 py-6">
    <section class="card flex items-center gap-4">
      <ProfileAvatar :url="profile.avatar_url" :name="profile.display_name" :size="64" />
      <div class="min-w-0 flex-1">
        <h1 class="truncate text-lg font-semibold">{{ profile.display_name }}</h1>
        <p class="text-xs text-stone-500">
          {{ [genderLabel(profile.gender), age ? age + ' 岁' : '', profile.region].filter(Boolean).join(' · ') }}
        </p>
        <div class="mt-1"><ProfileSchoolBadge :domain="profile.school_domain" :verified="!!profile.school_verified_at" /></div>
      </div>
      <NuxtLink to="/me/edit" class="btn-secondary px-3 py-1.5">编辑</NuxtLink>
    </section>

    <PushOptIn install-hint />

    <ProfileTrustCard :user-id="profile.id" />

    <nav class="card divide-y divide-stone-100 p-0">
      <NuxtLink v-if="isOn('chat')" to="/messages" class="flex items-center justify-between px-4 py-3 text-sm">
        消息 <span v-if="unread" class="chip bg-red-500 text-white">{{ unreadLabel(unread) }}</span>
      </NuxtLink>
      <NuxtLink to="/me/requests" class="flex items-center justify-between px-4 py-3 text-sm">
        好友请求 <span v-if="incoming" class="chip bg-brand-500 text-white">{{ incoming }}</span>
      </NuxtLink>
      <NuxtLink to="/me/connections" class="block px-4 py-3 text-sm">我的好友</NuxtLink>
      <NuxtLink v-if="isOn('nearby')" to="/nearby" class="block px-4 py-3 text-sm">加好友（附近 50 米的人）</NuxtLink>
      <NuxtLink to="/me/history" class="block px-4 py-3 text-sm">参与记录与更正</NuxtLink>
      <NuxtLink to="/buddy" class="block px-4 py-3 text-sm">{{ isOn('intents') ? '我的找搭子需求与计划' : '我的搭子计划' }}</NuxtLink>
      <NuxtLink v-if="orgs?.length" to="/organiser" class="block px-4 py-3 text-sm">组织者后台</NuxtLink>
      <NuxtLink v-if="profile.role === 'admin'" to="/admin" class="block px-4 py-3 text-sm">管理后台</NuxtLink>
      <NuxtLink v-if="pushAvailable" to="/me/notifications" class="block px-4 py-3 text-sm">通知设置</NuxtLink>
      <NuxtLink to="/install" class="block px-4 py-3 text-sm">添加到主屏幕</NuxtLink>
    </nav>

    <button class="btn-secondary w-full" @click="logout">退出登录</button>
  </main>
</template>
