<script setup lang="ts">
const supabase = useSupabaseClient()
const { profile, refresh } = useProfile()
await refresh()

const { data: photos, refresh: refreshPhotos } = await useAsyncData('my-photos', async () => {
  const { data } = await supabase.from('profile_photos').select('*').order('sort')
  return data ?? []
})
const uploading = ref(false)
const error = ref('')

async function addPhoto(e: Event) {
  const file = (e.target as HTMLInputElement).files?.[0]
  if (!file || !profile.value) return
  if ((photos.value?.length ?? 0) >= 6) { error.value = '最多 6 张照片'; return }
  if (file.size > 5 * 1024 * 1024) { error.value = '图片不能超过 5MB'; return }
  uploading.value = true
  const path = `${profile.value.id}/${crypto.randomUUID()}`
  const { error: up } = await supabase.storage.from('photos').upload(path, file, { contentType: file.type })
  if (!up) await supabase.from('profile_photos').insert({ user_id: profile.value.id, storage_path: path, sort: photos.value?.length ?? 0 })
  uploading.value = false
  if (up) { error.value = '上传失败：' + up.message; return }
  refreshPhotos()
}

async function removePhoto(id: string, path: string) {
  await supabase.from('profile_photos').delete().eq('id', id)
  await supabase.storage.from('photos').remove([path])
  refreshPhotos()
}

async function saved() { await refresh(); navigateTo('/me') }
</script>

<template>
  <main v-if="profile" class="space-y-6 px-4 py-6">
    <h1 class="text-xl font-semibold">编辑资料</h1>

    <section class="card">
      <h2 class="text-sm font-semibold">照片</h2>
      <div class="mt-3 grid grid-cols-3 gap-2">
        <div v-for="p in photos" :key="p.id" class="relative aspect-square overflow-hidden rounded-xl bg-stone-100">
          <img :src="publicUrl('photos', p.storage_path)" alt="" class="h-full w-full object-cover">
          <button class="absolute right-1 top-1 rounded-full bg-black/60 px-2 text-xs text-white" @click="removePhoto(p.id, p.storage_path)">删除</button>
        </div>
        <label v-if="(photos?.length ?? 0) < 6" class="flex aspect-square cursor-pointer items-center justify-center rounded-xl border-2 border-dashed border-stone-200 text-sm text-stone-500">
          {{ uploading ? '上传中…' : '+ 添加' }}
          <input type="file" accept="image/jpeg,image/png,image/webp" class="hidden" @change="addPhoto">
        </label>
      </div>
      <p v-if="error" class="mt-2 text-sm text-red-700">{{ error }}</p>
    </section>

    <ProfileForm :profile="profile" show-visibility @saved="saved" />
  </main>
</template>
