<script setup lang="ts">
import { NOTIFICATION_CATEGORIES, type NotificationCategory, type NotificationPrefs } from '~/composables/usePush'

useHead({ title: '通知设置 · SHUAQI' })

const rpc = useRpc()
const { platform, guide } = useInstallPrompt()
const { support, configured, available, permission, subscribed, checked, refresh, enable, disable } = usePush()

const mounted = ref(false)
onMounted(async () => {
  mounted.value = true
  await refresh()
})

const { data: prefs, error: prefsError } = await useAsyncData('notification-prefs',
  async () => (await rpc('my_notification_preferences')) as unknown as NotificationPrefs | null)

const busy = ref(false)
const msg = ref<string | null>(null)
const err = ref<string | null>(null)

async function run(fn: () => Promise<void>) {
  busy.value = true
  msg.value = null
  err.value = null
  try { await fn() }
  catch (e) { err.value = messageFor(e) }
  finally { busy.value = false }
}

// No await before enable(): iOS only shows the prompt straight from a tap.
function onEnable() {
  return run(async () => {
    const result = await enable()
    if (result === 'granted') msg.value = '这台设备已开启通知。'
  })
}
const onDisable = () => run(async () => { await disable(); msg.value = '这台设备不会再收到通知。' })
const onTest = () => run(async () => {
  await rpc('send_test_push')
  msg.value = '测试通知已发出，几秒内会收到。'
})

const saving = ref<NotificationCategory | null>(null)
async function toggle(key: NotificationCategory, on: boolean) {
  if (!prefs.value) return
  saving.value = key
  err.value = null
  const before = prefs.value[key]
  prefs.value = { ...prefs.value, [key]: on }
  try { prefs.value = (await rpc('set_notification_preference', { p_category: key, p_enabled: on })) as unknown as NotificationPrefs }
  catch (e) {
    prefs.value = { ...prefs.value, [key]: before }
    err.value = messageFor(e)
  }
  finally { saving.value = null }
}

// How to turn notifications back on after "Block", per platform.
const deniedHelp = computed(() => {
  const os = platform.value?.os
  if (os === 'ios') {
    return '打开 iPhone「设置 → 通知 → SHUAQI」，允许通知，然后回到这里刷新。'
  }
  if (os === 'android') {
    return '点地址栏左侧的图标 →「权限」或「网站设置」→ 通知 → 允许，然后刷新本页。已安装到桌面的，在系统「设置 → 应用 → SHUAQI → 通知」里打开。'
  }
  return '点地址栏左侧的图标，把「通知」改成允许，然后刷新本页。'
})
</script>

<template>
  <main class="space-y-4 px-4 py-6">
    <h1 class="text-xl font-semibold">通知设置</h1>

    <FeatureOff v-if="mounted && !available" title="通知暂时关闭了" :text="configured ? '现在不会发送任何通知，消息和请求仍然可以在 App 里查看。' : '通知功能还没配置好，消息和请求仍然可以在 App 里查看。'" back-to="/me" back-label="返回我的" />

    <template v-else>
      <!-- This device -->
      <section class="card space-y-3" data-testid="push-device">
        <h2 class="font-medium text-stone-900">这台设备</h2>
        <div v-if="!mounted || !checked" class="h-10 animate-pulse rounded bg-stone-100" aria-busy="true" />

        <template v-else-if="support === 'in-app'">
          <p class="text-sm text-stone-700">在微信或其他 App 里打开时收不到通知。请用手机浏览器打开 SHUAQI，再开启通知。</p>
          <NuxtLink to="/install" class="btn-secondary block text-center">怎么在浏览器打开</NuxtLink>
        </template>

        <template v-else-if="support === 'needs-install'">
          <p class="text-sm text-stone-700">iPhone 需要先把 SHUAQI 添加到主屏幕，再从桌面图标打开，才能收到通知（需要 iOS 16.4 或更新）。</p>
          <InstallSteps :guide="guide('ios')" class="!p-0 !shadow-none !ring-0" />
        </template>

        <p v-else-if="support === 'ios-too-old'" class="text-sm text-stone-700">
          这台 iPhone 的系统版本太旧，收不到网页通知。升级到 iOS 16.4 或更新后就可以开启。
        </p>

        <p v-else-if="support === 'unsupported'" class="text-sm text-stone-700">
          这个浏览器不支持通知。可以换用 Chrome、Edge、Safari 或 Firefox。
        </p>

        <template v-else-if="permission === 'denied'">
          <p class="text-sm text-stone-700">你之前拒绝了通知，网页没法再次询问。</p>
          <p class="text-xs leading-relaxed text-stone-500">{{ deniedHelp }}</p>
        </template>

        <template v-else-if="subscribed">
          <p class="flex items-center gap-2 text-sm text-stone-700"><span class="size-2 rounded-full bg-green-500" />已开启</p>
          <div class="flex gap-2">
            <button type="button" class="btn-secondary flex-1" :disabled="busy" @click="onTest">发一条测试通知</button>
            <button type="button" class="btn-secondary" :disabled="busy" @click="onDisable">关闭</button>
          </div>
        </template>

        <template v-else>
          <p class="text-sm text-stone-700">开启后，SHUAQI 没打开时也能收到通知。</p>
          <button type="button" class="btn-primary w-full" :disabled="busy" data-testid="push-enable" @click="onEnable">开启通知</button>
        </template>

        <p v-if="msg" class="text-sm text-green-700" role="status">{{ msg }}</p>
        <p v-if="err" class="text-sm text-red-700" role="alert">{{ err }}</p>
      </section>

      <!-- What to be notified about (all devices) -->
      <section class="card p-0" data-testid="push-categories">
        <h2 class="px-4 pt-4 font-medium text-stone-900">通知哪些事</h2>
        <p class="px-4 text-xs text-stone-500">对你所有开启了通知的设备生效。</p>
        <p v-if="prefsError" class="px-4 py-3 text-sm text-red-700">加载失败，请刷新重试。</p>
        <ul v-else-if="prefs" class="mt-2 divide-y divide-stone-100">
          <li v-for="c in NOTIFICATION_CATEGORIES" :key="c.key">
            <label class="flex items-center gap-3 px-4 py-3">
              <span class="flex-1">
                <span class="block text-sm text-stone-900">{{ c.label }}</span>
                <span class="block text-xs text-stone-500">{{ c.hint }}</span>
              </span>
              <input type="checkbox" class="size-5 accent-brand-600" :checked="prefs[c.key]"
                     :disabled="saving === c.key" @change="toggle(c.key, ($event.target as HTMLInputElement).checked)">
            </label>
          </li>
        </ul>
      </section>

      <p class="text-xs leading-relaxed text-stone-400">
        消息通知会显示好友的名字和消息开头。通知经浏览器厂商（Google、Apple、Mozilla）的推送服务加密送达，它们看不到内容。
      </p>
    </template>
  </main>
</template>
