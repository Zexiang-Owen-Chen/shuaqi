<script setup lang="ts">
const rpc = useRpc()
const { data, pending, error, refresh } = await useAsyncData('requests', () => rpc('list_my_requests'))
const incoming = computed(() => (data.value ?? []).filter(r => r.direction === 'incoming'))
const outgoing = computed(() => (data.value ?? []).filter(r => r.direction === 'outgoing'))
const busy = ref<string | null>(null)
const msg = ref('')
const contextLabel: Record<string, string> = { event: '来自同一活动', nearby: '来自附近 50m', intent: '来自找搭子计划', profile: '' }

async function act(fn: () => Promise<unknown>, id: string, done: string) {
  busy.value = id; msg.value = ''
  try { await fn(); msg.value = done; await refresh() } catch (e) { msg.value = (e as Error).message }
  busy.value = null
}
</script>

<template>
  <main class="space-y-4 px-4 py-6">
    <h1 class="text-xl font-semibold">好友请求</h1>
    <p v-if="msg" class="rounded-xl bg-stone-100 p-3 text-sm">{{ msg }}</p>
    <p v-if="pending" class="text-sm text-stone-500">加载中…</p>
    <p v-else-if="error" class="text-sm text-red-700">加载失败，<button class="underline" @click="refresh()">重试</button></p>
    <template v-else>
      <section>
        <h2 class="mb-2 text-sm font-semibold text-stone-500">收到的（{{ incoming.length }}）</h2>
        <p v-if="!incoming.length" class="text-sm text-stone-400">暂时没有新的请求</p>
        <div v-for="r in incoming" :key="r.id" class="card mb-2">
          <ProfilePersonCard :card="r.card as any" compact>
            <p class="mt-1 text-xs text-stone-400">{{ contextLabel[r.context] }}</p>
            <p v-if="r.message" class="mt-1 text-sm">“{{ r.message }}”</p>
            <div class="mt-2 flex gap-2">
              <button class="btn-primary flex-1 py-2" :disabled="busy === r.id" @click="act(() => rpc('respond_connection_request', { p_request: r.id, p_accept: true }), r.id, '已成为好友')">接受</button>
              <button class="btn-secondary flex-1 py-2" :disabled="busy === r.id" @click="act(() => rpc('respond_connection_request', { p_request: r.id, p_accept: false }), r.id, '已拒绝')">拒绝</button>
              <button class="btn-danger py-2" :disabled="busy === r.id" @click="act(() => rpc('block_user', { p_target: (r.card as any).id }), r.id, '已拉黑')">拉黑</button>
            </div>
          </ProfilePersonCard>
        </div>
      </section>
      <section>
        <h2 class="mb-2 text-sm font-semibold text-stone-500">发出的（{{ outgoing.length }}）</h2>
        <p v-if="!outgoing.length" class="text-sm text-stone-400">没有等待中的请求</p>
        <div v-for="r in outgoing" :key="r.id" class="card mb-2">
          <ProfilePersonCard :card="r.card as any" compact>
            <p class="mt-1 text-xs text-stone-400">等待对方回应 · {{ contextLabel[r.context] }}</p>
            <button class="btn-secondary mt-2 py-1.5" :disabled="busy === r.id" @click="act(() => rpc('withdraw_connection_request', { p_request: r.id }), r.id, '已撤回')">撤回</button>
          </ProfilePersonCard>
        </div>
      </section>
    </template>
  </main>
</template>
