<script setup lang="ts">
import type { CheckinEvent, CheckinMessage, CheckinResult } from '~/composables/useCheckin'

definePageMeta({ layout: 'bare' })
useHead({ title: '扫码签到 · SHUAQI' })

const route = useRoute()
const code = computed(() => String(route.params.code ?? ''))
const { userId, lookup, myState, checkin } = useCheckin()
// qr_checkin switched off: don't ask for location, send people to the staff at the entrance.
const { isOn } = useFeatureFlags()
const selfCheckinOn = computed(() => isOn('qr_checkin'))

type Phase = 'idle' | 'locating' | 'submitting' | 'done'

const event = ref<CheckinEvent | null>(null)
const loadError = ref('')
const loading = ref(true)
const going = ref(false)
const checkedIn = ref(false)
const phase = ref<Phase>('idle')
const result = ref<CheckinResult | null>(null)
const message = ref<CheckinMessage | null>(null)
const locationError = ref('')
const permissionDenied = ref(false)
const inWeChat = ref(false)

const loginLink = computed(() => `/login?redirect=${encodeURIComponent(route.fullPath)}`)
const success = computed(() => checkedIn.value || !!result.value?.ok)

async function load() {
  loading.value = true
  loadError.value = ''
  try {
    event.value = await lookup(code.value)
    if (event.value && userId.value) {
      const s = await myState(event.value.event_id)
      going.value = s.going
      checkedIn.value = s.checkedIn
    }
  } catch (e) {
    loadError.value = (e as Error).message
  } finally {
    loading.value = false
  }
}

async function start() {
  if (!event.value || phase.value === 'locating' || phase.value === 'submitting') return
  phase.value = 'locating'
  result.value = null
  message.value = null
  locationError.value = ''
  permissionDenied.value = false
  try {
    const r = await checkin(code.value, () => { phase.value = 'submitting' })
    result.value = r
    message.value = describeCheckin(r, event.value.checkin_radius_m)
    if (r.ok) checkedIn.value = true
  } catch (e) {
    locationError.value = (e as Error).message
    permissionDenied.value = await geolocationDenied()
  } finally {
    phase.value = 'done'
  }
}

async function geolocationDenied(): Promise<boolean> {
  try {
    const p = await navigator.permissions?.query({ name: 'geolocation' as PermissionName })
    return p?.state === 'denied'
  } catch {
    return /拒绝/.test(locationError.value)
  }
}

onMounted(() => {
  inWeChat.value = isWeChat(navigator.userAgent)
})

// Re-check after sign-in completes in another tab or the session restores.
watch(userId, () => load())
await load()

// Opened from the in-app scanner (/scan): the scanner already explained the location use,
// so go straight to locating instead of asking for another tap.
onMounted(async () => {
  if (route.query.auto !== '1') return
  navigateTo({ path: route.path }, { replace: true })
  if (!event.value || !userId.value || !going.value || !selfCheckinOn.value || success.value) return
  // Only skip the tap when location is already allowed: iOS may not show the permission prompt for a
  // request that no tap started, which leaves the page stuck on "正在定位".
  if (await geolocationGranted()) start()
})

async function geolocationGranted(): Promise<boolean> {
  try {
    return (await navigator.permissions?.query({ name: 'geolocation' as PermissionName }))?.state === 'granted'
  } catch {
    return false
  }
}
</script>

<template>
  <main class="flex min-h-dvh flex-col gap-4 px-4 py-6">
    <header class="flex items-center justify-between">
      <NuxtLink to="/" class="text-sm font-semibold text-brand-600">SHUAQI 耍起</NuxtLink>
      <span class="text-xs text-stone-400">活动签到</span>
    </header>

    <div v-if="inWeChat" class="rounded-xl bg-amber-50 p-3 text-sm text-amber-800">
      微信内无法使用定位签到。请点右上角“···”，选择“在浏览器打开”。
    </div>

    <div v-if="loading" class="card animate-pulse space-y-3" aria-busy="true">
      <div class="h-5 w-2/3 rounded bg-stone-100" />
      <div class="h-4 w-1/2 rounded bg-stone-100" />
      <div class="h-4 w-1/3 rounded bg-stone-100" />
    </div>

    <div v-else-if="loadError" class="card space-y-3 text-center">
      <p class="text-stone-700">{{ loadError }}</p>
      <button class="btn-secondary w-full" @click="load">重新加载</button>
    </div>

    <div v-else-if="!event" class="card space-y-3 text-center">
      <p class="text-4xl" aria-hidden="true">🔍</p>
      <h1 class="text-lg font-semibold">签到码无效</h1>
      <p class="text-sm text-stone-500">这个二维码已被主办方重置，或活动未发布。请扫描现场最新的二维码。</p>
      <NuxtLink to="/" class="btn-secondary w-full">去首页看看活动</NuxtLink>
    </div>

    <template v-else>
      <CheckinEventCard :event="event" />

      <!-- Signed out -->
      <div v-if="!userId" class="card space-y-3">
        <p class="text-sm text-stone-600">登录后即可签到。用学校邮箱登录，收到验证码后会回到这个页面。</p>
        <NuxtLink :to="loginLink" class="btn-primary w-full">登录后签到</NuxtLink>
      </div>

      <!-- Done -->
      <div v-else-if="success" class="card space-y-4 text-center">
        <div class="mx-auto flex size-16 items-center justify-center rounded-full bg-green-50 text-3xl text-green-600" aria-hidden="true">✓</div>
        <div>
          <h1 class="text-lg font-semibold">{{ message?.title ?? '你已经签到过了' }}</h1>
          <p class="mt-1 text-sm text-green-700">{{ message?.detail ?? '已到场（定位核验）' }}</p>
          <p v-if="result?.distance_m != null && !result.already" class="mt-1 text-xs text-stone-400">
            距离活动地点约 {{ formatDistance(result.distance_m) }}
          </p>
        </div>
        <div class="grid gap-2">
          <NuxtLink v-if="isOn('nearby')" :to="`/events/${event.event_id}/nearby`" class="btn-primary">看看附近 50 米的人</NuxtLink>
          <NuxtLink v-if="isOn('event_discovery')" :to="`/events/${event.event_id}/people`" class="btn-secondary">查看活动参与者</NuxtLink>
          <NuxtLink :to="`/events/${event.event_id}`" class="text-sm text-stone-500 underline-offset-2 hover:underline">返回活动页</NuxtLink>
        </div>
      </div>

      <!-- Not registered -->
      <div v-else-if="!going" class="card space-y-3">
        <h1 class="font-semibold">你还没有报名这个活动</h1>
        <p class="text-sm text-stone-500">报名后回到这个页面即可签到。</p>
        <NuxtLink :to="`/events/${event.event_id}`" class="btn-primary w-full">去报名</NuxtLink>
      </div>

      <!-- Self check-in switched off -->
      <div v-else-if="!selfCheckinOn" class="card space-y-3">
        <h1 class="font-semibold">扫码签到暂时关闭了</h1>
        <p class="text-sm text-stone-500">请到入口找工作人员确认到场，确认后同样会记入你的参与记录。</p>
        <NuxtLink :to="`/events/${event.event_id}`" class="btn-secondary w-full">返回活动页</NuxtLink>
      </div>

      <!-- Ready / failed -->
      <div v-else class="card space-y-4">
        <template v-if="phase === 'idle'">
          <h1 class="font-semibold">到达现场后点下面的按钮签到</h1>
          <p class="text-sm text-stone-500">
            签到会读取一次你的位置，只用来确认你在活动现场（{{ event.checkin_radius_m }} 米内）。我们只保存你与活动地点的距离，不保存具体位置。
          </p>
        </template>

        <div v-else-if="phase === 'locating' || phase === 'submitting'" class="flex items-center gap-3 py-2" role="status">
          <span class="size-5 animate-spin rounded-full border-2 border-brand-500 border-t-transparent" aria-hidden="true" />
          <span class="text-sm text-stone-700">{{ phase === 'locating' ? '正在定位，请稍候…' : '正在签到…' }}</span>
        </div>

        <CheckinFailure
          v-else-if="message && !result?.ok"
          :message="message"
        />

        <div v-else-if="locationError" class="space-y-2" role="alert">
          <h2 class="font-semibold text-red-700">{{ locationError }}</h2>
          <CheckinPermissionHelp v-if="permissionDenied" />
          <p v-else class="text-sm text-stone-500">请确认手机已开启定位服务，然后重试。仍无法签到时，请找现场工作人员手动确认。</p>
        </div>

        <button
          v-if="phase === 'idle' || (phase === 'done' && (locationError || message?.retry))"
          class="btn-primary w-full py-3 text-base"
          @click="start"
        >
          {{ phase === 'idle' ? '定位并签到' : '重新定位签到' }}
        </button>
        <NuxtLink
          v-else-if="phase === 'done' && result?.reason === 'not_registered'"
          :to="`/events/${event.event_id}`"
          class="btn-primary w-full"
        >去报名</NuxtLink>
      </div>
    </template>
  </main>
</template>
