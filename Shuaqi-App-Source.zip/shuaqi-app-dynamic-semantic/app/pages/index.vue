<script setup lang="ts">
import type { Database } from '~/types/database.types'

useHead({ title: '发现活动 · SHUAQI 耍起' })

const supabase = useSupabaseClient<Database>()
const user = useSupabaseUser()
// Not in FLAG_KEYS on purpose (keeps this flag local to the recommender); same rule as flagOn().
const { flags, isOn } = useFeatureFlags()
const recommendationsOn = computed(() => !flags.value || flags.value.recommendations === true)

const q = ref('')
const category = ref<string>('')

const { data: events, status, error, refresh } = await useAsyncData('discover-events', async () => {
  const now = new Date()
  const sixHoursAgo = new Date(now.getTime() - 6 * 3600e3).toISOString()
  const { data, error: err } = await supabase
    .from('events')
    .select('id, title, category, starts_at, ends_at, location_text, status, capacity, image_paths')
    .eq('status', 'published')
    // Upcoming or ongoing: ends in the future, or (no end time) started within the last 6 hours.
    .or(`ends_at.gte.${now.toISOString()},and(ends_at.is.null,starts_at.gte.${sixHoursAgo})`)
    .order('starts_at', { ascending: true })
    .limit(200)
  if (err) throw new Error(messageFor(err))
  return data ?? []
}, { default: () => [] })

const filtered = computed(() => {
  const term = q.value.trim().toLowerCase()
  return (events.value ?? []).filter((e) =>
    e.status === 'published' && (!category.value || e.category === category.value)
    && (!term || e.title.toLowerCase().includes(term) || e.location_text.toLowerCase().includes(term)
      || e.category.toLowerCase().includes(term)))
})
</script>

<template>
  <div class="px-4 pt-4">
    <header class="mb-3 flex items-center justify-between">
      <h1 class="text-xl font-bold"><span class="text-brand-500">SHUAQI</span> 耍起</h1>
      <div class="flex gap-2">
        <NuxtLink v-if="recommendationsOn" to="/recommend" class="btn-secondary !px-3 !py-2">✨ 为你推荐</NuxtLink>
        <NuxtLink v-if="user && isOn('qr_checkin')" to="/scan" class="btn-secondary !px-3 !py-2" aria-label="扫码签到" title="扫码签到">📷</NuxtLink>
        <NuxtLink to="/create" class="btn-primary !px-3 !py-2">➕ 发布活动</NuxtLink>
      </div>
    </header>

    <NuxtLink v-if="!user" to="/login?redirect=/"
              class="mb-3 flex items-center justify-between rounded-2xl bg-brand-50 p-3 text-sm text-brand-700 ring-1 ring-brand-100">
      <span>用学校邮箱登录，报名活动、认识同学</span>
      <span class="font-medium">去登录 →</span>
    </NuxtLink>

    <div class="sticky top-0 z-10 -mx-4 bg-[#fafaf9]/95 px-4 pb-2 pt-1 backdrop-blur">
      <input v-model="q" type="search" class="input" placeholder="搜索活动、地点" aria-label="搜索活动">
      <div class="-mx-4 mt-2 flex gap-2 overflow-x-auto px-4 pb-1 [scrollbar-width:none]">
        <button type="button" class="chip shrink-0" :class="category === '' ? '!bg-brand-500 !text-white' : ''"
                @click="category = ''">全部</button>
        <button v-for="c in EVENT_CATEGORIES" :key="c" type="button" class="chip shrink-0"
                :class="category === c ? '!bg-brand-500 !text-white' : ''" @click="category = c">{{ c }}</button>
      </div>
    </div>

    <div v-if="status === 'pending' && !events?.length" class="grid grid-cols-2 gap-3 pt-2">
      <div v-for="i in 6" :key="i" class="card h-32 animate-pulse bg-stone-100" />
    </div>

    <div v-else-if="error" class="card mt-2 text-center text-sm">
      <p class="mb-3 text-red-600">活动加载失败：{{ error.message }}</p>
      <button class="btn-secondary" @click="refresh()">重试</button>
    </div>

    <div v-else-if="!filtered.length" class="py-16 text-center text-sm text-stone-500">
      <p class="mb-1 text-3xl">🗓️</p>
      <p v-if="events?.length">没有符合条件的活动，换个关键词试试</p>
      <p v-else>最近还没有活动</p>
      <NuxtLink to="/create" class="btn-primary mt-4">发起第一个活动</NuxtLink>
    </div>

    <div v-else class="grid grid-cols-2 gap-3 pt-2">
      <EventCard v-for="e in filtered" :key="e.id" :event="e" />
    </div>
  </div>
</template>
