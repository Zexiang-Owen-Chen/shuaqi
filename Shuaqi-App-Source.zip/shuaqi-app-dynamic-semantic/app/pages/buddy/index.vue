<script setup lang="ts">
import type { Database } from '~/types/database.types'
import type { BuddyCard } from '~/components/buddy/BuddyPersonCard.vue'

type Intent = Database['public']['Tables']['intents']['Row']
type Invitation = Database['public']['Tables']['match_invitations']['Row']
type Plan = Database['public']['Tables']['shared_plans']['Row']

useHead({ title: '找搭子 · SHUAQI' })

const supabase = useSupabaseClient<Database>()
const user = useSupabaseUser()
const rpc = useRpc()
// intents switched off: no new needs or matching; plans already agreed stay visible.
const { isOn } = useFeatureFlags()
const enabled = computed(() => isOn('intents'))
const me = computed(() => (user.value as { sub?: string; id?: string } | null)?.sub ?? (user.value as { id?: string } | null)?.id ?? '')

const loading = ref(true)
const error = ref('')
const intents = ref<Intent[]>([])
const invitations = ref<Invitation[]>([])
const plans = ref<Plan[]>([])
const cards = ref<Record<string, BuddyCard | null>>({})
const busy = ref<string | null>(null)
const actionError = ref('')
const now = ref(Date.now())

const fmt = new Intl.DateTimeFormat('zh-CN', {
  timeZone: 'Europe/London', month: 'numeric', day: 'numeric', weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false,
})
const fmtTime = new Intl.DateTimeFormat('zh-CN', { timeZone: 'Europe/London', hour: '2-digit', minute: '2-digit', hour12: false })
const when = (iso: string | null) => (iso ? fmt.format(new Date(iso)) : '时间待定')
const range = (a: string, b: string) => {
  const sameDay = new Date(a).toLocaleDateString('en-GB', { timeZone: 'Europe/London' })
    === new Date(b).toLocaleDateString('en-GB', { timeZone: 'Europe/London' })
  return `${fmt.format(new Date(a))} – ${sameDay ? fmtTime.format(new Date(b)) : fmt.format(new Date(b))}`
}

const isExpired = (i: Intent) => i.status === 'open' && new Date(i.expires_at).getTime() < now.value
function intentStatus(i: Intent) {
  if (i.status === 'withdrawn') return { text: '已撤回', cls: 'bg-stone-100 text-stone-500' }
  if (i.status === 'matched') return { text: '已成局', cls: 'bg-emerald-50 text-emerald-700' }
  if (isExpired(i)) return { text: '已过期', cls: 'bg-stone-100 text-stone-500' }
  return { text: '匹配中', cls: 'bg-brand-50 text-brand-700' }
}
const activeIntents = computed(() => intents.value.filter((i) => i.status === 'open' && !isExpired(i)))
const pastIntents = computed(() => intents.value.filter((i) => !(i.status === 'open' && !isExpired(i))).slice(0, 10))
const intentById = computed(() => Object.fromEntries(intents.value.map((i) => [i.id, i])))

const incoming = computed(() => invitations.value.filter((i) => i.to_user === me.value))
const outgoing = computed(() => invitations.value.filter((i) => i.from_user === me.value))

const otherOf = (p: Plan) => (p.user_a === me.value ? p.user_b : p.user_a)
function planStatus(p: Plan) {
  if (p.status === 'cancelled') return { text: '已取消', cls: 'bg-stone-100 text-stone-500' }
  if (p.a_met_at && p.b_met_at) return { text: '已见面', cls: 'bg-emerald-50 text-emerald-700' }
  if (p.status === 'confirmed') return { text: '双方已确认', cls: 'bg-emerald-50 text-emerald-700' }
  const mine = p.user_a === me.value ? p.a_confirmed_at : p.b_confirmed_at
  return mine ? { text: '等对方确认', cls: 'bg-amber-50 text-amber-700' } : { text: '待你确认', cls: 'bg-brand-50 text-brand-700' }
}
const activePlans = computed(() => plans.value.filter((p) => p.status !== 'cancelled'))
const cancelledPlans = computed(() => plans.value.filter((p) => p.status === 'cancelled'))

async function loadCards(ids: string[]) {
  const missing = [...new Set(ids)].filter((id) => id && !(id in cards.value))
  await Promise.all(missing.map(async (id) => {
    try {
      cards.value[id] = (await rpc('get_profile_card', { p_target: id, p_context: 'intent' })) as unknown as BuddyCard | null
    } catch {
      cards.value[id] = null
    }
  }))
}

async function load() {
  loading.value = true
  error.value = ''
  now.value = Date.now()
  try {
    const [a, b, c] = await Promise.all([
      supabase.from('intents').select('*').order('created_at', { ascending: false }).limit(50),
      supabase.from('match_invitations').select('*').eq('status', 'pending').order('created_at', { ascending: false }),
      supabase.from('shared_plans').select('*').order('created_at', { ascending: false }).limit(50),
    ])
    const err = a.error || b.error || c.error
    if (err) throw new Error(messageFor(err))
    intents.value = a.data ?? []
    invitations.value = b.data ?? []
    plans.value = c.data ?? []
    await loadCards([
      ...invitations.value.map((i) => (i.from_user === me.value ? i.to_user : i.from_user)),
      ...plans.value.map(otherOf),
    ])
  } catch (e) {
    error.value = messageFor(e)
  } finally {
    loading.value = false
  }
}

async function run(key: string, fn: () => Promise<void>) {
  busy.value = key
  actionError.value = ''
  try {
    await fn()
  } catch (e) {
    actionError.value = messageFor(e)
  } finally {
    busy.value = null
  }
}

function withdrawIntent(i: Intent) {
  if (!confirm(`撤回“${i.activity_type}”的需求？撤回后别人将看不到它。`)) return
  return run(`intent:${i.id}`, async () => {
    const { error: err } = await supabase.from('intents').update({ status: 'withdrawn' }).eq('id', i.id)
    if (err) throw new Error(messageFor(err))
    i.status = 'withdrawn'
  })
}

function respond(inv: Invitation, accept: boolean) {
  return run(`inv:${inv.id}`, async () => {
    const planId = await rpc('respond_match_invitation', { p_invitation: inv.id, p_accept: accept })
    invitations.value = invitations.value.filter((x) => x.id !== inv.id)
    if (accept && planId) await navigateTo(`/buddy/plans/${planId}`)
    else if (accept) await load()
  })
}

function withdrawInvitation(inv: Invitation) {
  return run(`inv:${inv.id}`, async () => {
    await rpc('withdraw_match_invitation', { p_invitation: inv.id })
    invitations.value = invitations.value.filter((x) => x.id !== inv.id)
  })
}

onMounted(load)
</script>

<template>
  <div class="space-y-6 px-4 pt-6">
    <header class="flex items-start justify-between gap-3">
      <div>
        <h1 class="text-xl font-bold text-stone-900">找搭子</h1>
        <p class="mt-0.5 text-sm text-stone-500">说出你想做的事，系统帮你找时间、兴趣都对得上的同学</p>
      </div>
      <NuxtLink v-if="enabled" to="/buddy/new" class="btn-primary shrink-0">发布需求</NuxtLink>
    </header>

    <p v-if="!enabled" class="rounded-xl bg-amber-50 p-3 text-sm text-amber-800">
      找搭子暂时关闭了，现在不能发布需求或匹配新的搭子。已经约好的计划仍然可以查看和确认。
    </p>

    <div v-if="loading" class="space-y-3">
      <div v-for="n in 3" :key="n" class="card h-20 animate-pulse bg-stone-50" />
    </div>

    <div v-else-if="error" class="card text-center">
      <p class="text-sm text-red-700">{{ error }}</p>
      <button class="btn-secondary mt-3" @click="load">重试</button>
    </div>

    <template v-else>
      <p v-if="actionError" class="rounded-xl bg-red-50 px-3 py-2 text-sm text-red-700" role="alert">{{ actionError }}</p>

      <!-- Incoming invitations come first: they need an answer. -->
      <section v-if="enabled && incoming.length" class="space-y-3">
        <h2 class="text-sm font-semibold text-stone-700">收到的邀请 <span class="text-brand-600">{{ incoming.length }}</span></h2>
        <div v-for="inv in incoming" :key="inv.id" class="card space-y-3 ring-brand-100">
          <BuddyPersonCard :card="cards[inv.from_user] ?? null" compact />
          <p class="text-xs text-stone-500">
            想和你一起：<span class="font-medium text-stone-700">{{ intentById[inv.to_intent_id]?.activity_type ?? '你的需求' }}</span>
            <template v-if="intentById[inv.to_intent_id]"> · {{ range(intentById[inv.to_intent_id]!.window_start, intentById[inv.to_intent_id]!.window_end) }}</template>
          </p>
          <p v-if="inv.message" class="rounded-xl bg-stone-50 px-3 py-2 text-sm text-stone-700">“{{ inv.message }}”</p>
          <div class="grid grid-cols-2 gap-2">
            <button class="btn-secondary" :disabled="busy === `inv:${inv.id}`" @click="respond(inv, false)">婉拒</button>
            <button class="btn-primary" :disabled="busy === `inv:${inv.id}`" @click="respond(inv, true)">接受并建立计划</button>
          </div>
          <p class="text-[11px] text-stone-400">接受后会生成一份共同计划，双方确认时间地点后才算约定好。</p>
        </div>
      </section>

      <section class="space-y-3">
        <h2 class="text-sm font-semibold text-stone-700">我的计划</h2>
        <p v-if="!activePlans.length" class="card text-sm text-stone-500">还没有计划。{{ enabled ? '对方接受邀请后，计划会出现在这里。' : '' }}</p>
        <NuxtLink v-for="p in activePlans" :key="p.id" :to="`/buddy/plans/${p.id}`" class="card block active:bg-stone-50">
          <div class="flex items-center justify-between gap-2">
            <span class="font-medium text-stone-900">{{ p.title }}</span>
            <span class="rounded-full px-2 py-0.5 text-xs" :class="planStatus(p).cls">{{ planStatus(p).text }}</span>
          </div>
          <p class="mt-1 text-xs text-stone-500">
            和 {{ cards[otherOf(p)]?.display_name ?? '对方' }} · {{ when(p.planned_at) }}{{ p.place ? ` · ${p.place}` : '' }}
          </p>
        </NuxtLink>
      </section>

      <section v-if="enabled" class="space-y-3">
        <h2 class="text-sm font-semibold text-stone-700">我的需求</h2>
        <div v-if="!activeIntents.length" class="card text-center">
          <p class="text-sm text-stone-500">还没有正在匹配的需求</p>
          <NuxtLink to="/buddy/new" class="btn-primary mt-3">说说你想做什么</NuxtLink>
        </div>
        <div v-for="i in activeIntents" :key="i.id" class="card">
          <NuxtLink :to="`/buddy/intents/${i.id}`" class="block">
            <div class="flex items-center justify-between gap-2">
              <span class="font-medium text-stone-900">{{ i.activity_type }}</span>
              <span class="rounded-full px-2 py-0.5 text-xs" :class="intentStatus(i).cls">{{ intentStatus(i).text }}</span>
            </div>
            <p class="mt-1 text-xs text-stone-500">
              {{ range(i.window_start, i.window_end) }}{{ i.region ? ` · ${i.region}` : '' }} · {{ i.group_size }} 人
            </p>
          </NuxtLink>
          <div class="mt-3 flex gap-2">
            <NuxtLink :to="`/buddy/intents/${i.id}`" class="btn-primary flex-1">看候选人</NuxtLink>
            <button class="btn-secondary" :disabled="busy === `intent:${i.id}`" @click="withdrawIntent(i)">撤回</button>
          </div>
        </div>
      </section>

      <section v-if="enabled && outgoing.length" class="space-y-3">
        <h2 class="text-sm font-semibold text-stone-700">我发出的邀请</h2>
        <div v-for="inv in outgoing" :key="inv.id" class="card space-y-2">
          <BuddyPersonCard :card="cards[inv.to_user] ?? null" compact />
          <p class="text-xs text-stone-500">
            {{ intentById[inv.from_intent_id]?.activity_type ?? '' }} · 等待对方回应
          </p>
          <button class="btn-secondary w-full" :disabled="busy === `inv:${inv.id}`" @click="withdrawInvitation(inv)">撤回邀请</button>
        </div>
      </section>

      <details v-if="pastIntents.length || cancelledPlans.length" class="text-sm">
        <summary class="cursor-pointer py-1 text-stone-500">历史记录</summary>
        <div class="mt-2 space-y-2">
          <div v-for="i in pastIntents" :key="i.id" class="card flex items-center justify-between gap-2 !py-3">
            <div class="min-w-0">
              <p class="truncate text-stone-800">{{ i.activity_type }}</p>
              <p class="text-xs text-stone-400">{{ range(i.window_start, i.window_end) }}</p>
            </div>
            <span class="shrink-0 rounded-full px-2 py-0.5 text-xs" :class="intentStatus(i).cls">{{ intentStatus(i).text }}</span>
          </div>
          <NuxtLink v-for="p in cancelledPlans" :key="p.id" :to="`/buddy/plans/${p.id}`"
                    class="card flex items-center justify-between gap-2 !py-3">
            <span class="truncate text-stone-800">{{ p.title }} · 和 {{ cards[otherOf(p)]?.display_name ?? '对方' }}</span>
            <span class="shrink-0 rounded-full bg-stone-100 px-2 py-0.5 text-xs text-stone-500">已取消</span>
          </NuxtLink>
        </div>
      </details>
    </template>
  </div>
</template>
