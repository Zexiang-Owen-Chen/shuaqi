<script setup lang="ts">
import type { Database } from '~/types/database.types'
import type { BuddyCard } from '~/components/buddy/BuddyPersonCard.vue'

type Plan = Database['public']['Tables']['shared_plans']['Row']

useHead({ title: '共同计划 · SHUAQI' })

const route = useRoute()
const id = computed(() => String(route.params.id))
const supabase = useSupabaseClient<Database>()
const user = useSupabaseUser()
const rpc = useRpc()
const me = computed(() => (user.value as { sub?: string; id?: string } | null)?.sub ?? (user.value as { id?: string } | null)?.id ?? '')

const TZ = 'Europe/London'
function londonParts(d: Date) {
  const p = Object.fromEntries(new Intl.DateTimeFormat('en-GB', {
    timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false,
  }).formatToParts(d).map((x) => [x.type, x.value]))
  return { y: +p.year!, m: +p.month!, d: +p.day!, h: +p.hour! % 24, min: +p.minute! }
}
const pad = (n: number) => String(n).padStart(2, '0')
function toLocalInput(d: Date) {
  const p = londonParts(d)
  return `${p.y}-${pad(p.m)}-${pad(p.d)}T${pad(p.h)}:${pad(p.min)}`
}
function fromLocalInput(v: string): Date | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/.exec(v)
  if (!m) return null
  const wall = Date.UTC(+m[1]!, +m[2]! - 1, +m[3]!, +m[4]!, +m[5]!)
  const offsetAt = (t: number) => {
    const p = londonParts(new Date(t))
    return Date.UTC(p.y, p.m - 1, p.d, p.h, p.min) - t
  }
  let t = wall - offsetAt(wall)
  t = wall - offsetAt(t)
  return new Date(t)
}
const fmt = new Intl.DateTimeFormat('zh-CN', {
  timeZone: TZ, year: 'numeric', month: 'numeric', day: 'numeric', weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false,
})

const loading = ref(true)
const error = ref('')
const plan = ref<Plan | null>(null)
const cards = ref<Record<string, BuddyCard | null>>({})
const busy = ref<string | null>(null)
const actionError = ref('')
const notice = ref('')
const now = ref(Date.now())

const editing = ref(false)
const editTime = ref('')
const editPlace = ref('')
const editError = ref('')

const amA = computed(() => plan.value?.user_a === me.value)
const otherId = computed(() => (plan.value ? (amA.value ? plan.value.user_b : plan.value.user_a) : ''))
const myConfirmed = computed(() => (plan.value ? (amA.value ? plan.value.a_confirmed_at : plan.value.b_confirmed_at) : null))
const otherConfirmed = computed(() => (plan.value ? (amA.value ? plan.value.b_confirmed_at : plan.value.a_confirmed_at) : null))
const myMet = computed(() => (plan.value ? (amA.value ? plan.value.a_met_at : plan.value.b_met_at) : null))
const otherMet = computed(() => (plan.value ? (amA.value ? plan.value.b_met_at : plan.value.a_met_at) : null))
const cancelled = computed(() => plan.value?.status === 'cancelled')
const confirmed = computed(() => plan.value?.status === 'confirmed')
const bothMet = computed(() => !!myMet.value && !!otherMet.value)
// report_met is accepted from one hour before the planned time.
const canReportMet = computed(() => confirmed.value && !!plan.value?.planned_at
  && new Date(plan.value.planned_at).getTime() - 3600_000 <= now.value)
const otherName = computed(() => cards.value[otherId.value]?.display_name || '对方')
// Arrival prompt is open from 1 hour before until 6 hours after the planned time (update_plan_presence).
const meetupOpen = computed(() => {
  if (!confirmed.value || !plan.value?.planned_at) return false
  const t = new Date(plan.value.planned_at).getTime()
  return now.value >= t - 3600_000 && now.value <= t + 6 * 3600_000
})

const statusBadge = computed(() => {
  if (!plan.value) return { text: '', cls: '' }
  if (cancelled.value) return { text: '已取消', cls: 'bg-stone-100 text-stone-500' }
  if (bothMet.value) return { text: '双方确认已见面', cls: 'bg-emerald-50 text-emerald-700' }
  if (confirmed.value) return { text: '双方已确认计划', cls: 'bg-emerald-50 text-emerald-700' }
  return { text: '待确认', cls: 'bg-amber-50 text-amber-700' }
})

async function load() {
  loading.value = true
  error.value = ''
  now.value = Date.now()
  try {
    const { data, error: err } = await supabase.from('shared_plans').select('*').eq('id', id.value).maybeSingle()
    if (err) throw new Error(messageFor(err))
    plan.value = data
    if (data) {
      await Promise.all([data.user_a, data.user_b].map(async (uid) => {
        try {
          cards.value[uid] = (await rpc('get_profile_card', { p_target: uid, p_context: 'intent', p_context_id: data.id })) as unknown as BuddyCard | null
        } catch {
          cards.value[uid] = null
        }
      }))
    }
  } catch (e) {
    error.value = messageFor(e)
  } finally {
    loading.value = false
  }
}

async function run(key: string, fn: () => Promise<void>) {
  busy.value = key
  actionError.value = ''
  notice.value = ''
  try {
    await fn()
  } catch (e) {
    actionError.value = messageFor(e)
  } finally {
    busy.value = null
    now.value = Date.now()
  }
}

function startEdit() {
  if (!plan.value) return
  editTime.value = plan.value.planned_at ? toLocalInput(new Date(plan.value.planned_at)) : ''
  editPlace.value = plan.value.place
  editError.value = ''
  editing.value = true
}

function saveEdit() {
  editError.value = ''
  const t = fromLocalInput(editTime.value)
  if (!t) { editError.value = '请选择时间'; return }
  if (t.getTime() < Date.now()) { editError.value = '时间不能早于现在'; return }
  if (editPlace.value.trim().length > 120) { editError.value = '地点太长了'; return }
  return run('edit', async () => {
    plan.value = await rpc('update_shared_plan', { p_plan: id.value, p_planned_at: t.toISOString(), p_place: editPlace.value.trim() })
    editing.value = false
    notice.value = `已更新，等待${otherName.value}重新确认`
  })
}

const confirmPlan = () => run('confirm', async () => {
  plan.value = await rpc('confirm_shared_plan', { p_plan: id.value })
  notice.value = plan.value?.status === 'confirmed' ? '双方都确认了，到时候见！' : `已确认，等待${otherName.value}确认`
})

function cancelPlan() {
  if (!confirm('取消这个计划？对方会看到计划已取消，这个操作不能撤销。')) return
  return run('cancel', async () => {
    await rpc('cancel_shared_plan', { p_plan: id.value })
    if (plan.value) plan.value = { ...plan.value, status: 'cancelled' }
  })
}

const reportMet = () => run('met', async () => {
  plan.value = await rpc('report_met', { p_plan: id.value })
  notice.value = bothMet.value ? '双方都确认见面了，已记录为“双方确认的见面”' : `已记下，等${otherName.value}也确认后才会记录`
})

const friendSent = ref(false)
const addFriend = () => run('friend', async () => {
  await rpc('send_connection_request', { p_to: otherId.value, p_context: 'intent', p_context_id: id.value })
  friendSent.value = true
  notice.value = '好友请求已发送'
})

onMounted(load)
</script>

<template>
  <div class="space-y-4 px-4 pt-4 pb-6">
    <NuxtLink to="/buddy" class="text-sm text-stone-500">‹ 找搭子</NuxtLink>

    <div v-if="loading" class="space-y-3">
      <div class="card h-32 animate-pulse bg-stone-50" />
      <div class="card h-40 animate-pulse bg-stone-50" />
    </div>

    <div v-else-if="error" class="card text-center">
      <p class="text-sm text-red-700">{{ error }}</p>
      <button class="btn-secondary mt-3" @click="load">重试</button>
    </div>

    <div v-else-if="!plan" class="card text-center">
      <p class="text-sm text-stone-500">计划不存在，或你不是参与者</p>
      <NuxtLink to="/buddy" class="btn-secondary mt-3">返回</NuxtLink>
    </div>

    <template v-else>
      <section class="card">
        <div class="flex items-center justify-between gap-2">
          <h1 class="text-lg font-bold text-stone-900">{{ plan.title }}</h1>
          <span class="rounded-full px-2 py-0.5 text-xs" :class="statusBadge.cls">{{ statusBadge.text }}</span>
        </div>
        <dl class="mt-3 space-y-1.5 text-sm">
          <div class="flex gap-2"><dt class="w-10 shrink-0 text-stone-400">时间</dt>
            <dd class="text-stone-800">{{ plan.planned_at ? fmt.format(new Date(plan.planned_at)) : '待定' }}<span class="text-xs text-stone-400">（英国时间）</span></dd></div>
          <div class="flex gap-2"><dt class="w-10 shrink-0 text-stone-400">地点</dt>
            <dd class="text-stone-800">{{ plan.place || '待定' }}</dd></div>
        </dl>
        <button v-if="!cancelled && !bothMet && !editing" class="mt-3 text-sm text-brand-600" @click="startEdit">修改时间或地点</button>

        <div v-if="editing" class="mt-3 space-y-3 border-t border-stone-100 pt-3">
          <div>
            <label class="label" for="pt">时间（英国时间）</label>
            <input id="pt" v-model="editTime" type="datetime-local" class="input">
          </div>
          <div>
            <label class="label" for="pp">地点</label>
            <input id="pp" v-model="editPlace" class="input" maxlength="120" placeholder="比如：Hyde Park 九曲湖北门">
          </div>
          <p class="rounded-xl bg-amber-50 px-3 py-2 text-xs text-amber-800">
            修改后会视为你确认了新安排，但{{ otherName }}之前的确认会被清除，需要对方重新确认。
          </p>
          <p v-if="editError" class="text-xs text-red-600">{{ editError }}</p>
          <div class="grid grid-cols-2 gap-2">
            <button class="btn-secondary" :disabled="busy === 'edit'" @click="editing = false">取消</button>
            <button class="btn-primary" :disabled="busy === 'edit'" @click="saveEdit">{{ busy === 'edit' ? '保存中…' : '保存' }}</button>
          </div>
        </div>
      </section>

      <section class="card space-y-4">
        <h2 class="text-sm font-semibold text-stone-700">参与者</h2>
        <div v-for="uid in [me, otherId]" :key="uid" class="space-y-2">
          <BuddyPersonCard :card="cards[uid] ?? null" compact />
          <div class="flex flex-wrap gap-1.5 pl-14 text-xs">
            <span class="rounded-full px-2 py-0.5"
                  :class="(uid === me ? myConfirmed : otherConfirmed) ? 'bg-emerald-50 text-emerald-700' : 'bg-stone-100 text-stone-500'">
              {{ (uid === me ? myConfirmed : otherConfirmed) ? '✓ 已确认计划' : '未确认计划' }}
            </span>
            <span v-if="confirmed" class="rounded-full px-2 py-0.5"
                  :class="(uid === me ? myMet : otherMet) ? 'bg-emerald-50 text-emerald-700' : 'bg-stone-100 text-stone-500'">
              {{ (uid === me ? myMet : otherMet) ? '✓ 已标记见面' : '未标记见面' }}
            </span>
          </div>
        </div>
      </section>

      <p v-if="notice" class="rounded-xl bg-emerald-50 px-3 py-2 text-sm text-emerald-800" role="status">{{ notice }}</p>
      <p v-if="actionError" class="rounded-xl bg-red-50 px-3 py-2 text-sm text-red-700" role="alert">{{ actionError }}</p>

      <div v-if="cancelled" class="card text-center text-sm text-stone-500">这个计划已取消。</div>

      <template v-else>
        <!-- Step 1: both confirm the arrangement. -->
        <section v-if="!confirmed" class="card space-y-2">
          <h2 class="text-sm font-semibold text-stone-700">确认计划</h2>
          <p class="text-xs text-stone-500">双方都确认时间地点后，计划才算约定好。确认计划不代表已经见面。</p>
          <button v-if="!myConfirmed" class="btn-primary w-full" :disabled="busy === 'confirm' || !plan.planned_at" @click="confirmPlan">
            {{ busy === 'confirm' ? '确认中…' : '我确认这个时间和地点' }}
          </button>
          <p v-else class="text-center text-sm text-stone-500">你已确认，等待{{ otherName }}确认</p>
          <p v-if="!plan.planned_at" class="text-xs text-amber-700">请先填写时间。</p>
        </section>

        <!-- Step 2: after meeting, both report it. -->
        <section v-else class="card space-y-2">
          <h2 class="text-sm font-semibold text-stone-700">见面了吗？</h2>
          <template v-if="bothMet">
            <p class="text-sm text-emerald-700">✓ 你们都确认见过面了，已记录为“双方确认的见面”。</p>
          </template>
          <template v-else>
            <p class="text-xs text-stone-500">
              约定好 ≠ 已经见面。见面后两个人都点“我们见面了”，才会记录为一次“双方确认的见面”；只有一方标记不会记录。
            </p>
            <button v-if="!myMet" class="btn-primary w-full" :disabled="!canReportMet || busy === 'met'" @click="reportMet">
              {{ busy === 'met' ? '提交中…' : '我们见面了' }}
            </button>
            <p v-else class="text-center text-sm text-stone-500">你已标记，等待{{ otherName }}也确认</p>
            <p v-if="!canReportMet && !myMet" class="text-xs text-stone-400">计划时间到了之后才能标记（最早提前 1 小时）。</p>
          </template>
        </section>

        <NearbyPlanMeetup v-if="meetupOpen && otherId" :plan-id="plan.id" :other-name="otherName"
                    :connected="!!cards[otherId]?.connected" :request-sent="friendSent" :sending="busy === 'friend'"
                    @add-friend="addFriend" />

        <section v-if="otherId && !cards[otherId]?.connected" class="card space-y-2">
          <h2 class="text-sm font-semibold text-stone-700">加个好友？</h2>
          <p class="text-xs text-stone-500">成为好友后，可以按对方的设置看到更多资料。</p>
          <button class="btn-secondary w-full" :disabled="friendSent || busy === 'friend'" @click="addFriend">
            {{ friendSent ? '已发送好友请求' : busy === 'friend' ? '发送中…' : `加 ${otherName} 为好友` }}
          </button>
        </section>

        <button v-if="!bothMet" class="btn-danger w-full" :disabled="busy === 'cancel'" @click="cancelPlan">取消计划</button>
      </template>
    </template>
  </div>
</template>
