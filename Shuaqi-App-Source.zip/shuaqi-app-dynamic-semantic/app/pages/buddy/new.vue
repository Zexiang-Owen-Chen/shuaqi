<script setup lang="ts">
import { z } from 'zod'
import type { Database } from '~/types/database.types'

type Intent = Database['public']['Tables']['intents']['Row']

useHead({ title: '发布需求 · SHUAQI' })

const supabase = useSupabaseClient<Database>()
const user = useSupabaseUser()
const { isOn } = useFeatureFlags()
const enabled = computed(() => isOn('intents'))
const me = computed(() => (user.value as { sub?: string; id?: string } | null)?.sub ?? (user.value as { id?: string } | null)?.id ?? '')

const TZ = 'Europe/London'
const ACTIVITIES = ['跑步', '健身', '羽毛球', '学习', '吃饭', '看展', '桌游', '徒步', '其他']

// --- Europe/London <-> datetime-local helpers ------------------------------
function londonParts(d: Date) {
  const p = Object.fromEntries(new Intl.DateTimeFormat('en-GB', {
    timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false,
  }).formatToParts(d).map((x) => [x.type, x.value]))
  return { y: +p.year!, m: +p.month!, d: +p.day!, h: +p.hour! % 24, min: +p.minute! }
}
const pad = (n: number) => String(n).padStart(2, '0')
function toLocalInput(d: Date) {
  const p = londonParts(d)
  return `${p.y}-${pad(p.m)}-${pad(p.d)}T${pad(p.h)}:${pad(p.min)}`
}
// Interprets "YYYY-MM-DDTHH:mm" as London wall-clock time.
function fromLocalInput(v: string): Date | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/.exec(v)
  if (!m) return null
  const wall = Date.UTC(+m[1]!, +m[2]! - 1, +m[3]!, +m[4]!, +m[5]!)
  const offsetAt = (t: number) => {
    const p = londonParts(new Date(t))
    return Date.UTC(p.y, p.m - 1, p.d, p.h, p.min) - t
  }
  let t = wall - offsetAt(wall)
  t = wall - offsetAt(t)
  return new Date(t)
}

// --- form state -----------------------------------------------------------
const start0 = new Date()
start0.setMinutes(0, 0, 0)
start0.setHours(start0.getHours() + 2)
const end0 = new Date(start0.getTime() + 2 * 3600_000)

const preset = ref<string>('')
const customType = ref('')
const form = reactive({
  windowStart: toLocalInput(start0),
  windowEnd: toLocalInput(end0),
  expiresAt: toLocalInput(end0),
  region: '',
  groupSize: 2,
  budget: '' as string | number,
  note: '',
})
const expiresTouched = ref(false)
watch(() => form.windowEnd, (v) => { if (!expiresTouched.value) form.expiresAt = v })

const activityType = computed(() =>
  preset.value === '其他' || !preset.value ? customType.value.trim() : preset.value)

const schema = z.object({
  activity_type: z.string().min(1, '请选择或填写想做的事').max(30, '活动名称最多 30 个字'),
  window_start: z.date({ message: '请选择开始时间' }),
  window_end: z.date({ message: '请选择结束时间' }),
  expires_at: z.date({ message: '请选择有效期' }),
  region: z.string().refine(v => v === '' || isRegion(v), '请选择有效地区'),
  group_size: z.number().int().min(2).max(6),
  budget_max: z.number().int('预算请填整数').min(0, '预算不能为负').nullable(),
  note: z.string().max(300, '补充说明最多 300 个字'),
}).superRefine((v, ctx) => {
  if (v.window_start.getTime() < Date.now() - 60_000) ctx.addIssue({ code: 'custom', path: ['window_start'], message: '开始时间不能早于现在' })
  if (v.window_end <= v.window_start) ctx.addIssue({ code: 'custom', path: ['window_end'], message: '结束时间要晚于开始时间' })
  if (v.expires_at > v.window_end) ctx.addIssue({ code: 'custom', path: ['expires_at'], message: '有效期不能晚于结束时间' })
  if (v.expires_at.getTime() <= Date.now()) ctx.addIssue({ code: 'custom', path: ['expires_at'], message: '有效期要晚于现在' })
})

const errors = ref<Record<string, string>>({})
const submitError = ref('')
const submitting = ref(false)

function parsed() {
  const budgetRaw = String(form.budget).trim()
  return schema.safeParse({
    activity_type: activityType.value,
    window_start: fromLocalInput(form.windowStart) ?? undefined,
    window_end: fromLocalInput(form.windowEnd) ?? undefined,
    expires_at: fromLocalInput(form.expiresAt) ?? undefined,
    region: form.region.trim(),
    group_size: Number(form.groupSize),
    budget_max: budgetRaw === '' ? null : Number(budgetRaw),
    note: form.note.trim(),
  })
}

// --- duplicate warning ----------------------------------------------------
const myOpen = ref<Intent[]>([])
onMounted(async () => {
  const { data } = await supabase.from('intents').select('*').eq('status', 'open').gt('expires_at', new Date().toISOString())
  myOpen.value = data ?? []
})
const duplicate = computed(() => {
  const type = activityType.value.toLowerCase()
  const s = fromLocalInput(form.windowStart)
  const e = fromLocalInput(form.windowEnd)
  if (!type || !s || !e) return null
  return myOpen.value.find((i) => i.activity_type.toLowerCase() === type
    && new Date(i.window_start) < e && new Date(i.window_end) > s) ?? null
})

const fmt = new Intl.DateTimeFormat('zh-CN', { timeZone: TZ, month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false })

async function submit() {
  submitError.value = ''
  const r = parsed()
  if (!r.success) {
    errors.value = {}
    for (const issue of r.error.issues) {
      const k = String(issue.path[0] ?? 'form')
      if (!errors.value[k]) errors.value[k] = issue.message
    }
    return
  }
  errors.value = {}
  if (!me.value) { submitError.value = '请先登录'; return }
  submitting.value = true
  try {
    const v = r.data
    const { data, error } = await supabase.from('intents').insert({
      user_id: me.value,
      activity_type: v.activity_type,
      window_start: v.window_start.toISOString(),
      window_end: v.window_end.toISOString(),
      expires_at: v.expires_at.toISOString(),
      region: v.region,
      group_size: v.group_size,
      budget_max: v.budget_max,
      note: v.note,
    }).select('id').single()
    if (error) {
      // RLS rejects unverified users or a disabled feature without a readable code.
      if (error.code === '42501' || /row-level security/i.test(error.message)) {
        throw new Error('发布失败：请先完成学校邮箱验证（或找搭子功能暂时关闭）')
      }
      throw new Error(messageFor(error))
    }
    await navigateTo(`/buddy/intents/${data.id}`)
  } catch (e) {
    submitError.value = messageFor(e)
  } finally {
    submitting.value = false
  }
}
</script>

<template>
  <div class="px-4 pt-4 pb-6">
    <NuxtLink to="/buddy" class="text-sm text-stone-500">‹ 找搭子</NuxtLink>
    <h1 class="mt-2 text-xl font-bold text-stone-900">说说你想做什么</h1>
    <p class="mt-0.5 text-sm text-stone-500">写得越具体，匹配到的人越合适。时间均为英国时间。</p>

    <FeatureOff v-if="!enabled" class="mt-5" title="找搭子暂时关闭了" text="现在不能发布新需求。已经约好的计划仍然可以在“找搭子”里查看。"
                back-to="/buddy" back-label="返回找搭子" />

    <form v-else class="mt-5 space-y-5" novalidate @submit.prevent="submit">
      <div class="card space-y-3">
        <p class="text-sm text-stone-800">我想找人一起 <span class="font-semibold text-brand-600">{{ activityType || '……' }}</span></p>
        <div class="flex flex-wrap gap-2">
          <button v-for="a in ACTIVITIES" :key="a" type="button" class="chip !px-3 !py-1.5 !text-sm"
                  :class="preset === a ? '!bg-brand-500 !text-white' : ''"
                  :aria-pressed="preset === a" @click="preset = preset === a ? '' : a">{{ a }}</button>
        </div>
        <div v-if="preset === '其他' || !preset">
          <label class="label" for="custom-type">{{ preset === '其他' ? '具体是什么？' : '或者自己写' }}</label>
          <input id="custom-type" v-model="customType" class="input" maxlength="30" placeholder="比如：攀岩、练口语、逛市集">
        </div>
        <p v-if="errors.activity_type" class="text-xs text-red-600">{{ errors.activity_type }}</p>
      </div>

      <div class="card space-y-3">
        <p class="text-sm text-stone-800">什么时候有空？</p>
        <div class="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div>
            <label class="label" for="ws">最早</label>
            <input id="ws" v-model="form.windowStart" type="datetime-local" class="input">
            <p v-if="errors.window_start" class="mt-1 text-xs text-red-600">{{ errors.window_start }}</p>
          </div>
          <div>
            <label class="label" for="we">最晚</label>
            <input id="we" v-model="form.windowEnd" type="datetime-local" class="input">
            <p v-if="errors.window_end" class="mt-1 text-xs text-red-600">{{ errors.window_end }}</p>
          </div>
        </div>
        <p class="text-[11px] text-stone-400">和别人的空闲时间有重叠才会匹配。</p>
      </div>

      <div class="card space-y-3">
        <div>
          <RegionSelect id="region" v-model="form.region" optional />
          <p class="mt-1 text-xs text-stone-500">选择相同地区才会匹配；不限地区可匹配所有选项。“伦敦其他”是独立选项，不代表全伦敦。</p>
          <p v-if="errors.region" class="mt-1 text-xs text-red-600">{{ errors.region }}</p>
        </div>
        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="label" for="size">几个人（含自己）</label>
            <select id="size" v-model.number="form.groupSize" class="input">
              <option v-for="n in [2, 3, 4, 5, 6]" :key="n" :value="n">{{ n }} 人{{ n === 2 ? '（一对一）' : '' }}</option>
            </select>
          </div>
          <div>
            <label class="label" for="budget">人均预算上限（可选）</label>
            <div class="relative">
              <span class="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-sm text-stone-400">£</span>
              <input id="budget" v-model="form.budget" type="number" min="0" step="1" inputmode="numeric" class="input !pl-7" placeholder="不限">
            </div>
            <p v-if="errors.budget_max" class="mt-1 text-xs text-red-600">{{ errors.budget_max }}</p>
          </div>
        </div>
        <div>
          <label class="label" for="note">还想说点什么（可选）</label>
          <textarea id="note" v-model="form.note" class="input min-h-20" maxlength="300"
                    placeholder="比如：配速 6 分左右，跑完一起吃早饭" />
          <p class="text-right text-[11px] text-stone-400">{{ form.note.length }}/300</p>
          <p v-if="errors.note" class="text-xs text-red-600">{{ errors.note }}</p>
        </div>
      </div>

      <div class="card space-y-2">
        <label class="label" for="exp">需求有效期至</label>
        <input id="exp" v-model="form.expiresAt" type="datetime-local" class="input" @input="expiresTouched = true">
        <p class="text-[11px] text-stone-400">默认到你空闲时间结束为止，过期后不再被匹配。</p>
        <p v-if="errors.expires_at" class="text-xs text-red-600">{{ errors.expires_at }}</p>
      </div>

      <div v-if="duplicate" class="rounded-xl bg-amber-50 px-3 py-2 text-sm text-amber-800" role="status">
        你已经有一个“{{ duplicate.activity_type }}”需求（{{ fmt.format(new Date(duplicate.window_start)) }} 起），时间有重叠。
        <NuxtLink :to="`/buddy/intents/${duplicate.id}`" class="underline">去看看它的候选人</NuxtLink>，或者继续发布新的。
      </div>

      <p class="rounded-xl bg-stone-100 px-3 py-2 text-xs leading-relaxed text-stone-600">
        🔒 地区始终公开展示。找搭子时，<b>你的性别和年龄也会展示给匹配到的候选人</b>（即使你在资料里设置了隐藏）。其他资料按你的可见性设置展示。
      </p>

      <p v-if="submitError" class="rounded-xl bg-red-50 px-3 py-2 text-sm text-red-700" role="alert">{{ submitError }}</p>

      <button type="submit" class="btn-primary w-full !py-3" :disabled="submitting">
        {{ submitting ? '发布中…' : '发布并查看候选人' }}
      </button>
    </form>
  </div>
</template>
