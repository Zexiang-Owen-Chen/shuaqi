<script setup lang="ts">
import type { Database } from '~/types/database.types'
import type { BuddyCard } from '~/components/buddy/BuddyPersonCard.vue'

type Intent = Database['public']['Tables']['intents']['Row']
type Candidate = Database['public']['Functions']['match_candidates']['Returns'][number]

useHead({ title: '候选搭子 · SHUAQI' })

const route = useRoute()
const id = computed(() => String(route.params.id))
const supabase = useSupabaseClient<Database>()
const rpc = useRpc()
const { isOn } = useFeatureFlags()

const loading = ref(true)
const error = ref('')
const intent = ref<Intent | null>(null)
const candidates = ref<Candidate[]>([])
const candError = ref('')
const candLoading = ref(false)

const composing = ref<string | null>(null)
const message = ref('')
const sending = ref<string | null>(null)
const inviteError = ref<Record<string, string>>({})

const fmt = new Intl.DateTimeFormat('zh-CN', {
  timeZone: 'Europe/London', month: 'numeric', day: 'numeric', weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false,
})
const fmtTime = new Intl.DateTimeFormat('zh-CN', { timeZone: 'Europe/London', hour: '2-digit', minute: '2-digit', hour12: false })
const dayKey = (iso: string) => new Date(iso).toLocaleDateString('en-GB', { timeZone: 'Europe/London' })
const range = (a: string, b: string) =>
  `${fmt.format(new Date(a))} – ${dayKey(a) === dayKey(b) ? fmtTime.format(new Date(b)) : fmt.format(new Date(b))}`

const expired = computed(() => !!intent.value && new Date(intent.value.expires_at).getTime() < Date.now())
const matchable = computed(() => intent.value?.status === 'open' && !expired.value)
const statusText = computed(() => {
  const i = intent.value
  if (!i) return ''
  if (i.status === 'withdrawn') return '已撤回'
  if (i.status === 'matched') return '已成局'
  return expired.value ? '已过期' : '匹配中'
})

function duration(min: number) {
  const h = Math.floor(min / 60)
  const m = min % 60
  if (h && m) return `${h} 小时 ${m} 分钟`
  return h ? `${h} 小时` : `${m} 分钟`
}
function explain(c: Candidate) {
  const parts = [`时间重叠 ${duration(Math.max(0, c.overlap_minutes ?? 0))}`]
  if (c.shared_interests?.length) parts.push(`共同兴趣：${c.shared_interests.join('、')}`)
  if (intent.value?.region && c.region && c.region.toLowerCase() === intent.value.region.toLowerCase()) parts.push(`同在 ${c.region}`)
  if (intent.value && c.group_size === intent.value.group_size) parts.push(c.group_size === 2 ? '都想一对一' : `都想 ${c.group_size} 人`)
  return parts.join(' · ')
}
const cardOf = (c: Candidate) => c.card as unknown as BuddyCard | null

async function loadCandidates() {
  if (!isOn('intents')) {
    candidates.value = []
    candError.value = '找搭子暂时关闭了，现在不能匹配新的搭子'
    return
  }
  candLoading.value = true
  candError.value = ''
  try {
    candidates.value = (await rpc('match_candidates', { p_intent: id.value })) ?? []
  } catch (e) {
    candError.value = messageFor(e)
  } finally {
    candLoading.value = false
  }
}

async function load() {
  loading.value = true
  error.value = ''
  try {
    const { data, error: err } = await supabase.from('intents').select('*').eq('id', id.value).maybeSingle()
    if (err) throw new Error(messageFor(err))
    intent.value = data
    if (data && data.status === 'open' && new Date(data.expires_at).getTime() >= Date.now()) await loadCandidates()
  } catch (e) {
    error.value = messageFor(e)
  } finally {
    loading.value = false
  }
}

function openCompose(c: Candidate) {
  composing.value = c.intent_id
  message.value = ''
}

async function invite(c: Candidate) {
  sending.value = c.intent_id
  inviteError.value = { ...inviteError.value, [c.intent_id]: '' }
  try {
    await rpc('send_match_invitation', {
      p_from_intent: id.value, p_to_intent: c.intent_id, p_message: message.value.trim() || undefined,
    })
    c.invitation_status = 'pending'
    composing.value = null
  } catch (e) {
    inviteError.value = { ...inviteError.value, [c.intent_id]: messageFor(e) }
  } finally {
    sending.value = null
  }
}

const invitationLabel: Record<string, string> = {
  pending: '已邀请，等对方回应',
  accepted: '已成局，去“找搭子”查看计划',
  declined: '对方婉拒了',
  withdrawn: '你撤回了邀请',
}

onMounted(load)
</script>

<template>
  <div class="space-y-5 px-4 pt-4 pb-6">
    <NuxtLink to="/buddy" class="text-sm text-stone-500">‹ 找搭子</NuxtLink>

    <div v-if="loading" class="space-y-3">
      <div class="card h-24 animate-pulse bg-stone-50" />
      <div v-for="n in 3" :key="n" class="card h-28 animate-pulse bg-stone-50" />
    </div>

    <div v-else-if="error" class="card text-center">
      <p class="text-sm text-red-700">{{ error }}</p>
      <button class="btn-secondary mt-3" @click="load">重试</button>
    </div>

    <div v-else-if="!intent" class="card text-center">
      <p class="text-sm text-stone-500">需求不存在，或不是你发布的</p>
      <NuxtLink to="/buddy" class="btn-secondary mt-3">返回</NuxtLink>
    </div>

    <template v-else>
      <section class="card">
        <div class="flex items-center justify-between gap-2">
          <h1 class="text-lg font-bold text-stone-900">{{ intent.activity_type }}</h1>
          <span class="rounded-full px-2 py-0.5 text-xs"
                :class="matchable ? 'bg-brand-50 text-brand-700' : 'bg-stone-100 text-stone-500'">{{ statusText }}</span>
        </div>
        <p class="mt-1 text-sm text-stone-600">{{ range(intent.window_start, intent.window_end) }}</p>
        <div class="mt-2 flex flex-wrap gap-1.5">
          <span v-if="intent.region" class="chip">📍 {{ intent.region }}</span>
          <span class="chip">{{ intent.group_size }} 人</span>
          <span v-if="intent.budget_max != null" class="chip">≤ £{{ intent.budget_max }}</span>
          <span class="chip">有效至 {{ fmt.format(new Date(intent.expires_at)) }}</span>
        </div>
        <p v-if="intent.note" class="mt-2 text-sm text-stone-600">{{ intent.note }}</p>
      </section>

      <div v-if="!matchable" class="card text-center text-sm text-stone-500">
        <template v-if="intent.status === 'matched'">这个需求已经成局了，去“找搭子”查看你们的计划。</template>
        <template v-else-if="intent.status === 'withdrawn'">这个需求已撤回，不再匹配。</template>
        <template v-else>这个需求已过期，不再匹配。</template>
        <div class="mt-3 flex justify-center gap-2">
          <NuxtLink to="/buddy" class="btn-secondary">返回找搭子</NuxtLink>
          <NuxtLink to="/buddy/new" class="btn-primary">发布新需求</NuxtLink>
        </div>
      </div>

      <section v-else class="space-y-3">
        <div class="flex items-center justify-between">
          <h2 class="text-sm font-semibold text-stone-700">
            候选搭子<span v-if="!candLoading && !candError" class="text-stone-400"> · {{ candidates.length }}</span>
          </h2>
          <button class="text-xs text-brand-600" :disabled="candLoading" @click="loadCandidates">刷新</button>
        </div>
        <p class="text-[11px] text-stone-400">按时间重叠、共同兴趣和人数偏好排序。一对一匹配时，双方都能看到对方的性别、年龄和地区。</p>

        <div v-if="candLoading" class="space-y-3">
          <div v-for="n in 3" :key="n" class="card h-28 animate-pulse bg-stone-50" />
        </div>

        <div v-else-if="candError" class="card text-center">
          <p class="text-sm text-red-700">{{ candError }}</p>
          <button class="btn-secondary mt-3" @click="loadCandidates">重试</button>
        </div>

        <div v-else-if="!candidates.length" class="card text-center">
          <p class="text-2xl" aria-hidden="true">🌱</p>
          <p class="mt-1 text-sm text-stone-600">暂时还没有时间和地点都对得上的同学</p>
          <p class="mt-1 text-xs text-stone-400">需求在有效期内会一直被匹配；别人发布相近的需求时，会出现在这里。可以稍后回来刷新，或放宽时间、地区。</p>
        </div>

        <template v-else>
        <div v-for="c in candidates" :key="c.intent_id" class="card space-y-3">
          <BuddyPersonCard :card="cardOf(c)" :highlight="c.shared_interests ?? []" />
          <div class="rounded-xl bg-stone-50 px-3 py-2 text-xs text-stone-600">
            <p class="font-medium text-stone-700">{{ explain(c) }}</p>
            <p class="mt-1">TA 的时间：{{ range(c.window_start, c.window_end) }}{{ c.region ? ` · ${c.region}` : '' }}{{ c.budget_max != null ? ` · ≤ £${c.budget_max}` : '' }}</p>
            <p v-if="c.note" class="mt-1 text-stone-500">“{{ c.note }}”</p>
          </div>

          <p v-if="c.invitation_status && c.invitation_status !== 'withdrawn' && c.invitation_status !== 'declined'"
             class="text-center text-sm" :class="c.invitation_status === 'accepted' ? 'text-emerald-700' : 'text-stone-500'">
            {{ invitationLabel[c.invitation_status] ?? c.invitation_status }}
          </p>
          <template v-else>
            <p v-if="c.invitation_status" class="text-center text-xs text-stone-400">{{ invitationLabel[c.invitation_status] }}</p>
            <div v-if="composing === c.intent_id" class="space-y-2">
              <textarea v-model="message" class="input min-h-16" maxlength="200" placeholder="打个招呼（可选），比如：周六早上海德公园跑 5k 怎么样？" />
              <div class="grid grid-cols-2 gap-2">
                <button class="btn-secondary" :disabled="sending === c.intent_id" @click="composing = null">取消</button>
                <button class="btn-primary" :disabled="sending === c.intent_id" @click="invite(c)">
                  {{ sending === c.intent_id ? '发送中…' : '发送邀请' }}
                </button>
              </div>
            </div>
            <button v-else class="btn-primary w-full" @click="openCompose(c)">邀请</button>
          </template>
          <p v-if="inviteError[c.intent_id]" class="text-sm text-red-700" role="alert">{{ inviteError[c.intent_id] }}</p>
        </div>
        </template>
      </section>
    </template>
  </div>
</template>
