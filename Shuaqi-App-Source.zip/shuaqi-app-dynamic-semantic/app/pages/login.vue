<script setup lang="ts">
definePageMeta({ layout: 'bare' })

const supabase = useSupabaseClient()
const user = useSupabaseUser()
const route = useRoute()
const savedRedirect = useSupabaseCookieRedirect()
const redirectTo = computed(() => safeRedirect(route.query.redirect, savedRedirect.path.value))

const email = ref('')
const code = ref('')
const step = ref<'email' | 'code'>('email')
const busy = ref(false)
const error = ref('')
const domains = ref<{ domain: string; school_name: string }[]>([])

onMounted(async () => {
  const { data } = await supabase.from('allowed_school_domains').select('domain, school_name').eq('active', true).order('school_name')
  domains.value = data ?? []
})

watchEffect(() => {
  if (!user.value) return
  const to = redirectTo.value
  savedRedirect.path.value = null
  navigateTo(to)
})

function looksLikeSchoolEmail(v: string) {
  const host = normalizeSchoolEmail(v).split('@')[1] ?? ''
  return domains.value.some(d => host === d.domain || host.endsWith('.' + d.domain))
}

async function sendCode() {
  error.value = ''
  const v = normalizeSchoolEmail(email.value)
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v)) { error.value = '请输入有效的邮箱'; return }
  if (domains.value.length && !looksLikeSchoolEmail(v)) { error.value = errorText.school_email_required!; return }
  busy.value = true
  const { error: e } = await supabase.auth.signInWithOtp({
    email: v,
    options: { shouldCreateUser: true, emailRedirectTo: `${location.origin}/confirm?redirect=${encodeURIComponent(redirectTo.value)}` },
  })
  busy.value = false
  if (e) { error.value = messageFor(e); return }
  email.value = v
  step.value = 'code'
}

async function verify() {
  error.value = ''
  if (!/^\d{6}$/.test(code.value.trim())) { error.value = '请输入邮件里的 6 位验证码'; return }
  busy.value = true
  const { error: e } = await supabase.auth.verifyOtp({ email: normalizeSchoolEmail(email.value), token: code.value.trim(), type: 'email' })
  busy.value = false
  if (e) { error.value = e.message.includes('expired') || e.message.includes('invalid') ? '验证码错误或已过期' : messageFor(e); return }
  // Navigation happens in the watchEffect above once useSupabaseUser() is populated;
  // navigating here would run the onboarding middleware before the user is known.
}
</script>

<template>
  <main class="flex min-h-dvh flex-col justify-center px-6 py-10">
    <h1 class="text-3xl font-bold text-brand-600">SHUAQI 耍起</h1>
    <p class="mt-1 text-sm text-stone-500">找活动，找搭子，线下见。</p>

    <form v-if="step === 'email'" class="mt-8 space-y-4" @submit.prevent="sendCode">
      <div>
        <label class="label" for="email">学校邮箱</label>
        <input id="email" v-model="email" class="input" type="email" inputmode="email" autocomplete="email" placeholder="name@ucl.ac.uk" required>
        <p class="mt-2 text-xs text-stone-500">目前支持：{{ domains.map(d => d.school_name).join('、') || '支持的英国院校' }}</p>
        <p class="mt-1 text-xs text-stone-500">帝国理工支持 @ic.ac.uk 和 @imperial.ac.uk，统一使用 @imperial.ac.uk 登录。</p>
      </div>
      <button class="btn-primary w-full" :disabled="busy">{{ busy ? '发送中…' : '发送验证码' }}</button>
    </form>

    <form v-else class="mt-8 space-y-4" @submit.prevent="verify">
      <p class="text-sm text-stone-600">验证码已发送到 <b>{{ email }}</b>。学校邮箱可能会把邮件放进垃圾箱或隔离区，请一并查看。</p>
      <div>
        <label class="label" for="code">6 位验证码</label>
        <input id="code" v-model="code" class="input tracking-[0.5em] text-center text-lg" inputmode="numeric" autocomplete="one-time-code" maxlength="6" required>
      </div>
      <button class="btn-primary w-full" :disabled="busy">{{ busy ? '验证中…' : '登录' }}</button>
      <button type="button" class="btn-secondary w-full" :disabled="busy" @click="step = 'email'; code = ''">换个邮箱</button>
    </form>

    <p v-if="error" class="mt-4 rounded-xl bg-red-50 p-3 text-sm text-red-700" role="alert">{{ error }}</p>
    <p class="mt-10 text-xs text-stone-400">登录即表示你同意我们按隐私政策处理你的学校邮箱和资料。位置信息只在你签到或开启“附近的人”时读取。</p>
  </main>
</template>
