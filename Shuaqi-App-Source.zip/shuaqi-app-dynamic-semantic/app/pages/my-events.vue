<script setup lang="ts">
import type { Database } from '~/types/database.types'
import type { EventRow } from '~/utils/eventFormat'

useHead({ title: '我的活动 · SHUAQI 耍起' })

type Item = Pick<EventRow, 'id' | 'title' | 'category' | 'starts_at' | 'ends_at' | 'location_text' | 'status' | 'capacity'>
const COLS = 'id, title, category, starts_at, ends_at, location_text, status, capacity'

const supabase = useSupabaseClient<Database>()
const user = useSupabaseUser()
const { isOn } = useFeatureFlags()
const uid = computed(() => currentUid(user.value))

const tab = ref<'going' | 'hosting' | 'cancelled'>('going')
const loading = ref(true)
const error = ref('')
const going = ref<Item[]>([])
const hosting = ref<Item[]>([])

async function load() {
  if (!uid.value) { loading.value = false; return }
  loading.value = true
  error.value = ''
  const [a, b] = await Promise.all([
    supabase.from('event_rsvps').select(`status, events (${COLS})`).eq('user_id', uid.value).eq('status', 'going'),
    supabase.from('events').select(COLS).eq('host_user_id', uid.value).order('starts_at', { ascending: false }),
  ])
  loading.value = false
  if (a.error || b.error) { error.value = messageFor(a.error ?? b.error); return }
  going.value = (a.data ?? []).map((r) => r.events as Item | null).filter((e): e is Item => !!e)
  hosting.value = b.data ?? []
}
onMounted(() => { load(); watch(uid, (v, old) => { if (v !== old) load() }) })

const activeGoing = computed(() => going.value.filter(e => e.status !== 'cancelled'))
const activeHosting = computed(() => hosting.value.filter(e => e.status !== 'cancelled'))
// Hosts also have an RSVP, so a cancelled activity can occur in both queries.
const cancelled = computed(() => [...new Map([...going.value, ...hosting.value]
  .filter(e => e.status === 'cancelled').map(e => [e.id, e])).values()]
  .sort((x, y) => y.starts_at.localeCompare(x.starts_at)))
const list = computed(() => tab.value === 'cancelled' ? cancelled.value
  : tab.value === 'going' ? activeGoing.value : activeHosting.value)
const upcoming = computed(() => list.value
  .filter((e) => e.status !== 'ended' && !eventIsOver(e))
  .sort((x, y) => x.starts_at.localeCompare(y.starts_at)))
const past = computed(() => list.value
  .filter((e) => e.status === 'ended' || eventIsOver(e))
  .sort((x, y) => y.starts_at.localeCompare(x.starts_at)))
</script>

<template>
  <div class="px-4 pt-4">
    <header class="mb-3 flex items-center justify-between">
      <h1 class="text-xl font-bold">我的活动</h1>
      <NuxtLink v-if="isOn('qr_checkin')" to="/scan" class="btn-secondary !px-3 !py-2">📷 扫码签到</NuxtLink>
    </header>

    <div v-if="!user" class="card text-center text-sm">
      <p class="mb-3">登录后查看你报名和发起的活动</p>
      <NuxtLink to="/login?redirect=/my-events" class="btn-primary">去登录</NuxtLink>
    </div>

    <template v-else>
      <div class="mb-4 grid grid-cols-3 rounded-xl bg-stone-100 p-1 text-sm" role="tablist" aria-label="我的活动分类">
        <button type="button" role="tab" :aria-selected="tab === 'going'" class="rounded-lg py-2"
                :class="tab === 'going' ? 'bg-white font-medium shadow-sm' : 'text-stone-500'" @click="tab = 'going'">
          我报名的<span v-if="!loading" class="ml-1 text-xs text-stone-400">{{ activeGoing.length }}</span>
        </button>
        <button type="button" role="tab" :aria-selected="tab === 'hosting'" class="rounded-lg py-2"
                :class="tab === 'hosting' ? 'bg-white font-medium shadow-sm' : 'text-stone-500'" @click="tab = 'hosting'">
          我发起的<span v-if="!loading" class="ml-1 text-xs text-stone-400">{{ activeHosting.length }}</span>
        </button>
        <button type="button" role="tab" :aria-selected="tab === 'cancelled'" class="rounded-lg py-2"
                :class="tab === 'cancelled' ? 'bg-white font-medium shadow-sm' : 'text-stone-500'" @click="tab = 'cancelled'">
          已取消<span v-if="!loading" class="ml-1 text-xs text-stone-400">{{ cancelled.length }}</span>
        </button>
      </div>

      <div v-if="loading" class="grid grid-cols-2 gap-3">
        <div v-for="i in 4" :key="i" class="card h-32 animate-pulse bg-stone-100" />
      </div>
      <div v-else-if="error" class="card text-center text-sm">
        <p class="mb-3 text-red-600">{{ error }}</p>
        <button class="btn-secondary" @click="load">重试</button>
      </div>
      <div v-else-if="!list.length" class="py-16 text-center text-sm text-stone-500">
        <p class="mb-1 text-3xl">📅</p>
        <template v-if="tab === 'going'">
          <p>你还没有报名活动</p>
          <NuxtLink to="/" class="btn-primary mt-4">去发现活动</NuxtLink>
        </template>
        <template v-else-if="tab === 'hosting'">
          <p>你还没有发起过活动</p>
          <NuxtLink to="/create" class="btn-primary mt-4">发布活动</NuxtLink>
        </template>
        <p v-else>暂无已取消的活动</p>
      </div>
      <section v-else-if="tab === 'cancelled'">
        <h2 class="mb-2 text-xs font-medium text-stone-500">已取消的活动</h2>
        <p class="mb-3 text-xs text-stone-500">你发起或报名的活动取消后，会保留在这里。</p>
        <div class="grid grid-cols-2 gap-3">
          <EventCard v-for="e in cancelled" :key="e.id" :event="e" />
        </div>
      </section>
      <template v-else>
        <section v-if="upcoming.length" class="mb-5">
          <h2 class="mb-2 text-xs font-medium text-stone-500">即将开始 / 进行中</h2>
          <div class="grid grid-cols-2 gap-3">
            <EventCard v-for="e in upcoming" :key="e.id" :event="e" />
          </div>
        </section>
        <section v-if="past.length">
          <h2 class="mb-2 text-xs font-medium text-stone-500">已结束</h2>
          <div class="grid grid-cols-2 gap-3 opacity-80">
            <EventCard v-for="e in past" :key="e.id" :event="e" />
          </div>
        </section>
      </template>
    </template>
  </div>
</template>
