<script setup lang="ts">
// Landing page for the e-mail magic link; @nuxtjs/supabase exchanges the code for a session.
definePageMeta({ layout: 'bare' })
const user = useSupabaseUser()
const route = useRoute()
const target = safeRedirect(route.query.redirect, useSupabaseCookieRedirect().pluck())
watch(user, () => { if (user.value) navigateTo(target) }, { immediate: true })
</script>

<template>
  <main class="flex min-h-dvh items-center justify-center p-6 text-sm text-stone-500">正在登录…</main>
</template>
