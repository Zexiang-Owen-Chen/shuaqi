<script setup lang="ts">
import type { Database } from '~/types/database.types'
import type { ProfileCard } from '~/utils/eventFormat'

useHead({ title: '活动内找人 · SHUAQI 耍起' })

const route = useRoute()
const id = String(route.params.id)
const supabase = useSupabaseClient<Database>()
const user = useSupabaseUser()
const rpc = useRpc()
const uid = computed(() => currentUid(user.value))
const { isOn } = useFeatureFlags()
const enabled = computed(() => isOn('event_discovery'))

const ALL_FIELDS = ['bio', 'interests', 'photos', 'gender', 'age'] as const

const loading = ref(true)
const loadError = ref('')
const event = ref<{ id: string; title: string; require_checkin_for_connect: boolean; status: string } | null>(null)
const going = ref(false)
const staff = ref(false)

// My opt-in settings. Off by default.
const optedIn = ref(false)
const fields = ref<string[]>(['interests'])
const savedOptin = ref<{ opted_in: boolean; fields: string[] }>({ opted_in: false, fields: ['interests'] })
const saving = ref(false)
const optinError = ref('')
const optinNotice = ref('')
const dirty = computed(() => optedIn.value !== savedOptin.value.opted_in
  || [...fields.value].sort().join() !== [...savedOptin.value.fields].sort().join())

type Person = { card: ProfileCard; request_status: string | null }
const people = ref<Person[]>([])
const peopleLoading = ref(false)
const peopleError = ref('')

async function load() {
  loading.value = true
  loadError.value = ''
  if (!uid.value || !enabled.value) { loading.value = false; return }
  try {
    const [ev, rsvp, optin, isStaff] = await Promise.all([
      supabase.from('events').select('id, title, require_checkin_for_connect, status').eq('id', id).maybeSingle(),
      supabase.from('event_rsvps').select('status').eq('event_id', id).eq('user_id', uid.value).maybeSingle(),
      supabase.from('event_social_optin').select('opted_in, visible_fields').eq('event_id', id).eq('user_id', uid.value).maybeSingle(),
      rpc('is_event_staff', { p_event: id }).catch(() => false),
    ])
    if (ev.error) throw new Error(messageFor(ev.error))
    event.value = ev.data
    going.value = rsvp.data?.status === 'going'
    staff.value = !!isStaff
    if (optin.data) {
      optedIn.value = optin.data.opted_in
      fields.value = [...optin.data.visible_fields]
    }
    savedOptin.value = { opted_in: optedIn.value, fields: [...fields.value] }
    if (going.value || staff.value) await loadPeople()
  } catch (e) {
    loadError.value = (e as Error).message
  } finally {
    loading.value = false
  }
}

async function loadPeople() {
  peopleLoading.value = true
  peopleError.value = ''
  try {
    const rows = await rpc('list_event_participants', { p_event: id })
    people.value = (rows ?? [])
      .filter((r) => r.card)
      .map((r) => ({ card: r.card as unknown as ProfileCard, request_status: r.request_status }))
  } catch (e) {
    peopleError.value = (e as Error).message
  } finally {
    peopleLoading.value = false
  }
}

onMounted(() => { load(); watch(uid, (v, old) => { if (v !== old) load() }) })

async function saveOptin() {
  saving.value = true
  optinError.value = ''
  optinNotice.value = ''
  try {
    const res = await rpc('set_event_optin', { p_event: id, p_opted_in: optedIn.value, p_visible_fields: fields.value })
    savedOptin.value = { opted_in: res.opted_in, fields: [...res.visible_fields] }
    optinNotice.value = res.opted_in ? '已开启，同活动的人现在可以看到你' : '已关闭，你不会出现在列表里'
  } catch (e) {
    optinError.value = (e as Error).message
  } finally {
    saving.value = false
  }
}

function toggleField(f: string) {
  fields.value = fields.value.includes(f) ? fields.value.filter((x) => x !== f) : [...fields.value, f]
}

// --- Per-person actions ------------------------------------------------------------
const rowBusy = ref<string | null>(null)
const rowError = reactive<Record<string, string>>({})
const menuFor = ref<string | null>(null)

async function connect(p: Person) {
  rowBusy.value = p.card.id
  rowError[p.card.id] = ''
  try {
    const r = await rpc('send_connection_request', { p_to: p.card.id, p_context: 'event', p_context_id: id })
    p.request_status = r.status
  } catch (e) {
    rowError[p.card.id] = (e as Error).message
  } finally {
    rowBusy.value = null
  }
}

async function block(p: Person) {
  menuFor.value = null
  if (!confirm(`拉黑「${p.card.display_name || '这位同学'}」？拉黑后你们互相看不到，也无法发送请求。`)) return
  rowBusy.value = p.card.id
  try {
    await rpc('block_user', { p_target: p.card.id })
    people.value = people.value.filter((x) => x.card.id !== p.card.id)
  } catch (e) {
    rowError[p.card.id] = (e as Error).message
  } finally {
    rowBusy.value = null
  }
}

const reportTarget = ref<ProfileCard | null>(null)
const reportOpen = ref(false)
function report(p: Person) {
  menuFor.value = null
  reportTarget.value = p.card
  reportOpen.value = true
}

function requestLabel(p: Person): string | null {
  if (p.card.connected) return '已是好友'
  switch (p.request_status) {
    case 'pending': return '已发送请求'
    case 'accepted': return '已是好友'
    default: return null
  }
}
</script>

<template>
  <div class="px-4 pt-3">
    <NuxtLink :to="`/events/${id}`" class="mb-2 inline-block text-sm text-stone-500">← 返回活动</NuxtLink>
    <h1 class="mb-1 text-lg font-bold">活动内找人</h1>
    <p v-if="event" class="mb-3 truncate text-sm text-stone-500">{{ event.title }}</p>

    <FeatureOff v-if="!enabled" title="活动内找人暂时关闭了" text="现在看不到同活动的参与者列表，报名和签到不受影响。"
                :back-to="`/events/${id}`" back-label="返回活动" />

    <div v-else-if="!user" class="card text-center text-sm">
      <p class="mb-3">登录后才能看到同活动的人</p>
      <NuxtLink :to="`/login?redirect=${encodeURIComponent(route.fullPath)}`" class="btn-primary">去登录</NuxtLink>
    </div>

    <div v-else-if="loading" class="space-y-3">
      <div class="card h-28 animate-pulse bg-stone-100" />
      <div class="card h-20 animate-pulse bg-stone-100" />
    </div>

    <div v-else-if="loadError" class="card text-center text-sm">
      <p class="mb-3 text-red-600">{{ loadError }}</p>
      <button class="btn-secondary" @click="load">重试</button>
    </div>

    <div v-else-if="!event" class="py-16 text-center text-sm text-stone-500">活动不存在或你无权查看</div>

    <div v-else-if="!going && !staff" class="card text-center text-sm">
      <p class="mb-3">报名这个活动后，才能看到同样报名并愿意被发现的人</p>
      <NuxtLink :to="`/events/${id}`" class="btn-primary">去报名</NuxtLink>
    </div>

    <template v-else>
      <!-- Opt-in -->
      <section v-if="going" class="card mb-4 space-y-3">
        <label class="flex items-start justify-between gap-3">
          <span>
            <span class="block text-sm font-medium">让同活动的人看到我</span>
            <span class="block text-xs text-stone-500">
              默认关闭。开启后，报名了这个活动的人能在这里看到你的名字、头像、学校，以及你下面勾选的信息。
              不会展示任何联系方式，加好友需要双方同意。随时可以关闭。
            </span>
          </span>
          <input v-model="optedIn" type="checkbox" role="switch" class="mt-1 size-5 shrink-0 accent-brand-500"
                 aria-label="让同活动的人看到我">
        </label>

        <div v-if="optedIn">
          <p class="label">额外展示（可多选，地区始终可见）</p>
          <div class="flex flex-wrap gap-2">
            <button v-for="f in ALL_FIELDS" :key="f" type="button" class="chip"
                    :class="fields.includes(f) ? '!bg-brand-500 !text-white' : ''"
                    :aria-pressed="fields.includes(f)" @click="toggleField(f)">
              {{ fields.includes(f) ? '✓ ' : '' }}{{ VISIBLE_FIELD_LABEL[f] }}
            </button>
          </div>
        </div>

        <p v-if="optinError" class="text-sm text-red-600">{{ optinError }}</p>
        <p v-if="optinNotice && !dirty" class="text-sm text-emerald-700">{{ optinNotice }}</p>
        <button v-if="dirty" type="button" class="btn-primary w-full" :disabled="saving" @click="saveOptin">
          {{ saving ? '保存中…' : '保存设置' }}
        </button>
      </section>
      <p v-else class="mb-4 rounded-xl bg-stone-50 p-3 text-xs text-stone-500">你是这个活动的工作人员，可以查看愿意被发现的参与者。</p>

      <p v-if="event.require_checkin_for_connect" class="mb-3 rounded-xl bg-brand-50 p-3 text-xs text-brand-700">
        这个活动要求双方都在现场签到后才能加好友。
      </p>

      <!-- Participants -->
      <section>
        <div class="mb-2 flex items-center justify-between">
          <h2 class="text-sm font-semibold">愿意认识新朋友的同学</h2>
          <button type="button" class="text-xs text-stone-500" :disabled="peopleLoading" @click="loadPeople">刷新</button>
        </div>

        <div v-if="peopleLoading && !people.length" class="space-y-2">
          <div v-for="i in 3" :key="i" class="card h-20 animate-pulse bg-stone-100" />
        </div>
        <div v-else-if="peopleError" class="card text-center text-sm">
          <p class="mb-3 text-red-600">{{ peopleError }}</p>
          <button class="btn-secondary" @click="loadPeople">重试</button>
        </div>
        <div v-else-if="!people.length" class="py-10 text-center text-sm text-stone-500">
          <p class="mb-1 text-3xl">🙋</p>
          <p>还没有其他人开启</p>
          <p class="text-xs">{{ optedIn && !dirty ? '有人开启后会出现在这里' : '你可以先开启，让别人看到你' }}</p>
        </div>

        <ul v-else class="space-y-2">
          <li v-for="p in people" :key="p.card.id" class="card">
            <div class="flex items-start gap-3">
              <ProfileAvatar :url="p.card.avatar_url" :name="p.card.display_name" :size="44" />
              <div class="min-w-0 flex-1">
                <div class="flex items-center justify-between gap-2">
                  <p class="truncate font-medium">{{ p.card.display_name || '同学' }}</p>
                  <div class="relative">
                    <button type="button" class="px-2 text-stone-400" aria-label="更多操作"
                            @click="menuFor = menuFor === p.card.id ? null : p.card.id">⋯</button>
                    <div v-if="menuFor === p.card.id"
                         class="absolute right-0 z-10 mt-1 w-28 overflow-hidden rounded-xl bg-white text-sm shadow-lg ring-1 ring-stone-100">
                      <button type="button" class="block w-full px-3 py-2 text-left active:bg-stone-50" @click="block(p)">拉黑</button>
                      <button type="button" class="block w-full px-3 py-2 text-left text-red-600 active:bg-stone-50" @click="report(p)">举报</button>
                    </div>
                  </div>
                </div>
                <div class="mt-1 flex flex-wrap gap-1">
                  <ProfileSchoolBadge :domain="p.card.school_domain" :verified="p.card.school_verified" />
                  <span v-if="p.card.gender" class="chip">{{ genderLabel(p.card.gender) || p.card.gender }}</span>
                  <span v-if="p.card.age" class="chip">{{ p.card.age }} 岁</span>
                  <span v-if="p.card.region" class="chip">{{ p.card.region }}</span>
                </div>
                <p v-if="p.card.bio" class="mt-2 line-clamp-3 text-sm text-stone-700">{{ p.card.bio }}</p>
                <div v-if="p.card.interests?.length" class="mt-2 flex flex-wrap gap-1">
                  <span v-for="t in p.card.interests" :key="t" class="chip bg-brand-50 text-brand-700">{{ t }}</span>
                </div>
                <div v-if="p.card.photos?.length" class="mt-2 flex gap-1 overflow-x-auto">
                  <img v-for="ph in p.card.photos" :key="ph" :src="publicUrl('photos', ph)" alt=""
                       class="size-16 shrink-0 rounded-lg object-cover" loading="lazy">
                </div>

                <div class="mt-3">
                  <span v-if="requestLabel(p)" class="chip bg-emerald-50 text-emerald-700">{{ requestLabel(p) }}</span>
                  <button v-else type="button" class="btn-primary !py-2" :disabled="rowBusy === p.card.id" @click="connect(p)">
                    {{ rowBusy === p.card.id ? '发送中…' : '👋 加好友' }}
                  </button>
                  <p v-if="rowError[p.card.id]" class="mt-1 text-xs text-red-600">{{ rowError[p.card.id] }}</p>
                </div>
              </div>
            </div>
          </li>
        </ul>
      </section>
    </template>

    <EventReportDialog v-if="reportTarget" v-model:open="reportOpen" target-type="user"
                       :target-id="reportTarget.id" :target-name="reportTarget.display_name" />
  </div>
</template>
