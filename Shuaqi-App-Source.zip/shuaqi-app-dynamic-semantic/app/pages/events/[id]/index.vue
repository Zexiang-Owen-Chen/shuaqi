<script setup lang="ts">
import type { Database } from '~/types/database.types'
import type { ProfileCard } from '~/utils/eventFormat'

const route = useRoute()
const id = computed(() => String(route.params.id))
const supabase = useSupabaseClient<Database>()
const user = useSupabaseUser()
const rpc = useRpc()
const uid = computed(() => currentUid(user.value))
const { isOn } = useFeatureFlags()

const { data: event, status, error, refresh } = await useAsyncData(`event-${id.value}`, async () => {
  const { data, error: err } = await supabase.from('events').select('*').eq('id', id.value).maybeSingle()
  if (err) throw new Error(messageFor(err))
  return data
}, { watch: [id] })

useHead(() => ({ title: event.value ? `${event.value.title} · SHUAQI 耍起` : '活动 · SHUAQI 耍起' }))

// --- Viewer-specific state (logged-in only, fetched in the browser) ----------------
const me = reactive({
  loading: false,
  going: false,
  manager: false,
  checkedIn: false,
  goingCount: null as number | null,
  host: null as ProfileCard | null,
  orgName: '' as string,
})

async function loadViewer() {
  const e = event.value
  if (!e || !uid.value) return
  me.loading = true
  try {
    const [rsvp, manager, checked, host, org] = await Promise.all([
      supabase.from('event_rsvps').select('status').eq('event_id', e.id).eq('user_id', uid.value).maybeSingle(),
      rpc('is_event_manager', { p_event: e.id }).catch(() => false),
      rpc('is_checked_in', { p_event: e.id, p_user: uid.value }).catch(() => false),
      rpc('get_profile_card', { p_target: e.host_user_id }).catch(() => null),
      e.org_id ? supabase.from('organisations').select('name').eq('id', e.org_id).maybeSingle() : Promise.resolve(null),
    ])
    me.going = rsvp.data?.status === 'going'
    me.manager = !!manager
    me.checkedIn = !!checked
    me.host = (host as unknown as ProfileCard | null) ?? null
    me.orgName = org && 'data' in org ? (org.data?.name ?? '') : ''
    if (me.manager) {
      const { count } = await supabase.from('event_rsvps').select('user_id', { count: 'exact', head: true })
        .eq('event_id', e.id).eq('status', 'going')
      me.goingCount = count ?? null
    } else {
      me.goingCount = null
    }
  } finally {
    me.loading = false
  }
}

onMounted(() => { watch([event, uid], loadViewer, { immediate: true }) })

const isHost = computed(() => !!event.value && event.value.host_user_id === uid.value)
const over = computed(() => !!event.value && (event.value.status === 'ended' || eventIsOver(event.value)))
const cancelled = computed(() => event.value?.status === 'cancelled')
const canJoin = computed(() => !!event.value && event.value.status === 'published' && !over.value)
// qr_checkin switched off: QR events fall back to the organiser confirming attendance on site.
const selfCheckinPaused = computed(() => event.value?.checkin_mode === 'qr_geo' && !isOn('qr_checkin'))
const showPeople = computed(() => isOn('event_discovery'))
const showNearby = computed(() => isOn('nearby'))

// --- Actions ---------------------------------------------------------------------------
const busy = ref(false)
const actionError = ref('')
const notice = ref('')

function goLogin() {
  return navigateTo(`/login?redirect=${encodeURIComponent(route.fullPath)}`)
}

async function join() {
  if (!uid.value) return goLogin()
  busy.value = true; actionError.value = ''; notice.value = ''
  try {
    await rpc('join_event', { p_event: id.value })
    notice.value = '报名成功！'
    await loadViewer()
  } catch (e) { actionError.value = (e as Error).message } finally { busy.value = false }
}

async function leave() {
  if (!confirm('确定要退出这个活动吗？')) return
  busy.value = true; actionError.value = ''; notice.value = ''
  try {
    await rpc('leave_event', { p_event: id.value })
    notice.value = '已退出活动'
    await loadViewer()
  } catch (e) { actionError.value = (e as Error).message } finally { busy.value = false }
}

async function cancelEvent() {
  if (!confirm('确定取消这个活动吗？取消后无法恢复，报名的人会看到“已取消”。')) return
  busy.value = true; actionError.value = ''; notice.value = ''
  try {
    await rpc('cancel_event', { p_event: id.value })
    notice.value = '活动已取消'
    await refresh()
  } catch (e) { actionError.value = (e as Error).message } finally { busy.value = false }
}

const reportOpen = ref(false)
function openReport() {
  if (!uid.value) return goLogin()
  reportOpen.value = true
}

const mapUrl = computed(() => {
  const e = event.value
  if (!e) return ''
  if (e.location_lat != null && e.location_lng != null) {
    return `https://www.google.com/maps/search/?api=1&query=${e.location_lat},${e.location_lng}`
  }
  return e.location_text ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(e.location_text)}` : ''
})
</script>

<template>
  <div class="px-4 pt-3">
    <button type="button" class="mb-2 text-sm text-stone-500" @click="$router.back()">← 返回</button>

    <div v-if="status === 'pending' && !event" class="space-y-3">
      <div class="card h-40 animate-pulse bg-stone-100" />
      <div class="card h-24 animate-pulse bg-stone-100" />
    </div>

    <div v-else-if="error" class="card text-center text-sm">
      <p class="mb-3 text-red-600">加载失败：{{ error.message }}</p>
      <button class="btn-secondary" @click="refresh()">重试</button>
    </div>

    <div v-else-if="!event" class="py-16 text-center text-sm text-stone-500">
      <p class="mb-1 text-3xl">🔍</p>
      <p>活动不存在，或者你没有权限查看</p>
      <p v-if="!user" class="mt-2">仅本校可见的活动需要<NuxtLink :to="`/login?redirect=${encodeURIComponent(route.fullPath)}`" class="text-brand-600 underline">登录</NuxtLink>后查看</p>
      <NuxtLink to="/" class="btn-secondary mt-4">去发现活动</NuxtLink>
    </div>

    <template v-else>
      <article class="card space-y-3">
        <div class="flex flex-wrap items-center gap-1">
          <span class="chip bg-brand-50 text-brand-700">{{ event.category }}</span>
          <EventStatusBadge :status="event.status" :starts-at="event.starts_at" :ends-at="event.ends_at" />
          <span v-if="event.visibility === 'school'" class="chip">仅本校</span>
          <span v-if="event.type === 'group'" class="chip">组织活动</span>
        </div>
        <h1 class="text-lg font-bold leading-snug" :class="cancelled ? 'line-through text-stone-500' : ''">{{ event.title }}</h1>

        <div v-if="cancelled" class="rounded-xl bg-red-50 p-3 text-sm text-red-700">这个活动已被取消</div>

        <dl class="space-y-2 text-sm">
          <div class="flex gap-2"><dt class="w-5 shrink-0">🕒</dt><dd>{{ formatEventTime(event.starts_at, event.ends_at) }}<span class="text-xs text-stone-400">（伦敦时间）</span></dd></div>
          <div v-if="event.location_text" class="flex gap-2">
            <dt class="w-5 shrink-0">📍</dt>
            <dd>
              {{ event.location_text }}
              <a v-if="mapUrl" :href="mapUrl" target="_blank" rel="noopener" class="ml-1 text-xs text-brand-600 underline">地图</a>
            </dd>
          </div>
          <div class="flex gap-2">
            <dt class="w-5 shrink-0">👥</dt>
            <dd>
              <template v-if="me.goingCount !== null">已报名 {{ me.goingCount }} 人{{ event.capacity ? ` / 上限 ${event.capacity}` : '' }}</template>
              <template v-else>{{ event.capacity ? `限 ${event.capacity} 人` : '人数不限' }}</template>
            </dd>
          </div>
          <div class="flex gap-2"><dt class="w-5 shrink-0">✅</dt><dd>{{ CHECKIN_MODE_LABEL[event.checkin_mode] }}<span v-if="selfCheckinPaused" class="text-xs text-amber-700">（自助签到暂停，改由主办方现场确认）</span><span v-else-if="event.checkin_mode === 'qr_geo'" class="text-xs text-stone-400">（{{ event.checkin_radius_m }} 米内）</span></dd></div>
          <div v-if="event.require_checkin_for_connect" class="flex gap-2"><dt class="w-5 shrink-0">🤝</dt><dd>双方签到后才能加好友</dd></div>
        </dl>

        <div class="flex items-center gap-3 border-t border-stone-100 pt-3">
          <template v-if="user && me.host">
            <ProfileAvatar :url="me.host.avatar_url" :name="me.host.display_name" :size="36" />
            <div class="min-w-0 text-sm">
              <p class="truncate font-medium">{{ me.host.display_name || '发起人' }}<span v-if="isHost" class="text-stone-400">（我）</span></p>
              <p class="text-xs text-stone-500">{{ me.orgName ? `${me.orgName} · ` : '' }}发起人</p>
            </div>
          </template>
          <p v-else-if="!user" class="text-xs text-stone-500">登录后可以看到发起人信息</p>
          <p v-else-if="me.loading" class="text-xs text-stone-400">加载中…</p>
        </div>

        <EventImages :paths="event.image_paths" />
        <p v-if="event.description" class="whitespace-pre-wrap border-t border-stone-100 pt-3 text-sm leading-relaxed text-stone-700">{{ event.description }}</p>
      </article>

      <!-- Join / leave -->
      <section class="card mt-3 space-y-3">
        <p v-if="notice" class="text-sm text-emerald-700">{{ notice }}</p>
        <p v-if="actionError" class="text-sm text-red-600">{{ actionError }}</p>

        <template v-if="!user">
          <button v-if="canJoin" class="btn-primary w-full" @click="goLogin">登录后报名</button>
          <p v-else class="text-center text-sm text-stone-500">{{ cancelled ? '活动已取消' : '活动已结束' }}</p>
        </template>

        <template v-else-if="me.going">
          <div class="flex items-center justify-between">
            <span class="text-sm font-medium text-emerald-700">✓ 你已报名</span>
            <span v-if="me.checkedIn" class="chip bg-emerald-50 text-emerald-700">已签到</span>
            <span v-else-if="event.checkin_mode !== 'none'" class="chip">未签到</span>
          </div>
          <div v-if="!me.checkedIn && event.checkin_mode === 'qr_geo' && !selfCheckinPaused && !cancelled" class="space-y-2 rounded-xl bg-brand-50 p-3 text-sm text-brand-700">
            <p>到现场扫主办方的二维码签到</p>
            <NuxtLink to="/scan" class="btn-primary w-full">📷 扫码签到</NuxtLink>
          </div>
          <p v-else-if="!me.checkedIn && (event.checkin_mode === 'manual' || selfCheckinPaused) && !cancelled" class="rounded-xl bg-stone-50 p-3 text-sm text-stone-600">
            到场后由主办方为你确认签到
          </p>
          <div v-if="!cancelled && (showPeople || showNearby)" class="grid gap-2"
               :class="showPeople && showNearby ? 'grid-cols-2' : 'grid-cols-1'">
            <NuxtLink v-if="showPeople" :to="`/events/${event.id}/people`" class="btn-secondary">🙋 活动内找人</NuxtLink>
            <NuxtLink v-if="showNearby" :to="`/events/${event.id}/nearby`" class="btn-secondary">📡 附近 50m</NuxtLink>
          </div>
          <button v-if="!isHost && !over && !cancelled" class="btn-secondary w-full !text-stone-500" :disabled="busy" @click="leave">
            退出活动
          </button>
        </template>

        <template v-else>
          <button v-if="canJoin" class="btn-primary w-full" :disabled="busy || me.loading" @click="join">
            {{ busy ? '报名中…' : '报名参加' }}
          </button>
          <p v-else class="text-center text-sm text-stone-500">{{ cancelled ? '活动已取消，无法报名' : '活动已结束' }}</p>
        </template>
      </section>

      <!-- Managers -->
      <section v-if="me.manager" class="card mt-3 space-y-2">
        <h2 class="text-sm font-semibold">管理活动</h2>
        <div class="grid grid-cols-2 gap-2">
          <NuxtLink :to="`/events/${event.id}/checkin-qr`" class="btn-secondary">🔳 签到码</NuxtLink>
          <NuxtLink :to="`/organiser/events/${event.id}`" class="btn-secondary">📋 管理报名</NuxtLink>
          <NuxtLink v-if="!cancelled" :to="`/events/${event.id}/edit`" class="btn-secondary">✏️ 编辑</NuxtLink>
          <button v-if="!cancelled" type="button" class="btn-danger" :disabled="busy" @click="cancelEvent">取消活动</button>
        </div>
      </section>

      <div class="mt-4 pb-4 text-center">
        <button v-if="!isHost" type="button" class="text-xs text-stone-400 underline" @click="openReport">举报这个活动</button>
      </div>

      <EventReportDialog v-model:open="reportOpen" target-type="event" :target-id="event.id" />
    </template>
  </div>
</template>
