<script setup lang="ts">
import type { Database } from '~/types/database.types'

definePageMeta({ layout: 'bare' })
useHead({ title: '签到二维码 · SHUAQI' })

type EventRow = Pick<Database['public']['Tables']['events']['Row'],
  'id' | 'title' | 'starts_at' | 'ends_at' | 'location_text' | 'status' | 'checkin_mode'
  | 'checkin_radius_m' | 'checkin_opens_at' | 'checkin_closes_at'>

const route = useRoute()
const eventId = computed(() => String(route.params.id))
const supabase = useSupabaseClient<Database>()
const rpc = useRpc()
const { isOn } = useFeatureFlags()
const origin = useRequestURL().origin

const event = ref<EventRow | null>(null)
const code = ref<string | null>(null)
const isManager = ref(false)
const loading = ref(true)
const error = ref('')
const forbidden = ref(false)
const notice = ref('')
const rotating = ref(false)
const projector = ref(false)
const counts = ref({ going: 0, checkedIn: 0, confirmed: 0 })

const link = computed(() => (code.value ? `${origin}/checkin/${code.value}` : ''))
const window_ = computed(() => (event.value ? checkinWindow(event.value) : null))
const qr = ref<{ src: string } | null>(null)

async function load() {
  loading.value = true
  error.value = ''
  forbidden.value = false
  try {
    const staff = await rpc('is_event_staff', { p_event: eventId.value })
    if (!staff) { forbidden.value = true; return }
    const [{ data, error: e }, c, m] = await Promise.all([
      supabase.from('events')
        .select('id,title,starts_at,ends_at,location_text,status,checkin_mode,checkin_radius_m,checkin_opens_at,checkin_closes_at')
        .eq('id', eventId.value).maybeSingle(),
      rpc('get_checkin_code', { p_event: eventId.value }),
      rpc('is_event_manager', { p_event: eventId.value }),
    ])
    if (e) throw new Error(messageFor(e))
    event.value = data
    code.value = c
    isManager.value = !!m
  } catch (e) {
    error.value = (e as Error).message
  } finally {
    loading.value = false
  }
}

async function rotate() {
  if (!window.confirm('重置后旧二维码立即失效，已打印或已发出的二维码都需要换成新的。确定重置吗？')) return
  rotating.value = true
  try {
    code.value = await rpc('rotate_checkin_code', { p_event: eventId.value })
    flash('已生成新的二维码')
  } catch (e) {
    flash((e as Error).message)
  } finally {
    rotating.value = false
  }
}

async function copyLink() {
  try {
    await navigator.clipboard.writeText(link.value)
    flash('链接已复制')
  } catch {
    flash('复制失败，请长按链接手动复制')
  }
}

function download() {
  if (!qr.value?.src) return
  const a = document.createElement('a')
  a.href = qr.value.src
  a.download = `SHUAQI-签到-${event.value?.title ?? eventId.value}.png`
  a.click()
}

function printPage() {
  window.print()
}

let noticeTimer: ReturnType<typeof setTimeout> | undefined
function flash(text: string) {
  notice.value = text
  clearTimeout(noticeTimer)
  noticeTimer = setTimeout(() => { notice.value = '' }, 2500)
}

// Projector mode: full screen, keep the screen awake, hide controls.
let wakeLock: { release: () => Promise<void> } | null = null
async function enterProjector() {
  projector.value = true
  try { await document.documentElement.requestFullscreen?.() } catch { /* not supported on iPhone */ }
  try { wakeLock = await (navigator as Navigator & { wakeLock?: { request: (t: 'screen') => Promise<{ release: () => Promise<void> }> } }).wakeLock?.request('screen') ?? null } catch { /* optional */ }
}
async function exitProjector() {
  projector.value = false
  if (document.fullscreenElement) await document.exitFullscreen().catch(() => {})
  await wakeLock?.release().catch(() => {})
  wakeLock = null
}
function onFullscreenChange() {
  if (!document.fullscreenElement && projector.value) exitProjector()
}
onMounted(() => document.addEventListener('fullscreenchange', onFullscreenChange))
onBeforeUnmount(() => {
  document.removeEventListener('fullscreenchange', onFullscreenChange)
  wakeLock?.release().catch(() => {})
})

await load()
</script>

<template>
  <!-- Projector / full screen -->
  <main v-if="projector && event && code" class="fixed inset-0 z-50 flex flex-col items-center justify-center gap-6 bg-white p-6" @click="exitProjector">
    <h1 class="text-center text-3xl font-bold">{{ event.title }}</h1>
    <div class="w-[min(80vw,70vh)]"><CheckinQr :value="link" /></div>
    <p class="text-xl text-stone-700">用手机相机扫码签到</p>
    <p class="text-lg text-stone-500">已到 {{ counts.checkedIn }} / 报名 {{ counts.going }}</p>
    <p class="text-xs text-stone-300">点击任意处退出</p>
  </main>

  <main class="space-y-4 px-4 py-6 print:p-0" :class="{ hidden: projector }">
    <header class="flex items-center justify-between print:hidden">
      <NuxtLink :to="`/events/${eventId}`" class="text-sm text-stone-500">‹ 返回活动</NuxtLink>
      <span class="text-xs text-stone-400">主办方 · 签到二维码</span>
    </header>

    <div v-if="loading" class="card animate-pulse space-y-3" aria-busy="true">
      <div class="h-5 w-2/3 rounded bg-stone-100" />
      <div class="mx-auto aspect-square w-3/4 rounded-xl bg-stone-100" />
    </div>

    <div v-else-if="forbidden" class="card space-y-3 text-center">
      <p class="text-stone-700">只有活动的发起人和组织工作人员可以查看签到二维码。</p>
      <NuxtLink :to="`/events/${eventId}`" class="btn-secondary w-full">返回活动</NuxtLink>
    </div>

    <div v-else-if="error" class="card space-y-3 text-center">
      <p class="text-stone-700">{{ error }}</p>
      <button class="btn-secondary w-full" @click="load">重新加载</button>
    </div>

    <div v-else-if="!event" class="card text-center text-stone-600">活动不存在或你无权查看。</div>

    <template v-else>
      <div v-if="!isOn('qr_checkin')" class="rounded-xl bg-amber-50 p-3 text-sm text-amber-800 print:hidden">
        自助扫码签到已被管理员暂停，用户扫码后会提示找工作人员。请在<NuxtLink :to="`/organiser/events/${eventId}`" class="underline">报名管理</NuxtLink>里手动确认到场。
      </div>
      <div v-else-if="event.checkin_mode !== 'qr_geo'" class="rounded-xl bg-amber-50 p-3 text-sm text-amber-800 print:hidden">
        这个活动没有开启扫码签到，用户扫码后会提示找工作人员。请在编辑活动中把签到方式改为“扫码 + 定位”。
      </div>
      <div v-else-if="event.status !== 'published'" class="rounded-xl bg-amber-50 p-3 text-sm text-amber-800 print:hidden">
        活动发布后二维码才能使用。
      </div>

      <!-- This block is what gets printed. -->
      <section class="card space-y-3 text-center print:shadow-none print:ring-0">
        <h1 class="text-xl font-bold">{{ event.title }}</h1>
        <p class="text-sm text-stone-500">
          {{ formatLondon(event.starts_at) }}<span v-if="event.location_text"> · {{ event.location_text }}</span>
        </p>
        <div class="mx-auto w-full max-w-xs print:max-w-md">
          <CheckinQr v-if="code" ref="qr" :value="link" />
          <p v-else class="py-10 text-sm text-stone-500">还没有签到码，点“重置二维码”生成。</p>
        </div>
        <p class="text-base font-medium">用手机相机扫码签到</p>
        <p class="text-xs text-stone-500">需要先在 SHUAQI 报名，并在活动地点 {{ event.checkin_radius_m }} 米内</p>
        <p v-if="window_" class="text-xs text-stone-400">
          签到时间 {{ formatLondon(window_.opensAt.toISOString()) }} – {{ formatLondon(window_.closesAt.toISOString(), false) }}（英国时间）
        </p>
      </section>

      <div v-if="code" class="grid grid-cols-2 gap-2 print:hidden">
        <button class="btn-primary col-span-2 py-3" @click="enterProjector">全屏投屏</button>
        <button class="btn-secondary" @click="download">下载图片</button>
        <button class="btn-secondary" @click="printPage">打印</button>
        <button class="btn-secondary col-span-2 truncate" @click="copyLink">复制签到链接</button>
      </div>

      <details class="card text-sm text-stone-600 print:hidden">
        <summary class="cursor-pointer font-medium text-stone-800">使用说明</summary>
        <ul class="mt-2 list-disc space-y-1 pl-5">
          <li>二维码固定不变，可以提前打印贴在入口，或在现场投屏。</li>
          <li>用户扫码后，系统会核对报名状态和手机定位，在范围内才算“已到场（定位核验）”。</li>
          <li>定位失败的用户，可以在下面的名单里点“确认到场”，这会记为主办方核验。</li>
          <li>如果二维码被外传，点“重置二维码”，旧码立即失效。</li>
        </ul>
      </details>

      <CheckinAttendeeList class="print:hidden" :event-id="eventId" @counts="counts = $event" />

      <div v-if="isManager" class="print:hidden">
        <button class="btn-danger w-full" :disabled="rotating" @click="rotate">
          {{ rotating ? '正在重置…' : (code ? '重置二维码' : '生成二维码') }}
        </button>
      </div>
    </template>

    <p
      v-if="notice"
      class="fixed inset-x-4 bottom-6 z-40 mx-auto max-w-sm rounded-xl bg-stone-900/90 px-4 py-3 text-center text-sm text-white print:hidden"
      role="status"
    >{{ notice }}</p>
  </main>
</template>
