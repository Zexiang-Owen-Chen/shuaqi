<script setup lang="ts">
import type { Database } from '~/types/database.types'
import type { EventFormPayload, EventRow } from '~/utils/eventFormat'

useHead({ title: '编辑活动 · SHUAQI 耍起' })

const route = useRoute()
const id = String(route.params.id)
const supabase = useSupabaseClient<Database>()
const user = useSupabaseUser()
const rpc = useRpc()

const loading = ref(true)
const loadError = ref('')
const event = ref<EventRow | null>(null)
const canEdit = ref(false)
const submitting = ref(false)
const serverError = ref('')

async function load() {
  loading.value = true
  loadError.value = ''
  try {
    const { data, error } = await supabase.from('events').select('*').eq('id', id).maybeSingle()
    if (error) throw new Error(messageFor(error))
    event.value = data
    if (data && currentUid(user.value)) {
      canEdit.value = await rpc('is_event_manager', { p_event: id }).catch(() => false)
    }
  } catch (e) {
    loadError.value = (e as Error).message
  } finally {
    loading.value = false
  }
}
onMounted(load)

async function save(p: EventFormPayload) {
  submitting.value = true
  serverError.value = ''
  // org_id, type and host_user_id cannot be changed after creation.
  const { error } = await supabase.from('events').update({
    title: p.title,
    category: p.category,
    description: p.description,
    image_paths: p.image_paths,
    starts_at: p.starts_at,
    ends_at: p.ends_at,
    location_text: p.location_text,
    location_lat: p.location_lat,
    location_lng: p.location_lng,
    checkin_mode: p.checkin_mode,
    checkin_radius_m: p.checkin_radius_m,
    capacity: p.capacity,
    visibility: p.visibility,
    require_checkin_for_connect: p.require_checkin_for_connect,
  }).eq('id', id)
  submitting.value = false
  if (error) { serverError.value = messageFor(error); return }
  await navigateTo(`/events/${id}`, { replace: true })
}
</script>

<template>
  <div class="px-4 pt-3">
    <NuxtLink :to="`/events/${id}`" class="mb-2 inline-block text-sm text-stone-500">← 返回活动</NuxtLink>
    <h1 class="mb-4 text-xl font-bold">编辑活动</h1>

    <div v-if="loading" class="space-y-3">
      <div class="card h-40 animate-pulse bg-stone-100" />
      <div class="card h-24 animate-pulse bg-stone-100" />
    </div>
    <div v-else-if="loadError" class="card text-center text-sm">
      <p class="mb-3 text-red-600">{{ loadError }}</p>
      <button class="btn-secondary" @click="load">重试</button>
    </div>
    <div v-else-if="!event" class="py-16 text-center text-sm text-stone-500">活动不存在或你无权查看</div>
    <div v-else-if="!canEdit" class="card text-center text-sm text-stone-600">只有发起人或组织者可以编辑这个活动</div>
    <div v-else-if="event.status === 'cancelled'" class="card text-center text-sm text-stone-600">活动已取消，不能再编辑</div>
    <EventForm v-else mode="edit" :initial="event" :submitting="submitting" :server-error="serverError" @submit="save" />
  </div>
</template>
