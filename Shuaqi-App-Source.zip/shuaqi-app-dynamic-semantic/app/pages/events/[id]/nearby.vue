<script setup lang="ts">
import type { Database } from '~/types/database.types'
definePageMeta({ requiresBrowser: true })

const route = useRoute()
const eventId = computed(() => String(route.params.id))
const supabase = useSupabaseClient<Database>()

const { data: page, status, error: loadError } = await useAsyncData(`nearby-${eventId.value}`, async () => {
  const [{ data: event }, { data: flag }] = await Promise.all([
    supabase.from('events').select('id, title, status, ends_at').eq('id', eventId.value).maybeSingle(),
    supabase.from('feature_flags').select('enabled').eq('key', 'nearby').maybeSingle(),
  ])
  return { event, enabled: flag?.enabled ?? true }
}, { server: false })

useHead({ title: '附近的人 · SHUAQI 耍起' })
</script>

<template>
  <div class="space-y-4 p-4">
    <header class="flex items-center gap-2">
      <NuxtLink :to="`/events/${eventId}`" class="btn-secondary !px-3" aria-label="返回活动">‹</NuxtLink>
      <div class="min-w-0">
        <h1 class="text-lg font-semibold">附近的人</h1>
        <p v-if="page?.event" class="truncate text-xs text-stone-500">{{ page.event.title }}</p>
      </div>
    </header>

    <div v-if="status === 'pending' || status === 'idle'" class="card animate-pulse text-sm text-stone-400">加载中…</div>

    <div v-else-if="loadError || !page?.event" class="card text-sm text-stone-600">
      活动不存在或你无权查看。
      <NuxtLink to="/" class="mt-3 block text-brand-600">返回首页</NuxtLink>
    </div>

    <div v-else-if="!page.enabled" class="card text-sm text-stone-600">“附近的人”暂时关闭了，可以在活动页的参与者名单里添加好友。</div>

    <NearbyPanel v-else :event-id="eventId" />
  </div>
</template>
