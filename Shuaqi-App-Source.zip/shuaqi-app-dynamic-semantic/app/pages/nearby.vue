<script setup lang="ts">
// "Add friends nearby": people within 50 m, not tied to any event.
definePageMeta({ requiresBrowser: true })
const { isOn } = useFeatureFlags()
useHead({ title: '加好友 · 附近的人 · SHUAQI 耍起' })
</script>

<template>
  <div class="space-y-4 p-4">
    <header class="flex items-center gap-2">
      <NuxtLink to="/me/connections" class="btn-secondary !px-3" aria-label="返回我的好友">‹</NuxtLink>
      <div class="min-w-0">
        <h1 class="text-lg font-semibold">加好友</h1>
        <p class="text-xs text-stone-500">附近 50 米内的人</p>
      </div>
    </header>

    <div v-if="!isOn('nearby')" class="card text-sm text-stone-600">“附近的人”暂时关闭了。</div>
    <NearbyPanel v-else :event-id="null" />
  </div>
</template>
