<script setup lang="ts">
import type QrScannerType from 'qr-scanner'

definePageMeta({ layout: 'bare' })
useHead({ title: '扫码签到 · SHUAQI' })

type State = 'idle' | 'starting' | 'scanning' | 'no_camera' | 'denied' | 'insecure' | 'error' | 'stalled'

// If the camera prompt never shows, scanner.start() never settles; stop waiting after this long.
const CAMERA_START_TIMEOUT_MS = 15000

const video = ref<HTMLVideoElement | null>(null)
const fileInput = ref<HTMLInputElement | null>(null)
const state = ref<State>('idle')
const hint = ref('')
const inWeChat = ref(false)
let scanner: QrScannerType | null = null
let QrScanner: typeof QrScannerType | null = null
let done = false

async function go(raw: string) {
  if (done) return
  const code = parseCheckinCode(raw)
  if (!code) {
    hint.value = '这不是 SHUAQI 活动签到码，请扫描活动现场的二维码'
    return
  }
  done = true
  scanner?.stop()
  await navigateTo(`/checkin/${encodeURIComponent(code)}?auto=1`)
}

async function loadScanner() {
  QrScanner ??= (await import('qr-scanner')).default
  scanner ??= new QrScanner(video.value!, (r) => go(r.data), {
    preferredCamera: 'environment',
    highlightScanRegion: true,
    highlightCodeOutline: true,
    returnDetailedScanResult: true,
  })
  return scanner
}

// Nothing may be awaited before scanner.start() when this runs from a tap, or the browser no longer
// treats the camera request as user-initiated; the scanner is loaded on mount for that reason.
async function startCamera() {
  hint.value = ''
  if (!window.isSecureContext) { state.value = 'insecure'; return }
  state.value = 'starting'
  try {
    const s = scanner ?? await loadScanner()
    let timer: ReturnType<typeof setTimeout> | undefined
    const stalled = new Promise<'stalled'>((resolve) => { timer = setTimeout(() => resolve('stalled'), CAMERA_START_TIMEOUT_MS) })
    const outcome = await Promise.race([s.start().then(() => 'started' as const), stalled])
    clearTimeout(timer)
    state.value = outcome === 'started' ? 'scanning' : 'stalled'
  } catch (e) {
    const name = (e as Error)?.name ?? ''
    const msg = String((e as Error)?.message ?? e)
    state.value = name === 'NotAllowedError' || /denied|permission/i.test(msg) ? 'denied'
      : name === 'NotFoundError' || /not found/i.test(msg) ? 'no_camera' : 'error'
  }
}

async function fromPhoto(ev: Event) {
  const file = (ev.target as HTMLInputElement).files?.[0]
  if (!file) return
  hint.value = ''
  try {
    QrScanner ??= (await import('qr-scanner')).default
    const r = await QrScanner.scanImage(file, { returnDetailedScanResult: true })
    await go(r.data)
  } catch {
    hint.value = '图片里没有识别到二维码，请换一张更清晰的照片'
  } finally {
    if (fileInput.value) fileInput.value.value = ''
  }
}

// Open the camera straight away only when it is already allowed; otherwise wait for a tap so the
// browser shows its permission prompt (iOS may not show one for a request no tap started).
async function cameraGranted(): Promise<boolean> {
  try {
    return (await navigator.permissions?.query({ name: 'camera' as PermissionName }))?.state === 'granted'
  } catch {
    return false
  }
}

onMounted(async () => {
  inWeChat.value = isWeChat(navigator.userAgent)
  try {
    await loadScanner()
  } catch {
    state.value = 'error'
    return
  }
  if (await cameraGranted()) startCamera()
})
onBeforeUnmount(() => {
  scanner?.destroy()
  scanner = null
})
</script>

<template>
  <main class="flex min-h-dvh flex-col bg-stone-950 text-white">
    <header class="flex items-center justify-between px-4 py-3">
      <button type="button" class="text-sm text-stone-300" @click="$router.back()">← 返回</button>
      <span class="text-sm font-medium">扫码签到</span>
      <span class="w-10" />
    </header>

    <div class="relative mx-4 aspect-square overflow-hidden rounded-2xl bg-black">
      <video ref="video" class="size-full object-cover" playsinline muted />
      <div v-if="state === 'idle'" class="absolute inset-0 flex flex-col items-center justify-center gap-3 p-6 text-center">
        <p class="text-sm text-stone-300">扫码需要使用相机</p>
        <button type="button" class="btn-primary" @click="startCamera">📷 打开相机</button>
      </div>
      <div v-else-if="state === 'starting'" class="absolute inset-0 flex items-center justify-center text-sm text-stone-300" role="status">
        正在打开相机…
      </div>
      <div v-else-if="state !== 'scanning'" class="absolute inset-0 flex flex-col items-center justify-center gap-3 p-6 text-center" role="alert">
        <p v-if="state === 'denied'" class="text-sm">相机权限被拒绝了。请在浏览器或系统设置里允许 SHUAQI 使用相机，然后重试。</p>
        <p v-else-if="state === 'no_camera'" class="text-sm">没有找到可用的相机。可以用下面的“从相册选择”。</p>
        <p v-else-if="state === 'insecure'" class="text-sm">当前页面不是 HTTPS，浏览器不允许打开相机。</p>
        <p v-else-if="state === 'stalled'" class="text-sm">相机一直没有打开。请确认已允许浏览器使用相机，然后点重试。</p>
        <p v-else class="text-sm">相机打开失败。可以重试，或用下面的“从相册选择”。</p>
        <button v-if="state === 'denied' || state === 'error' || state === 'stalled'" type="button" class="btn-primary" @click="startCamera">重试</button>
      </div>
    </div>

    <div class="flex flex-1 flex-col gap-3 px-4 py-4">
      <p v-if="hint" class="rounded-xl bg-amber-500/15 p-3 text-sm text-amber-200" role="alert">{{ hint }}</p>
      <p v-if="inWeChat" class="rounded-xl bg-amber-500/15 p-3 text-sm text-amber-200">
        微信内可能无法打开相机和定位。请点右上角“···”，选择“在浏览器打开”。
      </p>
      <p class="text-sm text-stone-300">把活动现场的二维码放进框内，识别后会进入签到页，按提示允许定位即可。</p>
      <p class="text-xs text-stone-400">签到时会读取一次你的位置，只用来确认你在活动现场；我们只保存你与活动地点的距离，不保存具体位置。</p>
      <label class="btn-secondary mt-auto cursor-pointer text-center">
        从相册选择二维码图片
        <input ref="fileInput" type="file" accept="image/*" class="sr-only" @change="fromPhoto">
      </label>
    </div>
  </main>
</template>
