<script setup lang="ts">
import type { ChatMessage } from '~/utils/chat'

// /messages/<friend's user id>: one-to-one chat with a friend.
definePageMeta({ layout: 'bare' })

const route = useRoute()
const rpc = useRpc()
const supabase = useSupabaseClient()
const user = useSupabaseUser()
const { isOn } = useFeatureFlags()
const { refresh: refreshUnread } = useChatUnread()
const otherId = route.params.id as string
const me = computed(() => currentUid(user.value))
const enabled = computed(() => isOn('chat'))

const PAGE = 50
const card = ref<Record<string, any> | null>(null)
const conversationId = ref<string | null>(null)
const messages = ref<ChatMessage[]>([])
const loading = ref(true)
const loadError = ref('')
const hasOlder = ref(false)
const loadingOlder = ref(false)
const draft = ref('')
const sending = ref(false)
const sendError = ref('')
const selected = ref<string | null>(null)
const afterReport = ref(false)
const scroller = ref<HTMLElement | null>(null)

useHead(() => ({ title: `${card.value?.display_name || '聊天'} · SHUAQI` }))

const COLS = 'id, sender_id, body, created_at'

async function load() {
  loading.value = true
  loadError.value = ''
  try {
    card.value = await rpc('get_profile_card', { p_target: otherId, p_context: 'general' }) as Record<string, any> | null
    if (!card.value || !card.value.connected) return
    conversationId.value = await rpc('open_conversation', { p_other: otherId })
    const { data, error } = await supabase.from('messages').select(COLS)
      .eq('conversation_id', conversationId.value).order('created_at', { ascending: false }).limit(PAGE)
    if (error) throw new Error(messageFor(error))
    messages.value = mergeMessages([], data ?? [])
    hasOlder.value = (data?.length ?? 0) === PAGE
    await markRead()
    scrollToEnd()
  } catch (e) {
    loadError.value = (e as Error).message
  } finally {
    loading.value = false
  }
}

async function loadOlder() {
  if (!conversationId.value || !messages.value.length) return
  loadingOlder.value = true
  const { data } = await supabase.from('messages').select(COLS).eq('conversation_id', conversationId.value)
    .lt('created_at', messages.value[0]!.created_at).order('created_at', { ascending: false }).limit(PAGE)
  messages.value = mergeMessages(messages.value, data ?? [])
  hasOlder.value = (data?.length ?? 0) === PAGE
  loadingOlder.value = false
}

// Fallback when Realtime is not connected: fetch anything newer than what we have.
async function fetchNewer() {
  if (!conversationId.value) return
  const last = messages.value.at(-1)?.created_at
  let q = supabase.from('messages').select(COLS).eq('conversation_id', conversationId.value)
  if (last) q = q.gt('created_at', last)
  const { data } = await q.order('created_at', { ascending: true }).limit(PAGE)
  if (data?.length) receive(data)
}

function receive(incoming: ChatMessage[]) {
  const nearEnd = isNearEnd()
  messages.value = mergeMessages(messages.value, incoming)
  if (incoming.some(m => m.sender_id !== me.value) && document.visibilityState === 'visible') markRead()
  if (nearEnd || incoming.some(m => m.sender_id === me.value)) scrollToEnd()
}

async function markRead() {
  if (!conversationId.value) return
  try { await rpc('mark_conversation_read', { p_conversation: conversationId.value }) } catch { /* not fatal */ }
  refreshUnread(true)
}

function isNearEnd() {
  const el = scroller.value
  return !el || el.scrollHeight - el.scrollTop - el.clientHeight < 120
}
function scrollToEnd() {
  nextTick(() => { const el = scroller.value; if (el) el.scrollTop = el.scrollHeight })
}

async function send() {
  const body = draft.value.trim()
  if (!body || sending.value) return
  sending.value = true
  sendError.value = ''
  try {
    const m = await rpc('send_message', { p_to: otherId, p_body: body })
    draft.value = ''
    receive([m])
  } catch (e) {
    sendError.value = (e as Error).message
  } finally {
    sending.value = false
  }
}

function onKeydown(e: KeyboardEvent) {
  // Enter sends on a keyboard; Shift+Enter adds a line. IME composition (Chinese input) never sends.
  if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); send() }
}

async function block() {
  if (!confirm('拉黑后你们将互相看不到，也无法再聊天或发送请求。确定吗？')) return
  try { await rpc('block_user', { p_target: otherId }); navigateTo('/messages') } catch (e) { sendError.value = (e as Error).message }
}

let stop: (() => void) | null = null
let realtimeOk = false
let poll: ReturnType<typeof setInterval> | null = null
const onVisible = () => { if (document.visibilityState === 'visible') { fetchNewer(); markRead() } }

onMounted(async () => {
  if (!enabled.value) { loading.value = false; return }
  await load()
  if (!conversationId.value) return
  stop = subscribeToMessages(`chat-${conversationId.value}`, m => receive([m]),
    `conversation_id=eq.${conversationId.value}`, (s) => { realtimeOk = s === 'SUBSCRIBED' })
  poll = setInterval(() => { if (!realtimeOk && document.visibilityState === 'visible') fetchNewer() }, 5000)
  document.addEventListener('visibilitychange', onVisible)
})
onBeforeUnmount(() => {
  stop?.()
  if (poll) clearInterval(poll)
  document.removeEventListener('visibilitychange', onVisible)
})
</script>

<template>
  <div class="mx-auto flex h-dvh max-w-lg flex-col bg-stone-50">
    <header class="flex items-center gap-3 border-b border-stone-200 bg-white px-4 py-3">
      <NuxtLink to="/messages" class="text-xl leading-none text-stone-500" aria-label="返回消息列表">‹</NuxtLink>
      <NuxtLink v-if="card" :to="`/u/${otherId}`" class="flex min-w-0 flex-1 items-center gap-2">
        <ProfileAvatar :url="card.avatar_url" :name="card.display_name" :size="32" />
        <span class="truncate font-medium">{{ card.display_name || '未命名' }}</span>
      </NuxtLink>
      <span v-else class="flex-1 font-medium">聊天</span>
      <button v-if="card?.connected" class="text-xs text-red-600 underline" @click="block">拉黑</button>
    </header>

    <main v-if="!enabled" class="p-4">
      <FeatureOff title="聊天暂时关闭了" text="现在不能收发消息。好友关系不受影响。" back-to="/me" back-label="返回我的" />
    </main>
    <main v-else-if="loading" class="p-4 text-sm text-stone-500">加载中…</main>
    <main v-else-if="loadError" class="p-4 text-sm text-red-700">{{ loadError }}，<button class="underline" @click="load">重试</button></main>
    <main v-else-if="!card?.connected" class="p-4">
      <div class="card py-8 text-center text-sm text-stone-500">
        你们还不是好友，或已删除好友，不能聊天。
        <NuxtLink to="/messages" class="mt-3 block text-brand-600 underline">返回消息列表</NuxtLink>
      </div>
    </main>
    <template v-else>
      <main ref="scroller" class="flex-1 space-y-2 overflow-y-auto px-4 py-4" data-testid="messages">
        <div v-if="hasOlder" class="text-center">
          <button class="text-xs text-stone-500 underline" :disabled="loadingOlder" @click="loadOlder">{{ loadingOlder ? '加载中…' : '查看更早的消息' }}</button>
        </div>
        <p v-if="!messages.length" class="py-10 text-center text-sm text-stone-400">打个招呼吧。消息只有你们两人能看到。</p>
        <template v-for="(m, i) in messages" :key="m.id">
          <p v-if="showTimeDivider(messages[i - 1], m)" class="pt-2 text-center text-[11px] text-stone-400">
            {{ formatDividerTime(m.created_at) }}
          </p>
          <div class="flex flex-col" :class="m.sender_id === me ? 'items-end' : 'items-start'">
            <button type="button" class="max-w-[80%] whitespace-pre-wrap break-words rounded-2xl px-3 py-2 text-left text-sm"
                    :class="m.sender_id === me ? 'bg-brand-500 text-white' : 'bg-white text-stone-800 shadow-sm'"
                    data-testid="message" @click="selected = selected === m.id ? null : m.id">{{ m.body }}</button>
            <div v-if="selected === m.id && m.sender_id !== me" class="mt-1 px-1">
              <ProfileReportButton target-type="message" :target-id="m.id" label="举报这条消息" @reported="afterReport = true" />
            </div>
          </div>
        </template>
      </main>
      <div v-if="afterReport" class="flex items-center gap-3 border-t border-stone-200 bg-white px-4 py-2 text-xs text-stone-600">
        <span class="flex-1">已举报。不想再收到对方的消息？</span>
        <button class="text-red-600 underline" @click="block">拉黑对方</button>
        <button class="text-stone-400" @click="afterReport = false">关闭</button>
      </div>
      <form class="border-t border-stone-200 bg-white px-3 pt-2" style="padding-bottom: calc(0.5rem + env(safe-area-inset-bottom))" @submit.prevent="send">
        <p v-if="sendError" class="mb-1 text-xs text-red-700">{{ sendError }}</p>
        <div class="flex items-end gap-2">
          <textarea v-model="draft" rows="1" :maxlength="MESSAGE_MAX" class="input max-h-32 min-h-10 flex-1 resize-none"
                    placeholder="发消息…" aria-label="消息内容" @keydown="onKeydown" />
          <button class="btn-primary shrink-0 px-4" :disabled="sending || !draft.trim()">发送</button>
        </div>
        <p v-if="draft.length > MESSAGE_MAX - 100" class="mt-1 text-right text-[11px] text-stone-400">{{ draft.length }}/{{ MESSAGE_MAX }}</p>
      </form>
    </template>
  </div>
</template>
