<script setup lang="ts">
useHead({ title: '消息 · SHUAQI' })

const rpc = useRpc()
const user = useSupabaseUser()
const { isOn } = useFeatureFlags()
const enabled = computed(() => isOn('chat'))
const { refresh: refreshUnread } = useChatUnread()

const { data, pending, error, refresh } = await useAsyncData('conversations',
  () => (enabled.value ? rpc('list_my_conversations') : Promise.resolve([])))
const list = computed(() => (data.value ?? []).filter(c => c.card))
const me = computed(() => currentUid(user.value))

// New messages move their conversation to the top and bump its unread count.
let stop: (() => void) | null = null
onMounted(() => {
  if (enabled.value) stop = subscribeToMessages('conversation-list', () => { refresh(); refreshUnread(true) })
})
onBeforeUnmount(() => stop?.())
</script>

<template>
  <main class="space-y-3 px-4 py-6">
    <div class="flex items-center justify-between">
      <h1 class="text-xl font-semibold">消息</h1>
      <NuxtLink to="/me/connections" class="text-sm text-brand-600">好友列表</NuxtLink>
    </div>
    <FeatureOff v-if="!enabled" title="聊天暂时关闭了" text="现在不能收发消息。好友关系不受影响。" back-to="/me" back-label="返回我的" />
    <template v-else>
      <PushOptIn text="好友发来消息时，即使没打开 SHUAQI 也能收到通知。" />
      <p v-if="pending" class="text-sm text-stone-500">加载中…</p>
      <p v-else-if="error" class="text-sm text-red-700">加载失败，<button class="underline" @click="refresh()">重试</button></p>
      <div v-else-if="!list.length" class="card py-8 text-center text-sm text-stone-500">
        还没有聊天。只能和好友聊天，去<NuxtLink to="/me/connections" class="text-brand-600 underline">好友列表</NuxtLink>里打个招呼吧。
      </div>
      <ul v-else class="card divide-y divide-stone-100 p-0">
        <li v-for="c in list" :key="c.conversation_id">
          <NuxtLink :to="`/messages/${c.other_id}`" class="flex items-center gap-3 px-4 py-3" data-testid="conversation">
            <ProfileAvatar :url="(c.card as any).avatar_url" :name="(c.card as any).display_name" :size="44" />
            <div class="min-w-0 flex-1">
              <div class="flex items-baseline gap-2">
                <span class="truncate font-medium">{{ (c.card as any).display_name || '未命名' }}</span>
                <span class="ml-auto shrink-0 text-xs text-stone-400">{{ formatChatTime(c.last_message_at) }}</span>
              </div>
              <div class="flex items-center gap-2">
                <p class="min-w-0 flex-1 truncate text-sm text-stone-500">
                  <template v-if="c.last_sender_id === me">我：</template>{{ c.last_body }}
                </p>
                <span v-if="c.unread" class="shrink-0 rounded-full bg-red-500 px-1.5 text-[11px] font-medium leading-5 text-white">
                  {{ unreadLabel(c.unread) }}<span class="sr-only"> 条未读</span>
                </span>
              </div>
            </div>
          </NuxtLink>
        </li>
      </ul>
      <p class="text-xs text-stone-400">消息只有你和好友能看到，保存 12 个月；删除好友或拉黑后对话会隐藏。</p>
    </template>
  </main>
</template>
