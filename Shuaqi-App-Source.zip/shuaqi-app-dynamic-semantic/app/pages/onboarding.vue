<script setup lang="ts">
definePageMeta({ layout: 'bare' })
const { profile, refresh } = useProfile()
const route = useRoute()
const target = typeof route.query.redirect === 'string' && route.query.redirect.startsWith('/') ? route.query.redirect : '/'
await refresh()
async function done() { await refresh(); navigateTo(target) }
</script>

<template>
  <main class="px-5 py-8">
    <h1 class="text-2xl font-bold">完善资料</h1>
    <p class="mt-1 text-sm text-stone-500">这些信息帮助你在活动和找搭子时被认识。之后可以随时修改，也可以设置谁能看到。</p>
    <div v-if="profile" class="mt-6"><ProfileForm :profile="profile" submit-label="开始使用" @saved="done" /></div>
    <p v-else class="mt-6 text-sm text-stone-500">加载中…</p>
  </main>
</template>
