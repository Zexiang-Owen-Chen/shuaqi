<script setup lang="ts">
import type { Database } from '~/types/database.types'
import type { EventFormPayload } from '~/utils/eventFormat'

useHead({ title: '发布活动 · SHUAQI 耍起' })

const supabase = useSupabaseClient<Database>()
const user = useSupabaseUser()
const rpc = useRpc()
const { isOn } = useFeatureFlags()
const submitting = ref(false)
const serverError = ref('')

// peer_event_creation switched off: only org owners/organisers (and admins) can still publish.
const peerOpen = computed(() => isOn('peer_event_creation'))
const access = reactive({ checking: false, admin: false, organiser: false })
async function checkAccess() {
  if (peerOpen.value || !user.value) return
  access.checking = true
  try {
    const [admin, orgs] = await Promise.all([
      rpc('is_admin').catch(() => false),
      rpc('my_organisations').catch(() => []),
    ])
    access.admin = !!admin
    access.organiser = (orgs ?? []).some((o) => o.role === 'owner' || o.role === 'organiser')
  } finally {
    access.checking = false
  }
}
onMounted(() => { watch([peerOpen, user], checkAccess, { immediate: true }) })
const canCreate = computed(() => peerOpen.value || access.admin || access.organiser)

async function create(p: EventFormPayload) {
  const uid = currentUid(user.value)
  if (!uid) return navigateTo('/login?redirect=/create')
  submitting.value = true
  serverError.value = ''
  const { data, error } = await supabase.from('events').insert({
    host_user_id: uid,
    org_id: p.org_id,
    type: p.org_id ? 'group' : 'peer',
    title: p.title,
    category: p.category,
    description: p.description,
    image_paths: p.image_paths,
    starts_at: p.starts_at,
    ends_at: p.ends_at,
    location_text: p.location_text,
    location_lat: p.location_lat,
    location_lng: p.location_lng,
    checkin_mode: p.checkin_mode,
    checkin_radius_m: p.checkin_radius_m,
    capacity: p.capacity,
    visibility: p.visibility,
    require_checkin_for_connect: p.require_checkin_for_connect,
  }).select('id').single()
  submitting.value = false
  if (error || !data) { serverError.value = messageFor(error); return }
  await navigateTo(`/events/${data.id}`, { replace: true })
}
</script>

<template>
  <div class="px-4 pt-4">
    <h1 class="mb-1 text-xl font-bold">发布活动</h1>
    <p class="mb-4 text-sm text-stone-500">发起一个线下活动，和同学一起耍起来</p>
    <div v-if="!user" class="card text-center text-sm">
      <p class="mb-3">登录并验证学校邮箱后才能发布活动</p>
      <NuxtLink to="/login?redirect=/create" class="btn-primary">去登录</NuxtLink>
    </div>
    <div v-else-if="access.checking" class="card h-40 animate-pulse bg-stone-100" />
    <FeatureOff v-else-if="!canCreate" title="暂时只有组织者可以发布活动"
                text="个人发布活动暂时关闭了。你仍然可以报名参加别人发布的活动。" />
    <template v-else>
      <p v-if="!peerOpen" class="mb-3 rounded-xl bg-amber-50 p-3 text-sm text-amber-800">个人发布暂时关闭，现在只能以组织的名义发布活动。</p>
      <EventForm mode="create" :submitting="submitting" :server-error="serverError" :require-org="!peerOpen && !access.admin" @submit="create" />
    </template>
  </div>
</template>
