<script setup lang="ts">
import type { Database } from '~/types/database.types'
import { EVIDENCE_TYPE_TEXT, VERIFICATION_TEXT, formatDateTime } from '~/components/organiser/-format'

definePageMeta({ layout: false })
useHead({ title: '活动与证据 · SHUAQI 后台' })

type EventRow = Database['public']['Tables']['events']['Row']
type Evidence = Database['public']['Tables']['participation_evidence']['Row']
type VStatus = Database['public']['Enums']['verification_status']

const supabase = useSupabaseClient<Database>()
const rpc = useRpc()

const events = ref<EventRow[]>([])
const search = ref('')
const loading = ref(true)
const error = ref<string | null>(null)

const openId = ref<string | null>(null)
const evidence = shallowRef<Evidence[]>([])
const names = ref<Record<string, string>>({})
const evLoading = ref(false)
const edit = ref<Record<string, { status: VStatus, note: string }>>({})
const busy = ref<string | null>(null)
const msg = ref<string | null>(null)

async function load() {
  loading.value = true
  error.value = null
  let q = supabase.from('events').select('*').order('starts_at', { ascending: false }).limit(100)
  const s = search.value.trim()
  if (s) q = q.ilike('title', `%${s.replace(/[%_\\]/g, m => `\\${m}`)}%`)
  const { data, error: e } = await q
  error.value = e ? messageFor(e) : null
  events.value = data ?? []
  loading.value = false
}
onMounted(load)

async function openEvent(id: string) {
  if (openId.value === id) { openId.value = null; return }
  openId.value = id
  evLoading.value = true
  msg.value = null
  const { data, error: e } = await supabase.from('participation_evidence').select('*').eq('event_id', id).order('occurred_at')
  if (e) msg.value = messageFor(e)
  evidence.value = data ?? []
  for (const x of evidence.value) edit.value[x.id] = { status: x.verification_status, note: '' }
  const ids = [...new Set(evidence.value.flatMap(x => [x.subject_user_id, x.operator_id]).filter(Boolean) as string[])]
  if (ids.length) {
    const { data: p } = await supabase.from('profiles').select('id, display_name, school_domain').in('id', ids)
    names.value = { ...names.value, ...Object.fromEntries((p ?? []).map(x => [x.id, `${x.display_name || '未填写昵称'}（${x.school_domain ?? '—'}）`])) }
  }
  evLoading.value = false
}

async function save(x: Evidence) {
  const f = edit.value[x.id]!
  if (!f.note.trim()) { msg.value = '请填写修改原因，会写入审计记录'; return }
  busy.value = x.id
  msg.value = null
  try {
    await rpc('admin_set_evidence_status', { p_evidence: x.id, p_status: f.status, p_note: f.note.trim() })
    evidence.value = evidence.value.map(e => (e.id === x.id ? { ...e, verification_status: f.status } : e))
    f.note = ''
    msg.value = '已更新'
  } catch (e) {
    msg.value = (e as Error).message
  } finally {
    busy.value = null
  }
}
</script>

<template>
  <AdminPage title="活动与证据">
    <form class="mb-3 flex gap-2" @submit.prevent="load">
      <input v-model="search" class="input max-w-72" placeholder="按标题搜索活动">
      <button class="btn-secondary">搜索</button>
    </form>
    <OrganiserState :loading="loading" :error="error" :empty="!events.length" empty-text="没有找到活动" @retry="load">
      <ul class="space-y-2">
        <li v-for="e in events" :key="e.id" class="card text-sm">
          <div class="flex flex-wrap items-center gap-2">
            <OrganiserStatusBadge kind="event" :value="e.status" />
            <span class="font-medium">{{ e.title }}</span>
            <span class="text-xs text-stone-500">{{ formatDateTime(e.starts_at) }}</span>
            <div class="ml-auto flex gap-2">
              <NuxtLink :to="`/organiser/events/${e.id}`" class="btn-secondary py-1.5">名单</NuxtLink>
              <button class="btn-secondary py-1.5" @click="openEvent(e.id)">{{ openId === e.id ? '收起证据' : '参与证据' }}</button>
            </div>
          </div>
          <div v-if="openId === e.id" class="mt-3 space-y-2 border-t border-stone-100 pt-3">
            <p v-if="evLoading" class="text-stone-400">加载中…</p>
            <p v-else-if="!evidence.length" class="text-stone-500">这个活动还没有参与证据。</p>
            <p v-if="msg" class="text-xs text-amber-700">{{ msg }}</p>
            <div v-for="x in evidence" :key="x.id" class="flex flex-wrap items-center gap-2 rounded-xl bg-stone-50 p-2">
              <div class="min-w-48 flex-1">
                <p>{{ names[x.subject_user_id] ?? x.subject_user_id }}</p>
                <p class="text-xs text-stone-500">
                  {{ EVIDENCE_TYPE_TEXT[x.type] ?? x.type }} · {{ formatDateTime(x.occurred_at) }}
                  <template v-if="x.geo_distance_m !== null"> · {{ Math.round(x.geo_distance_m) }}m ±{{ Math.round(x.geo_accuracy_m ?? 0) }}m</template>
                  <template v-if="x.operator_id && x.operator_id !== x.subject_user_id"> · 操作人 {{ names[x.operator_id] ?? x.operator_id }}</template>
                </p>
              </div>
              <OrganiserStatusBadge kind="checkin" :value="x.verification_status" />
              <select v-model="edit[x.id]!.status" class="input w-28 py-1">
                <option v-for="(t, k) in VERIFICATION_TEXT" :key="k" :value="k">{{ t }}</option>
              </select>
              <input v-model="edit[x.id]!.note" class="input w-48 py-1" placeholder="修改原因（必填）">
              <button class="btn-primary py-1" :disabled="busy === x.id || edit[x.id]!.status === x.verification_status" @click="save(x)">保存</button>
            </div>
          </div>
        </li>
      </ul>
    </OrganiserState>
  </AdminPage>
</template>
