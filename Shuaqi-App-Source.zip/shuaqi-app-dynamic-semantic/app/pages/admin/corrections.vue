<script setup lang="ts">
import type { Database } from '~/types/database.types'
import { EVIDENCE_TYPE_TEXT, VERIFICATION_TEXT, formatDateTime } from '~/components/organiser/-format'

definePageMeta({ layout: false })
useHead({ title: '证据更正 · SHUAQI 后台' })

type Correction = Database['public']['Tables']['evidence_corrections']['Row']
type Evidence = Database['public']['Tables']['participation_evidence']['Row']
type VStatus = Database['public']['Enums']['verification_status']
interface Item extends Correction { evidence: (Evidence & { events: { title: string } | null }) | null }

const supabase = useSupabaseClient<Database>()
const rpc = useRpc()

const items = shallowRef<Item[]>([])
const names = ref<Record<string, string>>({})
const loading = ref(true)
const error = ref<string | null>(null)
const filter = ref<'pending' | 'all'>('pending')
const form = ref<Record<string, { status: VStatus, note: string }>>({})
const busy = ref<string | null>(null)

async function load() {
  loading.value = true
  error.value = null
  try {
    let q = supabase.from('evidence_corrections')
      .select('*, evidence:participation_evidence(*, events(title))')
      .order('created_at', { ascending: false }).limit(200)
    if (filter.value === 'pending') q = q.eq('status', 'pending')
    const { data, error: e } = await q
    if (e) throw new Error(messageFor(e))
    items.value = (data ?? []) as unknown as Item[]
    for (const c of items.value) form.value[c.id] ??= { status: c.evidence?.verification_status === 'revoked' ? 'verified' : 'revoked', note: '' }
    const ids = [...new Set(items.value.flatMap(c => [c.requested_by, c.evidence?.subject_user_id]).filter(Boolean) as string[])]
    if (ids.length) {
      const { data: p } = await supabase.from('profiles').select('id, display_name').in('id', ids)
      names.value = Object.fromEntries((p ?? []).map(x => [x.id, x.display_name || '未填写昵称']))
    }
  } catch (err) {
    error.value = (err as Error).message
  } finally {
    loading.value = false
  }
}
onMounted(load)
watch(filter, load)

async function resolve(c: Item, approve: boolean) {
  const f = form.value[c.id]!
  if (!f.note.trim()) { error.value = '请填写处理说明，会写入审计记录'; return }
  busy.value = c.id
  error.value = null
  try {
    await rpc('admin_resolve_correction', {
      p_correction: c.id, p_approve: approve, p_new_status: approve ? f.status : undefined, p_note: f.note.trim(),
    })
    await load()
  } catch (e) {
    error.value = (e as Error).message
  } finally {
    busy.value = null
  }
}
</script>

<template>
  <AdminPage title="证据更正">
    <div class="mb-3 flex gap-1 text-sm">
      <button v-for="f in ([['pending', '待处理'], ['all', '全部']] as const)" :key="f[0]" class="rounded-lg px-3 py-1.5"
              :class="filter === f[0] ? 'bg-stone-800 text-white' : 'bg-stone-100 text-stone-600'" @click="filter = f[0]">{{ f[1] }}</button>
    </div>
    <OrganiserState :loading="loading" :error="error" :empty="!items.length" empty-text="没有待处理的更正申请" @retry="load">
      <ul class="space-y-3">
        <li v-for="c in items" :key="c.id" class="card space-y-2 text-sm">
          <div class="flex flex-wrap items-center gap-2">
            <OrganiserStatusBadge kind="correction" :value="c.status" />
            <span class="font-medium">{{ names[c.requested_by] ?? '用户' }} 申请更正</span>
            <span class="ml-auto text-xs text-stone-400">{{ formatDateTime(c.created_at) }}</span>
          </div>
          <p v-if="c.evidence" class="text-stone-600">
            {{ c.evidence.events?.title ?? '一对一计划' }} · {{ EVIDENCE_TYPE_TEXT[c.evidence.type] ?? c.evidence.type }} ·
            当前状态 <b>{{ VERIFICATION_TEXT[c.evidence.verification_status] }}</b> · {{ formatDateTime(c.evidence.occurred_at) }}
          </p>
          <p class="whitespace-pre-wrap rounded-xl bg-stone-50 p-3">{{ c.reason }}</p>
          <div v-if="c.status === 'pending'" class="flex flex-wrap items-center gap-2">
            <label class="text-xs text-stone-500">通过后改为</label>
            <select v-model="form[c.id]!.status" class="input w-32 py-1.5">
              <option v-for="(t, k) in VERIFICATION_TEXT" :key="k" :value="k">{{ t }}</option>
            </select>
            <input v-model="form[c.id]!.note" class="input max-w-md flex-1" placeholder="处理说明（必填）">
            <button class="btn-primary" :disabled="busy === c.id" @click="resolve(c, true)">通过</button>
            <button class="btn-secondary" :disabled="busy === c.id" @click="resolve(c, false)">拒绝</button>
          </div>
          <p v-else class="text-xs text-stone-400">{{ formatDateTime(c.resolved_at) }} 处理<template v-if="c.resolution_note">：{{ c.resolution_note }}</template></p>
        </li>
      </ul>
    </OrganiserState>
  </AdminPage>
</template>
