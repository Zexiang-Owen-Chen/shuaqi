<script setup lang="ts">
import type { Database } from '~/types/database.types'

definePageMeta({ layout: false })
useHead({ title: '组织 · SHUAQI 后台' })

type Org = Database['public']['Tables']['organisations']['Row']

const supabase = useSupabaseClient<Database>()
const rpc = useRpc()

const orgs = ref<Org[]>([])
const loading = ref(true)
const error = ref<string | null>(null)
const name = ref('')
const ownerEmail = ref('')
const creating = ref(false)
const msg = ref<{ ok: boolean, text: string } | null>(null)

async function load() {
  loading.value = true
  const { data, error: e } = await supabase.from('organisations').select('*').order('name')
  error.value = e ? messageFor(e) : null
  orgs.value = data ?? []
  loading.value = false
}
onMounted(load)

async function create() {
  const n = name.value.trim()
  if (!n) return
  creating.value = true
  msg.value = null
  try {
    const { data, error: e } = await supabase.from('organisations').insert({ name: n }).select('*').single()
    if (e) throw new Error(messageFor(e))
    if (ownerEmail.value.trim()) {
      try {
        await rpc('add_org_member', { p_org: data.id, p_email: ownerEmail.value.trim(), p_role: 'owner' })
      } catch (err) {
        msg.value = { ok: false, text: `组织已创建，但添加负责人失败：${(err as Error).message}` }
      }
    }
    msg.value ??= { ok: true, text: `已创建「${n}」` }
    name.value = ''
    ownerEmail.value = ''
    await load()
  } catch (err) {
    msg.value = { ok: false, text: (err as Error).message }
  } finally {
    creating.value = false
  }
}

async function toggleVerified(o: Org) {
  const { error: e } = await supabase.from('organisations').update({ verified: !o.verified }).eq('id', o.id)
  if (e) msg.value = { ok: false, text: messageFor(e) }
  else o.verified = !o.verified
}
</script>

<template>
  <AdminPage title="组织">
    <section class="card mb-4 space-y-2">
      <h2 class="font-medium">新建组织</h2>
      <div class="flex flex-wrap gap-2">
        <input v-model="name" class="input max-w-64" maxlength="80" placeholder="组织名称，如 UCL CSSA">
        <input v-model="ownerEmail" type="email" class="input max-w-72" placeholder="负责人邮箱（可选，需已注册）">
        <button class="btn-primary" :disabled="creating || !name.trim()" @click="create">{{ creating ? '创建中…' : '创建' }}</button>
      </div>
    </section>
    <p v-if="msg" class="mb-3 text-sm" :class="msg.ok ? 'text-green-700' : 'text-red-700'">{{ msg.text }}</p>
    <OrganiserState :loading="loading" :error="error" :empty="!orgs.length" empty-text="还没有组织" @retry="load">
      <ul class="divide-y divide-stone-100 overflow-hidden rounded-2xl bg-white ring-1 ring-stone-100">
        <li v-for="o in orgs" :key="o.id" class="flex flex-wrap items-center gap-3 px-4 py-3 text-sm">
          <span class="flex-1 font-medium">{{ o.name }}</span>
          <label class="flex items-center gap-1 text-xs text-stone-600">
            <input type="checkbox" :checked="o.verified" @change="toggleVerified(o)"> 已认证
          </label>
          <NuxtLink :to="`/organiser/orgs/${o.id}`" class="btn-secondary py-1.5">成员</NuxtLink>
        </li>
      </ul>
    </OrganiserState>
  </AdminPage>
</template>
