<script setup lang="ts">
import type { Database } from '~/types/database.types'

definePageMeta({ layout: false })
useHead({ title: '推荐算法 · SHUAQI 后台' })

type Settings = Database['public']['Tables']['recommendation_settings']['Row']
interface Providers {
  configured: Record<string, boolean>
  serviceKey: boolean
  defaults: { llm: Record<string, string>; embedding: Record<string, string> }
}

const LLM = [
  ['none', '不使用（只按关键词规则理解搜索）'],
  ['openai', 'OpenAI'],
  ['anthropic', 'Anthropic Claude'],
  ['openai_compatible', 'OpenAI 兼容接口（如 DeepSeek、通义千问）'],
] as const
const EMBEDDING = [
  ['none', '不使用（不做语义相似度）'],
  ['openai', 'OpenAI'],
  ['openai_compatible', 'OpenAI 兼容接口'],
] as const
const ENV: Record<string, string> = {
  openai: 'OPENAI_API_KEY',
  anthropic: 'ANTHROPIC_API_KEY',
  openai_compatible: 'LLM_COMPAT_BASE_URL 和 LLM_COMPAT_API_KEY',
}

const supabase = useSupabaseClient<Database>()
const form = reactive({ llm_provider: 'none', llm_model: '', embedding_provider: 'none', embedding_model: '' })
const saved = ref<Settings | null>(null)
const providers = ref<Providers | null>(null)
const loading = ref(true)
const saving = ref(false)
const error = ref<string | null>(null)
const notice = ref<string | null>(null)

async function load() {
  loading.value = true
  error.value = null
  try {
    const [s, p] = await Promise.all([
      supabase.from('recommendation_settings').select('*').single(),
      $fetch<Providers>('/api/recommendations/providers'),
    ])
    if (s.error) throw new Error(messageFor(s.error))
    saved.value = s.data
    Object.assign(form, {
      llm_provider: s.data.llm_provider, llm_model: s.data.llm_model,
      embedding_provider: s.data.embedding_provider, embedding_model: s.data.embedding_model,
    })
    providers.value = p
  } catch (e) {
    error.value = (e as Error).message
  } finally {
    loading.value = false
  }
}
onMounted(load)

const missingKey = (provider: string) => provider !== 'none' && providers.value && !providers.value.configured[provider]

async function save() {
  saving.value = true
  notice.value = null
  error.value = null
  const { error: e } = await supabase.from('recommendation_settings')
    .update({ ...form, llm_model: form.llm_model.trim(), embedding_model: form.embedding_model.trim() })
    .eq('id', true)
  if (e) error.value = e.code === '23514' ? '模型名只能包含字母、数字和 . _ : / -' : messageFor(e)
  else { notice.value = '已保存，下一次搜索起生效。'; await load() }
  saving.value = false
}
</script>

<template>
  <AdminPage title="推荐算法">
    <OrganiserState :loading="loading" :error="error && !saved ? error : null" :empty="false" @retry="load">
      <form class="space-y-4" @submit.prevent="save">
        <section class="card space-y-3">
          <h2 class="font-semibold">理解搜索的语言模型</h2>
          <p class="text-xs text-stone-500">
            只把搜索文字和当前时间发给模型，不发送用户身份。模型只能提出筛选条件，系统会再校验一遍；模型不可用时自动退回关键词规则。
          </p>
          <label class="label" for="llm-provider">提供方</label>
          <select id="llm-provider" v-model="form.llm_provider" class="input">
            <option v-for="[k, l] in LLM" :key="k" :value="k">{{ l }}</option>
          </select>
          <template v-if="form.llm_provider !== 'none'">
            <label class="label" for="llm-model">模型</label>
            <input id="llm-model" v-model="form.llm_model" class="input" maxlength="80"
                   :placeholder="providers?.defaults.llm[form.llm_provider] || '填写模型名'">
            <p v-if="missingKey(form.llm_provider)" class="text-xs text-amber-700">
              服务器还没有配置 {{ ENV[form.llm_provider] }}，保存后也不会调用这个模型。
            </p>
          </template>
        </section>

        <section class="card space-y-3">
          <h2 class="font-semibold">语义相似度（向量）</h2>
          <p class="text-xs text-stone-500">把活动文字转成向量，按意思而不是字面匹配。换模型后会重新计算。</p>
          <label class="label" for="emb-provider">提供方</label>
          <select id="emb-provider" v-model="form.embedding_provider" class="input">
            <option v-for="[k, l] in EMBEDDING" :key="k" :value="k">{{ l }}</option>
          </select>
          <template v-if="form.embedding_provider !== 'none'">
            <label class="label" for="emb-model">模型</label>
            <input id="emb-model" v-model="form.embedding_model" class="input" maxlength="80"
                   :placeholder="providers?.defaults.embedding[form.embedding_provider] || '填写模型名'">
            <p v-if="missingKey(form.embedding_provider)" class="text-xs text-amber-700">
              服务器还没有配置 {{ ENV[form.embedding_provider] }}。
            </p>
            <p v-if="providers && !providers.serviceKey" class="text-xs text-amber-700">
              服务器没有配置 NUXT_SUPABASE_SECRET_KEY，活动向量无法缓存，只有本次请求里新算的活动有语义分。
            </p>
          </template>
        </section>

        <p v-if="error && saved" class="text-sm text-red-700">{{ error }}</p>
        <p v-if="notice" class="text-sm text-green-700">{{ notice }}</p>
        <button class="btn-primary" :disabled="saving">{{ saving ? '保存中…' : '保存' }}</button>
        <p v-if="saved?.updated_at" class="text-xs text-stone-400">上次修改：{{ new Date(saved.updated_at).toLocaleString('zh-CN') }}</p>
      </form>
    </OrganiserState>
  </AdminPage>
</template>
