<script setup lang="ts">
import type { Database } from '~/types/database.types'

definePageMeta({ layout: false })
useHead({ title: '管理员 · SHUAQI 后台' })

const supabase = useSupabaseClient<Database>()
const counts = ref<Record<string, number | null>>({ reports: null, corrections: null, events: null, orgs: null })
const flagsOff = ref<string[]>([])
const error = ref<string | null>(null)

onMounted(async () => {
  try {
    const head = { count: 'exact' as const, head: true }
    const [r, c, e, o, f] = await Promise.all([
      supabase.from('reports').select('id', head).in('status', ['open', 'reviewing']),
      supabase.from('evidence_corrections').select('id', head).eq('status', 'pending'),
      supabase.from('events').select('id', head).eq('status', 'published').gte('starts_at', new Date(Date.now() - 6 * 3600_000).toISOString()),
      supabase.from('organisations').select('id', head),
      supabase.from('feature_flags').select('key, enabled'),
    ])
    for (const x of [r, c, e, o, f]) if (x.error) throw new Error(messageFor(x.error))
    counts.value = { reports: r.count, corrections: c.count, events: e.count, orgs: o.count }
    flagsOff.value = (f.data ?? []).filter(x => !x.enabled).map(x => x.key)
  } catch (err) {
    error.value = (err as Error).message
  }
})

const cards = computed(() => [
  { to: '/admin/reports', label: '待处理举报', value: counts.value.reports, warn: (counts.value.reports ?? 0) > 0 },
  { to: '/admin/corrections', label: '待处理证据更正', value: counts.value.corrections, warn: (counts.value.corrections ?? 0) > 0 },
  { to: '/admin/events', label: '进行中和即将开始的活动', value: counts.value.events, warn: false },
  { to: '/admin/orgs', label: '组织', value: counts.value.orgs, warn: false },
])
</script>

<template>
  <AdminPage title="管理员">
    <p v-if="error" class="card mb-3 text-sm text-red-700">{{ error }}</p>
    <div class="grid gap-3 sm:grid-cols-4">
      <NuxtLink v-for="c in cards" :key="c.to" :to="c.to" class="card hover:ring-brand-500">
        <p class="text-xs text-stone-500">{{ c.label }}</p>
        <p class="text-2xl font-semibold" :class="c.warn ? 'text-amber-600' : ''">{{ c.value ?? '…' }}</p>
      </NuxtLink>
    </div>
    <NuxtLink to="/admin/flags" class="card mt-3 block text-sm">
      <template v-if="flagsOff.length">⚠️ 已关闭的功能：{{ flagsOff.join('、') }}</template>
      <template v-else>所有功能开关均为开启。</template>
    </NuxtLink>
  </AdminPage>
</template>
