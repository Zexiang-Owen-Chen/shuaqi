<script setup lang="ts">
import type { Database } from '~/types/database.types'

definePageMeta({ layout: false })
useHead({ title: '功能开关 · SHUAQI 后台' })

type Flag = Database['public']['Tables']['feature_flags']['Row']

const supabase = useSupabaseClient<Database>()
const flags = ref<Flag[]>([])
const loading = ref(true)
const error = ref<string | null>(null)
const busy = ref<string | null>(null)

const LABEL: Record<string, [string, string]> = {
  qr_checkin: ['扫码定位签到', '关闭后用户扫码无法签到，只能由工作人员在名单里手动确认'],
  nearby: ['附近 50 米加好友', '关闭后活动页不再显示“附近的人”'],
  event_discovery: ['活动内找人', '关闭后参与者名单不可见'],
  intents: ['找搭子（Intent 匹配）', '关闭后隐藏找搭子入口'],
  trust_card: ['履约事实卡', '关闭后他人资料页不显示参与记录'],
  peer_event_creation: ['普通用户发起活动', '关闭后只有组织的组织者能创建活动'],
  chat: ['好友聊天', '关闭后不能收发消息，消息入口隐藏；已有消息保留'],
  push: ['通知推送', '关闭后不再发送任何通知，也不能开启通知；已开启的设备保留，重新打开后继续收到'],
}

async function load() {
  loading.value = true
  const { data, error: e } = await supabase.from('feature_flags').select('*').order('key')
  error.value = e ? messageFor(e) : null
  flags.value = data ?? []
  loading.value = false
}
onMounted(load)

async function toggle(f: Flag) {
  const next = !f.enabled
  const name = LABEL[f.key]?.[0] ?? f.key
  if (!window.confirm(`${next ? '开启' : '关闭'}「${name}」？会立即对所有用户生效。`)) return
  busy.value = f.key
  const { error: e } = await supabase.from('feature_flags').update({ enabled: next }).eq('key', f.key)
  if (e) error.value = messageFor(e)
  else { f.enabled = next; await useFeatureFlags().load(true) }
  busy.value = null
}
</script>

<template>
  <AdminPage title="功能开关">
    <OrganiserState :loading="loading" :error="error" :empty="!flags.length" @retry="load">
      <ul class="divide-y divide-stone-100 overflow-hidden rounded-2xl bg-white ring-1 ring-stone-100">
        <li v-for="f in flags" :key="f.key" class="flex items-center gap-3 px-4 py-3">
          <div class="flex-1">
            <p class="font-medium">{{ LABEL[f.key]?.[0] ?? f.key }} <span class="text-xs font-normal text-stone-400">{{ f.key }}</span></p>
            <p class="text-xs text-stone-500">{{ LABEL[f.key]?.[1] ?? f.description }}</p>
          </div>
          <button class="relative h-7 w-12 rounded-full transition" :class="f.enabled ? 'bg-brand-500' : 'bg-stone-300'"
                  :disabled="busy === f.key" :aria-pressed="f.enabled" :aria-label="LABEL[f.key]?.[0] ?? f.key" @click="toggle(f)">
            <span class="absolute top-1 size-5 rounded-full bg-white shadow transition-all" :class="f.enabled ? 'left-6' : 'left-1'" />
          </button>
        </li>
      </ul>
    </OrganiserState>
  </AdminPage>
</template>
