<script setup lang="ts">
import type { Database } from '~/types/database.types'
import { formatDateTime } from '~/components/organiser/-format'

definePageMeta({ layout: false })
useHead({ title: '举报 · SHUAQI 后台' })

// report_message() keeps a copy of the reported message and up to 10 before it.
interface SnapMsg { id: string; sender_id: string; body: string; created_at: string }
interface Snapshot { reported_user_id: string; message: SnapMsg; context: SnapMsg[] }
type Report = Omit<Database['public']['Tables']['reports']['Row'], 'snapshot'> & { snapshot: Snapshot | null }
type ReportStatus = Database['public']['Enums']['report_status']

const supabase = useSupabaseClient<Database>()
const rpc = useRpc()

const reports = ref<Report[]>([])
const names = ref<Record<string, string>>({})
const eventTitles = ref<Record<string, string>>({})
const loading = ref(true)
const error = ref<string | null>(null)
const filter = ref<'active' | 'all'>('active')
const notes = ref<Record<string, string>>({})
const busy = ref<string | null>(null)

const TARGET_TEXT: Record<string, string> = { user: '用户', event: '活动', intent: '找搭子需求', evidence: '参与证据', message: '聊天消息' }
const snap = (r: Report) => (r.target_type === 'message' ? r.snapshot : null)

async function load() {
  loading.value = true
  error.value = null
  try {
    let q = supabase.from('reports').select('*').order('created_at', { ascending: false }).limit(200)
    if (filter.value === 'active') q = q.in('status', ['open', 'reviewing'])
    const { data, error: e } = await q
    if (e) throw new Error(messageFor(e))
    reports.value = (data ?? []) as unknown as Report[]
    for (const r of reports.value) notes.value[r.id] ??= r.admin_note ?? ''
    // 举报人和被举报用户的昵称、被举报活动的标题
    const ids: string[] = []
    for (const r of reports.value) {
      ids.push(r.reporter_id)
      if (r.target_type === 'user') ids.push(r.target_id)
      const sn = snap(r)
      if (sn) ids.push(sn.message.sender_id, ...sn.context.map(m => m.sender_id))
    }
    const userIds = [...new Set(ids)]
    const eventIds = [...new Set(reports.value.filter(r => r.target_type === 'event').map(r => r.target_id))]
    const [p, ev] = await Promise.all([
      userIds.length ? supabase.from('profiles').select('id, display_name, school_domain').in('id', userIds) : Promise.resolve({ data: [] }),
      eventIds.length ? supabase.from('events').select('id, title').in('id', eventIds) : Promise.resolve({ data: [] }),
    ])
    names.value = Object.fromEntries((p.data ?? []).map((x: { id: string, display_name: string, school_domain: string | null }) => [x.id, `${x.display_name || '未填写昵称'}（${x.school_domain ?? '—'}）`]))
    eventTitles.value = Object.fromEntries((ev.data ?? []).map((x: { id: string, title: string }) => [x.id, x.title]))
  } catch (err) {
    error.value = (err as Error).message
  } finally {
    loading.value = false
  }
}
onMounted(load)
watch(filter, load)

async function setStatus(r: Report, status: ReportStatus) {
  busy.value = r.id
  try {
    await rpc('admin_update_report', { p_report: r.id, p_status: status, p_note: notes.value[r.id]?.trim() || undefined })
    r.status = status
    r.admin_note = notes.value[r.id]?.trim() || null
    r.handled_at = new Date().toISOString()
  } catch (e) {
    error.value = (e as Error).message
  } finally {
    busy.value = null
  }
}
</script>

<template>
  <AdminPage title="举报">
    <div class="mb-3 flex gap-1 text-sm">
      <button v-for="f in ([['active', '待处理'], ['all', '全部']] as const)" :key="f[0]" class="rounded-lg px-3 py-1.5"
              :class="filter === f[0] ? 'bg-stone-800 text-white' : 'bg-stone-100 text-stone-600'" @click="filter = f[0]">{{ f[1] }}</button>
    </div>
    <OrganiserState :loading="loading" :error="error" :empty="!reports.length" empty-text="没有需要处理的举报" @retry="load">
      <ul class="space-y-3">
        <li v-for="r in reports" :key="r.id" class="card space-y-2 text-sm">
          <div class="flex flex-wrap items-center gap-2">
            <OrganiserStatusBadge kind="report" :value="r.status" />
            <span class="font-medium">{{ r.reason }}</span>
            <span class="ml-auto text-xs text-stone-400">{{ formatDateTime(r.created_at) }}</span>
          </div>
          <p>
            被举报{{ TARGET_TEXT[r.target_type] }}：
            <template v-if="r.target_type === 'user'">{{ names[r.target_id] ?? r.target_id }}</template>
            <template v-else-if="snap(r)">{{ names[snap(r)!.reported_user_id] ?? snap(r)!.reported_user_id }} 发的消息</template>
            <NuxtLink v-else-if="r.target_type === 'event'" :to="`/organiser/events/${r.target_id}`" class="text-brand-600 underline">{{ eventTitles[r.target_id] ?? r.target_id }}</NuxtLink>
            <span v-else class="font-mono text-xs">{{ r.target_id }}</span>
          </p>
          <div v-if="snap(r)" class="space-y-1 rounded-xl bg-stone-50 p-3 text-xs" data-testid="report-snapshot">
            <p class="text-stone-400">聊天记录摘录（举报时保存，仅管理员可见）</p>
            <p v-for="m in snap(r)!.context" :key="m.id" class="text-stone-500">
              <span class="font-medium">{{ names[m.sender_id] ?? '—' }}</span> · {{ formatDateTime(m.created_at) }}：{{ m.body }}
            </p>
            <p class="rounded-lg bg-red-50 p-2 text-red-800">
              <span class="font-medium">{{ names[snap(r)!.message.sender_id] ?? '—' }}</span> · {{ formatDateTime(snap(r)!.message.created_at) }}：{{ snap(r)!.message.body }}
            </p>
          </div>
          <p class="text-stone-500">举报人：{{ names[r.reporter_id] ?? r.reporter_id }}</p>
          <p v-if="r.details" class="whitespace-pre-wrap rounded-xl bg-stone-50 p-3">{{ r.details }}</p>
          <div class="flex flex-wrap items-center gap-2">
            <input v-model="notes[r.id]" class="input max-w-md flex-1" placeholder="处理备注（仅管理员可见）">
            <button v-if="r.status === 'open'" class="btn-secondary" :disabled="busy === r.id" @click="setStatus(r, 'reviewing')">开始处理</button>
            <button class="btn-primary" :disabled="busy === r.id" @click="setStatus(r, 'resolved')">已解决</button>
            <button class="btn-secondary" :disabled="busy === r.id" @click="setStatus(r, 'dismissed')">驳回</button>
          </div>
          <p v-if="r.handled_at" class="text-xs text-stone-400">最近处理：{{ formatDateTime(r.handled_at) }}<template v-if="r.admin_note">，备注：{{ r.admin_note }}</template></p>
        </li>
      </ul>
    </OrganiserState>
    <p class="mt-3 text-xs text-stone-400">需要拉黑或停用账号时，目前在 Supabase 后台处理；处理结果写在备注里留档。</p>
  </AdminPage>
</template>
