<script setup lang="ts">
import type { Database } from '~/types/database.types'
import { formatDateTime } from '~/components/organiser/-format'

definePageMeta({ layout: false })
useHead({ title: '审计日志 · SHUAQI 后台' })

type Audit = Database['public']['Tables']['audit_log']['Row']

const PAGE = 50
const TABLES: Record<string, string> = {
  participation_evidence: '参与证据', evidence_corrections: '证据更正', org_members: '组织成员',
  reports: '举报', feature_flags: '功能开关', profiles: '用户角色', events: '活动状态', event_checkin_codes: '签到码',
}

const supabase = useSupabaseClient<Database>()
const rows = shallowRef<Audit[]>([])
const names = ref<Record<string, string>>({})
const table = ref('')
const loading = ref(true)
const error = ref<string | null>(null)
const hasMore = ref(false)
const expanded = ref<Set<number>>(new Set())

async function load(append = false) {
  loading.value = true
  error.value = null
  let q = supabase.from('audit_log').select('*').order('id', { ascending: false }).limit(PAGE + 1)
  if (table.value) q = q.eq('table_name', table.value)
  if (append && rows.value.length) q = q.lt('id', rows.value[rows.value.length - 1]!.id)
  const { data, error: e } = await q
  if (e) { error.value = messageFor(e); loading.value = false; return }
  const page: Audit[] = data ?? []
  hasMore.value = page.length > PAGE
  rows.value = (append ? [...rows.value, ...page.slice(0, PAGE)] : page.slice(0, PAGE)) as Audit[]
  const ids = [...new Set(rows.value.map(r => r.actor_id).filter(id => id && !names.value[id]) as string[])]
  if (ids.length) {
    const { data: p } = await supabase.from('profiles').select('id, display_name').in('id', ids)
    names.value = { ...names.value, ...Object.fromEntries((p ?? []).map(x => [x.id, x.display_name || '未填写昵称'])) }
  }
  loading.value = false
}
onMounted(() => load())
watch(table, () => load())

function toggle(id: number) {
  if (expanded.value.has(id)) expanded.value.delete(id)
  else expanded.value.add(id)
}

// 只列出 before / after 里变化的字段
function diff(r: Audit): [string, unknown, unknown][] {
  const b = (r.before ?? {}) as Record<string, unknown>
  const a = (r.after ?? {}) as Record<string, unknown>
  const keys = [...new Set([...Object.keys(b), ...Object.keys(a)])].filter(k => k !== 'updated_at')
  return keys.filter(k => JSON.stringify(b[k]) !== JSON.stringify(a[k])).map(k => [k, b[k], a[k]])
}
const show = (v: unknown) => (v === undefined ? '—' : typeof v === 'string' ? v : JSON.stringify(v))
</script>

<template>
  <AdminPage title="审计日志">
    <select v-model="table" class="input mb-3 w-48">
      <option value="">全部</option>
      <option v-for="(t, k) in TABLES" :key="k" :value="k">{{ t }}</option>
    </select>
    <OrganiserState :loading="loading && !rows.length" :error="error" :empty="!rows.length" empty-text="没有记录" @retry="load()">
      <ul class="divide-y divide-stone-100 overflow-hidden rounded-2xl bg-white text-sm ring-1 ring-stone-100">
        <li v-for="r in rows" :key="r.id" class="px-4 py-2">
          <button class="flex w-full flex-wrap items-center gap-2 text-left" @click="toggle(r.id)">
            <span class="text-xs text-stone-400">{{ formatDateTime(r.at) }}</span>
            <span class="chip">{{ TABLES[r.table_name] ?? r.table_name }}</span>
            <span>{{ r.action }}</span>
            <span class="text-stone-500">{{ r.actor_id ? (names[r.actor_id] ?? r.actor_id) : '系统' }}</span>
            <span class="ml-auto font-mono text-xs text-stone-400">{{ r.row_id }}</span>
          </button>
          <table v-if="expanded.has(r.id)" class="mt-2 w-full text-xs">
            <tr v-for="[k, b, a] in diff(r)" :key="k" class="align-top">
              <td class="py-0.5 pr-3 font-mono text-stone-500">{{ k }}</td>
              <td class="py-0.5 pr-3 break-all text-red-700">{{ show(b) }}</td>
              <td class="py-0.5 break-all text-green-700">{{ show(a) }}</td>
            </tr>
            <tr v-if="!diff(r).length"><td class="text-stone-400">没有字段变化</td></tr>
          </table>
        </li>
      </ul>
      <button v-if="hasMore" class="btn-secondary mt-3" :disabled="loading" @click="load(true)">{{ loading ? '加载中…' : '加载更多' }}</button>
    </OrganiserState>
  </AdminPage>
</template>
