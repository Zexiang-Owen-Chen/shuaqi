export default defineNuxtPlugin({
  name: 'session-sync-client',
  dependsOn: ['supabase'],
  enforce: 'pre',
  async setup(nuxtApp) {
    const session = useSupabaseSession()
    const user = useSupabaseUser()
    const sync = createSessionSync(useSupabaseClient(), (freshSession, verifiedClaims) => {
      session.value = freshSession
      user.value = verifiedClaims
    })
    // Do not assume a session serialized during SSR is still the cookie's current session.
    await sync()
    const resume = () => { if (document.visibilityState === 'visible') void sync() }
    document.addEventListener('visibilitychange', resume)
    window.addEventListener('pageshow', resume)
    window.addEventListener('online', resume)
    nuxtApp.vueApp.onUnmount(() => {
      document.removeEventListener('visibilitychange', resume)
      window.removeEventListener('pageshow', resume)
      window.removeEventListener('online', resume)
    })
  },
})
