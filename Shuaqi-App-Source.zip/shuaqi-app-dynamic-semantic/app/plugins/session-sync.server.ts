import { getHeader, setHeader } from 'h3'

export default defineNuxtPlugin({
  name: 'session-sync-server',
  dependsOn: ['supabase'],
  enforce: 'pre',
  async setup(nuxtApp) {
    const event = useRequestEvent()
    if (!event) return
    // The module's auth helpers already renewed this request's client. Reuse it for page queries
    // instead of the second client that would reread the original request's old refresh token.
    const provided = nuxtApp.$supabase
    if (!provided || typeof provided !== 'object' || !('client' in provided)) {
      throw new Error('Supabase client was not initialized before session synchronization')
    }
    // @nuxtjs/supabase 2.1 stores its auth-helper client here, scoped to this H3 request.
    // Check explicitly so a module upgrade cannot silently fall back to stale cookie state.
    const refreshedClient = event.context._supabaseClient
    if (!refreshedClient) throw new Error('Supabase SSR session client is unavailable')
    provided.client = refreshedClient
    const prefix = useRuntimeConfig().public.supabase.cookiePrefix
    const hasSession = prefix && getHeader(event, 'cookie')?.split(';').some(part => {
      const name = part.trim().split('=', 1)[0]!
      return name === prefix || name.startsWith(`${prefix}.`)
    })
    if (hasSession) setHeader(event, 'Cache-Control', 'private, no-store')
  },
})
