// Tapping a notification while SHUAQI is open: the service worker (public/push-sw.js) focuses the
// window and asks it to route to the notification's page.
export default defineNuxtPlugin(() => {
  if (!('serviceWorker' in navigator)) return
  const router = useRouter()
  navigator.serviceWorker.addEventListener('message', (e: MessageEvent) => {
    const data = e.data as { type?: string, url?: string } | null
    if (data?.type !== 'shuaqi:navigate' || typeof data.url !== 'string') return
    const url = new URL(data.url, location.origin)
    if (url.origin !== location.origin) return
    router.push(url.pathname + url.search + url.hash)
  })
})
