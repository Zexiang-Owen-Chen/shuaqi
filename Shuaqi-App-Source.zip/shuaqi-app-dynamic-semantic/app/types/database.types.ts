
export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export type Database = {
  
  "graphql_public": {
          Tables: {
            [_ in never]: never
          }
          Views: {
            [_ in never]: never
          }
          Functions: {
            "graphql":
{ Args: { "extensions"?: Json,"operationName"?: string,"query"?: string,"variables"?: Json }; Returns: Json
                           }
          }
          Enums: {
            [_ in never]: never
          }
          CompositeTypes: {
            [_ in never]: never
          }
        },"public": {
          Tables: {
            "recommendation_observations": {
              Row: { user_id: string; event_id: string; request_id: string; shown_at: string; position: number; features: Json; algorithm_version: string };
              Insert: { user_id: string; event_id: string; request_id: string; shown_at?: string; position: number; features: Json; algorithm_version: string };
              Update: { user_id?: string; event_id?: string; request_id?: string; shown_at?: string; position?: number; features?: Json; algorithm_version?: string };
              Relationships: [];
            },
            "allowed_school_domains": {
                  Row: {
                    "active": boolean,"allow_subdomains": boolean,"domain": string,"school_name": string
                  }
                  ComputedFields: never
                  Insert: {
                    "active"?: boolean,"allow_subdomains"?: boolean,"domain": string,"school_name": string
                  }
                  Update: {
                    "active"?: boolean,"allow_subdomains"?: boolean,"domain"?: string,"school_name"?: string
                  }
                  Relationships: [
                    
                  ]
                },"audit_log": {
                  Row: {
                    "action": string,"actor_id": string | null,"after": Json | null,"at": string,"before": Json | null,"id": number,"row_id": string | null,"table_name": string
                  }
                  ComputedFields: never
                  Insert: {
                    "action": string,"actor_id"?: string | null,"after"?: Json | null,"at"?: string,"before"?: Json | null,"id"?: never,"row_id"?: string | null,"table_name": string
                  }
                  Update: {
                    "action"?: string,"actor_id"?: string | null,"after"?: Json | null,"at"?: string,"before"?: Json | null,"id"?: never,"row_id"?: string | null,"table_name"?: string
                  }
                  Relationships: [
                    
                  ]
                },"blocks": {
                  Row: {
                    "blocked_id": string,"blocker_id": string,"created_at": string
                  }
                  ComputedFields: never
                  Insert: {
                    "blocked_id": string,"blocker_id": string,"created_at"?: string
                  }
                  Update: {
                    "blocked_id"?: string,"blocker_id"?: string,"created_at"?: string
                  }
                  Relationships: [
                    {
      foreignKeyName: "blocks_blocked_id_fkey"
      columns: ["blocked_id"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    },{
      foreignKeyName: "blocks_blocker_id_fkey"
      columns: ["blocker_id"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    }
                  ]
                },"connection_requests": {
                  Row: {
                    "context": Database["public"]['Enums']["request_context"],"context_id": string | null,"created_at": string,"from_user": string,"id": string,"message": string | null,"responded_at": string | null,"status": Database["public"]['Enums']["request_status"],"to_user": string
                  }
                  ComputedFields: never
                  Insert: {
                    "context": Database["public"]['Enums']["request_context"],"context_id"?: string | null,"created_at"?: string,"from_user": string,"id"?: string,"message"?: string | null,"responded_at"?: string | null,"status"?: Database["public"]['Enums']["request_status"],"to_user": string
                  }
                  Update: {
                    "context"?: Database["public"]['Enums']["request_context"],"context_id"?: string | null,"created_at"?: string,"from_user"?: string,"id"?: string,"message"?: string | null,"responded_at"?: string | null,"status"?: Database["public"]['Enums']["request_status"],"to_user"?: string
                  }
                  Relationships: [
                    {
      foreignKeyName: "connection_requests_from_user_fkey"
      columns: ["from_user"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    },{
      foreignKeyName: "connection_requests_to_user_fkey"
      columns: ["to_user"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    }
                  ]
                },"connections": {
                  Row: {
                    "created_at": string,"source_request_id": string | null,"user_a": string,"user_b": string
                  }
                  ComputedFields: never
                  Insert: {
                    "created_at"?: string,"source_request_id"?: string | null,"user_a": string,"user_b": string
                  }
                  Update: {
                    "created_at"?: string,"source_request_id"?: string | null,"user_a"?: string,"user_b"?: string
                  }
                  Relationships: [
                    {
      foreignKeyName: "connections_source_request_id_fkey"
      columns: ["source_request_id"]
isOneToOne: false
      referencedRelation: "connection_requests"
      referencedColumns: ["id"]
    },{
      foreignKeyName: "connections_user_a_fkey"
      columns: ["user_a"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    },{
      foreignKeyName: "connections_user_b_fkey"
      columns: ["user_b"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    }
                  ]
                },"conversations": {
                  Row: {
                    "created_at": string,"id": string,"last_message_at": string | null,"user_a": string,"user_a_read_at": string | null,"user_b": string,"user_b_read_at": string | null
                  }
                  ComputedFields: never
                  Insert: {
                    "created_at"?: string,"id"?: string,"last_message_at"?: string | null,"user_a": string,"user_a_read_at"?: string | null,"user_b": string,"user_b_read_at"?: string | null
                  }
                  Update: {
                    "created_at"?: string,"id"?: string,"last_message_at"?: string | null,"user_a"?: string,"user_a_read_at"?: string | null,"user_b"?: string,"user_b_read_at"?: string | null
                  }
                  Relationships: [
                    {
      foreignKeyName: "conversations_user_a_fkey"
      columns: ["user_a"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    },{
      foreignKeyName: "conversations_user_b_fkey"
      columns: ["user_b"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    }
                  ]
                },"event_checkin_codes": {
                  Row: {
                    "code": string,"event_id": string,"rotated_at": string
                  }
                  ComputedFields: never
                  Insert: {
                    "code": string,"event_id": string,"rotated_at"?: string
                  }
                  Update: {
                    "code"?: string,"event_id"?: string,"rotated_at"?: string
                  }
                  Relationships: [
                    {
      foreignKeyName: "event_checkin_codes_event_id_fkey"
      columns: ["event_id"]
isOneToOne: true
      referencedRelation: "events"
      referencedColumns: ["id"]
    }
                  ]
                },"event_embeddings": {
                  Row: {
                    "content_hash": string,"embedding": string,"event_id": string,"model": string,"updated_at": string
                  }
                  ComputedFields: never
                  Insert: {
                    "content_hash": string,"embedding": string,"event_id": string,"model": string,"updated_at"?: string
                  }
                  Update: {
                    "content_hash"?: string,"embedding"?: string,"event_id"?: string,"model"?: string,"updated_at"?: string
                  }
                  Relationships: [
                    {
      foreignKeyName: "event_embeddings_event_id_fkey"
      columns: ["event_id"]
isOneToOne: false
      referencedRelation: "events"
      referencedColumns: ["id"]
    }
                  ]
                },"event_rsvps": {
                  Row: {
                    "created_at": string,"event_id": string,"status": Database["public"]['Enums']["rsvp_status"],"updated_at": string,"user_id": string
                  }
                  ComputedFields: never
                  Insert: {
                    "created_at"?: string,"event_id": string,"status"?: Database["public"]['Enums']["rsvp_status"],"updated_at"?: string,"user_id": string
                  }
                  Update: {
                    "created_at"?: string,"event_id"?: string,"status"?: Database["public"]['Enums']["rsvp_status"],"updated_at"?: string,"user_id"?: string
                  }
                  Relationships: [
                    {
      foreignKeyName: "event_rsvps_event_id_fkey"
      columns: ["event_id"]
isOneToOne: false
      referencedRelation: "events"
      referencedColumns: ["id"]
    },{
      foreignKeyName: "event_rsvps_user_id_fkey"
      columns: ["user_id"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    }
                  ]
                },"event_social_optin": {
                  Row: {
                    "event_id": string,"opted_in": boolean,"updated_at": string,"user_id": string,"visible_fields": (string)[]
                  }
                  ComputedFields: never
                  Insert: {
                    "event_id": string,"opted_in"?: boolean,"updated_at"?: string,"user_id": string,"visible_fields"?: (string)[]
                  }
                  Update: {
                    "event_id"?: string,"opted_in"?: boolean,"updated_at"?: string,"user_id"?: string,"visible_fields"?: (string)[]
                  }
                  Relationships: [
                    {
      foreignKeyName: "event_social_optin_event_id_fkey"
      columns: ["event_id"]
isOneToOne: false
      referencedRelation: "events"
      referencedColumns: ["id"]
    },{
      foreignKeyName: "event_social_optin_user_id_fkey"
      columns: ["user_id"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    }
                  ]
                },"events": {
                  Row: {
                    "capacity": number | null,"category": string,"checkin_closes_at": string | null,"checkin_mode": Database["public"]['Enums']["checkin_mode"],"checkin_opens_at": string | null,"checkin_radius_m": number,"created_at": string,"description": string,"ends_at": string | null,"host_user_id": string,"id": string,"image_paths": (string)[],"location_lat": number | null,"location_lng": number | null,"location_text": string,"org_id": string | null,"require_checkin_for_connect": boolean,"starts_at": string,"status": Database["public"]['Enums']["event_status"],"title": string,"type": Database["public"]['Enums']["event_type"],"updated_at": string,"visibility": Database["public"]['Enums']["event_visibility"]
                  }
                  ComputedFields: never
                  Insert: {
                    "capacity"?: number | null,"category": string,"checkin_closes_at"?: string | null,"checkin_mode"?: Database["public"]['Enums']["checkin_mode"],"checkin_opens_at"?: string | null,"checkin_radius_m"?: number,"created_at"?: string,"description"?: string,"ends_at"?: string | null,"host_user_id": string,"id"?: string,"image_paths"?: (string)[],"location_lat"?: number | null,"location_lng"?: number | null,"location_text"?: string,"org_id"?: string | null,"require_checkin_for_connect"?: boolean,"starts_at": string,"status"?: Database["public"]['Enums']["event_status"],"title": string,"type"?: Database["public"]['Enums']["event_type"],"updated_at"?: string,"visibility"?: Database["public"]['Enums']["event_visibility"]
                  }
                  Update: {
                    "capacity"?: number | null,"category"?: string,"checkin_closes_at"?: string | null,"checkin_mode"?: Database["public"]['Enums']["checkin_mode"],"checkin_opens_at"?: string | null,"checkin_radius_m"?: number,"created_at"?: string,"description"?: string,"ends_at"?: string | null,"host_user_id"?: string,"id"?: string,"image_paths"?: (string)[],"location_lat"?: number | null,"location_lng"?: number | null,"location_text"?: string,"org_id"?: string | null,"require_checkin_for_connect"?: boolean,"starts_at"?: string,"status"?: Database["public"]['Enums']["event_status"],"title"?: string,"type"?: Database["public"]['Enums']["event_type"],"updated_at"?: string,"visibility"?: Database["public"]['Enums']["event_visibility"]
                  }
                  Relationships: [
                    {
      foreignKeyName: "events_host_user_id_fkey"
      columns: ["host_user_id"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    },{
      foreignKeyName: "events_org_id_fkey"
      columns: ["org_id"]
isOneToOne: false
      referencedRelation: "organisations"
      referencedColumns: ["id"]
    }
                  ]
                },"evidence_corrections": {
                  Row: {
                    "created_at": string,"evidence_id": string,"id": string,"reason": string,"requested_by": string,"resolution_note": string | null,"resolved_at": string | null,"resolved_by": string | null,"status": Database["public"]['Enums']["correction_status"]
                  }
                  ComputedFields: never
                  Insert: {
                    "created_at"?: string,"evidence_id": string,"id"?: string,"reason": string,"requested_by": string,"resolution_note"?: string | null,"resolved_at"?: string | null,"resolved_by"?: string | null,"status"?: Database["public"]['Enums']["correction_status"]
                  }
                  Update: {
                    "created_at"?: string,"evidence_id"?: string,"id"?: string,"reason"?: string,"requested_by"?: string,"resolution_note"?: string | null,"resolved_at"?: string | null,"resolved_by"?: string | null,"status"?: Database["public"]['Enums']["correction_status"]
                  }
                  Relationships: [
                    {
      foreignKeyName: "evidence_corrections_evidence_id_fkey"
      columns: ["evidence_id"]
isOneToOne: false
      referencedRelation: "participation_evidence"
      referencedColumns: ["id"]
    },{
      foreignKeyName: "evidence_corrections_requested_by_fkey"
      columns: ["requested_by"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    },{
      foreignKeyName: "evidence_corrections_resolved_by_fkey"
      columns: ["resolved_by"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    }
                  ]
                },"feature_flags": {
                  Row: {
                    "description": string,"enabled": boolean,"key": string
                  }
                  ComputedFields: never
                  Insert: {
                    "description"?: string,"enabled"?: boolean,"key": string
                  }
                  Update: {
                    "description"?: string,"enabled"?: boolean,"key"?: string
                  }
                  Relationships: [
                    
                  ]
                },"intents": {
                  Row: {
                    "activity_type": string,"budget_max": number | null,"created_at": string,"expires_at": string,"group_size": number,"id": string,"note": string,"region": string,"status": Database["public"]['Enums']["intent_status"],"updated_at": string,"user_id": string,"window_end": string,"window_start": string
                  }
                  ComputedFields: never
                  Insert: {
                    "activity_type": string,"budget_max"?: number | null,"created_at"?: string,"expires_at": string,"group_size"?: number,"id"?: string,"note"?: string,"region"?: string,"status"?: Database["public"]['Enums']["intent_status"],"updated_at"?: string,"user_id": string,"window_end": string,"window_start": string
                  }
                  Update: {
                    "activity_type"?: string,"budget_max"?: number | null,"created_at"?: string,"expires_at"?: string,"group_size"?: number,"id"?: string,"note"?: string,"region"?: string,"status"?: Database["public"]['Enums']["intent_status"],"updated_at"?: string,"user_id"?: string,"window_end"?: string,"window_start"?: string
                  }
                  Relationships: [
                    {
      foreignKeyName: "intents_user_id_fkey"
      columns: ["user_id"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    }
                  ]
                },"location_consents": {
                  Row: {
                    "granted_at": string,"policy_version": string,"purpose": string,"user_id": string,"withdrawn_at": string | null
                  }
                  ComputedFields: never
                  Insert: {
                    "granted_at"?: string,"policy_version": string,"purpose": string,"user_id": string,"withdrawn_at"?: string | null
                  }
                  Update: {
                    "granted_at"?: string,"policy_version"?: string,"purpose"?: string,"user_id"?: string,"withdrawn_at"?: string | null
                  }
                  Relationships: [
                    {
      foreignKeyName: "location_consents_user_id_fkey"
      columns: ["user_id"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    }
                  ]
                },"match_invitations": {
                  Row: {
                    "created_at": string,"from_intent_id": string,"from_user": string,"id": string,"message": string | null,"responded_at": string | null,"status": Database["public"]['Enums']["invitation_status"],"to_intent_id": string,"to_user": string
                  }
                  ComputedFields: never
                  Insert: {
                    "created_at"?: string,"from_intent_id": string,"from_user": string,"id"?: string,"message"?: string | null,"responded_at"?: string | null,"status"?: Database["public"]['Enums']["invitation_status"],"to_intent_id": string,"to_user": string
                  }
                  Update: {
                    "created_at"?: string,"from_intent_id"?: string,"from_user"?: string,"id"?: string,"message"?: string | null,"responded_at"?: string | null,"status"?: Database["public"]['Enums']["invitation_status"],"to_intent_id"?: string,"to_user"?: string
                  }
                  Relationships: [
                    {
      foreignKeyName: "match_invitations_from_intent_id_fkey"
      columns: ["from_intent_id"]
isOneToOne: false
      referencedRelation: "intents"
      referencedColumns: ["id"]
    },{
      foreignKeyName: "match_invitations_from_user_fkey"
      columns: ["from_user"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    },{
      foreignKeyName: "match_invitations_to_intent_id_fkey"
      columns: ["to_intent_id"]
isOneToOne: false
      referencedRelation: "intents"
      referencedColumns: ["id"]
    },{
      foreignKeyName: "match_invitations_to_user_fkey"
      columns: ["to_user"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    }
                  ]
                },"messages": {
                  Row: {
                    "body": string,"conversation_id": string,"created_at": string,"id": string,"sender_id": string
                  }
                  ComputedFields: never
                  Insert: {
                    "body": string,"conversation_id": string,"created_at"?: string,"id"?: string,"sender_id": string
                  }
                  Update: {
                    "body"?: string,"conversation_id"?: string,"created_at"?: string,"id"?: string,"sender_id"?: string
                  }
                  Relationships: [
                    {
      foreignKeyName: "messages_conversation_id_fkey"
      columns: ["conversation_id"]
isOneToOne: false
      referencedRelation: "conversations"
      referencedColumns: ["id"]
    },{
      foreignKeyName: "messages_sender_id_fkey"
      columns: ["sender_id"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    }
                  ]
                },"nearby_presence": {
                  Row: {
                    "accuracy_m": number,"event_id": string,"lat": number,"lng": number,"updated_at": string,"user_id": string
                  }
                  ComputedFields: never
                  Insert: {
                    "accuracy_m": number,"event_id": string,"lat": number,"lng": number,"updated_at"?: string,"user_id": string
                  }
                  Update: {
                    "accuracy_m"?: number,"event_id"?: string,"lat"?: number,"lng"?: number,"updated_at"?: string,"user_id"?: string
                  }
                  Relationships: [
                    {
      foreignKeyName: "nearby_presence_event_id_fkey"
      columns: ["event_id"]
isOneToOne: false
      referencedRelation: "events"
      referencedColumns: ["id"]
    },{
      foreignKeyName: "nearby_presence_user_id_fkey"
      columns: ["user_id"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    }
                  ]
                },"notification_preferences": {
                  Row: {
                    "buddy": boolean,"event_reminder": boolean,"friend_request": boolean,"message": boolean,"updated_at": string,"user_id": string
                  }
                  ComputedFields: never
                  Insert: {
                    "buddy"?: boolean,"event_reminder"?: boolean,"friend_request"?: boolean,"message"?: boolean,"updated_at"?: string,"user_id": string
                  }
                  Update: {
                    "buddy"?: boolean,"event_reminder"?: boolean,"friend_request"?: boolean,"message"?: boolean,"updated_at"?: string,"user_id"?: string
                  }
                  Relationships: [
                    {
      foreignKeyName: "notification_preferences_user_id_fkey"
      columns: ["user_id"]
isOneToOne: true
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    }
                  ]
                },"open_presence": {
                  Row: {
                    "accuracy_m": number,"lat": number,"lng": number,"updated_at": string,"user_id": string
                  }
                  ComputedFields: never
                  Insert: {
                    "accuracy_m": number,"lat": number,"lng": number,"updated_at"?: string,"user_id": string
                  }
                  Update: {
                    "accuracy_m"?: number,"lat"?: number,"lng"?: number,"updated_at"?: string,"user_id"?: string
                  }
                  Relationships: [
                    {
      foreignKeyName: "open_presence_user_id_fkey"
      columns: ["user_id"]
isOneToOne: true
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    }
                  ]
                },"org_members": {
                  Row: {
                    "created_at": string,"org_id": string,"role": Database["public"]['Enums']["org_role"],"user_id": string
                  }
                  ComputedFields: never
                  Insert: {
                    "created_at"?: string,"org_id": string,"role": Database["public"]['Enums']["org_role"],"user_id": string
                  }
                  Update: {
                    "created_at"?: string,"org_id"?: string,"role"?: Database["public"]['Enums']["org_role"],"user_id"?: string
                  }
                  Relationships: [
                    {
      foreignKeyName: "org_members_org_id_fkey"
      columns: ["org_id"]
isOneToOne: false
      referencedRelation: "organisations"
      referencedColumns: ["id"]
    },{
      foreignKeyName: "org_members_user_id_fkey"
      columns: ["user_id"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    }
                  ]
                },"organisations": {
                  Row: {
                    "created_at": string,"id": string,"name": string,"verified": boolean
                  }
                  ComputedFields: never
                  Insert: {
                    "created_at"?: string,"id"?: string,"name": string,"verified"?: boolean
                  }
                  Update: {
                    "created_at"?: string,"id"?: string,"name"?: string,"verified"?: boolean
                  }
                  Relationships: [
                    
                  ]
                },"participation_evidence": {
                  Row: {
                    "created_at": string,"event_id": string | null,"geo_accuracy_m": number | null,"geo_distance_m": number | null,"id": string,"meta": NonNullable<Json>,"occurred_at": string,"operator_id": string | null,"shared_plan_id": string | null,"source": Database["public"]['Enums']["evidence_source"],"subject_user_id": string,"type": Database["public"]['Enums']["evidence_type"],"updated_at": string,"verification_status": Database["public"]['Enums']["verification_status"]
                  }
                  ComputedFields: never
                  Insert: {
                    "created_at"?: string,"event_id"?: string | null,"geo_accuracy_m"?: number | null,"geo_distance_m"?: number | null,"id"?: string,"meta"?: NonNullable<Json>,"occurred_at"?: string,"operator_id"?: string | null,"shared_plan_id"?: string | null,"source": Database["public"]['Enums']["evidence_source"],"subject_user_id": string,"type": Database["public"]['Enums']["evidence_type"],"updated_at"?: string,"verification_status": Database["public"]['Enums']["verification_status"]
                  }
                  Update: {
                    "created_at"?: string,"event_id"?: string | null,"geo_accuracy_m"?: number | null,"geo_distance_m"?: number | null,"id"?: string,"meta"?: NonNullable<Json>,"occurred_at"?: string,"operator_id"?: string | null,"shared_plan_id"?: string | null,"source"?: Database["public"]['Enums']["evidence_source"],"subject_user_id"?: string,"type"?: Database["public"]['Enums']["evidence_type"],"updated_at"?: string,"verification_status"?: Database["public"]['Enums']["verification_status"]
                  }
                  Relationships: [
                    {
      foreignKeyName: "participation_evidence_event_id_fkey"
      columns: ["event_id"]
isOneToOne: false
      referencedRelation: "events"
      referencedColumns: ["id"]
    },{
      foreignKeyName: "participation_evidence_operator_id_fkey"
      columns: ["operator_id"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    },{
      foreignKeyName: "participation_evidence_shared_plan_id_fkey"
      columns: ["shared_plan_id"]
isOneToOne: false
      referencedRelation: "shared_plans"
      referencedColumns: ["id"]
    },{
      foreignKeyName: "participation_evidence_subject_user_id_fkey"
      columns: ["subject_user_id"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    }
                  ]
                },"plan_presence": {
                  Row: {
                    "accuracy_m": number,"lat": number,"lng": number,"plan_id": string,"updated_at": string,"user_id": string
                  }
                  ComputedFields: never
                  Insert: {
                    "accuracy_m": number,"lat": number,"lng": number,"plan_id": string,"updated_at"?: string,"user_id": string
                  }
                  Update: {
                    "accuracy_m"?: number,"lat"?: number,"lng"?: number,"plan_id"?: string,"updated_at"?: string,"user_id"?: string
                  }
                  Relationships: [
                    {
      foreignKeyName: "plan_presence_plan_id_fkey"
      columns: ["plan_id"]
isOneToOne: false
      referencedRelation: "shared_plans"
      referencedColumns: ["id"]
    },{
      foreignKeyName: "plan_presence_user_id_fkey"
      columns: ["user_id"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    }
                  ]
                },"profile_photos": {
                  Row: {
                    "created_at": string,"id": string,"sort": number,"storage_path": string,"user_id": string
                  }
                  ComputedFields: never
                  Insert: {
                    "created_at"?: string,"id"?: string,"sort"?: number,"storage_path": string,"user_id": string
                  }
                  Update: {
                    "created_at"?: string,"id"?: string,"sort"?: number,"storage_path"?: string,"user_id"?: string
                  }
                  Relationships: [
                    {
      foreignKeyName: "profile_photos_user_id_fkey"
      columns: ["user_id"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    }
                  ]
                },"profiles": {
                  Row: {
                    "avatar_url": string | null,"bio": string | null,"birth_year": number | null,"created_at": string,"display_name": string,"gender": string | null,"id": string,"interests": (string)[],"onboarded": boolean,"region": string | null,"role": Database["public"]['Enums']["app_role"],"school_domain": string | null,"school_verified_at": string | null,"updated_at": string,"visibility": NonNullable<Json>
                  }
                  ComputedFields: never
                  Insert: {
                    "avatar_url"?: string | null,"bio"?: string | null,"birth_year"?: number | null,"created_at"?: string,"display_name"?: string,"gender"?: string | null,"id": string,"interests"?: (string)[],"onboarded"?: boolean,"region"?: string | null,"role"?: Database["public"]['Enums']["app_role"],"school_domain"?: string | null,"school_verified_at"?: string | null,"updated_at"?: string,"visibility"?: NonNullable<Json>
                  }
                  Update: {
                    "avatar_url"?: string | null,"bio"?: string | null,"birth_year"?: number | null,"created_at"?: string,"display_name"?: string,"gender"?: string | null,"id"?: string,"interests"?: (string)[],"onboarded"?: boolean,"region"?: string | null,"role"?: Database["public"]['Enums']["app_role"],"school_domain"?: string | null,"school_verified_at"?: string | null,"updated_at"?: string,"visibility"?: NonNullable<Json>
                  }
                  Relationships: [
                    {
      foreignKeyName: "profiles_school_domain_fkey"
      columns: ["school_domain"]
isOneToOne: false
      referencedRelation: "allowed_school_domains"
      referencedColumns: ["domain"]
    }
                  ]
                },"push_outbox": {
                  Row: {
                    "attempts": number,"category": string,"claimed_at": string | null,"collapse_key": string | null,"created_at": string,"dedupe_key": string | null,"id": number,"payload": NonNullable<Json>,"sent_at": string | null,"status": string,"user_id": string
                  }
                  ComputedFields: never
                  Insert: {
                    "attempts"?: number,"category": string,"claimed_at"?: string | null,"collapse_key"?: string | null,"created_at"?: string,"dedupe_key"?: string | null,"id"?: never,"payload": NonNullable<Json>,"sent_at"?: string | null,"status"?: string,"user_id": string
                  }
                  Update: {
                    "attempts"?: number,"category"?: string,"claimed_at"?: string | null,"collapse_key"?: string | null,"created_at"?: string,"dedupe_key"?: string | null,"id"?: never,"payload"?: NonNullable<Json>,"sent_at"?: string | null,"status"?: string,"user_id"?: string
                  }
                  Relationships: [
                    {
      foreignKeyName: "push_outbox_user_id_fkey"
      columns: ["user_id"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    }
                  ]
                },"push_subscriptions": {
                  Row: {
                    "auth": string,"created_at": string,"endpoint": string,"id": string,"last_success_at": string | null,"p256dh": string,"user_agent": string,"user_id": string
                  }
                  ComputedFields: never
                  Insert: {
                    "auth": string,"created_at"?: string,"endpoint": string,"id"?: string,"last_success_at"?: string | null,"p256dh": string,"user_agent"?: string,"user_id": string
                  }
                  Update: {
                    "auth"?: string,"created_at"?: string,"endpoint"?: string,"id"?: string,"last_success_at"?: string | null,"p256dh"?: string,"user_agent"?: string,"user_id"?: string
                  }
                  Relationships: [
                    {
      foreignKeyName: "push_subscriptions_user_id_fkey"
      columns: ["user_id"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    }
                  ]
                },"recommendation_events": {
                  Row: {
                    "algorithm_version": string,"at": string,"event_id": string,"id": number,"kind": Database["public"]['Enums']["recommendation_event_kind"],"position": number | null,"request_id": string | null,"user_id": string
                  }
                  ComputedFields: never
                  Insert: {
                    "algorithm_version"?: string,"at"?: string,"event_id": string,"id"?: never,"kind": Database["public"]['Enums']["recommendation_event_kind"],"position"?: number | null,"request_id"?: string | null,"user_id"?: string
                  }
                  Update: {
                    "algorithm_version"?: string,"at"?: string,"event_id"?: string,"id"?: never,"kind"?: Database["public"]['Enums']["recommendation_event_kind"],"position"?: number | null,"request_id"?: string | null,"user_id"?: string
                  }
                  Relationships: [
                    {
      foreignKeyName: "recommendation_events_event_id_fkey"
      columns: ["event_id"]
isOneToOne: false
      referencedRelation: "events"
      referencedColumns: ["id"]
    },{
      foreignKeyName: "recommendation_events_user_id_fkey"
      columns: ["user_id"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    }
                  ]
                },"recommendation_requests": {
                  Row: {
                    "at": string,"id": string,"llm_used": boolean,"user_id": string
                  }
                  ComputedFields: never
                  Insert: {
                    "at"?: string,"id"?: string,"llm_used"?: boolean,"user_id": string
                  }
                  Update: {
                    "at"?: string,"id"?: string,"llm_used"?: boolean,"user_id"?: string
                  }
                  Relationships: [
                    {
      foreignKeyName: "recommendation_requests_user_id_fkey"
      columns: ["user_id"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    }
                  ]
                },"recommendation_settings": {
                  Row: {
                    "embedding_model": string,"embedding_provider": string,"id": boolean,"llm_model": string,"llm_provider": string,"updated_at": string,"updated_by": string | null
                  }
                  ComputedFields: never
                  Insert: {
                    "embedding_model"?: string,"embedding_provider"?: string,"id"?: boolean,"llm_model"?: string,"llm_provider"?: string,"updated_at"?: string,"updated_by"?: string | null
                  }
                  Update: {
                    "embedding_model"?: string,"embedding_provider"?: string,"id"?: boolean,"llm_model"?: string,"llm_provider"?: string,"updated_at"?: string,"updated_by"?: string | null
                  }
                  Relationships: [
                    {
      foreignKeyName: "recommendation_settings_updated_by_fkey"
      columns: ["updated_by"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    }
                  ]
                },"reports": {
                  Row: {
                    "admin_note": string | null,"created_at": string,"details": string,"handled_at": string | null,"handled_by": string | null,"id": string,"reason": string,"reporter_id": string,"snapshot": Json | null,"status": Database["public"]['Enums']["report_status"],"target_id": string,"target_type": Database["public"]['Enums']["report_target"]
                  }
                  ComputedFields: never
                  Insert: {
                    "admin_note"?: string | null,"created_at"?: string,"details"?: string,"handled_at"?: string | null,"handled_by"?: string | null,"id"?: string,"reason": string,"reporter_id": string,"snapshot"?: Json | null,"status"?: Database["public"]['Enums']["report_status"],"target_id": string,"target_type": Database["public"]['Enums']["report_target"]
                  }
                  Update: {
                    "admin_note"?: string | null,"created_at"?: string,"details"?: string,"handled_at"?: string | null,"handled_by"?: string | null,"id"?: string,"reason"?: string,"reporter_id"?: string,"snapshot"?: Json | null,"status"?: Database["public"]['Enums']["report_status"],"target_id"?: string,"target_type"?: Database["public"]['Enums']["report_target"]
                  }
                  Relationships: [
                    {
      foreignKeyName: "reports_handled_by_fkey"
      columns: ["handled_by"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    },{
      foreignKeyName: "reports_reporter_id_fkey"
      columns: ["reporter_id"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    }
                  ]
                },"shared_plans": {
                  Row: {
                    "a_confirmed_at": string | null,"a_met_at": string | null,"b_confirmed_at": string | null,"b_met_at": string | null,"created_at": string,"id": string,"invitation_id": string,"place": string,"planned_at": string | null,"status": Database["public"]['Enums']["plan_status"],"title": string,"updated_at": string,"user_a": string,"user_b": string
                  }
                  ComputedFields: never
                  Insert: {
                    "a_confirmed_at"?: string | null,"a_met_at"?: string | null,"b_confirmed_at"?: string | null,"b_met_at"?: string | null,"created_at"?: string,"id"?: string,"invitation_id": string,"place"?: string,"planned_at"?: string | null,"status"?: Database["public"]['Enums']["plan_status"],"title": string,"updated_at"?: string,"user_a": string,"user_b": string
                  }
                  Update: {
                    "a_confirmed_at"?: string | null,"a_met_at"?: string | null,"b_confirmed_at"?: string | null,"b_met_at"?: string | null,"created_at"?: string,"id"?: string,"invitation_id"?: string,"place"?: string,"planned_at"?: string | null,"status"?: Database["public"]['Enums']["plan_status"],"title"?: string,"updated_at"?: string,"user_a"?: string,"user_b"?: string
                  }
                  Relationships: [
                    {
      foreignKeyName: "shared_plans_invitation_id_fkey"
      columns: ["invitation_id"]
isOneToOne: true
      referencedRelation: "match_invitations"
      referencedColumns: ["id"]
    },{
      foreignKeyName: "shared_plans_user_a_fkey"
      columns: ["user_a"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    },{
      foreignKeyName: "shared_plans_user_b_fkey"
      columns: ["user_b"]
isOneToOne: false
      referencedRelation: "profiles"
      referencedColumns: ["id"]
    }
                  ]
                }
          }
          Views: {
            [_ in never]: never
          }
          Functions: {
            "add_org_member":
{ Args: { "p_email": string,"p_org": string,"p_role": Database["public"]['Enums']["org_role"] }; Returns: undefined
                           },
"admin_resolve_correction":
{ Args: { "p_approve": boolean,"p_correction": string,"p_new_status"?: Database["public"]['Enums']["verification_status"],"p_note"?: string }; Returns: undefined
                           },
"admin_set_evidence_status":
{ Args: { "p_evidence": string,"p_note": string,"p_status": Database["public"]['Enums']["verification_status"] }; Returns: undefined
                           },
"admin_update_report":
{ Args: { "p_note"?: string,"p_report": string,"p_status": Database["public"]['Enums']["report_status"] }; Returns: undefined
                           },
"are_connected":
{ Args: { "p_a": string,"p_b": string }; Returns: boolean
                           },
"block_user":
{ Args: { "p_target": string }; Returns: undefined
                           },
"can_chat":
{ Args: { "p_a": string,"p_b": string }; Returns: boolean
                           },
"can_read_conversation":
{ Args: { "p_conversation": string }; Returns: boolean
                           },
"can_view_event":
{ Args: { "p_event": string }; Returns: boolean
                           },
"cancel_event":
{ Args: { "p_event": string }; Returns: undefined
                           },
"cancel_shared_plan":
{ Args: { "p_plan": string }; Returns: undefined
                           },
"check_position":
{ Args: { "p_accuracy": number,"p_lat": number,"p_lng": number }; Returns: undefined
                           },
"claim_push_batch":
{ Args: { "p_limit"?: number }; Returns: {
              "id": number,"payload": Json,"subscriptions": Json
            }[]
                           },
"complete_push_batch":
{ Args: { "p_done": (number)[],"p_gone": (string)[],"p_ok": (string)[],"p_retry": (number)[] }; Returns: undefined
                           },
"confirm_shared_plan":
{ Args: { "p_plan": string }; Returns: {
              "a_confirmed_at": string | null,
"a_met_at": string | null,
"b_confirmed_at": string | null,
"b_met_at": string | null,
"created_at": string,
"id": string,
"invitation_id": string,
"place": string,
"planned_at": string | null,
"status": Database["public"]['Enums']["plan_status"],
"title": string,
"updated_at": string,
"user_a": string,
"user_b": string
            }
                          SetofOptions: {
        from: "*"
        to: "shared_plans"
        isOneToOne: true
        isSetofReturn: false
      } },
"delete_push_subscription":
{ Args: { "p_endpoint": string }; Returns: undefined
                           },
"distance_m":
{ Args: { "lat1": number,"lat2": number,"lng1": number,"lng2": number }; Returns: number
                           },
"enqueue_event_reminders":
{ Args: Record<PropertyKey, never>; Returns: number
                           },
"event_checkin":
{ Args: { "p_accuracy": number,"p_code": string,"p_lat": number,"p_lng": number }; Returns: Json
                           },
"flag_enabled":
{ Args: { "p_key": string }; Returns: boolean
                           },
"get_checkin_code":
{ Args: { "p_event": string }; Returns: string
                           },
"get_profile_card":
{ Args: { "p_context"?: string,"p_context_id"?: string,"p_target": string }; Returns: Json
                           },
"grant_location_consent":
{ Args: { "p_policy_version": string,"p_purpose": string }; Returns: undefined
                           },
"has_location_consent":
{ Args: { "p_purpose": string,"p_user": string }; Returns: boolean
                           },
"has_push_subscription":
{ Args: { "p_endpoint": string }; Returns: boolean
                           },
"intents_compatible":
{ Args: { "p_a": string,"p_b": string }; Returns: boolean
                           },
"is_admin":
{ Args: Record<PropertyKey, never>; Returns: boolean
                           },
"is_blocked":
{ Args: { "p_a": string,"p_b": string }; Returns: boolean
                           },
"is_checked_in":
{ Args: { "p_event": string,"p_user": string }; Returns: boolean
                           },
"is_event_manager":
{ Args: { "p_event": string,"p_user"?: string }; Returns: boolean
                           },
"is_event_staff":
{ Args: { "p_event": string,"p_user"?: string }; Returns: boolean
                           },
"is_going":
{ Args: { "p_event": string,"p_user"?: string }; Returns: boolean
                           },
"is_school_verified":
{ Args: { "p_user"?: string }; Returns: boolean
                           },
"join_event":
{ Args: { "p_event": string }; Returns: {
              "created_at": string,
"event_id": string,
"status": Database["public"]['Enums']["rsvp_status"],
"updated_at": string,
"user_id": string
            }
                          SetofOptions: {
        from: "*"
        to: "event_rsvps"
        isOneToOne: true
        isSetofReturn: false
      } },
"latest_request_status":
{ Args: { "p_other": string }; Returns: string
                           },
"leave_event":
{ Args: { "p_event": string }; Returns: undefined
                           },
"list_event_attendees":
{ Args: { "p_event": string }; Returns: {
              "avatar_url": string,"display_name": string,"organiser_confirmed": boolean,"rsvp_at": string,"rsvp_status": string,"school_domain": string,"self_checkin": string,"user_id": string
            }[]
                           },
"list_event_participants":
{ Args: { "p_event": string }; Returns: {
              "card": Json,"request_status": string
            }[]
                           },
"list_my_connections":
{ Args: Record<PropertyKey, never>; Returns: {
              "card": Json,"connected_at": string
            }[]
                           },
"list_my_conversations":
{ Args: Record<PropertyKey, never>; Returns: {
              "card": Json,"conversation_id": string,"last_body": string,"last_message_at": string,"last_sender_id": string,"other_id": string,"unread": number
            }[]
                           },
"list_my_requests":
{ Args: Record<PropertyKey, never>; Returns: {
              "card": Json,"context": string,"context_id": string,"created_at": string,"direction": string,"id": string,"message": string,"status": string
            }[]
                           },
"list_nearby":
{ Args: { "p_event": string }; Returns: {
              "card": Json,"distance_m": number,"request_status": string
            }[]
                           },
"list_open_nearby":
{ Args: Record<PropertyKey, never>; Returns: {
              "card": Json,"distance_m": number,"request_status": string
            }[]
                           },
"list_org_members":
{ Args: { "p_org": string }; Returns: {
              "avatar_url": string,"display_name": string,"email": string,"joined_at": string,"role": string,"user_id": string
            }[]
                           },
"lookup_checkin_code":
{ Args: { "p_code": string }; Returns: {
              "checkin_radius_m": number,"event_id": string,"location_text": string,"starts_at": string,"title": string
            }[]
                           },
"mark_conversation_read":
{ Args: { "p_conversation": string }; Returns: undefined
                           },
"match_candidates":
{ Args: { "p_intent": string }; Returns: {
              "activity_type": string,"budget_max": number,"card": Json,"group_size": number,"intent_id": string,"invitation_status": string,"note": string,"overlap_minutes": number,"region": string,"score": number,"shared_interests": (string)[],"window_end": string,"window_start": string
            }[]
                           },
"my_notification_preferences":
{ Args: Record<PropertyKey, never>; Returns: Json
                           },
"my_organisations":
{ Args: Record<PropertyKey, never>; Returns: {
              "name": string,"org_id": string,"role": string
            }[]
                           },
"my_participation_history":
{ Args: Record<PropertyKey, never>; Returns: {
              "correction_status": string,"event_id": string,"event_title": string,"evidence_id": string,"occurred_at": string,"shared_plan_id": string,"source": string,"type": string,"verification_status": string
            }[]
                           },
"nearby_card":
{ Args: { "p_user": string }; Returns: Json
                           },
"nearby_distance":
{ Args: { "p_a": string,"p_b": string,"p_event": string }; Returns: number
                           },
"normalize_region":
{ Args: { "p_region": string }; Returns: string
                           },
"open_conversation":
{ Args: { "p_other": string }; Returns: string
                           },
"open_distance":
{ Args: { "p_a": string,"p_b": string }; Returns: number
                           },
"org_role_of":
{ Args: { "p_org": string,"p_user"?: string }; Returns: Database["public"]['Enums']["org_role"]
                           },
"organiser_confirm_attendance":
{ Args: { "p_confirm"?: boolean,"p_event": string,"p_user": string }; Returns: undefined
                           },
"plan_distance":
{ Args: { "p_a": string,"p_b": string,"p_plan": string }; Returns: number
                           },
"purge_nearby_presence":
{ Args: Record<PropertyKey, never>; Returns: number
                           },
"purge_old_messages":
{ Args: Record<PropertyKey, never>; Returns: number
                           },
"push_enqueue":
{ Args: { "p_body": string,"p_category": string,"p_collapse_key"?: string,"p_dedupe_key"?: string,"p_title": string,"p_url": string,"p_user": string }; Returns: undefined
                           },
"push_kick":
{ Args: Record<PropertyKey, never>; Returns: undefined
                           },
"push_name":
{ Args: { "p_user": string }; Returns: string
                           },
"push_tick":
{ Args: Record<PropertyKey, never>; Returns: undefined
                           },
"push_time":
{ Args: { "p_at": string }; Returns: string
                           },
"push_wanted":
{ Args: { "p_category": string,"p_user": string }; Returns: boolean
                           },
"recommendation_candidates":
{ Args: { "p_embedding_model"?: string,"p_from"?: string,"p_limit"?: number,"p_query_embedding"?: string,"p_to"?: string }; Returns: {
              "capacity": number,"category": string,"description": string,"embedding_hash": string,"ends_at": string,"going": number,"id": string,"location_lat": number,"location_lng": number,"location_text": string,"org_verified": boolean,"similarity": number,"starts_at": string,"title": string
            }[]
                           },
"recommendation_search_candidates":
{ Args: { "p_terms"?: string[],"p_category"?: string,"p_embedding_model"?: string,"p_from"?: string,"p_limit"?: number,"p_query_embedding"?: string,"p_to"?: string }; Returns: {
              "capacity": number,"category": string,"description": string,"embedding_hash": string,"ends_at": string,"going": number,"id": string,"location_lat": number,"location_lng": number,"location_text": string,"org_verified": boolean,"similarity": number,"starts_at": string,"title": string
            }[]
                           },
"recommendation_weight_observations": {
              Args: Record<PropertyKey, never>;
              Returns: { request_id: string; event_id: string; shown_at: string; position: number; features: Json; feedback: string | null; feedback_at: string | null }[];
            },
            "recommendation_signals":
{ Args: Record<PropertyKey, never>; Returns: {
              "at": string,"category": string,"signal": string
            }[]
                           },
"remove_connection":
{ Args: { "p_other": string }; Returns: undefined
                           },
"remove_org_member":
{ Args: { "p_org": string,"p_user": string }; Returns: undefined
                           },
"report_message":
{ Args: { "p_details"?: string,"p_message": string,"p_reason": string }; Returns: string
                           },
"report_met":
{ Args: { "p_plan": string }; Returns: {
              "a_confirmed_at": string | null,
"a_met_at": string | null,
"b_confirmed_at": string | null,
"b_met_at": string | null,
"created_at": string,
"id": string,
"invitation_id": string,
"place": string,
"planned_at": string | null,
"status": Database["public"]['Enums']["plan_status"],
"title": string,
"updated_at": string,
"user_a": string,
"user_b": string
            }
                          SetofOptions: {
        from: "*"
        to: "shared_plans"
        isOneToOne: true
        isSetofReturn: false
      } },
"respond_connection_request":
{ Args: { "p_accept": boolean,"p_request": string }; Returns: {
              "context": Database["public"]['Enums']["request_context"],
"context_id": string | null,
"created_at": string,
"from_user": string,
"id": string,
"message": string | null,
"responded_at": string | null,
"status": Database["public"]['Enums']["request_status"],
"to_user": string
            }
                          SetofOptions: {
        from: "*"
        to: "connection_requests"
        isOneToOne: true
        isSetofReturn: false
      } },
"respond_match_invitation":
{ Args: { "p_accept": boolean,"p_invitation": string }; Returns: string
                           },
"rotate_checkin_code":
{ Args: { "p_event": string }; Returns: string
                           },
"save_push_subscription":
{ Args: { "p_auth": string,"p_endpoint": string,"p_p256dh": string,"p_user_agent"?: string }; Returns: undefined
                           },
"schedule_push_jobs":
{ Args: Record<PropertyKey, never>; Returns: boolean
                           },
"school_domain_for_email":
{ Args: { "p_email": string }; Returns: string
                           },
"send_connection_request":
{ Args: { "p_context": Database["public"]['Enums']["request_context"],"p_context_id"?: string,"p_message"?: string,"p_to": string }; Returns: {
              "context": Database["public"]['Enums']["request_context"],
"context_id": string | null,
"created_at": string,
"from_user": string,
"id": string,
"message": string | null,
"responded_at": string | null,
"status": Database["public"]['Enums']["request_status"],
"to_user": string
            }
                          SetofOptions: {
        from: "*"
        to: "connection_requests"
        isOneToOne: true
        isSetofReturn: false
      } },
"send_match_invitation":
{ Args: { "p_from_intent": string,"p_message"?: string,"p_to_intent": string }; Returns: {
              "created_at": string,
"from_intent_id": string,
"from_user": string,
"id": string,
"message": string | null,
"responded_at": string | null,
"status": Database["public"]['Enums']["invitation_status"],
"to_intent_id": string,
"to_user": string
            }
                          SetofOptions: {
        from: "*"
        to: "match_invitations"
        isOneToOne: true
        isSetofReturn: false
      } },
"send_message":
{ Args: { "p_body": string,"p_to": string }; Returns: {
              "body": string,
"conversation_id": string,
"created_at": string,
"id": string,
"sender_id": string
            }
                          SetofOptions: {
        from: "*"
        to: "messages"
        isOneToOne: true
        isSetofReturn: false
      } },
"send_test_push":
{ Args: Record<PropertyKey, never>; Returns: boolean
                           },
"set_event_optin":
{ Args: { "p_event": string,"p_opted_in": boolean,"p_visible_fields"?: (string)[] }; Returns: {
              "event_id": string,
"opted_in": boolean,
"updated_at": string,
"user_id": string,
"visible_fields": (string)[]
            }
                          SetofOptions: {
        from: "*"
        to: "event_social_optin"
        isOneToOne: true
        isSetofReturn: false
      } },
"set_notification_preference":
{ Args: { "p_category": string,"p_enabled": boolean }; Returns: Json
                           },
"start_recommendation_request":
{ Args: { "p_want_llm"?: boolean }; Returns: Json
                           },
"stop_nearby":
{ Args: { "p_event": string }; Returns: undefined
                           },
"stop_open_presence":
{ Args: Record<PropertyKey, never>; Returns: undefined
                           },
"stop_plan_presence":
{ Args: { "p_plan": string }; Returns: undefined
                           },
"trust_summary":
{ Args: { "p_user"?: string }; Returns: Json
                           },
"unread_message_count":
{ Args: Record<PropertyKey, never>; Returns: number
                           },
"update_nearby_presence":
{ Args: { "p_accuracy": number,"p_event": string,"p_lat": number,"p_lng": number }; Returns: undefined
                           },
"update_open_presence":
{ Args: { "p_accuracy": number,"p_lat": number,"p_lng": number }; Returns: undefined
                           },
"update_plan_presence":
{ Args: { "p_accuracy": number,"p_lat": number,"p_lng": number,"p_plan": string }; Returns: Json
                           },
"update_shared_plan":
{ Args: { "p_place": string,"p_plan": string,"p_planned_at": string }; Returns: {
              "a_confirmed_at": string | null,
"a_met_at": string | null,
"b_confirmed_at": string | null,
"b_met_at": string | null,
"created_at": string,
"id": string,
"invitation_id": string,
"place": string,
"planned_at": string | null,
"status": Database["public"]['Enums']["plan_status"],
"title": string,
"updated_at": string,
"user_a": string,
"user_b": string
            }
                          SetofOptions: {
        from: "*"
        to: "shared_plans"
        isOneToOne: true
        isSetofReturn: false
      } },
"withdraw_connection_request":
{ Args: { "p_request": string }; Returns: undefined
                           },
"withdraw_location_consent":
{ Args: { "p_purpose": string }; Returns: undefined
                           },
"withdraw_match_invitation":
{ Args: { "p_invitation": string }; Returns: undefined
                           }
          }
          Enums: {
            "app_role": "user"|"admin","checkin_mode": "none"|"qr_geo"|"manual","correction_status": "pending"|"approved"|"rejected","event_status": "draft"|"published"|"cancelled"|"ended","event_type": "peer"|"group","event_visibility": "public"|"school","evidence_source": "qr_geo"|"organiser_manual"|"mutual_report","evidence_type": "self_reported_presence"|"organiser_confirmed_attendance"|"mutually_reported_interaction","intent_status": "open"|"matched"|"withdrawn","invitation_status": "pending"|"accepted"|"declined"|"withdrawn","org_role": "owner"|"organiser"|"staff","plan_status": "proposed"|"confirmed"|"cancelled","recommendation_event_kind": "impression"|"click"|"dismiss","report_status": "open"|"reviewing"|"resolved"|"dismissed","report_target": "user"|"event"|"intent"|"evidence"|"message","request_context": "event"|"nearby"|"intent"|"profile","request_status": "pending"|"accepted"|"declined"|"withdrawn","rsvp_status": "going"|"cancelled","verification_status": "unverified"|"geo_verified"|"verified"|"disputed"|"revoked"
          }
          CompositeTypes: {
            [_ in never]: never
          }
        }
}

type DatabaseWithoutInternals = Omit<Database, '__InternalSupabase'>

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never
> = DefaultSchemaTableNameOrOptions extends { schema: keyof DatabaseWithoutInternals }
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
  ? (DefaultSchema["Tables"] & DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
      Row: infer R
    }
    ? R
    : never
  : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never
> = DefaultSchemaTableNameOrOptions extends { schema: keyof DatabaseWithoutInternals }
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
  ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
      Insert: infer I
    }
    ? I
    : never
  : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never
> = DefaultSchemaTableNameOrOptions extends { schema: keyof DatabaseWithoutInternals }
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
  ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
      Update: infer U
    }
    ? U
    : never
  : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never
> = DefaultSchemaEnumNameOrOptions extends { schema: keyof DatabaseWithoutInternals }
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
  ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
  : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never
> = PublicCompositeTypeNameOrOptions extends { schema: keyof DatabaseWithoutInternals }
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
  ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
  : never

export const Constants = {
  "graphql_public": {
          Enums: {
            
          }
        },"public": {
          Enums: {
            "app_role": ["user", "admin"],"checkin_mode": ["none", "qr_geo", "manual"],"correction_status": ["pending", "approved", "rejected"],"event_status": ["draft", "published", "cancelled", "ended"],"event_type": ["peer", "group"],"event_visibility": ["public", "school"],"evidence_source": ["qr_geo", "organiser_manual", "mutual_report"],"evidence_type": ["self_reported_presence", "organiser_confirmed_attendance", "mutually_reported_interaction"],"intent_status": ["open", "matched", "withdrawn"],"invitation_status": ["pending", "accepted", "declined", "withdrawn"],"org_role": ["owner", "organiser", "staff"],"plan_status": ["proposed", "confirmed", "cancelled"],"recommendation_event_kind": ["impression", "click", "dismiss"],"report_status": ["open", "reviewing", "resolved", "dismissed"],"report_target": ["user", "event", "intent", "evidence", "message"],"request_context": ["event", "nearby", "intent", "profile"],"request_status": ["pending", "accepted", "declined", "withdrawn"],"rsvp_status": ["going", "cancelled"],"verification_status": ["unverified", "geo_verified", "verified", "disputed", "revoked"]
          }
        }
} as const
