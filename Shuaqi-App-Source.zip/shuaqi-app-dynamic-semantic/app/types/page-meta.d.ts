declare module '#app' {
  interface PageMeta {
    // Page needs a real browser (geolocation/camera); WeChat in-app browser shows an "open in browser" guide.
    requiresBrowser?: boolean
  }
}
export {}
