interface SessionClient<Session, Claims> {
  auth: {
    getSession(): Promise<{ data: { session: Session | null }; error: unknown }>
    getClaims(): Promise<{ data: { claims: Claims } | null; error: unknown }>
  }
}

/** Reconcile state from cookie storage; share one read when several resume events fire. */
export function createSessionSync<Session, Claims>(
  client: SessionClient<Session, Claims>,
  apply: (session: Session | null, claims: Claims | null) => void,
) {
  let pending: Promise<boolean> | null = null
  async function read() {
    try {
      const { data, error } = await client.auth.getSession()
      if (error) return false
      if (!data.session) { apply(null, null); return true }
      const verified = await client.auth.getClaims()
      if (verified.error || !verified.data?.claims) return false
      apply(data.session, verified.data.claims)
      return true
    } catch {
      // A temporary network failure must not erase a still-valid session or sign out other devices.
      return false
    }
  }
  return () => {
    pending ??= read().finally(() => { pending = null })
    return pending
  }
}
