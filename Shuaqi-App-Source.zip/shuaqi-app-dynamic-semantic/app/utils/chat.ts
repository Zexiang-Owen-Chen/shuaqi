import { LONDON_TZ } from './eventFormat'

export const MESSAGE_MAX = 1000

export interface ChatMessage { id: string; sender_id: string; body: string; created_at: string }

// Adds messages that arrived from Realtime, a poll or a send, without duplicates, oldest first.
export function mergeMessages<T extends ChatMessage>(list: T[], incoming: T[]): T[] {
  const byId = new Map(list.map(m => [m.id, m]))
  for (const m of incoming) byId.set(m.id, m)
  return [...byId.values()].sort((a, b) => Date.parse(a.created_at) - Date.parse(b.created_at) || a.id.localeCompare(b.id))
}

const dayKey = (d: Date) => d.toLocaleDateString('en-CA', { timeZone: LONDON_TZ })
const clock = (d: Date) => d.toLocaleTimeString('zh-CN', { timeZone: LONDON_TZ, hour: '2-digit', minute: '2-digit', hour12: false })

// Conversation list: time today, 昨天, weekday within a week, otherwise the date (London time).
export function formatChatTime(iso: string, now: Date = new Date()): string {
  const d = new Date(iso)
  const today = dayKey(now)
  const key = dayKey(d)
  if (key === today) return clock(d)
  const days = Math.round((Date.parse(today) - Date.parse(key)) / 86_400_000)
  if (days === 1) return '昨天'
  if (days > 1 && days < 7) return d.toLocaleDateString('zh-CN', { timeZone: LONDON_TZ, weekday: 'short' })
  const [, m, day] = key.split('-')
  return `${Number(m)}月${Number(day)}日`
}

// Divider inside a conversation: always includes the time, e.g. "14:05", "昨天 14:05", "10月3日 14:05".
export function formatDividerTime(iso: string, now: Date = new Date()): string {
  const d = new Date(iso)
  return dayKey(d) === dayKey(now) ? clock(d) : `${formatChatTime(iso, now)} ${clock(d)}`
}

// In a conversation, show a time divider when 5+ minutes passed since the previous message.
export function showTimeDivider(prev: ChatMessage | undefined, cur: ChatMessage): boolean {
  return !prev || Date.parse(cur.created_at) - Date.parse(prev.created_at) >= 5 * 60_000
}

export const unreadLabel = (n: number) => (n > 99 ? '99+' : String(n))
