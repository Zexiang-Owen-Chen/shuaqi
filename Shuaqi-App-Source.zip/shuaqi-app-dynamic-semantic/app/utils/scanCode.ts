// Event QR codes encode `${origin}/checkin/<code>`. The in-app scanner accepts any host (staging,
// production, preview deployments) but only ever navigates inside the app, so a foreign QR code
// cannot send people to another site.
const CODE = /^[A-Za-z0-9_-]{4,128}$/

export function parseCheckinCode(raw: string): string | null {
  const text = raw.trim()
  if (!text) return null
  if (CODE.test(text)) return text
  let url: URL
  try {
    url = new URL(text)
  } catch {
    return null
  }
  if (url.protocol !== 'https:' && url.protocol !== 'http:') return null
  const m = url.pathname.match(/^\/checkin\/([^/]+)\/?$/)
  if (!m) return null
  return CODE.test(m[1]!) ? m[1]! : null
}
