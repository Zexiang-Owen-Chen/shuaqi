// Where to go after sign-in: ?redirect= first, then the page the auth middleware remembered.
// Only same-site paths are accepted.
export function safeRedirect(...candidates: unknown[]): string {
  for (const c of candidates) {
    if (typeof c === 'string' && c.startsWith('/') && !c.startsWith('//') && !c.startsWith('/login')) return c
  }
  return '/'
}
