/** Imperial's short email domain uses the same login identity as its full domain. */
export function normalizeSchoolEmail(email: string): string {
  return email.trim().toLowerCase().replace(/@ic\.ac\.uk$/, '@imperial.ac.uk')
}
