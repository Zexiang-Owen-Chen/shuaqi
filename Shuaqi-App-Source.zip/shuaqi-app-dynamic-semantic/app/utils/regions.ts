export const REGION_CITIES = ['London', 'Oxford', 'Cambridge'] as const

// Keep these persisted values aligned with normalize_region() in the migration.
export const LONDON_REGIONS = [
  { value: 'London / South Kensington / Chelsea', label: 'South Kensington / Chelsea' },
  { value: "London / Bloomsbury / King's Cross", label: "Bloomsbury / King's Cross" },
  { value: 'London / Holborn / Covent Garden', label: 'Holborn / Covent Garden' },
  { value: 'London / Camden', label: 'Camden' },
  { value: 'London / City / Shoreditch', label: 'City / Shoreditch' },
  { value: 'London / Canary Wharf / East', label: 'Canary Wharf / East' },
  { value: 'London / South Bank / Southwark', label: 'South Bank / Southwark' },
  { value: 'London / West', label: 'West（Hammersmith 等）' },
  { value: 'London / Other', label: '伦敦其他 / 未细分' },
] as const

export function isRegion(value: string): boolean {
  return value === 'Oxford' || value === 'Cambridge' || LONDON_REGIONS.some(r => r.value === value)
}

export function regionCity(value: string): string {
  if (!isRegion(value)) return ''
  return value.startsWith('London / ') ? 'London' : value
}
