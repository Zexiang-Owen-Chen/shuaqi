export const EVENT_IMAGE_BUCKET = 'event-images'
export const MAX_EVENT_IMAGES = 6
export const MAX_EVENT_IMAGE_BYTES = 5 * 1024 * 1024
export const EVENT_IMAGE_TYPES: Record<string, string> = {
  'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp',
}

export function eventImageError(file: { type: string; size: number }): string | null {
  if (!Object.hasOwn(EVENT_IMAGE_TYPES, file.type)) return '请选择 JPEG、PNG 或 WebP 图片'
  if (file.size > MAX_EVENT_IMAGE_BYTES) return '每张图片不能超过 5MB'
  return null
}
