// Shared helpers for event pages (owned by the events module).
import type { Database } from '~/types/database.types'

export type EventRow = Database['public']['Tables']['events']['Row']

/** What EventForm emits; org_id is only used on create. */
export type EventFormPayload = {
  title: string
  category: string
  description: string
  image_paths: string[]
  starts_at: string
  ends_at: string | null
  location_text: string
  location_lat: number | null
  location_lng: number | null
  checkin_mode: Database['public']['Enums']['checkin_mode']
  checkin_radius_m: number
  capacity: number | null
  visibility: Database['public']['Enums']['event_visibility']
  require_checkin_for_connect: boolean
  /** Only used when creating. */
  org_id: string | null
}

export const EVENT_CATEGORIES = ['运动', '学习', '美食', '音乐', '桌游', '户外', '派对', '其他'] as const

export const LONDON_TZ = 'Europe/London'

export const CHECKIN_MODE_LABEL: Record<string, string> = {
  none: '不签到',
  qr_geo: '扫码 + 定位签到',
  manual: '主办方手动确认',
}

export const EVENT_STATUS_LABEL: Record<string, string> = {
  draft: '草稿',
  published: '报名中',
  cancelled: '已取消',
  ended: '已结束',
}

export const VISIBLE_FIELD_LABEL: Record<string, string> = {
  bio: '个人简介',
  interests: '兴趣',
  photos: '照片',
  gender: '性别',
  age: '年龄',
  region: '地区',
}

/** Card returned by get_profile_card / list_event_participants. Keys are present only when visible. */
export interface ProfileCard {
  id: string
  display_name: string | null
  avatar_url: string | null
  school_domain: string | null
  school_verified: boolean
  connected: boolean
  is_me: boolean
  bio?: string | null
  interests?: string[] | null
  gender?: string | null
  region?: string | null
  age?: number | null
  photos?: string[]
}

export function currentUid(user: { sub?: string; id?: string } | null | undefined): string | null {
  return (user?.sub ?? user?.id) || null
}

const dayFmt = new Intl.DateTimeFormat('zh-CN', {
  timeZone: LONDON_TZ, month: 'long', day: 'numeric', weekday: 'short',
})
const timeFmt = new Intl.DateTimeFormat('zh-CN', {
  timeZone: LONDON_TZ, hour: '2-digit', minute: '2-digit', hour12: false,
})
const dateKeyFmt = new Intl.DateTimeFormat('en-CA', {
  timeZone: LONDON_TZ, year: 'numeric', month: '2-digit', day: '2-digit',
})

/** e.g. "10月21日 周二 19:00–21:00" (London time). */
export function formatEventTime(startsAt: string, endsAt?: string | null): string {
  const s = new Date(startsAt)
  let out = `${dayFmt.format(s)} ${timeFmt.format(s)}`
  if (endsAt) {
    const e = new Date(endsAt)
    out += dateKeyFmt.format(s) === dateKeyFmt.format(e)
      ? `–${timeFmt.format(e)}`
      : ` – ${dayFmt.format(e)} ${timeFmt.format(e)}`
  }
  return out
}

/** Whether the event is over (ends_at, or starts_at + 6h when no end time). */
export function eventIsOver(e: Pick<EventRow, 'starts_at' | 'ends_at'>): boolean {
  const end = e.ends_at ? new Date(e.ends_at) : new Date(new Date(e.starts_at).getTime() + 6 * 3600e3)
  return end.getTime() < Date.now()
}

function londonParts(d: Date) {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: LONDON_TZ, year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
  }).formatToParts(d)
  const get = (t: string) => Number(parts.find((p) => p.type === t)?.value)
  return { y: get('year'), mo: get('month'), d: get('day'), h: get('hour'), mi: get('minute') }
}

/** ISO timestamp -> "YYYY-MM-DDTHH:mm" in London time, for <input type="datetime-local">. */
export function toLondonInput(iso: string | null | undefined): string {
  if (!iso) return ''
  const p = londonParts(new Date(iso))
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${p.y}-${pad(p.mo)}-${pad(p.d)}T${pad(p.h)}:${pad(p.mi)}`
}

/** "YYYY-MM-DDTHH:mm" interpreted as London wall-clock time -> ISO (UTC). */
export function fromLondonInput(value: string): string | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/.exec(value)
  if (!m) return null
  const [y, mo, d, h, mi] = m.slice(1).map(Number) as [number, number, number, number, number]
  const wanted = Date.UTC(y, mo - 1, d, h, mi)
  // Guess UTC = wall clock, then correct by London's offset at that instant (twice to settle DST edges).
  let t = wanted
  for (let i = 0; i < 2; i++) {
    const p = londonParts(new Date(t))
    const shown = Date.UTC(p.y, p.mo - 1, p.d, p.h, p.mi)
    t += wanted - shown
  }
  return new Date(t).toISOString()
}
