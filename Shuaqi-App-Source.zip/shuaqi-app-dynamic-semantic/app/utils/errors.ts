// Database functions raise short snake_case codes; this maps them to UI text.
export const errorText: Record<string, string> = {
  region_invalid: '请选择列表中的城市和地区',
  region_required: '请选择所在城市和地区',
  not_authenticated: '请先登录',
  event_images_limit: '最多上传 6 张活动图片',
  event_images_invalid: '活动图片无效，请重新上传',
  event_image_not_owned: '只能添加自己上传的活动图片',
  school_email_required: '请使用已支持的学校邮箱（牛津、剑桥、帝国理工、UCL、LSE、KCL、UAL）注册',
  school_verification_required: '请先完成学校邮箱验证',
  forbidden: '你没有权限进行这个操作',
  feature_disabled: '这个功能暂时关闭了',
  event_not_found: '活动不存在或你无权查看',
  event_cancelled: '活动已取消',
  event_closed: '活动已结束或未开放报名',
  event_full: '活动已满员',
  host_cannot_leave: '发起人不能退出自己的活动，可以取消活动',
  host_must_be_self: '只能以自己的身份发起活动',
  not_org_organiser: '你不是这个组织的组织者',
  starts_in_past: '开始时间不能早于现在',
  capacity_below_going: '人数上限不能低于已报名人数',
  immutable_owner: '不能更改活动的发起人或组织',
  not_registered: '请先报名这个活动',
  invalid_fields: '可见字段无效',
  cannot_connect_self: '不能添加自己',
  blocked: '无法与对方建立联系',
  already_connected: '你们已经是好友了',
  incoming_request_pending: '对方已经向你发送了请求，去“我的”里处理吧',
  not_discoverable: '对方当前不可被发现',
  checkin_required: '双方都需要先在活动现场签到',
  not_nearby: '对方不在你 50 米范围内',
  nearby_not_active: '请先开启“附近的人”',
  context_not_allowed: '当前场景不支持添加好友',
  request_not_found: '请求不存在',
  request_not_pending: '这个请求已经处理过了',
  cannot_block_self: '不能拉黑自己',
  intent_not_found: '需求不存在',
  not_compatible: '双方需求已不再匹配',
  incoming_invitation_pending: '对方已经邀请了你，去处理邀请吧',
  invitation_not_found: '邀请不存在',
  invitation_not_pending: '这个邀请已经处理过了',
  plan_not_found: '计划不存在',
  plan_cancelled: '计划已取消',
  plan_time_required: '请先确定时间',
  plan_not_confirmed: '双方确认计划后才能标记见面',
  plan_not_started: '计划开始后才能标记见面',
  correction_not_pending: '这个更正申请已经处理过了',
  note_required: '请填写备注',
  user_not_found: '找不到这个邮箱对应的用户',
  // event_checkin() reasons
  invalid_code: '签到码无效或已被主办方重置',
  event_not_active: '活动当前不可签到',
  checkin_disabled: '这个活动未开启扫码签到',
  outside_window: '不在签到时间内',
  location_required: '签到需要获取你的位置',
  location_inaccurate: '定位精度不够，请到窗边或开启精确定位后重试',
  too_far: '你离活动地点太远了',
  cannot_confirm_self: '不能给自己确认到场，请让其他工作人员确认',
  invalid_status: '活动状态无效',
  location_consent_required: '使用“附近的人”需要先同意使用你的位置',
  meetup_not_open: '约定时间前 1 小时到之后 6 小时内才能使用到达提示',
  // chat
  not_connected: '你们还不是好友，不能聊天',
  message_empty: '请输入消息内容',
  message_too_long: '消息太长了，最多 1000 字',
  rate_limited: '发送太频繁了，请稍后再试',
  conversation_not_found: '对话不存在',
  message_not_found: '消息不存在',
  cannot_report_own_message: '不能举报自己发的消息',
  // push notifications
  invalid_subscription: '这台设备无法开启通知，请换个浏览器试试',
  push_not_subscribed: '这台设备还没有开启通知',
  invalid_category: '通知类型无效',
}

export function messageFor(err: unknown): string {
  const raw = typeof err === 'string' ? err : (err as { message?: string })?.message ?? ''
  const code = (err as { code?: string })?.code
  if (code === '42501' || raw.includes('row-level security')) return '没有权限：请确认已完成学校邮箱验证，或该功能暂未开放'
  const known = errorText[raw]
  if (known) return known
  if (raw.includes('school_email_required') || raw.includes('Database error saving new user')) return errorText.school_email_required!
  return raw || '出了点问题，请稍后再试'
}
