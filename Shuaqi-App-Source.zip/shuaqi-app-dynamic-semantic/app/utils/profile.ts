export const GENDERS = [
  { value: 'female', label: '女' },
  { value: 'male', label: '男' },
  { value: 'non_binary', label: '非二元' },
  { value: 'prefer_not_to_say', label: '不透露' },
] as const

export const INTERESTS = ['跑步', '健身', '羽毛球', '网球', '篮球', '足球', '游泳', '徒步', '骑行', '学习', '读书',
  '美食', '咖啡', '看展', '音乐', '电影', '桌游', '剧本杀', '摄影', '旅行', '派对', '编程', '创业'] as const

export const VISIBILITY_FIELDS = [
  { key: 'bio', label: '个人介绍' },
  { key: 'interests', label: '兴趣' },
  { key: 'photos', label: '照片' },
  { key: 'gender', label: '性别' },
  { key: 'age', label: '年龄' },
] as const

export const SCOPES = [
  { value: 'public', label: '所有人' },
  { value: 'connections', label: '仅好友' },
  { value: 'hidden', label: '隐藏' },
] as const

export const SCHOOL_NAMES: Record<string, string> = {
  'ox.ac.uk': '牛津大学',
  'cam.ac.uk': '剑桥大学',
  'imperial.ac.uk': '帝国理工',
  'ucl.ac.uk': 'UCL',
  'lse.ac.uk': 'LSE',
  'kcl.ac.uk': '伦敦国王学院',
  'ual.ac.uk': '伦敦艺术大学',
}

export const genderLabel = (g?: string | null) => GENDERS.find(x => x.value === g)?.label ?? ''

export function publicUrl(bucket: 'avatars' | 'photos', path?: string | null) {
  if (!path) return ''
  if (path.startsWith('http')) return path
  const base = useRuntimeConfig().public.supabase.url as string
  return `${base}/storage/v1/object/public/${bucket}/${path}`
}
