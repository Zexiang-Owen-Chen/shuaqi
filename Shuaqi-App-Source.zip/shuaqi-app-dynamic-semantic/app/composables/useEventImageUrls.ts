export function useEventImageUrls(paths: MaybeRefOrGetter<readonly string[]>) {
  const supabase = useSupabaseClient()
  const images = ref<{ path: string; url: string }[]>([])
  const loading = ref(false)
  const error = ref('')
  let revision = 0

  async function refresh() {
    const current = ++revision
    const list = [...toValue(paths)]
    images.value = list.map(path => ({ path, url: '' }))
    error.value = ''
    if (!list.length) { loading.value = false; return }
    loading.value = true
    try {
      const { data, error: failure } = await supabase.storage.from(EVENT_IMAGE_BUCKET).createSignedUrls(list, 3600)
      if (current !== revision) return
      if (failure || !data || data.some(image => !image.signedUrl)) throw new Error('活动图片加载失败，请重试')
      images.value = list.map((path, i) => ({ path, url: data?.[i]?.signedUrl ?? '' }))
    } catch {
      if (current === revision) error.value = '活动图片加载失败，请重试'
    } finally {
      if (current === revision) loading.value = false
    }
  }

  watch(() => [...toValue(paths)], refresh, { immediate: true })
  onScopeDispose(() => { revision++ })
  return { images, loading, error, refresh }
}
