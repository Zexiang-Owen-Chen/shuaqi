/**
 * PWA install guide (S13): device detection, Android install prompt,
 * 7-day dismissal, and the "nudge" other pages fire after RSVP / check-in.
 *
 * A web page can only offer installation; the user always confirms the last
 * step. Everything works without installing.
 */

import { computed, readonly, ref, shallowRef } from 'vue'

// ---------------------------------------------------------------------------
// Detection (pure, unit-tested in useInstallPrompt.test.ts)
// ---------------------------------------------------------------------------

export type PwaOs = 'ios' | 'android' | 'desktop'

/**
 * - `wechat`: WeChat / WeCom built-in browser (cannot install, location unreliable)
 * - `inapp`: other in-app browsers (Instagram, Facebook, Weibo, QQ, LINE...)
 * - `safari`: iOS Safari
 * - `ios-other`: Chrome / Edge / Firefox on iOS (share-menu install since iOS 16.4)
 * - `chromium`: Chrome / Edge / Samsung Internet / Opera on Android or desktop
 * - `firefox`: Firefox on Android or desktop (never fires beforeinstallprompt)
 */
export type PwaBrowser = 'wechat' | 'inapp' | 'safari' | 'ios-other' | 'chromium' | 'firefox' | 'other'

export interface PwaPlatform {
  os: PwaOs
  browser: PwaBrowser
  /** Safari major version on iOS (e.g. 26), null when unknown. */
  safariVersion: number | null
  /** Already running from the home screen. */
  standalone: boolean
}

const INAPP_RE = /FBAN|FBAV|FB_IAB|Instagram|Line\/|Weibo|QQ\/|DingTalk|Lark|Feishu|LinkedInApp|Snapchat|TikTok|musical_ly|Bytedance/i

export function detectPlatform(ua: string, env: { maxTouchPoints?: number, standalone?: boolean } = {}): PwaPlatform {
  // iPadOS Safari reports "Macintosh"; only touch tells it apart from a Mac.
  const iPadOs = /Macintosh/.test(ua) && (env.maxTouchPoints ?? 0) > 1
  const os: PwaOs = /iPhone|iPad|iPod/.test(ua) || iPadOs ? 'ios' : /Android/i.test(ua) ? 'android' : 'desktop'

  let browser: PwaBrowser
  if (/MicroMessenger|wxwork/i.test(ua)) browser = 'wechat'
  else if (INAPP_RE.test(ua)) browser = 'inapp'
  else if (os === 'ios') browser = /CriOS|FxiOS|EdgiOS|OPiOS|GSA\//.test(ua) ? 'ios-other' : 'safari'
  else if (/Firefox\//.test(ua)) browser = 'firefox'
  else if (/Chrome\/|Chromium\/|SamsungBrowser|EdgA?\//.test(ua)) browser = 'chromium'
  else browser = 'other'

  // Safari 26 freezes the OS version in the UA at 18_6, so read Version/xx instead.
  const v = os === 'ios' ? /Version\/(\d+)/.exec(ua) : null
  return { os, browser, safariVersion: v ? Number(v[1]) : null, standalone: !!env.standalone }
}

export type PwaGuideKind = 'installed' | 'wechat' | 'inapp' | 'ios' | 'android' | 'desktop'

export function guideKind(p: PwaPlatform): PwaGuideKind {
  if (p.standalone) return 'installed'
  if (p.browser === 'wechat' || p.browser === 'inapp') return p.browser
  return p.os === 'ios' ? 'ios' : p.os === 'android' ? 'android' : 'desktop'
}

export interface InstallGuide {
  title: string
  steps: string[]
  note?: string
}

/** Real, device-specific steps shown on S13 and in the banner sheet. */
export function installGuide(kind: Exclude<PwaGuideKind, 'installed'>, p?: PwaPlatform | null): InstallGuide {
  switch (kind) {
    case 'ios': {
      const sessionNote = '从主屏幕打开的 SHUAQI 不和浏览器共用登录状态，第一次打开需要再登录一次。'
      if (p?.browser === 'ios-other') {
        return {
          title: 'iPhone',
          steps: ['点地址栏右侧的「分享」按钮', '在菜单里找到「添加到主屏幕」', '点右上角「添加」'],
          note: `如果找不到「添加到主屏幕」，请用 Safari 打开本页。${sessionNote}`,
        }
      }
      if (p?.safariVersion && p.safariVersion >= 26) {
        return {
          title: 'iPhone',
          steps: ['点地址栏旁边的「···」', '点「分享」', '向下滑，点「添加到主屏幕」（可能在「更多」里）', '保持「作为 Web App 打开」开启，点「添加」'],
          note: sessionNote,
        }
      }
      return {
        title: 'iPhone',
        steps: ['点浏览器底部的「分享」按钮（方框加向上箭头；iPad 在顶部）', '向下滑，点「添加到主屏幕」', '点右上角「添加」'],
        note: sessionNote,
      }
    }
    case 'android':
      return {
        title: 'Android',
        steps: ['点下方「安装 SHUAQI」按钮', '在系统弹窗里点「安装」'],
        note: '没有看到按钮？点浏览器右上角「⋮」，选「安装应用」或「添加到主屏幕」。三星浏览器在底部菜单「≡」→「添加页面至」→「主屏幕」。',
      }
    case 'wechat':
      return {
        title: '微信内打开',
        steps: ['点右上角「···」', '选择「在浏览器打开」（iPhone 上可能显示为「在 Safari 中打开」或「在默认浏览器中打开」）'],
        note: '在微信里可以先浏览，但扫码签到、定位和安装需要在浏览器里进行。',
      }
    case 'inapp':
      return {
        title: 'App 内打开',
        steps: ['点右上角「···」或分享按钮', '选择「在浏览器中打开」'],
        note: '在当前 App 里可以先浏览，但签到、定位和安装需要在手机浏览器里进行。',
      }
    case 'desktop':
      return {
        title: '电脑',
        steps: ['用手机扫描下方二维码，在手机上打开 SHUAQI', 'Chrome 或 Edge 也可以点地址栏右侧的安装图标安装到电脑'],
      }
  }
}

// ---------------------------------------------------------------------------
// Runtime state (client only)
// ---------------------------------------------------------------------------

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>
}

export type InstallNudgeReason = 'rsvp' | 'checkin'

const DISMISS_KEY = 'shuaqi.install.dismissedAt'
const DISMISS_MS = 7 * 24 * 60 * 60 * 1000

// Module-level so the event is caught as soon as the layout imports this file,
// before any page asks for it. Only ever written on the client.
const deferredPrompt = shallowRef<BeforeInstallPromptEvent | null>(null)
const installedNow = ref(false)
const platform = shallowRef<PwaPlatform | null>(null)
const dismissedAt = ref<number | null>(null)

function readDismissed(): number | null {
  try {
    const v = Number(localStorage.getItem(DISMISS_KEY))
    return Number.isFinite(v) && v > 0 ? v : null
  }
  catch { return null }
}

function isStandalone(): boolean {
  return window.matchMedia?.('(display-mode: standalone)').matches
    || (navigator as Navigator & { standalone?: boolean }).standalone === true
}

if (import.meta.client) {
  platform.value = detectPlatform(navigator.userAgent, { maxTouchPoints: navigator.maxTouchPoints, standalone: isStandalone() })
  dismissedAt.value = readDismissed()
  window.addEventListener('beforeinstallprompt', (e) => {
    // Keep Chrome's mini-infobar away; we show our own button at the right moment.
    e.preventDefault()
    deferredPrompt.value = e as BeforeInstallPromptEvent
  })
  window.addEventListener('appinstalled', () => {
    installedNow.value = true
    deferredPrompt.value = null
  })
}

export function useInstallPrompt() {
  const nudgeReason = useState<InstallNudgeReason | null>('install-nudge', () => null)

  const kind = computed<PwaGuideKind | null>(() => (platform.value ? guideKind(platform.value) : null))
  const standalone = computed(() => kind.value === 'installed')
  const installed = computed(() => installedNow.value || standalone.value)
  const canPrompt = computed(() => !!deferredPrompt.value && !installed.value)
  const dismissed = computed(() => dismissedAt.value !== null && Date.now() - dismissedAt.value < DISMISS_MS)

  /** Whether the post-RSVP / post-check-in banner may appear on this device. */
  const eligible = computed(() => {
    if (!kind.value || installed.value || dismissed.value) return false
    if (kind.value === 'ios') return true
    return (kind.value === 'android' || kind.value === 'desktop') && canPrompt.value
  })

  /** Call after a successful RSVP or check-in. Shows the banner if eligible. */
  function nudge(reason: InstallNudgeReason) {
    if (eligible.value) nudgeReason.value = reason
  }

  /** User closed the banner: hide it for 7 days. */
  function dismiss() {
    nudgeReason.value = null
    dismissedAt.value = Date.now()
    try { localStorage.setItem(DISMISS_KEY, String(dismissedAt.value)) }
    catch { /* private mode: dismissal lasts this session only */ }
  }

  /** Opens the system install dialog (Android / desktop Chromium only). */
  async function install(): Promise<'accepted' | 'dismissed' | 'unavailable'> {
    const e = deferredPrompt.value
    if (!e) return 'unavailable'
    // A prompt event can only be used once.
    deferredPrompt.value = null
    await e.prompt()
    const { outcome } = await e.userChoice
    if (outcome === 'accepted') {
      installedNow.value = true
      nudgeReason.value = null
    }
    return outcome
  }

  return {
    platform: readonly(platform),
    kind,
    /** Running from the home screen right now. */
    standalone,
    /** Running from the home screen, or installed during this visit. */
    installed,
    canPrompt,
    dismissed,
    eligible,
    nudgeReason: readonly(nudgeReason),
    nudge,
    dismiss,
    install,
    guide: (k: Exclude<PwaGuideKind, 'installed'>) => installGuide(k, platform.value),
  }
}
