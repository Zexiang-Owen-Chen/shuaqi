/**
 * Web push notifications: what this device supports, the browser permission, and subscribing
 * this device for the signed-in user. Delivery happens on the server (server/api/push/dispatch).
 *
 * Platforms: Android and desktop browsers work in the browser. iPhone/iPad (iOS 16.4+) only from
 * the home-screen app, so the install guide (S13) comes first. WeChat and other in-app browsers
 * never get the system prompt.
 */

import type { PwaPlatform } from './useInstallPrompt'

// ---------------------------------------------------------------------------
// Pure helpers (unit-tested in tests/unit/usePush.test.ts)
// ---------------------------------------------------------------------------

/**
 * - `supported`: can ask for permission here
 * - `needs-install`: iPhone/iPad in the browser; add to home screen first
 * - `ios-too-old`: home-screen app on iOS older than 16.4
 * - `in-app`: WeChat or another in-app browser
 * - `unsupported`: this browser has no web push
 */
export type PushSupport = 'supported' | 'needs-install' | 'ios-too-old' | 'in-app' | 'unsupported'

export interface PushCaps {
  serviceWorker: boolean
  pushManager: boolean
  notification: boolean
}

export function pushSupport(p: PwaPlatform, caps: PushCaps): PushSupport {
  if (p.browser === 'wechat' || p.browser === 'inapp') return 'in-app'
  const hasPush = caps.serviceWorker && caps.pushManager && caps.notification
  if (p.os === 'ios') {
    if (!p.standalone) return 'needs-install'
    return hasPush ? 'supported' : 'ios-too-old'
  }
  return hasPush ? 'supported' : 'unsupported'
}

/** VAPID public key (base64url) → bytes for pushManager.subscribe. */
export function urlBase64ToUint8Array(base64url: string): Uint8Array<ArrayBuffer> {
  const padded = (base64url + '='.repeat((4 - (base64url.length % 4)) % 4)).replace(/-/g, '+').replace(/_/g, '/')
  const raw = atob(padded)
  const out = new Uint8Array(new ArrayBuffer(raw.length))
  for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i)
  return out
}

export function sameKey(a: ArrayBuffer | null | undefined, b: Uint8Array): boolean {
  if (!a || a.byteLength !== b.length) return false
  const x = new Uint8Array(a)
  return x.every((v, i) => v === b[i])
}

export type NotificationCategory = 'message' | 'friend_request' | 'buddy' | 'event_reminder'
export type NotificationPrefs = Record<NotificationCategory, boolean>

export const NOTIFICATION_CATEGORIES: { key: NotificationCategory, label: string, hint: string }[] = [
  { key: 'message', label: '新消息', hint: '好友发来的聊天消息' },
  { key: 'friend_request', label: '好友请求', hint: '有人想加你，或通过了你的请求' },
  { key: 'buddy', label: '搭子', hint: '收到搭子邀请、匹配成功、计划确定' },
  { key: 'event_reminder', label: '活动提醒', hint: '报名的活动开始前约 1 小时' },
]

// ---------------------------------------------------------------------------
// Runtime (client only)
// ---------------------------------------------------------------------------

export type PushPermission = NotificationPermission | 'unsupported'

const ASK_KEY = 'shuaqi.push.askDismissedAt'
const ASK_SNOOZE_MS = 14 * 24 * 60 * 60 * 1000
const SW_READY_MS = 10_000

function caps(): PushCaps {
  return {
    serviceWorker: 'serviceWorker' in navigator,
    pushManager: 'PushManager' in window,
    notification: 'Notification' in window,
  }
}

async function registration(): Promise<ServiceWorkerRegistration> {
  // The service worker is registered by @vite-pwa; it is off in `nuxt dev`.
  const timeout = new Promise<never>((_, reject) =>
    setTimeout(() => reject(new Error('通知服务还没准备好，请刷新页面后再试')), SW_READY_MS))
  return Promise.race([navigator.serviceWorker.ready, timeout])
}

async function currentSubscription(): Promise<PushSubscription | null> {
  const reg = await navigator.serviceWorker.getRegistration()
  return (await reg?.pushManager.getSubscription()) ?? null
}

export function usePush() {
  const rpc = useRpc()
  const user = useSupabaseUser()
  const config = useRuntimeConfig()
  const { platform } = useInstallPrompt()
  const { isOn } = useFeatureFlags()

  const permission = useState<PushPermission>('push-permission', () => 'default')
  /** This device is registered for the signed-in user. */
  const subscribed = useState<boolean>('push-subscribed', () => false)
  const checked = useState<boolean>('push-checked', () => false)
  const askDismissedAt = useState<number | null>('push-ask-dismissed', () => null)

  const configured = computed(() => !!config.public.vapidPublicKey)
  const support = computed<PushSupport | null>(() =>
    import.meta.client && platform.value ? pushSupport(platform.value, caps()) : null)
  const available = computed(() => isOn('push') && configured.value)

  const askSnoozed = computed(() => !!askDismissedAt.value && Date.now() - askDismissedAt.value < ASK_SNOOZE_MS)
  /** Whether to show the "开启通知" card (never the system prompt by itself). */
  const canAsk = computed(() => available.value && checked.value && !subscribed.value
    && support.value === 'supported' && permission.value !== 'denied' && !askSnoozed.value)

  /** Reads the permission and whether this device is registered. Safe to call often. */
  async function refresh() {
    if (import.meta.server) return
    try { askDismissedAt.value = Number(localStorage.getItem(ASK_KEY)) || null }
    catch { /* private mode */ }
    if (support.value !== 'supported') {
      permission.value = 'unsupported'
      subscribed.value = false
      checked.value = true
      return
    }
    permission.value = Notification.permission
    try {
      const sub = permission.value === 'granted' && user.value ? await currentSubscription() : null
      subscribed.value = sub ? await rpc('has_push_subscription', { p_endpoint: sub.endpoint }) : false
    }
    catch { subscribed.value = false }
    checked.value = true
  }

  /**
   * Asks for permission and registers this device. Call straight from a tap: iOS only shows the
   * prompt for a user gesture, so nothing may be awaited before requestPermission().
   */
  async function enable(): Promise<PushPermission> {
    if (support.value !== 'supported') return 'unsupported'
    if (!configured.value) throw new Error('通知功能还没配置好，请稍后再试')
    const result = await Notification.requestPermission()
    permission.value = result
    if (result !== 'granted') return result

    const key = urlBase64ToUint8Array(config.public.vapidPublicKey as string)
    const reg = await registration()
    let sub = await reg.pushManager.getSubscription()
    // A subscription made with an older key cannot receive our pushes.
    if (sub && !sameKey(sub.options.applicationServerKey, key)) {
      await sub.unsubscribe()
      sub = null
    }
    sub ??= await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: key })
    const json = sub.toJSON()
    await rpc('save_push_subscription', {
      p_endpoint: sub.endpoint,
      p_p256dh: json.keys?.p256dh ?? '',
      p_auth: json.keys?.auth ?? '',
      p_user_agent: navigator.userAgent.slice(0, 300),
    })
    subscribed.value = true
    return result
  }

  /** Stops notifications on this device (other devices keep theirs). Also used on sign-out. */
  async function disable() {
    if (import.meta.server || !('serviceWorker' in navigator)) return
    const sub = await currentSubscription().catch(() => null)
    if (sub) {
      await rpc('delete_push_subscription', { p_endpoint: sub.endpoint }).catch(() => {})
      await sub.unsubscribe().catch(() => false)
    }
    subscribed.value = false
  }

  /** "以后再说" on the opt-in card: hide it for 14 days. */
  function snoozeAsk() {
    askDismissedAt.value = Date.now()
    try { localStorage.setItem(ASK_KEY, String(askDismissedAt.value)) }
    catch { /* private mode: lasts this visit */ }
  }

  return { support, configured, available, permission, subscribed, checked, canAsk, askSnoozed, refresh, enable, disable, snoozeAsk }
}
