import type { Database } from '~/types/database.types'

type Fns = Database['public']['Functions']

// A request that never answers (lost connection, captive Wi-Fi) would leave the caller's spinner
// running forever; give up after this long and say so.
export const RPC_TIMEOUT_MS = 20000
export const RPC_TIMEOUT_MESSAGE = '网络连接超时，请检查网络后重试'

// AbortController rather than AbortSignal.timeout(): that needs iOS 16 or later.
export function timeoutSignal(ms: number): AbortSignal {
  const c = new AbortController()
  setTimeout(() => c.abort(), ms)
  return c.signal
}

// Typed wrapper around supabase.rpc that throws a readable Error.
export function useRpc() {
  const supabase = useSupabaseClient<Database>()
  return async function rpc<K extends keyof Fns & string>(
    name: K,
    args?: Fns[K]['Args'],
  ): Promise<Fns[K]['Returns']> {
    const signal = timeoutSignal(RPC_TIMEOUT_MS)
    const { data, error } = await supabase.rpc(name, args as never).abortSignal(signal)
    if (error) throw new Error(signal.aborted ? RPC_TIMEOUT_MESSAGE : messageFor(error))
    return data as Fns[K]['Returns']
  }
}
