import { STALLED_MESSAGE, type GeoFix } from './useGeo'

// Shape of the jsonb returned by event_checkin() (see CONTRACT.md).
export interface CheckinResult {
  ok: boolean
  reason?: CheckinReason
  already?: boolean
  status?: string
  event_id?: string
  distance_m?: number
  accuracy_m?: number
  opens_at?: string
  closes_at?: string
}

export type CheckinReason =
  | 'invalid_code' | 'event_not_active' | 'checkin_disabled' | 'outside_window'
  | 'not_registered' | 'location_required' | 'location_inaccurate' | 'too_far'

export interface CheckinEvent {
  event_id: string
  title: string
  starts_at: string
  location_text: string | null
  checkin_radius_m: number
}

// The server rejects fixes worse than this.
export const MAX_ACCURACY_M = 100
// Stop retrying once a fix is at least this good.
const GOOD_ACCURACY_M = 50

export function formatLondon(iso: string | null | undefined, withDate = true): string {
  if (!iso) return ''
  return new Date(iso).toLocaleString('zh-CN', {
    timeZone: 'Europe/London',
    ...(withDate ? { month: 'numeric', day: 'numeric', weekday: 'short' } : {}),
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  })
}

// Mirrors the default window in event_checkin(); used only for display.
export function checkinWindow(e: {
  starts_at: string
  ends_at?: string | null
  checkin_opens_at?: string | null
  checkin_closes_at?: string | null
}): { opensAt: Date; closesAt: Date } {
  const start = new Date(e.starts_at).getTime()
  const opensAt = e.checkin_opens_at ? new Date(e.checkin_opens_at) : new Date(start - 3600_000)
  const closesAt = e.checkin_closes_at
    ? new Date(e.checkin_closes_at)
    : e.ends_at ? new Date(e.ends_at) : new Date(start + 6 * 3600_000)
  return { opensAt, closesAt }
}

// Take several fixes and keep the most accurate; indoor GPS often improves on the second try.
// getFix receives the attempt number so retries can use a shorter timeout.
export async function bestFix(
  getFix: (attempt: number) => Promise<GeoFix>,
  maxTries = 3,
): Promise<GeoFix> {
  let best: GeoFix | null = null
  let lastError: unknown
  for (let i = 0; i < maxTries; i++) {
    try {
      const fix = await getFix(i)
      if (!best || fix.accuracy < best.accuracy) best = fix
      if (best.accuracy <= GOOD_ACCURACY_M) break
    } catch (e) {
      lastError = e
      // Keep what we have rather than make the user wait; a denied or stalled permission will not change on retry.
      const msg = (e as Error)?.message ?? ''
      if (best || /拒绝/.test(msg) || msg === STALLED_MESSAGE) break
    }
  }
  if (best) return best
  throw lastError instanceof Error ? lastError : new Error('无法获取位置')
}

export interface CheckinMessage {
  title: string
  detail?: string
  tips?: string[]
  // Whether trying again on the spot can help.
  retry: boolean
}

// Turns an event_checkin() result into what the page shows.
export function describeCheckin(r: CheckinResult, radiusM?: number): CheckinMessage {
  if (r.ok) {
    return {
      title: r.already ? '你已经签到过了' : '签到成功',
      detail: r.status === 'verified' ? '已到场（主办方核验）' : '已到场（定位核验）',
      retry: false,
    }
  }
  const staff = '仍无法签到时，请找现场工作人员手动确认。'
  switch (r.reason) {
    case 'too_far':
      return {
        title: '你离活动地点太远了',
        detail: r.distance_m != null
          ? `你距离活动地点约 ${formatDistance(r.distance_m)}，需要在 ${radiusM ?? 100} 米以内。`
          : undefined,
        tips: ['走到活动入口附近再试', '如果你已在现场，可能是定位偏了，到窗边或室外再试一次', staff],
        retry: true,
      }
    case 'location_inaccurate':
      return {
        title: '定位精度不够',
        detail: r.accuracy_m != null
          ? `当前定位误差约 ${Math.round(r.accuracy_m)} 米，需要在 ${MAX_ACCURACY_M} 米以内。`
          : undefined,
        tips: ['到窗边或室外再试', '在手机设置中为浏览器开启“精确位置”', '打开 Wi-Fi 能明显提高室内定位精度', staff],
        retry: true,
      }
    case 'location_required':
      return { title: '签到需要获取你的位置', tips: [staff], retry: true }
    case 'outside_window':
      return {
        title: '现在不在签到时间内',
        detail: r.opens_at && r.closes_at
          ? `签到时间：${formatLondon(r.opens_at)} 至 ${formatLondon(r.closes_at)}（英国时间）`
          : undefined,
        retry: false,
      }
    case 'not_registered':
      return { title: '你还没有报名这个活动', detail: '报名后再扫码签到。', retry: false }
    case 'invalid_code':
      return { title: '签到码无效', detail: '这个二维码已被主办方重置或不存在，请扫描现场最新的二维码。', retry: false }
    case 'event_not_active':
      return { title: '活动当前不可签到', detail: '活动可能已取消或已结束。', retry: false }
    case 'checkin_disabled':
      return { title: '这个活动没有开启扫码签到', detail: '请找现场工作人员签到。', retry: false }
    default:
      return { title: '签到失败', detail: '出了点问题，请稍后再试。', tips: [staff], retry: true }
  }
}

export function formatDistance(m: number): string {
  return m >= 1000 ? `${(m / 1000).toFixed(1)} 公里` : `${Math.round(m)} 米`
}

export function isWeChat(ua: string): boolean {
  return /MicroMessenger/i.test(ua)
}

// Data access for the check-in pages. Every rule is enforced by the database functions.
export function useCheckin() {
  const rpc = useRpc()
  const user = useSupabaseUser()
  const userId = computed(() => user.value?.sub ?? (user.value as { id?: string } | null)?.id ?? null)

  async function lookup(code: string): Promise<CheckinEvent | null> {
    const rows = await rpc('lookup_checkin_code', { p_code: code })
    return rows?.[0] ?? null
  }

  async function myState(eventId: string): Promise<{ going: boolean; checkedIn: boolean }> {
    const uid = userId.value
    if (!uid) return { going: false, checkedIn: false }
    const [going, checkedIn] = await Promise.all([
      rpc('is_going', { p_event: eventId }),
      rpc('is_checked_in', { p_event: eventId, p_user: uid }),
    ])
    return { going: !!going, checkedIn: !!checkedIn }
  }

  // Gets a position (the caller must be handling a tap) and submits it.
  async function checkin(code: string, onLocated?: (fix: GeoFix) => void): Promise<CheckinResult> {
    const fix = await bestFix(attempt => getPosition(attempt === 0 ? 15000 : 5000))
    onLocated?.(fix)
    const res = await rpc('event_checkin', {
      p_code: code,
      p_lat: fix.lat,
      p_lng: fix.lng,
      p_accuracy: fix.accuracy,
    })
    const result = res as unknown as CheckinResult
    // The server does not echo accuracy on every reason; fill it in for the message.
    if (result.reason === 'location_inaccurate' && result.accuracy_m == null) result.accuracy_m = fix.accuracy
    return result
  }

  return { userId, lookup, myState, checkin }
}
