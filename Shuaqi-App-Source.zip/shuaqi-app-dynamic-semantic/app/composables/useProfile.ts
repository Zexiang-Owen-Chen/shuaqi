import type { Database } from '~/types/database.types'

export type Profile = Database['public']['Tables']['profiles']['Row']

// The signed-in user's own profile row, shared across pages.
export function useProfile() {
  const supabase = useSupabaseClient<Database>()
  const user = useSupabaseUser()
  const profile = useState<Profile | null>('profile', () => null)

  async function refresh() {
    const uid = user.value?.sub ?? user.value?.id
    if (!uid) { profile.value = null; return null }
    const { data } = await supabase.from('profiles').select('*').eq('id', uid).single()
    profile.value = data
    return data
  }

  return { profile, refresh }
}
