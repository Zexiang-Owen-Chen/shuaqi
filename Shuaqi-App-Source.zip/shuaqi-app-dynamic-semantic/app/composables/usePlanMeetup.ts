import type { GeoFix } from '~/composables/useGeo'

const REPORT_EVERY_MS = 30_000

// Arrival check for a confirmed shared plan: while switched on, reports the position every 30 seconds
// and learns whether the other person is within 50 m (they must have it switched on too).
export function usePlanMeetup(planId: MaybeRefOrGetter<string>) {
  const rpc = useRpc()
  const { consented, loadConsent, grantConsent } = useLocationConsent()

  const active = ref(false)
  const busy = ref(false)
  const nearby = ref(false)
  const distance = ref<number | null>(null)
  const accuracy = ref<number | null>(null)
  const error = ref('')
  let timer: ReturnType<typeof setInterval> | null = null

  async function report(fix: GeoFix) {
    const res = (await rpc('update_plan_presence', {
      p_plan: toValue(planId), p_lat: fix.lat, p_lng: fix.lng, p_accuracy: fix.accuracy,
    })) as { nearby?: boolean; distance_m?: number | null } | null
    accuracy.value = Math.round(fix.accuracy)
    nearby.value = !!res?.nearby
    distance.value = res?.distance_m ?? null
  }

  function fail(e: unknown) {
    error.value = nearbyMessage(e)
    if (isConsentError(e)) {
      consented.value = false
      stopTimer()
      active.value = false
    }
  }

  async function tick() {
    try {
      await report(await getPosition())
      error.value = ''
    } catch (e) {
      fail(e)
    }
  }

  function stopTimer() {
    if (timer) clearInterval(timer)
    timer = null
  }

  async function start(firstFix?: Promise<GeoFix>) {
    if (busy.value) return
    busy.value = true
    error.value = ''
    try {
      await report(await (firstFix ?? getPosition()))
      active.value = true
      stopTimer()
      timer = setInterval(() => { if (document.visibilityState === 'visible') tick() }, REPORT_EVERY_MS)
    } catch (e) {
      fail(e)
    } finally {
      busy.value = false
    }
  }

  async function stop() {
    stopTimer()
    active.value = false
    nearby.value = false
    distance.value = null
    try { await rpc('stop_plan_presence', { p_plan: toValue(planId) }) } catch { /* expires in 5 min anyway */ }
  }

  function onVisible() {
    if (active.value && document.visibilityState === 'visible') tick()
  }

  onMounted(() => document.addEventListener('visibilitychange', onVisible))
  onBeforeUnmount(() => {
    document.removeEventListener('visibilitychange', onVisible)
    if (active.value) stop()
  })

  return { consented, active, busy, nearby, distance, accuracy, error, loadConsent, grantConsent, start, stop }
}
