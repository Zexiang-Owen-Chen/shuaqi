export interface GeoFix { lat: number; lng: number; accuracy: number }

export const STALL_GRACE_MS = 20000
export const STALLED_MESSAGE = '定位没有响应。请确认手机已开启定位服务，并允许浏览器使用位置，然后重试'

// One high-accuracy position fix. Rejects with readable Chinese text.
export function getPosition(timeoutMs = 15000): Promise<GeoFix> {
  return new Promise((resolve, reject) => {
    if (!import.meta.client || !('geolocation' in navigator)) {
      reject(new Error('当前浏览器不支持定位'))
      return
    }
    // The browser's own timeout only starts once permission is granted, so a permission prompt that
    // never shows (seen on iOS) would leave the caller waiting forever. Leave time to answer the prompt.
    const guard = setTimeout(() => reject(new Error(STALLED_MESSAGE)), timeoutMs + STALL_GRACE_MS)
    navigator.geolocation.getCurrentPosition(
      (p) => { clearTimeout(guard); resolve({ lat: p.coords.latitude, lng: p.coords.longitude, accuracy: p.coords.accuracy }) },
      (e) => {
        clearTimeout(guard)
        reject(new Error(
          e.code === e.PERMISSION_DENIED ? '你拒绝了定位权限，请在浏览器设置中允许后重试'
            : e.code === e.TIMEOUT ? '定位超时，请重试' : '无法获取位置'))
      },
      { enableHighAccuracy: true, timeout: timeoutMs, maximumAge: 0 },
    )
  })
}
