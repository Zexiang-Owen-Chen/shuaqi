import type { Database } from '~/types/database.types'

export type MessageRow = Database['public']['Tables']['messages']['Row']

// Unread total for the nav badge, shared across pages. Kept fresh by a Realtime subscription in the
// default layout, by navigation (at most every 30 s) and by the chat pages after they mark a conversation read.
export function useChatUnread() {
  const rpc = useRpc()
  const user = useSupabaseUser()
  const { isOn } = useFeatureFlags()
  const unread = useState<number>('chat-unread', () => 0)
  const loadedAt = useState<number>('chat-unread-at', () => 0)

  async function refresh(force = false) {
    if (import.meta.server) return
    if (!user.value || !isOn('chat')) { unread.value = 0; return }
    if (!force && Date.now() - loadedAt.value < 30_000) return
    loadedAt.value = Date.now()
    try { unread.value = await rpc('unread_message_count') } catch { /* keep the last value */ }
  }

  return { unread, refresh }
}

// Calls onInsert for every new message the signed-in user may read (RLS filters the stream).
// Returns a stop function. `filter` narrows it to one conversation.
export function subscribeToMessages(name: string, onInsert: (m: MessageRow) => void,
  filter?: string, onStatus?: (status: string) => void): () => void {
  const supabase = useSupabaseClient<Database>()
  const channel = supabase
    .channel(name)
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', ...(filter ? { filter } : {}) },
      payload => onInsert(payload.new as MessageRow))
    .subscribe(status => onStatus?.(status))
  return () => { supabase.removeChannel(channel) }
}
