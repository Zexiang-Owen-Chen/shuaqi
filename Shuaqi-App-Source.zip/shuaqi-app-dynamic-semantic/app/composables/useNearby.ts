import type { Database } from '~/types/database.types'
import type { GeoFix } from '~/composables/useGeo'

export interface NearbyCard {
  id: string
  display_name: string
  avatar_url: string | null
  school_domain: string | null
  school_verified: boolean
  region?: string | null
  connected: boolean
}
export interface NearbyPerson { card: NearbyCard; distance_m: number; request_status: string | null }

// Bump when the consent wording in NearbyConsent.vue changes; users are asked again.
export const NEARBY_POLICY_VERSION = '2026-10-v2'
const REPORT_EVERY_MS = 30_000

// "People within 50m", either inside one event or (eventId null) anywhere, not tied to an event.
// Location is only read while the page is open and switched on; the server keeps the last fix
// for 5 minutes and never stores a history.
export function useNearby(eventId: MaybeRefOrGetter<string | null>) {
  const rpc = useRpc()

  const active = ref(false)
  const busy = ref(false)
  const people = ref<NearbyPerson[]>([])
  const accuracy = ref<number | null>(null)
  const updatedAt = ref<Date | null>(null)
  const error = ref('')
  let timer: ReturnType<typeof setInterval> | null = null

  const { consented, loadConsent, grantConsent, withdrawConsent: withdraw } = useLocationConsent()

  async function withdrawConsent() {
    stopTimer()
    await withdraw()
    active.value = false
    people.value = []
  }

  async function report(fix: GeoFix) {
    const ev = toValue(eventId)
    if (ev) await rpc('update_nearby_presence', { p_event: ev, p_lat: fix.lat, p_lng: fix.lng, p_accuracy: fix.accuracy })
    else await rpc('update_open_presence', { p_lat: fix.lat, p_lng: fix.lng, p_accuracy: fix.accuracy })
  }

  async function refreshList() {
    const ev = toValue(eventId)
    const rows = ev ? await rpc('list_nearby', { p_event: ev }) : await rpc('list_open_nearby')
    people.value = (rows ?? []).map(r => ({
      card: r.card as unknown as NearbyCard,
      distance_m: r.distance_m,
      request_status: r.request_status,
    }))
  }

  async function tick() {
    try {
      const fix = await getPosition()
      accuracy.value = Math.round(fix.accuracy)
      await report(fix)
      updatedAt.value = new Date()
      await refreshList()
      error.value = ''
    } catch (e) {
      fail(e)
    }
  }

  function fail(e: unknown) {
    error.value = nearbyMessage(e)
      // Consent was withdrawn elsewhere or the wording changed: show the consent step again.
    if (isConsentError(e)) {
      consented.value = false
      stopTimer()
      active.value = false
    }
  }

  function startTimer() {
    stopTimer()
    timer = setInterval(() => { if (document.visibilityState === 'visible') tick() }, REPORT_EVERY_MS)
  }
  function stopTimer() {
    if (timer) clearInterval(timer)
    timer = null
  }

  async function start(firstFix?: Promise<GeoFix>) {
    if (busy.value) return
    busy.value = true
    error.value = ''
    try {
      // First fix must succeed before we call it "on", so the user sees why it failed.
      const fix = await (firstFix ?? getPosition())
      accuracy.value = Math.round(fix.accuracy)
      await report(fix)
      updatedAt.value = new Date()
      active.value = true
      await refreshList()
      startTimer()
    } catch (e) {
      fail(e)
    } finally {
      busy.value = false
    }
  }

  async function stop() {
    stopTimer()
    active.value = false
    people.value = []
    const ev = toValue(eventId)
    try {
      if (ev) await rpc('stop_nearby', { p_event: ev })
      else await rpc('stop_open_presence')
    } catch { /* expires in 5 min anyway */ }
  }

  async function connect(userId: string) {
    await rpc('send_connection_request', { p_to: userId, p_context: 'nearby', p_context_id: toValue(eventId) ?? undefined })
    const p = people.value.find(x => x.card.id === userId)
    if (p) p.request_status = 'pending'
  }

  // Phones pause timers in the background; report straight away when the page comes back.
  function onVisible() {
    if (active.value && document.visibilityState === 'visible') tick()
  }

  onMounted(() => document.addEventListener('visibilitychange', onVisible))
  onBeforeUnmount(() => {
    document.removeEventListener('visibilitychange', onVisible)
    if (active.value) stop()
  })

  return {
    consented, active, busy, people, accuracy, updatedAt, error,
    loadConsent, grantConsent, withdrawConsent, start, stop, connect, refreshList,
  }
}

export function nearbyMessage(err: unknown): string {
  return messageFor(err)
}

// useRpc already turned the code into Chinese text, so compare against both.
export function isConsentError(e: unknown): boolean {
  const msg = (e as Error)?.message
  return msg === 'location_consent_required' || msg === errorText.location_consent_required
}

// The single 'nearby' location consent covers event nearby, add-friends-nearby and plan meetups.
export function useLocationConsent() {
  const supabase = useSupabaseClient<Database>()
  const rpc = useRpc()
  const consented = ref<boolean | null>(null)

  async function loadConsent() {
    const { data } = await supabase.from('location_consents')
      .select('policy_version, withdrawn_at')
      .eq('purpose', 'nearby')
      .maybeSingle()
    consented.value = !!data && !data.withdrawn_at && data.policy_version === NEARBY_POLICY_VERSION
  }

  async function grantConsent() {
    await rpc('grant_location_consent', { p_purpose: 'nearby', p_policy_version: NEARBY_POLICY_VERSION })
    consented.value = true
  }

  async function withdrawConsent() {
    await rpc('withdraw_location_consent', { p_purpose: 'nearby' })
    consented.value = false
  }

  return { consented, loadConsent, grantConsent, withdrawConsent }
}
