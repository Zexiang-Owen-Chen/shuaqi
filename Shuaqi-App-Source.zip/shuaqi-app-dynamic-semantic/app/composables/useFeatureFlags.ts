import type { Database } from '~/types/database.types'

// Keys seeded in feature_flags (core_schema migration).
export const FLAG_KEYS = ['intents', 'event_discovery', 'nearby', 'qr_checkin', 'trust_card', 'peer_event_creation', 'chat', 'push'] as const
export type FlagKey = (typeof FLAG_KEYS)[number]
export type FlagMap = Partial<Record<string, boolean>>

// Re-read at most once a minute, so a flag switched off on launch day reaches open tabs quickly.
export const FLAG_TTL_MS = 60_000

export function toFlagMap(rows: { key: string; enabled: boolean }[] | null | undefined): FlagMap {
  return Object.fromEntries((rows ?? []).map((r) => [r.key, r.enabled]))
}

// A missing row counts as off, matching public.flag_enabled() on the server.
// Before the first successful load (or if it failed) everything shows as on:
// the server still enforces every flag, so the worst case is a friendly
// "这个功能暂时关闭了" error instead of a page that wrongly hides itself.
export function flagOn(map: FlagMap | null, key: FlagKey): boolean {
  if (!map) return true
  return map[key] ?? false
}

export function useFeatureFlags() {
  const supabase = useSupabaseClient<Database>()
  const flags = useState<FlagMap | null>('feature-flags', () => null)
  const loadedAt = useState<number>('feature-flags-at', () => 0)

  async function load(force = false) {
    if (!force && flags.value && Date.now() - loadedAt.value < FLAG_TTL_MS) return
    const { data, error } = await supabase.from('feature_flags').select('key, enabled')
    if (error) return // keep what we had
    flags.value = toFlagMap(data)
    loadedAt.value = Date.now()
  }

  const isOn = (key: FlagKey) => flagOn(flags.value, key)

  return { flags, load, isOn }
}
