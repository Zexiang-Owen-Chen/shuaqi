// Keep feature flags fresh on every navigation (cached for a minute), so pages can read isOn() synchronously.
export default defineNuxtRouteMiddleware(async () => {
  await useFeatureFlags().load()
})
