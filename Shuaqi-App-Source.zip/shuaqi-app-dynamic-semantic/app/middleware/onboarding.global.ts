// Signed-in users finish their basic profile before using the app.
const OPEN = ['/onboarding', '/login', '/confirm', '/install']

export default defineNuxtRouteMiddleware(async (to) => {
  if (OPEN.includes(to.path) || to.path.startsWith('/checkin/')) return
  const user = useSupabaseUser()
  if (!user.value) return
  const { profile, refresh } = useProfile()
  if (!profile.value) await refresh()
  if (profile.value && !profile.value.onboarded) {
    return navigateTo({ path: '/onboarding', query: { redirect: to.fullPath } })
  }
})
