<script setup lang="ts">
import type { Database } from '~/types/database.types'

// Inserts a row into reports. Parent controls visibility with v-model:open.
const props = defineProps<{ targetType: 'event' | 'user'; targetId: string; targetName?: string | null }>()
const open = defineModel<boolean>('open', { default: false })
const emit = defineEmits<{ done: [] }>()

const supabase = useSupabaseClient<Database>()
const user = useSupabaseUser()

const reasons = computed(() => props.targetType === 'event'
  ? ['虚假或误导信息', '违法或危险活动', '骚扰或歧视', '广告或诈骗', '其他']
  : ['骚扰或不当言行', '虚假身份', '广告或诈骗', '让我感到不安全', '其他'])
const reason = ref('')
const details = ref('')
const busy = ref(false)
const error = ref('')
const sent = ref(false)

watch(open, (v) => { if (v) { reason.value = ''; details.value = ''; error.value = ''; sent.value = false } })

async function submit() {
  const uid = currentUid(user.value)
  if (!uid) { error.value = '请先登录'; return }
  if (!reason.value) { error.value = '请选择举报原因'; return }
  busy.value = true
  error.value = ''
  const { error: err } = await supabase.from('reports').insert({
    reporter_id: uid,
    target_type: props.targetType,
    target_id: props.targetId,
    reason: reason.value,
    details: details.value.trim().slice(0, 2000),
  })
  busy.value = false
  if (err) { error.value = messageFor(err); return }
  sent.value = true
  emit('done')
}
</script>

<template>
  <Teleport to="body">
    <div v-if="open" class="fixed inset-0 z-40 flex items-end justify-center bg-black/40 sm:items-center" @click.self="open = false">
      <div class="w-full max-w-lg rounded-t-2xl bg-white p-4 sm:rounded-2xl" role="dialog" aria-modal="true"
           style="padding-bottom: calc(1rem + env(safe-area-inset-bottom))">
        <template v-if="sent">
          <p class="py-6 text-center text-sm text-stone-700">已收到你的举报，我们会尽快处理。</p>
          <button class="btn-primary w-full" @click="open = false">好的</button>
        </template>
        <template v-else>
          <h2 class="mb-3 text-base font-semibold">
            举报{{ targetType === 'event' ? '活动' : (targetName ? `「${targetName}」` : '用户') }}
          </h2>
          <div class="mb-3 flex flex-wrap gap-2">
            <button v-for="r in reasons" :key="r" type="button" class="chip"
                    :class="reason === r ? '!bg-brand-500 !text-white' : ''" @click="reason = r">{{ r }}</button>
          </div>
          <label class="label" for="report-details">补充说明（可选）</label>
          <textarea id="report-details" v-model="details" class="input mb-3" rows="3" maxlength="2000"
                    placeholder="发生了什么？" />
          <p v-if="error" class="mb-2 text-sm text-red-600">{{ error }}</p>
          <div class="flex gap-2">
            <button class="btn-secondary flex-1" type="button" @click="open = false">取消</button>
            <button class="btn-danger flex-1" type="button" :disabled="busy" @click="submit">
              {{ busy ? '提交中…' : '提交举报' }}
            </button>
          </div>
        </template>
      </div>
    </div>
  </Teleport>
</template>
