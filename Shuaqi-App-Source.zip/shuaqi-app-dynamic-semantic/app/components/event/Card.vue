<script setup lang="ts">
import type { EventRow } from '~/utils/eventFormat'

defineProps<{
  event: Pick<EventRow, 'id' | 'title' | 'category' | 'starts_at' | 'ends_at' | 'location_text' | 'status' | 'capacity'> & { image_paths?: string[] }
}>()
</script>

<template>
  <NuxtLink :to="`/events/${event.id}`" class="card flex flex-col gap-2 !p-3 active:bg-stone-50"
            :class="event.status === 'cancelled' ? 'opacity-70' : ''">
    <EventImages v-if="event.image_paths?.length" :paths="event.image_paths" compact />
    <div class="flex flex-wrap items-center gap-1">
      <span class="chip bg-brand-50 text-brand-700">{{ event.category }}</span>
      <EventStatusBadge :status="event.status" :starts-at="event.starts_at" :ends-at="event.ends_at" />
    </div>
    <h3 class="line-clamp-2 text-sm font-semibold leading-snug" :class="event.status === 'cancelled' ? 'line-through' : ''">
      {{ event.title }}
    </h3>
    <p class="text-xs text-stone-600">🕒 {{ formatEventTime(event.starts_at, event.ends_at) }}</p>
    <p v-if="event.location_text" class="line-clamp-1 text-xs text-stone-500">📍 {{ event.location_text }}</p>
    <p v-if="event.capacity" class="text-xs text-stone-400">限 {{ event.capacity }} 人</p>
  </NuxtLink>
</template>
