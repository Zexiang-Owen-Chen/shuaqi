<script setup lang="ts">
const props = defineProps<{ disabled?: boolean }>()
const paths = defineModel<string[]>({ required: true })
const emit = defineEmits<{ uploading: [value: boolean] }>()
const supabase = useSupabaseClient()
const user = useSupabaseUser()
const uploading = ref(false)
const uploadError = ref('')
const { images, loading, error, refresh } = useEventImageUrls(() => paths.value)

async function upload(event: Event) {
  const input = event.target as HTMLInputElement
  const files = Array.from(input.files ?? [])
  input.value = ''
  if (!files.length || uploading.value || props.disabled) return
  uploadError.value = ''
  if (paths.value.length + files.length > MAX_EVENT_IMAGES) { uploadError.value = '最多上传 6 张活动图片'; return }
  for (const file of files) {
    const failure = eventImageError(file)
    if (failure) { uploadError.value = failure; return }
  }
  const uid = currentUid(user.value)
  if (!uid) { uploadError.value = '请先登录再上传图片'; return }
  uploading.value = true
  emit('uploading', true)
  try {
    for (const file of files) {
      const path = `${uid}/${crypto.randomUUID()}.${EVENT_IMAGE_TYPES[file.type]}`
      const { error } = await supabase.storage.from(EVENT_IMAGE_BUCKET).upload(path, file)
      if (error) throw new Error(`图片上传失败：${messageFor(error)}`)
      paths.value = [...paths.value, path]
    }
  } catch (e) {
    uploadError.value = (e as Error).message
  } finally {
    uploading.value = false
    emit('uploading', false)
  }
}
</script>

<template>
  <div class="space-y-2" data-testid="event-image-upload">
    <label class="label">活动介绍图片（可选）
      <input type="file" accept="image/jpeg,image/png,image/webp" multiple class="input mt-1 text-sm"
             :disabled="disabled || uploading || paths.length >= MAX_EVENT_IMAGES" @change="upload">
    </label>
    <p class="text-xs text-stone-500">最多 6 张，每张不超过 5MB，支持 JPEG、PNG、WebP。图片随活动的可见范围展示。</p>
    <p v-if="uploading" class="text-sm text-brand-600" role="status">图片上传中…</p>
    <p v-if="uploadError" class="text-sm text-red-600" role="alert">{{ uploadError }}</p>
    <button v-if="error" type="button" class="text-xs text-red-600" @click="refresh">{{ error }}</button>
    <div v-if="images.length" class="grid grid-cols-2 gap-2 sm:grid-cols-3">
      <div v-for="(image, i) in images" :key="image.path" class="space-y-1">
        <img v-if="image.url" :src="image.url" :alt="`活动图片预览 ${i + 1}`" class="aspect-square w-full rounded-xl object-cover">
        <div v-else class="aspect-square rounded-xl bg-stone-100" :class="loading ? 'animate-pulse' : ''" />
        <button type="button" class="text-xs text-stone-500" :disabled="disabled || uploading"
                @click="paths = paths.filter(path => path !== image.path)">移除图片 {{ i + 1 }}</button>
      </div>
    </div>
  </div>
</template>
