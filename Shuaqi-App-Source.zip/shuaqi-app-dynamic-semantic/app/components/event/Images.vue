<script setup lang="ts">
const props = defineProps<{ paths: string[]; compact?: boolean }>()
const { images, loading, error, refresh } = useEventImageUrls(() => props.compact ? props.paths.slice(0, 1) : props.paths)
</script>

<template>
  <div v-if="paths.length" :class="compact ? '' : 'space-y-3'" data-testid="event-images">
    <template v-for="(image, i) in images" :key="image.path">
      <img v-if="image.url" :src="image.url" :alt="`活动介绍图片 ${i + 1}`" loading="lazy"
           :class="compact ? 'aspect-[16/10] w-full rounded-xl object-cover' : 'h-auto max-h-[40rem] w-full rounded-xl object-contain'">
      <div v-else-if="loading" class="aspect-[16/10] animate-pulse rounded-xl bg-stone-100" />
    </template>
    <button v-if="error" type="button" class="text-xs text-stone-500" @click.prevent.stop="refresh">图片加载失败，点击重试</button>
  </div>
</template>
