<script setup lang="ts">
import { z } from 'zod'
import type { EventFormPayload, EventRow } from '~/utils/eventFormat'

const props = defineProps<{
  mode: 'create' | 'edit'
  initial?: Partial<EventRow> | null
  submitting?: boolean
  serverError?: string
  // Personal events are switched off (peer_event_creation): must publish as an organisation.
  requireOrg?: boolean
}>()
const emit = defineEmits<{ submit: [payload: EventFormPayload] }>()

const rpc = useRpc()
const user = useSupabaseUser()
const { isOn } = useFeatureFlags()

const init = props.initial ?? {}
const form = reactive({
  title: init.title ?? '',
  category: init.category ?? '',
  description: init.description ?? '',
  image_paths: [...(init.image_paths ?? [])],
  starts: toLondonInput(init.starts_at),
  ends: toLondonInput(init.ends_at),
  location_text: init.location_text ?? '',
  lat: init.location_lat != null ? String(init.location_lat) : '',
  lng: init.location_lng != null ? String(init.location_lng) : '',
  checkin_mode: (init.checkin_mode ?? 'none') as EventFormPayload['checkin_mode'],
  radius: String(init.checkin_radius_m ?? 100),
  capacity: init.capacity != null ? String(init.capacity) : '',
  visibility: (init.visibility ?? 'public') as EventFormPayload['visibility'],
  require_checkin_for_connect: init.require_checkin_for_connect ?? false,
  org_id: init.org_id ?? '',
})

const categories = computed(() => {
  const list: string[] = [...EVENT_CATEGORIES]
  if (form.category && !list.includes(form.category)) list.push(form.category)
  return list
})

// --- Location -------------------------------------------------------------
const hasCoords = computed(() => form.lat.trim() !== '' && form.lng.trim() !== '')
const modeTouched = ref(props.mode === 'edit')
watch(hasCoords, (v) => {
  if (!modeTouched.value) form.checkin_mode = v ? 'qr_geo' : 'none'
  else if (!v && form.checkin_mode === 'qr_geo') form.checkin_mode = 'none'
})

const locating = ref(false)
const geoError = ref('')
const geoAccuracy = ref<number | null>(null)
async function useMyLocation() {
  locating.value = true
  geoError.value = ''
  try {
    const fix = await getPosition()
    form.lat = fix.lat.toFixed(6)
    form.lng = fix.lng.toFixed(6)
    geoAccuracy.value = Math.round(fix.accuracy)
  } catch (e) {
    geoError.value = (e as Error).message
  } finally {
    locating.value = false
  }
}

// --- Organisations (create only) -------------------------------------------
const orgs = ref<{ org_id: string; name: string; role: string }[]>([])
onMounted(async () => {
  if (props.mode !== 'create' || !user.value) return
  try {
    const rows = await rpc('my_organisations')
    orgs.value = (rows ?? []).filter((o) => o.role === 'owner' || o.role === 'organiser')
    if (props.requireOrg && !form.org_id && orgs.value[0]) form.org_id = orgs.value[0].org_id
  } catch { /* optional: the select simply stays hidden */ }
})

// --- Validation ----------------------------------------------------------------
const optionalNumber = (label: string) => z.string().trim().transform((v, ctx) => {
  if (v === '') return null
  const n = Number(v)
  if (!Number.isFinite(n)) { ctx.addIssue({ code: 'custom', message: `${label}必须是数字` }); return z.NEVER }
  return n
})

const schema = z.object({
  title: z.string().trim().min(1, '请填写活动标题').max(80, '标题最多 80 个字'),
  category: z.string().min(1, '请选择分类').max(30),
  description: z.string().trim().max(2000, '介绍最多 2000 字'),
  starts: z.string().min(1, '请选择开始时间'),
  ends: z.string(),
  location_text: z.string().trim().min(1, '请填写地点').max(200, '地点最多 200 字'),
  lat: optionalNumber('纬度'),
  lng: optionalNumber('经度'),
  checkin_mode: z.enum(['none', 'qr_geo', 'manual']),
  radius: z.string().trim().transform(Number).pipe(
    z.number({ message: '签到半径必须是数字' }).int('签到半径必须是整数').min(20, '签到半径至少 20 米').max(1000, '签到半径最多 1000 米')),
  capacity: optionalNumber('人数上限'),
  visibility: z.enum(['public', 'school']),
  require_checkin_for_connect: z.boolean(),
  org_id: z.string(),
}).superRefine((v, ctx) => {
  const starts = fromLondonInput(v.starts)
  if (!starts) ctx.addIssue({ code: 'custom', path: ['starts'], message: '开始时间格式不正确' })
  else if (props.mode === 'create' && new Date(starts).getTime() < Date.now()) {
    ctx.addIssue({ code: 'custom', path: ['starts'], message: '开始时间不能早于现在' })
  }
  if (v.ends) {
    const ends = fromLondonInput(v.ends)
    if (!ends) ctx.addIssue({ code: 'custom', path: ['ends'], message: '结束时间格式不正确' })
    else if (starts && new Date(ends) <= new Date(starts)) {
      ctx.addIssue({ code: 'custom', path: ['ends'], message: '结束时间必须晚于开始时间' })
    }
  }
  if ((v.lat === null) !== (v.lng === null)) {
    ctx.addIssue({ code: 'custom', path: [v.lat === null ? 'lat' : 'lng'], message: '纬度和经度要一起填写' })
  }
  if (v.lat !== null && (v.lat < -90 || v.lat > 90)) ctx.addIssue({ code: 'custom', path: ['lat'], message: '纬度应在 -90 到 90 之间' })
  if (v.lng !== null && (v.lng < -180 || v.lng > 180)) ctx.addIssue({ code: 'custom', path: ['lng'], message: '经度应在 -180 到 180 之间' })
  if (v.checkin_mode === 'qr_geo' && (v.lat === null || v.lng === null)) {
    ctx.addIssue({ code: 'custom', path: ['checkin_mode'], message: '扫码 + 定位签到需要先设置活动坐标' })
  }
  if (v.capacity !== null && (!Number.isInteger(v.capacity) || v.capacity < 2 || v.capacity > 5000)) {
    ctx.addIssue({ code: 'custom', path: ['capacity'], message: '人数上限应为 2 到 5000 的整数' })
  }
})

const errors = ref<Record<string, string>>({})
const imagesUploading = ref(false)

function onSubmit() {
  if (imagesUploading.value) return
  const res = schema.safeParse(form)
  if (!res.success) {
    const map: Record<string, string> = {}
    for (const issue of res.error.issues) {
      const key = String(issue.path[0] ?? 'form')
      if (!map[key]) map[key] = issue.message
    }
    errors.value = map
    return
  }
  if (props.requireOrg && props.mode === 'create' && !res.data.org_id) {
    errors.value = { form: '个人发布暂时关闭，请选择以哪个组织的名义发布' }
    return
  }
  errors.value = {}
  const v = res.data
  emit('submit', {
    title: v.title,
    category: v.category,
    description: v.description,
    image_paths: [...form.image_paths],
    starts_at: fromLondonInput(v.starts)!,
    ends_at: v.ends ? fromLondonInput(v.ends) : null,
    location_text: v.location_text,
    location_lat: v.lat,
    location_lng: v.lng,
    checkin_mode: v.checkin_mode,
    checkin_radius_m: v.radius,
    capacity: v.capacity,
    visibility: v.visibility,
    require_checkin_for_connect: v.require_checkin_for_connect,
    org_id: v.org_id || null,
  })
}
</script>

<template>
  <form class="space-y-4" novalidate @submit.prevent="onSubmit">
    <div v-if="mode === 'create' && orgs.length" class="card space-y-1">
      <label class="label" for="ev-org">以谁的名义发布</label>
      <select id="ev-org" v-model="form.org_id" class="input">
        <option v-if="!requireOrg" value="">我个人</option>
        <option v-for="o in orgs" :key="o.org_id" :value="o.org_id">{{ o.name }}（组织活动）</option>
      </select>
    </div>

    <div class="card space-y-3">
      <div>
        <label class="label" for="ev-title">标题</label>
        <input id="ev-title" v-model="form.title" class="input" maxlength="80" placeholder="比如：周六海德公园晨跑 5K">
        <p v-if="errors.title" class="mt-1 text-xs text-red-600">{{ errors.title }}</p>
      </div>
      <div>
        <label class="label" for="ev-category">分类</label>
        <select id="ev-category" v-model="form.category" class="input">
          <option value="" disabled>请选择</option>
          <option v-for="c in categories" :key="c" :value="c">{{ c }}</option>
        </select>
        <p v-if="errors.category" class="mt-1 text-xs text-red-600">{{ errors.category }}</p>
      </div>
      <div>
        <label class="label" for="ev-desc">介绍</label>
        <textarea id="ev-desc" v-model="form.description" class="input" rows="4" maxlength="2000"
                  placeholder="活动内容、需要带什么、怎么集合……" />
        <p v-if="errors.description" class="mt-1 text-xs text-red-600">{{ errors.description }}</p>
      </div>
      <EventImageUpload v-model="form.image_paths" :disabled="submitting" @uploading="imagesUploading = $event" />
    </div>

    <div class="card space-y-3">
      <p class="text-xs text-stone-500">时间按英国伦敦时间填写</p>
      <div>
        <label class="label" for="ev-starts">开始时间</label>
        <input id="ev-starts" v-model="form.starts" type="datetime-local" class="input">
        <p v-if="errors.starts" class="mt-1 text-xs text-red-600">{{ errors.starts }}</p>
      </div>
      <div>
        <label class="label" for="ev-ends">结束时间（可选）</label>
        <input id="ev-ends" v-model="form.ends" type="datetime-local" class="input">
        <p v-if="errors.ends" class="mt-1 text-xs text-red-600">{{ errors.ends }}</p>
      </div>
    </div>

    <div class="card space-y-3">
      <div>
        <label class="label" for="ev-loc">地点</label>
        <input id="ev-loc" v-model="form.location_text" class="input" maxlength="200" placeholder="比如：UCL Main Quad 门口">
        <p v-if="errors.location_text" class="mt-1 text-xs text-red-600">{{ errors.location_text }}</p>
      </div>
      <div>
        <p class="mb-2 text-xs text-stone-500">
          活动坐标用于现场扫码签到和“附近的人”。点下面按钮会请求一次你的位置，只用来填写活动地点。
        </p>
        <button type="button" class="btn-secondary w-full" :disabled="locating" @click="useMyLocation">
          📍 {{ locating ? '定位中…' : '使用我当前位置' }}
        </button>
        <p v-if="geoAccuracy !== null" class="mt-1 text-xs text-stone-500">已获取位置（精度约 {{ geoAccuracy }} 米）</p>
        <p v-if="geoError" class="mt-1 text-xs text-red-600">{{ geoError }}</p>
      </div>
      <div class="grid grid-cols-2 gap-2">
        <div>
          <label class="label" for="ev-lat">纬度</label>
          <input id="ev-lat" v-model="form.lat" class="input" inputmode="decimal" placeholder="51.5246">
          <p v-if="errors.lat" class="mt-1 text-xs text-red-600">{{ errors.lat }}</p>
        </div>
        <div>
          <label class="label" for="ev-lng">经度</label>
          <input id="ev-lng" v-model="form.lng" class="input" inputmode="decimal" placeholder="-0.1340">
          <p v-if="errors.lng" class="mt-1 text-xs text-red-600">{{ errors.lng }}</p>
        </div>
      </div>
    </div>

    <div class="card space-y-3">
      <div>
        <label class="label" for="ev-mode">签到方式</label>
        <select id="ev-mode" v-model="form.checkin_mode" class="input" @change="modeTouched = true">
          <option value="none">{{ CHECKIN_MODE_LABEL.none }}</option>
          <option value="qr_geo" :disabled="!hasCoords">{{ CHECKIN_MODE_LABEL.qr_geo }}{{ hasCoords ? '' : '（需先设置坐标）' }}</option>
          <option value="manual">{{ CHECKIN_MODE_LABEL.manual }}</option>
        </select>
        <p v-if="errors.checkin_mode" class="mt-1 text-xs text-red-600">{{ errors.checkin_mode }}</p>
        <p v-if="form.checkin_mode === 'qr_geo' && !isOn('qr_checkin')" class="mt-1 text-xs text-amber-700">
          自助扫码签到目前暂停：恢复前用户扫码会提示找工作人员，请在报名管理里手动确认到场。
        </p>
      </div>
      <div v-if="form.checkin_mode === 'qr_geo'">
        <label class="label" for="ev-radius">签到半径（米）</label>
        <input id="ev-radius" v-model="form.radius" class="input" inputmode="numeric">
        <p v-if="errors.radius" class="mt-1 text-xs text-red-600">{{ errors.radius }}</p>
      </div>
      <div>
        <label class="label" for="ev-cap">人数上限（可选）</label>
        <input id="ev-cap" v-model="form.capacity" class="input" inputmode="numeric" placeholder="不限">
        <p v-if="errors.capacity" class="mt-1 text-xs text-red-600">{{ errors.capacity }}</p>
      </div>
      <div>
        <span class="label">谁能看到</span>
        <div class="flex gap-2">
          <button type="button" class="chip flex-1 justify-center py-2"
                  :class="form.visibility === 'public' ? '!bg-brand-500 !text-white' : ''"
                  @click="form.visibility = 'public'">所有人</button>
          <button type="button" class="chip flex-1 justify-center py-2"
                  :class="form.visibility === 'school' ? '!bg-brand-500 !text-white' : ''"
                  @click="form.visibility = 'school'">仅本校同学</button>
        </div>
      </div>
      <label class="flex items-start gap-3">
        <input v-model="form.require_checkin_for_connect" type="checkbox" class="mt-1 size-4 accent-brand-500">
        <span class="text-sm">
          签到后才能加好友
          <span class="block text-xs text-stone-500">开启后，参与者需双方都在现场签到才能互相发送好友请求</span>
        </span>
      </label>
    </div>

    <p v-if="Object.keys(errors).length" class="text-sm text-red-600">请检查上面标红的内容</p>
    <p v-if="errors.form" class="text-sm text-red-600">{{ errors.form }}</p>
    <p v-if="serverError" class="text-sm text-red-600">{{ serverError }}</p>
    <button type="submit" class="btn-primary w-full" :disabled="submitting || imagesUploading">
      {{ submitting ? '提交中…' : mode === 'create' ? '发布活动' : '保存修改' }}
    </button>
  </form>
</template>
