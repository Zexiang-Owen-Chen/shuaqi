<script setup lang="ts">
const props = defineProps<{ status: string; startsAt: string; endsAt?: string | null }>()
const view = computed(() => {
  if (props.status === 'cancelled') return { text: '已取消', cls: 'bg-red-50 text-red-700' }
  if (props.status === 'draft') return { text: '草稿', cls: 'bg-stone-100 text-stone-600' }
  if (props.status === 'ended' || eventIsOver({ starts_at: props.startsAt, ends_at: props.endsAt ?? null })) {
    return { text: '已结束', cls: 'bg-stone-100 text-stone-500' }
  }
  if (new Date(props.startsAt).getTime() <= Date.now()) return { text: '进行中', cls: 'bg-emerald-50 text-emerald-700' }
  return null
})
</script>

<template>
  <span v-if="view" class="chip" :class="view.cls">{{ view.text }}</span>
</template>
