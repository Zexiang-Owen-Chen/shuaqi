<script setup lang="ts">
const props = defineProps<{ url?: string | null; name?: string | null; size?: number }>()
const px = computed(() => props.size ?? 48)
const src = computed(() => publicUrl('avatars', props.url))
</script>

<template>
  <img v-if="src" :src="src" :alt="name ?? ''" class="shrink-0 rounded-full object-cover" :style="{ width: px + 'px', height: px + 'px' }">
  <div v-else class="flex shrink-0 items-center justify-center rounded-full bg-brand-100 font-semibold text-brand-700"
       :style="{ width: px + 'px', height: px + 'px', fontSize: px / 2.4 + 'px' }">
    {{ (name || '?').slice(0, 1).toUpperCase() }}
  </div>
</template>
