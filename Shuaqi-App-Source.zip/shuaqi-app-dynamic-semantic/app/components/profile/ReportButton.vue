<script setup lang="ts">
const props = defineProps<{ targetType: 'user' | 'event' | 'intent' | 'evidence' | 'message'; targetId: string; label?: string }>()
const emit = defineEmits<{ reported: [] }>()
const supabase = useSupabaseClient()
const rpc = useRpc()
const user = useSupabaseUser()
const open = ref(false)
const reason = ref('')
const details = ref('')
const state = ref<'idle' | 'busy' | 'done'>('idle')
const error = ref('')
const reasons = ['骚扰或不当言行', '虚假身份', '安全问题', '垃圾信息或广告', '活动信息不实', '其他']

async function submit() {
  if (!reason.value) { error.value = '请选择原因'; return }
  state.value = 'busy'
  // A message report goes through report_message() so admins get a copy of what was said.
  if (props.targetType === 'message') {
    try {
      await rpc('report_message', { p_message: props.targetId, p_reason: reason.value, p_details: details.value.trim() })
    } catch (err) { state.value = 'idle'; error.value = (err as Error).message; return }
    state.value = 'done'
    emit('reported')
    return
  }
  const { error: e } = await supabase.from('reports').insert({
    reporter_id: user.value!.sub ?? user.value!.id, target_type: props.targetType, target_id: props.targetId,
    reason: reason.value, details: details.value.trim(),
  })
  if (e) { state.value = 'idle'; error.value = messageFor(e); return }
  state.value = 'done'
  emit('reported')
}
</script>

<template>
  <button type="button" class="text-xs text-stone-400 underline" @click="open = true">{{ label ?? '举报' }}</button>
  <div v-if="open" class="fixed inset-0 z-40 flex items-end bg-black/40" @click.self="open = false">
    <div class="w-full rounded-t-3xl bg-white p-5" style="padding-bottom: calc(1.25rem + env(safe-area-inset-bottom))">
      <template v-if="state === 'done'">
        <h2 class="font-semibold">已收到你的举报</h2>
        <p class="mt-2 text-sm text-stone-600">管理员会尽快处理。举报内容不会公开，也不会告诉被举报人是谁举报的。如有紧急危险，请直接拨打 999。</p>
        <button class="btn-primary mt-4 w-full" @click="open = false">好的</button>
      </template>
      <form v-else class="space-y-3" @submit.prevent="submit">
        <h2 class="font-semibold">举报</h2>
        <div class="flex flex-wrap gap-2">
          <button v-for="r in reasons" :key="r" type="button" class="chip" :class="reason === r ? 'bg-brand-500 text-white' : ''" @click="reason = r">{{ r }}</button>
        </div>
        <textarea v-model="details" class="input min-h-20" maxlength="2000" placeholder="补充说明（可选）" />
        <p v-if="error" class="text-sm text-red-700">{{ error }}</p>
        <div class="flex gap-2">
          <button type="button" class="btn-secondary flex-1" @click="open = false">取消</button>
          <button class="btn-danger flex-1" :disabled="state === 'busy'">提交举报</button>
        </div>
      </form>
    </div>
  </div>
</template>
