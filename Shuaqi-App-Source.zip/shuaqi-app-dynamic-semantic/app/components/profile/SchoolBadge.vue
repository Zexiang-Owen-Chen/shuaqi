<script setup lang="ts">
defineProps<{ domain?: string | null; verified?: boolean }>()
</script>

<template>
  <span v-if="verified" class="chip bg-emerald-50 text-emerald-700">✓ {{ SCHOOL_NAMES[domain ?? ''] ?? domain }} 邮箱已验证</span>
  <span v-else class="chip bg-amber-50 text-amber-700">学校邮箱未验证</span>
</template>
