<script setup lang="ts">
import { z } from 'zod'
import type { Profile } from '~/composables/useProfile'

const props = defineProps<{ profile: Profile; showVisibility?: boolean; submitLabel?: string }>()
const emit = defineEmits<{ saved: [] }>()

const supabase = useSupabaseClient()
const thisYear = new Date().getFullYear()

const form = reactive({
  display_name: props.profile.display_name,
  gender: props.profile.gender ?? '',
  birth_year: props.profile.birth_year ?? ('' as number | ''),
  region: props.profile.region ?? '',
  bio: props.profile.bio ?? '',
  interests: [...(props.profile.interests ?? [])],
  avatar_url: props.profile.avatar_url ?? '',
  visibility: { ...(props.profile.visibility as Record<string, string>) },
})
const busy = ref(false)
const uploading = ref(false)
const error = ref('')

const schema = z.object({
  display_name: z.string().trim().min(1, '请填写昵称').max(40, '昵称最多 40 字'),
  gender: z.enum(['female', 'male', 'non_binary', 'prefer_not_to_say'], { message: '请选择性别' }),
  birth_year: z.coerce.number({ message: '请填写出生年份' }).int().min(thisYear - 80, '出生年份不正确').max(thisYear - 16, '需年满 16 岁'),
  region: z.string().refine(isRegion, '请选择所在城市和地区'),
  bio: z.string().max(500, '介绍最多 500 字'),
  interests: z.array(z.string()).max(10, '最多选 10 个兴趣'),
})

function toggleInterest(i: string) {
  const idx = form.interests.indexOf(i)
  if (idx >= 0) form.interests.splice(idx, 1)
  else form.interests.push(i)
}

async function uploadAvatar(e: Event) {
  const file = (e.target as HTMLInputElement).files?.[0]
  if (!file) return
  error.value = ''
  if (file.size > 5 * 1024 * 1024) { error.value = '图片不能超过 5MB'; return }
  uploading.value = true
  const path = `${props.profile.id}/${Date.now()}.${(file.type.split('/')[1] || 'jpg').replace('jpeg', 'jpg')}`
  const { error: e2 } = await supabase.storage.from('avatars').upload(path, file, { contentType: file.type })
  uploading.value = false
  if (e2) { error.value = '上传失败：' + e2.message; return }
  form.avatar_url = path
}

async function save() {
  error.value = ''
  const parsed = schema.safeParse(form)
  if (!parsed.success) { error.value = parsed.error.issues[0]?.message ?? '请检查填写内容'; return }
  busy.value = true
  const { error: e } = await supabase.from('profiles').update({
    ...parsed.data,
    avatar_url: form.avatar_url || null,
    visibility: form.visibility,
    onboarded: true,
  }).eq('id', props.profile.id)
  busy.value = false
  if (e) { error.value = messageFor(e); return }
  emit('saved')
}
</script>

<template>
  <form class="space-y-5" @submit.prevent="save">
    <div class="flex items-center gap-4">
      <ProfileAvatar :url="form.avatar_url" :name="form.display_name" :size="72" />
      <label class="btn-secondary cursor-pointer">
        {{ uploading ? '上传中…' : '上传头像' }}
        <input type="file" accept="image/jpeg,image/png,image/webp" class="hidden" @change="uploadAvatar">
      </label>
    </div>

    <div>
      <label class="label" for="pf-name">昵称</label>
      <input id="pf-name" v-model="form.display_name" class="input" maxlength="40">
    </div>

    <div class="grid grid-cols-2 gap-3">
      <div>
        <label class="label" for="pf-gender">性别</label>
        <select id="pf-gender" v-model="form.gender" class="input">
          <option value="" disabled>请选择</option>
          <option v-for="g in GENDERS" :key="g.value" :value="g.value">{{ g.label }}</option>
        </select>
      </div>
      <div>
        <label class="label" for="pf-year">出生年份</label>
        <input id="pf-year" v-model="form.birth_year" class="input" type="number" inputmode="numeric" :max="thisYear - 16" :min="thisYear - 80" placeholder="2003">
      </div>
    </div>

    <div>
      <RegionSelect id="pf-region" v-model="form.region" />
      <p class="mt-1 text-xs text-stone-500">地区对其他登录用户公开展示，用于认识同学和匹配搭子。只选择城市和片区，不填写住址。</p>
    </div>

    <div>
      <span class="label">兴趣（最多 10 个）</span>
      <div class="flex flex-wrap gap-2">
        <button v-for="i in INTERESTS" :key="i" type="button" class="chip"
                :class="form.interests.includes(i) ? 'bg-brand-500 text-white' : ''" @click="toggleInterest(i)">{{ i }}</button>
      </div>
    </div>

    <div>
      <label class="label" for="pf-bio">个人介绍</label>
      <textarea id="pf-bio" v-model="form.bio" class="input min-h-24" maxlength="500" placeholder="说说你喜欢做什么、想认识什么样的人" />
    </div>

    <section v-if="showVisibility" class="card space-y-3">
      <h2 class="text-sm font-semibold">谁能看到我的资料</h2>
      <p class="text-xs text-stone-500">头像、昵称、学校验证状态和地区始终可见。一对一找搭子时，性别和年龄也会展示给候选人。多人活动里，你可以单独选择展示其他资料。</p>
      <div v-for="f in VISIBILITY_FIELDS" :key="f.key" class="flex items-center justify-between gap-3">
        <span class="text-sm">{{ f.label }}</span>
        <select v-model="form.visibility[f.key]" class="input w-32 py-1.5">
          <option v-for="s in SCOPES" :key="s.value" :value="s.value">{{ s.label }}</option>
        </select>
      </div>
    </section>

    <p v-if="error" class="rounded-xl bg-red-50 p-3 text-sm text-red-700" role="alert">{{ error }}</p>
    <button class="btn-primary w-full" :disabled="busy || uploading">{{ busy ? '保存中…' : (submitLabel ?? '保存') }}</button>
  </form>
</template>
