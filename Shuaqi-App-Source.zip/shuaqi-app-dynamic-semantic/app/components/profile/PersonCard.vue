<script setup lang="ts">
// Renders whatever fields get_profile_card() returned; absent fields are hidden by the owner.
export interface Card {
  id: string; display_name: string; avatar_url?: string | null; school_domain?: string | null
  school_verified?: boolean; connected?: boolean; bio?: string | null; interests?: string[]
  gender?: string | null; age?: number | null; region?: string | null; photos?: string[]
}
defineProps<{ card: Card; compact?: boolean }>()
</script>

<template>
  <div class="flex gap-3">
    <NuxtLink :to="`/u/${card.id}`"><ProfileAvatar :url="card.avatar_url" :name="card.display_name" :size="compact ? 40 : 52" /></NuxtLink>
    <div class="min-w-0 flex-1">
      <div class="flex flex-wrap items-center gap-1.5">
        <NuxtLink :to="`/u/${card.id}`" class="font-medium">{{ card.display_name || '未命名' }}</NuxtLink>
        <span v-if="card.connected" class="chip bg-brand-50 text-brand-700">好友</span>
      </div>
      <p class="text-xs text-stone-500">
        {{ [card.school_verified ? (SCHOOL_NAMES[card.school_domain ?? ''] ?? card.school_domain) + ' ✓' : '', genderLabel(card.gender), card.age ? card.age + ' 岁' : '', card.region].filter(Boolean).join(' · ') }}
      </p>
      <p v-if="!compact && card.bio" class="mt-1 line-clamp-2 text-sm text-stone-700">{{ card.bio }}</p>
      <div v-if="!compact && card.interests?.length" class="mt-1.5 flex flex-wrap gap-1">
        <span v-for="i in card.interests" :key="i" class="chip">{{ i }}</span>
      </div>
      <slot />
    </div>
  </div>
</template>
