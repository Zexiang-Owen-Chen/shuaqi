<script setup lang="ts">
// Explainable participation facts. No score: no history does not mean low trust.
const props = defineProps<{ userId: string }>()
const rpc = useRpc()
const { data, error } = await useAsyncData(`trust-${props.userId}`, () => rpc('trust_summary', { p_user: props.userId }))
const t = computed(() => data.value as Record<string, number> | null)
// trust_card switched off: other people's cards come back null from the server;
// your own page keeps one line, the verified attendance count.
const { isOn } = useFeatureFlags()
const full = computed(() => isOn('trust_card'))
const rows = [
  { key: 'organiser_confirmed_attendance', label: '主办方核验到场', strong: true },
  { key: 'self_reported_presence', label: '扫码 + 定位签到' },
  { key: 'mutually_reported_interaction', label: '双方确认的见面' },
  { key: 'confirmed_rsvp', label: '报名的活动' },
  { key: 'intended_participation', label: '发布过的找搭子需求' },
]
</script>

<template>
  <section v-if="t && !full" class="card">
    <p class="text-sm">已核验到场 <span class="font-semibold text-emerald-700">{{ t.organiser_confirmed_attendance ?? 0 }}</span> 次</p>
  </section>
  <section v-else-if="t" class="card">
    <h2 class="text-sm font-semibold">参与记录</h2>
    <dl class="mt-3 grid grid-cols-2 gap-3">
      <div v-for="r in rows" :key="r.key" class="rounded-xl bg-stone-50 p-3">
        <dt class="text-xs text-stone-500">{{ r.label }}</dt>
        <dd class="mt-1 text-xl font-semibold" :class="r.strong ? 'text-emerald-700' : ''">{{ t[r.key] ?? 0 }}</dd>
      </div>
    </dl>
    <p v-if="t.disputed" class="mt-3 text-xs text-amber-700">{{ t.disputed }} 条记录正在核查中</p>
    <p class="mt-3 text-xs text-stone-400">这里只展示有来源的事实，不代表安全担保。没有记录不等于不可信。</p>
  </section>
  <p v-else-if="error" class="text-xs text-stone-400">参与记录暂时无法加载</p>
</template>
