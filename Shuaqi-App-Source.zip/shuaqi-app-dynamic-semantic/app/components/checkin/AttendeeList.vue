<script setup lang="ts">
import type { Database } from '~/types/database.types'

type Attendee = Database['public']['Functions']['list_event_attendees']['Returns'][number]

// Staff-only list: who registered, who checked in by QR + GPS, and manual confirmation.
const props = withDefaults(defineProps<{ eventId: string; refreshMs?: number }>(), { refreshMs: 15000 })
const emit = defineEmits<{ counts: [{ going: number; checkedIn: number; confirmed: number }] }>()

const rpc = useRpc()
const { userId } = useCheckin()

const rows = ref<Attendee[]>([])
const loading = ref(true)
const error = ref('')
const actionError = ref('')
const busy = ref<string | null>(null)
const filter = ref<'all' | 'in' | 'out'>('all')
const query = ref('')

const going = computed(() => rows.value.filter(r => r.rsvp_status === 'going'))
const isIn = (r: Attendee) => !!r.self_checkin && r.self_checkin !== 'revoked' || r.organiser_confirmed
const counts = computed(() => ({
  going: going.value.length,
  checkedIn: going.value.filter(isIn).length,
  confirmed: going.value.filter(r => r.organiser_confirmed).length,
}))
const shown = computed(() => {
  const q = query.value.trim().toLowerCase()
  return going.value.filter(r =>
    (filter.value === 'all' || (filter.value === 'in') === isIn(r))
    && (!q || (r.display_name ?? '').toLowerCase().includes(q)))
})

watch(counts, c => emit('counts', c))

async function load(quiet = false) {
  if (!quiet) loading.value = true
  try {
    rows.value = (await rpc('list_event_attendees', { p_event: props.eventId })) ?? []
    error.value = ''
  } catch (e) {
    error.value = (e as Error).message
  } finally {
    loading.value = false
  }
}

async function setConfirmed(r: Attendee, confirm: boolean) {
  if (!confirm && !window.confirm(`撤销对 ${r.display_name || '该用户'} 的到场确认？`)) return
  busy.value = r.user_id
  actionError.value = ''
  try {
    await rpc('organiser_confirm_attendance', { p_event: props.eventId, p_user: r.user_id, p_confirm: confirm })
    await load(true)
  } catch (e) {
    actionError.value = (e as Error).message
  } finally {
    busy.value = null
  }
}

function selfLabel(s: string | null): string {
  if (s === 'geo_verified') return '已定位签到'
  if (s === 'verified') return '已核验'
  if (s === 'disputed') return '有争议'
  if (s === 'unverified') return '已扫码（未核验）'
  return '未签到'
}

let timer: ReturnType<typeof setInterval> | undefined
onMounted(() => {
  load()
  timer = setInterval(() => { if (document.visibilityState === 'visible') load(true) }, props.refreshMs)
})
onBeforeUnmount(() => clearInterval(timer))
defineExpose({ reload: () => load(true) })
</script>

<template>
  <section class="space-y-3">
    <div class="flex items-baseline justify-between">
      <h2 class="font-semibold">到场名单</h2>
      <p class="text-sm text-stone-500">
        已到 <b class="text-stone-800">{{ counts.checkedIn }}</b> / 报名 {{ counts.going }}
        <span v-if="counts.confirmed">· 主办方已确认 {{ counts.confirmed }}</span>
      </p>
    </div>

    <div class="grid grid-cols-[1fr_6rem] gap-2">
      <input v-model="query" class="input" type="search" placeholder="搜索姓名" aria-label="搜索姓名">
      <select v-model="filter" class="input" aria-label="筛选">
        <option value="all">全部</option>
        <option value="out">未到</option>
        <option value="in">已到</option>
      </select>
    </div>

    <p v-if="actionError" class="rounded-xl bg-red-50 p-3 text-sm text-red-700" role="alert">{{ actionError }}</p>

    <div v-if="loading" class="space-y-2" aria-busy="true">
      <div v-for="i in 3" :key="i" class="h-14 animate-pulse rounded-xl bg-stone-100" />
    </div>
    <div v-else-if="error" class="card space-y-2 text-center">
      <p class="text-sm text-stone-600">{{ error }}</p>
      <button class="btn-secondary w-full" @click="load()">重新加载</button>
    </div>
    <p v-else-if="!going.length" class="card text-center text-sm text-stone-500">还没有人报名。</p>
    <p v-else-if="!shown.length" class="card text-center text-sm text-stone-500">没有符合条件的人。</p>

    <ul v-else class="divide-y divide-stone-100 rounded-2xl bg-white ring-1 ring-stone-100">
      <li v-for="r in shown" :key="r.user_id" class="flex items-center gap-3 px-3 py-2.5">
        <ProfileAvatar :url="r.avatar_url" :name="r.display_name" :size="36" />
        <div class="min-w-0 flex-1">
          <p class="truncate text-sm font-medium">{{ r.display_name || '未填写昵称' }}</p>
          <p class="text-xs" :class="isIn(r) ? 'text-green-700' : 'text-stone-400'">
            <template v-if="r.self_checkin">{{ selfLabel(r.self_checkin) }}<span v-if="r.organiser_confirmed"> · 主办方已确认</span></template>
            <template v-else>{{ r.organiser_confirmed ? '主办方已确认' : '未签到' }}</template>
          </p>
        </div>
        <template v-if="r.user_id !== userId">
          <button
            v-if="!r.organiser_confirmed"
            class="btn-secondary px-3 py-1.5 text-xs"
            :disabled="busy === r.user_id"
            @click="setConfirmed(r, true)"
          >确认到场</button>
          <button
            v-else
            class="px-2 py-1.5 text-xs text-stone-400"
            :disabled="busy === r.user_id"
            @click="setConfirmed(r, false)"
          >撤销</button>
        </template>
      </li>
    </ul>
  </section>
</template>
