<script setup lang="ts">
import QRCode from 'qrcode'

const props = withDefaults(defineProps<{ value: string; size?: number; alt?: string }>(), {
  size: 1024,
  alt: '签到二维码',
})

const src = ref('')
const error = ref(false)

watch(() => [props.value, props.size], async () => {
  error.value = false
  if (!props.value) { src.value = ''; return }
  try {
    src.value = await QRCode.toDataURL(props.value, { width: props.size, margin: 2, errorCorrectionLevel: 'M' })
  } catch {
    error.value = true
  }
}, { immediate: true })

defineExpose({ src })
</script>

<template>
  <img v-if="src" :src="src" :alt="alt" class="aspect-square w-full [image-rendering:pixelated]">
  <div v-else class="flex aspect-square w-full items-center justify-center rounded-xl bg-stone-100 text-sm text-stone-400">
    {{ error ? '二维码生成失败' : '生成中…' }}
  </div>
</template>
