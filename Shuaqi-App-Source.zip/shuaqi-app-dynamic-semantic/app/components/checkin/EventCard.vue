<script setup lang="ts">
import type { CheckinEvent } from '~/composables/useCheckin'

defineProps<{ event: CheckinEvent }>()
</script>

<template>
  <section class="card space-y-1.5">
    <h2 class="text-lg font-semibold leading-snug">{{ event.title }}</h2>
    <p class="text-sm text-stone-600">🕒 {{ formatLondon(event.starts_at) }}（英国时间）</p>
    <p v-if="event.location_text" class="text-sm text-stone-600">📍 {{ event.location_text }}</p>
  </section>
</template>
