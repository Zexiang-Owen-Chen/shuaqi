<script setup lang="ts">
import type { CheckinMessage } from '~/composables/useCheckin'

defineProps<{ message: CheckinMessage }>()
</script>

<template>
  <div class="space-y-2" role="alert">
    <h2 class="font-semibold text-red-700">{{ message.title }}</h2>
    <p v-if="message.detail" class="text-sm text-stone-600">{{ message.detail }}</p>
    <ul v-if="message.tips?.length" class="list-disc space-y-1 pl-5 text-sm text-stone-500">
      <li v-for="tip in message.tips" :key="tip">{{ tip }}</li>
    </ul>
  </div>
</template>
