<script setup lang="ts">
const ios = ref(false)
onMounted(() => { ios.value = /iPhone|iPad|iPod/i.test(navigator.userAgent) })
</script>

<template>
  <div class="space-y-1 rounded-xl bg-stone-50 p-3 text-sm text-stone-600">
    <p class="font-medium text-stone-700">如何重新允许定位</p>
    <template v-if="ios">
      <p>1. 打开“设置” → “隐私与安全性” → “定位服务”，确认已开启。</p>
      <p>2. 在同一页找到 Safari 网站（或你用的浏览器），选“使用 App 期间”，并打开“精确位置”。</p>
      <p>3. 回到这个页面，刷新后重试。</p>
    </template>
    <template v-else>
      <p>1. 点地址栏左侧的图标 → “权限”或“网站设置” → 位置信息，改为“允许”。</p>
      <p>2. 确认手机的定位服务已开启，并打开“精确位置”。</p>
      <p>3. 刷新页面后重试。</p>
    </template>
  </div>
</template>
