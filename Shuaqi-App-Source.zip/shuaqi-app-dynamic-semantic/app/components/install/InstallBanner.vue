<script setup lang="ts">
// Single mount point for the install guide. Put it once in app.vue (works for
// every layout). It shows:
// - in WeChat / in-app browsers: the "open in browser" mask on check-in pages
//   (or pages with definePageMeta({ requiresBrowser: true })), and a one-per-session
//   hint elsewhere;
// - after useInstallPrompt().nudge('rsvp' | 'checkin'): the install banner,
//   with the system install button on Android or the steps on iPhone.
const route = useRoute()
const { kind, canPrompt, nudgeReason, dismiss, install, guide } = useInstallPrompt()

const inApp = computed(() => kind.value === 'wechat' || kind.value === 'inapp')
const needsBrowser = computed(() => route.path.startsWith('/checkin/') || route.meta.requiresBrowser === true)

// --- WeChat / in-app -------------------------------------------------------
const maskClosedFor = ref<string | null>(null)
const showMask = computed(() => inApp.value && needsBrowser.value && maskClosedFor.value !== route.path)
const forceMask = ref(false)

const HINT_KEY = 'shuaqi.install.inappHintShown'
const hintSeen = ref(true)
onMounted(() => {
  try { hintSeen.value = sessionStorage.getItem(HINT_KEY) === '1' }
  catch { hintSeen.value = false }
})
const showHint = computed(() => inApp.value && !needsBrowser.value && !hintSeen.value && !forceMask.value)
function closeHint() {
  hintSeen.value = true
  try { sessionStorage.setItem(HINT_KEY, '1') }
  catch { /* ignore */ }
}
function closeMask() {
  forceMask.value = false
  maskClosedFor.value = route.path
}

// --- Install banner --------------------------------------------------------
const showSteps = ref(false)
const showInstall = computed(() => !inApp.value && nudgeReason.value !== null)
const headline = computed(() => (nudgeReason.value === 'checkin' ? '签到成功！' : nudgeReason.value === 'rsvp' ? '报名成功！' : ''))
const installing = ref(false)

async function onInstall() {
  installing.value = true
  try {
    const outcome = await install()
    // Declining the system dialog counts as "not now".
    if (outcome !== 'accepted') dismiss()
  }
  finally { installing.value = false }
}
function onClose() {
  showSteps.value = false
  dismiss()
}

// Sit above the bottom tab bar on the default layout.
const bottom = computed(() => (route.meta.layout === 'bare' ? 'calc(1rem + env(safe-area-inset-bottom))' : 'calc(4.75rem + env(safe-area-inset-bottom))'))
</script>

<template>
  <ClientOnly>
    <InstallWeChatGuide v-if="kind && (showMask || forceMask) && inApp" :kind="kind as 'wechat' | 'inapp'" @close="closeMask" />

    <div v-if="showHint || showInstall" class="fixed inset-x-0 z-30 px-3" :style="{ bottom }">
      <!-- In-app browser hint -->
      <div v-if="showHint" class="card mx-auto flex max-w-lg items-center gap-3 shadow-lg" role="status">
        <p class="flex-1 text-sm text-stone-700">在{{ kind === 'wechat' ? '微信' : '当前 App' }}里可以浏览，签到和定位请在浏览器打开。</p>
        <button type="button" class="btn-primary shrink-0" @click="forceMask = true; closeHint()">怎么打开</button>
        <button type="button" class="shrink-0 p-1 text-stone-400" aria-label="关闭" @click="closeHint">✕</button>
      </div>

      <!-- Install banner after RSVP / check-in -->
      <div v-else-if="showInstall" class="card mx-auto max-w-lg shadow-lg" role="status">
        <div class="flex items-start gap-3">
          <img src="/icons/icon-192.png" alt="" class="size-10 shrink-0 rounded-xl">
          <div class="flex-1">
            <p class="text-sm font-medium text-stone-900">{{ headline }}把 SHUAQI 放到桌面</p>
            <p class="mt-0.5 text-xs text-stone-500">{{ kind === 'ios' ? '下次一点就开，还能收到消息和活动提醒。不装也能继续用网页。' : '下次一点就开，不装也能继续用网页。' }}</p>
          </div>
          <button type="button" class="p-1 text-stone-400" aria-label="7 天内不再提示" @click="onClose">✕</button>
        </div>
        <div v-if="kind === 'ios'" class="mt-3">
          <button v-if="!showSteps" type="button" class="btn-secondary w-full" @click="showSteps = true">看看怎么添加</button>
          <InstallSteps v-else :guide="guide('ios')" class="!p-0 !shadow-none !ring-0" />
        </div>
        <button v-else-if="canPrompt" type="button" class="btn-primary mt-3 w-full" :disabled="installing" @click="onInstall">
          安装 SHUAQI
        </button>
      </div>
    </div>
  </ClientOnly>
</template>
