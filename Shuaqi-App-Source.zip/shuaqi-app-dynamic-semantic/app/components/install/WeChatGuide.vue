<script setup lang="ts">
// Full-screen mask telling WeChat / in-app browser users to open the page in a
// real browser. Dismissable: browsing still works inside WeChat.
const props = defineProps<{ kind: 'wechat' | 'inapp' }>()
const emit = defineEmits<{ close: [] }>()

const { guide } = useInstallPrompt()
const g = computed(() => guide(props.kind))
const copied = ref(false)

async function copyLink() {
  try {
    await navigator.clipboard.writeText(location.href)
    copied.value = true
  }
  catch {
    // Old WeChat WebViews block the clipboard API; fall back to a prompt the user can copy from.
    window.prompt('复制下面的链接，到浏览器里粘贴打开', location.href)
  }
}
</script>

<template>
  <div class="fixed inset-0 z-50 bg-stone-900/85 text-white" role="dialog" aria-modal="true" aria-labelledby="wechat-guide-title">
    <svg class="absolute right-5 top-2 h-24 w-20" viewBox="0 0 80 96" fill="none" aria-hidden="true">
      <path d="M12 92 C 20 50, 40 30, 66 12" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-dasharray="6 6" />
      <path d="M52 10 L 68 10 L 66 26" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
    </svg>
    <div class="mx-auto max-w-lg px-6 pt-32">
      <h2 id="wechat-guide-title" class="text-xl font-semibold">请在浏览器中打开</h2>
      <ol class="mt-5 space-y-3">
        <li v-for="(s, i) in g.steps" :key="i" class="flex gap-3 text-base">
          <span class="flex size-6 shrink-0 items-center justify-center rounded-full bg-white/15 text-sm">{{ i + 1 }}</span>
          <span>{{ s }}</span>
        </li>
      </ol>
      <p class="mt-5 text-sm leading-relaxed text-white/75">{{ g.note }}</p>
      <div class="mt-8 flex flex-col gap-3">
        <button type="button" class="btn bg-white text-stone-900" @click="copyLink">
          {{ copied ? '已复制，去浏览器粘贴打开' : '复制链接' }}
        </button>
        <button type="button" class="btn text-white/80 underline underline-offset-4" @click="emit('close')">
          先在这里看看
        </button>
      </div>
    </div>
  </div>
</template>
