<script setup lang="ts">
import type { InstallGuide } from '~/composables/useInstallPrompt'

defineProps<{ guide: InstallGuide, current?: boolean }>()
</script>

<template>
  <section class="card" :class="current ? 'ring-2 ring-brand-500' : ''">
    <div class="flex items-center justify-between">
      <h2 class="font-semibold text-stone-900">{{ guide.title }}</h2>
      <span v-if="current" class="chip bg-brand-50 text-brand-700">你的设备</span>
    </div>
    <ol class="mt-3 space-y-2">
      <li v-for="(s, i) in guide.steps" :key="i" class="flex gap-2 text-sm text-stone-700">
        <span class="flex size-5 shrink-0 items-center justify-center rounded-full bg-stone-100 text-xs font-medium text-stone-600">{{ i + 1 }}</span>
        <span>{{ s }}</span>
      </li>
    </ol>
    <slot />
    <p v-if="guide.note" class="mt-3 text-xs leading-relaxed text-stone-500">{{ guide.note }}</p>
  </section>
</template>
