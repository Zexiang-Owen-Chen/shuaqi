<script setup lang="ts">
const props = defineProps<{ id: string; optional?: boolean }>()
const model = defineModel<string>({ required: true })
const city = ref(regionCity(model.value))

watch(model, value => {
  if (value && value !== 'London') city.value = regionCity(value)
})

function changeCity(event: Event) {
  city.value = (event.target as HTMLSelectElement).value
  model.value = city.value
}
</script>

<template>
  <div class="space-y-2">
    <div>
      <label class="label" :for="`${props.id}-city`">所在城市{{ optional ? '（可选）' : '' }}</label>
      <select :id="`${props.id}-city`" :value="city" class="input" @change="changeCity">
        <option value="" :disabled="!optional">{{ optional ? '不限地区' : '请选择城市' }}</option>
        <option v-for="c in REGION_CITIES" :key="c" :value="c">{{ c }}</option>
      </select>
    </div>
    <div v-if="city === 'London'">
      <label class="label" :for="props.id">伦敦片区</label>
      <select :id="props.id" v-model="model" class="input" required>
        <option value="" disabled>请选择片区</option>
        <option v-for="r in LONDON_REGIONS" :key="r.value" :value="r.value">{{ r.label }}</option>
      </select>
    </div>
  </div>
</template>
