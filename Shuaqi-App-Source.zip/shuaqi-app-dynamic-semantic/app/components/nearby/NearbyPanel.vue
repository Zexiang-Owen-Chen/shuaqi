<script setup lang="ts">
// Switch, consent step and list of people within 50 m. eventId null = not tied to an event.
const props = defineProps<{ eventId: string | null }>()

const {
  consented, active, busy, people, accuracy, updatedAt, error,
  loadConsent, grantConsent, withdrawConsent, start, stop, connect,
} = useNearby(() => props.eventId)

const askingConsent = ref(false)
const notice = ref('')

onMounted(loadConsent)

async function turnOn() {
  notice.value = ''
  if (!consented.value) { askingConsent.value = true; return }
  await start()
}

async function onAgree() {
  try {
    // Ask for the position inside the tap: after an await iOS may never show the location prompt.
    const fix = getPosition()
    fix.catch(() => {})
    await grantConsent()
    askingConsent.value = false
    await start(fix)
  } catch (e) {
    error.value = nearbyMessage(e)
  }
}

async function onWithdraw() {
  if (!confirm('撤回后会立即删除你保存的位置，并关闭“附近的人”。确定吗？')) return
  try {
    await withdrawConsent()
    notice.value = '已撤回同意，位置已删除'
  } catch (e) {
    error.value = nearbyMessage(e)
  }
}

async function onConnect(userId: string) {
  notice.value = ''
  try {
    await connect(userId)
    notice.value = '已发送好友请求'
  } catch (e) {
    error.value = nearbyMessage(e)
  }
}

const updatedText = computed(() => {
  if (!updatedAt.value) return ''
  return updatedAt.value.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
})
const intro = computed(() => props.eventId
  ? '开启后可以看到这个活动里 50 米内同样开启了的人，并直接加好友。默认关闭，随时可以关掉。'
  : '开启后可以看到 50 米内同样开启了的同学，并直接发好友请求。默认关闭，随时可以关掉。')
</script>

<template>
  <div class="space-y-4">
    <NearbyConsent v-if="askingConsent" :busy="busy" @agree="onAgree" @cancel="askingConsent = false" />

    <div v-else-if="!active" class="card space-y-3 text-center">
      <p class="text-4xl" aria-hidden="true">📍</p>
      <p class="text-sm text-stone-600">{{ intro }}</p>
      <button class="btn-primary w-full" :disabled="busy || consented === null" @click="turnOn">
        {{ busy ? '正在定位…' : '开启附近的人' }}
      </button>
    </div>

    <template v-else>
      <div class="card flex items-center justify-between gap-3">
        <div class="text-xs text-stone-500">
          <p class="flex items-center gap-1.5 text-sm font-medium text-stone-800">
            <span class="size-2 rounded-full bg-green-500" aria-hidden="true" />已开启
          </p>
          <p v-if="accuracy">定位精度约 {{ accuracy }} 米 · {{ updatedText }} 更新</p>
        </div>
        <button class="btn-secondary" @click="stop">关闭</button>
      </div>
      <p class="px-1 text-xs text-stone-500">请保持这个页面在前台打开；锁屏或切到别的应用后，其他人会在 2 分钟内看不到你。</p>

      <ul v-if="people.length" class="space-y-2">
        <NearbyPersonCard v-for="p in people" :key="p.card.id" :person="p" @connect="onConnect" />
      </ul>
      <div v-else class="card text-center text-sm text-stone-500">
        50 米内暂时没有开启的人。<br>列表每 30 秒自动刷新。
      </div>
    </template>

    <p v-if="notice" class="rounded-xl bg-green-50 px-3 py-2 text-sm text-green-700">{{ notice }}</p>
    <p v-if="error" class="rounded-xl bg-red-50 px-3 py-2 text-sm text-red-700">{{ error }}</p>

    <button v-if="consented && !askingConsent" class="block w-full text-center text-xs text-stone-400 underline"
            @click="onWithdraw">
      撤回位置使用同意
    </button>
  </div>
</template>
