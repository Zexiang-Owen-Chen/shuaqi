<script setup lang="ts">
// One-off consent for using location in "people nearby" (UK GDPR: separate, specific, withdrawable).
defineProps<{ busy?: boolean }>()
const emit = defineEmits<{ agree: []; cancel: [] }>()
</script>

<template>
  <div class="card space-y-3">
    <h2 class="text-base font-semibold">使用你的位置找附近的人</h2>
    <ul class="list-disc space-y-1.5 pl-5 text-sm text-stone-600">
      <li>开启后，页面每 30 秒读取一次你的位置，只用来判断谁在你 50 米内：“加好友”里附近的人、活动里附近的人，以及共同计划里对方是否已到约定地点。</li>
      <li>只有同样开启的人能看到你，对方只看到大约距离（精确到 10 米），看不到你的位置。</li>
      <li>我们只保存你最近一次的位置，5 分钟后自动删除，不记录轨迹。</li>
      <li>离开这个页面或点“关闭”就停止读取。你可以随时撤回同意，已保存的位置会立即删除。</li>
    </ul>
    <div class="flex gap-2">
      <button class="btn-primary flex-1" :disabled="busy" @click="emit('agree')">同意并继续</button>
      <button class="btn-secondary" :disabled="busy" @click="emit('cancel')">暂不</button>
    </div>
  </div>
</template>
