<script setup lang="ts">
// "Arrived?" box on a confirmed shared plan: when both people are within 50 m, prompt them to add each other.
const props = defineProps<{ planId: string; otherName: string; connected: boolean; requestSent: boolean; sending: boolean }>()
const emit = defineEmits<{ addFriend: [] }>()

const { consented, active, busy, nearby, distance, accuracy, error, loadConsent, grantConsent, start, stop } =
  usePlanMeetup(() => props.planId)
const askingConsent = ref(false)

onMounted(loadConsent)

async function turnOn() {
  if (!consented.value) { askingConsent.value = true; return }
  await start()
}

async function onAgree() {
  try {
    // Ask for the position inside the tap: after an await iOS may never show the location prompt.
    const fix = getPosition()
    fix.catch(() => {})
    await grantConsent()
    askingConsent.value = false
    await start(fix)
  } catch (e) {
    error.value = nearbyMessage(e)
  }
}
</script>

<template>
  <section class="card space-y-3">
    <h2 class="text-sm font-semibold text-stone-700">到约定地点了吗？</h2>

    <NearbyConsent v-if="askingConsent" :busy="busy" @agree="onAgree" @cancel="askingConsent = false" />

    <template v-else-if="!active">
      <p class="text-xs text-stone-500">到了之后开启到达提示。{{ otherName }}也开启后，你们相距 50 米内时会提示你们加好友。</p>
      <button class="btn-secondary w-full" :disabled="busy || consented === null" @click="turnOn">
        {{ busy ? '正在定位…' : '📍 我到了，开启到达提示' }}
      </button>
    </template>

    <template v-else>
      <div v-if="nearby" class="space-y-3 rounded-xl bg-emerald-50 p-3">
        <p class="text-sm font-medium text-emerald-800">🎉 {{ otherName }}就在你附近（约 {{ distance }} 米）</p>
        <p v-if="connected" class="text-sm text-emerald-700">你们已经是好友了。</p>
        <button v-else class="btn-primary w-full" :disabled="requestSent || sending" @click="emit('addFriend')">
          {{ requestSent ? '已发送好友请求' : sending ? '发送中…' : `加 ${otherName} 为好友` }}
        </button>
      </div>
      <p v-else class="text-sm text-stone-600">已开启，正在等{{ otherName }}到达。对方也需要在这个页面开启到达提示。</p>
      <div class="flex items-center justify-between gap-2 text-xs text-stone-400">
        <span v-if="accuracy">定位精度约 {{ accuracy }} 米，每 30 秒更新</span>
        <button class="underline" @click="stop">关闭</button>
      </div>
      <p class="text-xs text-stone-400">请保持这个页面在前台打开。</p>
    </template>

    <p v-if="error" class="rounded-xl bg-red-50 px-3 py-2 text-sm text-red-700">{{ error }}</p>
  </section>
</template>
