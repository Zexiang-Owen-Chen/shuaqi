<script setup lang="ts">
import type { NearbyPerson } from '~/composables/useNearby'

const props = defineProps<{ person: NearbyPerson }>()
const emit = defineEmits<{ connect: [userId: string] }>()

const state = computed(() => {
  if (props.person.card.connected) return 'connected'
  if (props.person.request_status === 'pending') return 'pending'
  return 'none'
})
</script>

<template>
  <li class="card flex items-center gap-3">
    <NuxtLink :to="`/u/${person.card.id}`" class="flex min-w-0 flex-1 items-center gap-3">
      <ProfileAvatar :url="person.card.avatar_url" :name="person.card.display_name" :size="48" />
      <span class="min-w-0">
        <span class="block truncate font-medium">{{ person.card.display_name || '未命名用户' }}</span>
        <span class="mt-0.5 flex flex-wrap items-center gap-1 text-xs text-stone-500">
          <span>约 {{ person.distance_m }} 米</span>
          <span v-if="person.card.region">{{ person.card.region }}</span>
          <span v-if="person.card.school_verified" class="chip !py-0.5">学校已验证</span>
        </span>
      </span>
    </NuxtLink>
    <span v-if="state === 'connected'" class="text-xs text-stone-500">已是好友</span>
    <span v-else-if="state === 'pending'" class="text-xs text-stone-500">请求待处理</span>
    <button v-else class="btn-primary !px-3 !py-2" @click="emit('connect', person.card.id)">加好友</button>
  </li>
</template>
