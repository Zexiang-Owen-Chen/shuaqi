<script setup lang="ts">
// 管理员页面外框：先确认当前用户是 admin，再显示内容。真正的权限校验在数据库（RLS 与函数）。
defineProps<{ title: string }>()

const rpc = useRpc()
const state = ref<'checking' | 'ok' | 'denied' | 'error'>('checking')
const errorText = ref('')

onMounted(async () => {
  try {
    state.value = (await rpc('is_admin')) ? 'ok' : 'denied'
  } catch (e) {
    errorText.value = (e as Error).message
    state.value = 'error'
  }
})

const tabs = [
  { to: '/admin', label: '概览' },
  { to: '/admin/reports', label: '举报' },
  { to: '/admin/corrections', label: '证据更正' },
  { to: '/admin/events', label: '活动与证据' },
  { to: '/admin/orgs', label: '组织' },
  { to: '/admin/flags', label: '功能开关' },
  { to: '/admin/recommendations', label: '推荐算法' },
  { to: '/admin/audit', label: '审计日志' },
]
const route = useRoute()
</script>

<template>
  <OrganiserShell :title="title">
    <nav class="-mt-1 mb-4 flex gap-1 overflow-x-auto text-sm">
      <NuxtLink v-for="t in tabs" :key="t.to" :to="t.to" class="whitespace-nowrap rounded-lg px-3 py-1.5"
                :class="route.path === t.to ? 'bg-stone-800 text-white' : 'bg-stone-100 text-stone-600'">{{ t.label }}</NuxtLink>
    </nav>
    <div v-if="state === 'checking'" class="card animate-pulse text-sm text-stone-400">正在确认权限…</div>
    <div v-else-if="state === 'denied'" class="card text-sm text-stone-600">这个页面只对管理员开放。</div>
    <div v-else-if="state === 'error'" class="card text-sm text-red-700">{{ errorText }}</div>
    <slot v-else />
  </OrganiserShell>
</template>
