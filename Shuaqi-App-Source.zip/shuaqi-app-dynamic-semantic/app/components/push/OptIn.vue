<script setup lang="ts">
// Soft ask before the system prompt: the browser only asks once, so we ask in our own words first
// and call Notification.requestPermission() only after a tap. On iPhone in Safari it points to the
// install guide instead, since notifications only work from the home-screen app.
const props = withDefaults(defineProps<{ text?: string, installHint?: boolean }>(), {
  text: '好友发消息、有人加你、搭子匹配成功、活动快开始时，第一时间通知你。',
  installHint: false,
})

const { support, available, canAsk, askSnoozed, checked, refresh, enable, snoozeAsk } = usePush()
const busy = ref(false)
const error = ref<string | null>(null)
const done = ref(false)

onMounted(refresh)

const showInstall = computed(() => props.installHint && available.value && checked.value
  && support.value === 'needs-install' && !askSnoozed.value)

async function onEnable() {
  busy.value = true
  error.value = null
  try {
    const result = await enable()
    if (result === 'granted') done.value = true
    else if (result === 'denied') error.value = '你拒绝了通知。之后可以在「我的 → 通知设置」里重新开启。'
  }
  catch (e) { error.value = messageFor(e) }
  finally { busy.value = false }
}
function onLater() {
  error.value = null
  snoozeAsk()
}
</script>

<template>
  <ClientOnly>
    <section v-if="done" class="card text-sm text-stone-700" role="status">已开启通知。可以在「我的 → 通知设置」里选择接收哪些。</section>
    <section v-else-if="canAsk || error" class="card" data-testid="push-opt-in">
      <p class="text-sm font-medium text-stone-900">开启通知</p>
      <p class="mt-0.5 text-xs text-stone-500">{{ text }}</p>
      <p v-if="error" class="mt-2 text-xs text-red-700">{{ error }}</p>
      <div v-if="canAsk" class="mt-3 flex gap-2">
        <button type="button" class="btn-primary flex-1" :disabled="busy" @click="onEnable">开启</button>
        <button type="button" class="btn-secondary" @click="onLater">以后再说</button>
      </div>
    </section>
    <section v-else-if="showInstall" class="card">
      <p class="text-sm font-medium text-stone-900">想收到消息通知？</p>
      <p class="mt-0.5 text-xs text-stone-500">iPhone 需要先把 SHUAQI 添加到主屏幕，再从桌面图标打开，才能开启通知。</p>
      <div class="mt-3 flex gap-2">
        <NuxtLink to="/install" class="btn-primary flex-1 text-center">看看怎么添加</NuxtLink>
        <button type="button" class="btn-secondary" @click="onLater">以后再说</button>
      </div>
    </section>
  </ClientOnly>
</template>
