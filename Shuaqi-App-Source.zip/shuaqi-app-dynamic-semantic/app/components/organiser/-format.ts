// 后台通用的小工具：时间格式、datetime-local 转换、CSV 导出。

import { fromLondonInput, toLondonInput } from '../../utils/eventFormat'

const TZ = 'Europe/London'

export function formatDateTime(iso: string | null | undefined): string {
  if (!iso) return '—'
  return new Intl.DateTimeFormat('zh-CN', {
    timeZone: TZ, month: '2-digit', day: '2-digit', weekday: 'short', hour: '2-digit', minute: '2-digit',
  }).format(new Date(iso))
}

export function formatTime(iso: string | null | undefined): string {
  if (!iso) return '—'
  return new Intl.DateTimeFormat('zh-CN', { timeZone: TZ, hour: '2-digit', minute: '2-digit' }).format(new Date(iso))
}

// <input type="datetime-local"> 按伦敦墙上时间读写，与浏览器时区无关（和核心 EventForm 一致）
export function isoToLocalInput(iso: string | null | undefined): string {
  if (!iso || Number.isNaN(new Date(iso).getTime())) return ''
  return toLondonInput(iso)
}

export function localInputToIso(value: string | null | undefined): string | null {
  return value ? fromLondonInput(value) : null
}

// 以 = + - @ 开头的单元格前加 '，防止在 Excel 里被当成公式执行
export function csvCell(value: unknown): string {
  if (value === null || value === undefined) return ''
  let s = String(value)
  if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`
  if (/[",\n\r]/.test(s)) s = `"${s.replace(/"/g, '""')}"`
  return s
}

export function toCsv(headers: string[], rows: unknown[][]): string {
  return [headers, ...rows].map(r => r.map(csvCell).join(',')).join('\r\n')
}

export function downloadCsv(filename: string, csv: string) {
  // 加 BOM，Excel 打开中文不乱码
  const blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  a.click()
  URL.revokeObjectURL(url)
}

export function currentUserId(user: { id?: string, sub?: string } | null | undefined): string | null {
  return user?.sub ?? user?.id ?? null
}

export const EVIDENCE_TYPE_TEXT: Record<string, string> = {
  self_reported_presence: '扫码定位签到',
  organiser_confirmed_attendance: '主办方确认到场',
  mutually_reported_interaction: '双方确认见面',
}

export const VERIFICATION_TEXT: Record<string, string> = {
  unverified: '未核验',
  geo_verified: '定位核验',
  verified: '已核验',
  disputed: '有争议',
  revoked: '已撤销',
}
