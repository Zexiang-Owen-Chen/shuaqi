<script setup lang="ts">
// 在地图上点选活动位置，并画出签到半径。地图用 OpenStreetMap（Leaflet），不需要密钥。
import type { Map as LMap, CircleMarker, Circle } from 'leaflet'
import 'leaflet/dist/leaflet.css'

const lat = defineModel<number | null>('lat', { required: true })
const lng = defineModel<number | null>('lng', { required: true })
const props = defineProps<{ radius: number }>()

const DEFAULT_CENTER: [number, number] = [51.5246, -0.134] // UCL 附近

const el = ref<HTMLDivElement>()
const postcode = ref('')
const busy = ref(false)
const message = ref<string | null>(null)
let map: LMap | null = null
let marker: CircleMarker | null = null
let circle: Circle | null = null
let L: typeof import('leaflet') | null = null

function draw(recenter = false) {
  if (!map || !L) return
  if (lat.value === null || lng.value === null) {
    marker?.remove(); circle?.remove(); marker = circle = null
    return
  }
  const pos: [number, number] = [lat.value, lng.value]
  if (!marker) {
    marker = L.circleMarker(pos, { radius: 8, color: '#ea580c', fillColor: '#f97316', fillOpacity: 1 }).addTo(map)
    circle = L.circle(pos, { radius: props.radius, color: '#f97316', weight: 1, fillOpacity: 0.12 }).addTo(map)
  } else {
    marker.setLatLng(pos)
    circle!.setLatLng(pos)
    circle!.setRadius(props.radius)
  }
  if (recenter) map.setView(pos, Math.max(map.getZoom(), 17))
}

function setPoint(a: number, b: number, recenter = false) {
  lat.value = Math.round(a * 1e6) / 1e6
  lng.value = Math.round(b * 1e6) / 1e6
  draw(recenter)
}

onMounted(async () => {
  L = await import('leaflet')
  const start: [number, number] = lat.value !== null && lng.value !== null ? [lat.value, lng.value] : DEFAULT_CENTER
  map = L.map(el.value!, { zoomControl: true }).setView(start, lat.value !== null ? 17 : 14)
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; OpenStreetMap',
  }).addTo(map)
  map.on('click', e => setPoint(e.latlng.lat, e.latlng.lng))
  draw()
})

onBeforeUnmount(() => { map?.remove(); map = null })

watch(() => props.radius, () => draw())
watch([lat, lng], () => draw())

async function useMyLocation() {
  busy.value = true
  message.value = null
  try {
    const fix = await getPosition()
    setPoint(fix.lat, fix.lng, true)
    if (fix.accuracy > 50) message.value = `当前定位误差约 ${Math.round(fix.accuracy)} 米，建议在地图上再点一下确认入口位置`
  } catch (e) {
    message.value = (e as Error).message
  } finally {
    busy.value = false
  }
}

// 英国邮编查询（postcodes.io，免费、无需密钥），定位到邮编中心后再在地图上点准
async function searchPostcode() {
  const pc = postcode.value.trim()
  if (!pc) return
  busy.value = true
  message.value = null
  try {
    const res = await fetch(`https://api.postcodes.io/postcodes/${encodeURIComponent(pc)}`)
    const body = await res.json()
    if (!res.ok || !body?.result) throw new Error('找不到这个邮编')
    setPoint(body.result.latitude, body.result.longitude, true)
    message.value = '已定位到邮编中心，请在地图上点一下活动入口的准确位置'
  } catch (e) {
    message.value = (e as Error).message || '邮编查询失败'
  } finally {
    busy.value = false
  }
}
</script>

<template>
  <div class="space-y-2">
    <div class="flex flex-wrap gap-2">
      <input v-model="postcode" class="input max-w-40" placeholder="英国邮编，如 WC1E 6BT" @keydown.enter.prevent="searchPostcode">
      <button type="button" class="btn-secondary" :disabled="busy" @click="searchPostcode">查邮编</button>
      <button type="button" class="btn-secondary" :disabled="busy" @click="useMyLocation">用我现在的位置</button>
    </div>
    <div ref="el" class="h-72 w-full overflow-hidden rounded-xl ring-1 ring-stone-200" />
    <p class="text-xs text-stone-500">
      点击地图选择签到点（通常是活动入口），橙色圆圈是签到范围。
      <template v-if="lat !== null && lng !== null">当前：{{ lat }}, {{ lng }}</template>
      <template v-else>尚未选择位置。</template>
    </p>
    <p v-if="message" class="text-xs text-amber-700">{{ message }}</p>
  </div>
</template>
