<script setup lang="ts">
// 主办方创建 / 编辑活动的表单，包含地点、签到半径、签到方式和签到时间窗。
import type { Database } from '~/types/database.types'
import { isoToLocalInput, localInputToIso } from './-format'

type EventRow = Database['public']['Tables']['events']['Row']
type EventInsert = Database['public']['Tables']['events']['Insert']
export interface OrgOption { org_id: string, name: string, role: string }

const props = defineProps<{
  event?: EventRow | null
  orgs: OrgOption[]
  saving?: boolean
  submitLabel?: string
}>()
const emit = defineEmits<{ submit: [payload: Omit<EventInsert, 'host_user_id'> & { status?: EventRow['status'] }] }>()

const CATEGORIES = [
  ['social', '社交'], ['party', '派对'], ['sports', '运动'], ['study', '学习'], ['food', '美食'],
  ['music', '音乐'], ['outdoor', '户外'], ['career', '职业'], ['culture', '文化'], ['other', '其他'],
] as const

const HOUR = 3600_000
const isEdit = computed(() => !!props.event)
// 能用来建活动的组织：owner / organiser（staff 只能协助签到）
const creatableOrgs = computed(() => props.orgs.filter(o => o.role === 'owner' || o.role === 'organiser'))

function initial() {
  const e = props.event
  if (e) {
    return {
      org_id: e.org_id, type: e.type, category: e.category, title: e.title, description: e.description,
      image_paths: [...e.image_paths],
      starts_at: isoToLocalInput(e.starts_at), ends_at: isoToLocalInput(e.ends_at),
      location_text: e.location_text, location_lat: e.location_lat, location_lng: e.location_lng,
      checkin_radius_m: e.checkin_radius_m, checkin_mode: e.checkin_mode,
      checkin_opens_at: isoToLocalInput(e.checkin_opens_at), checkin_closes_at: isoToLocalInput(e.checkin_closes_at),
      require_checkin_for_connect: e.require_checkin_for_connect,
      capacity: e.capacity as number | null, visibility: e.visibility, status: e.status,
    }
  }
  const start = new Date(Math.ceil(Date.now() / HOUR) * HOUR + 24 * HOUR)
  return {
    org_id: (creatableOrgs.value[0]?.org_id ?? null) as string | null,
    type: 'group' as EventRow['type'], category: 'social', title: '', description: '',
    image_paths: [] as string[],
    starts_at: isoToLocalInput(start.toISOString()),
    ends_at: isoToLocalInput(new Date(start.getTime() + 2 * HOUR).toISOString()),
    location_text: '', location_lat: null as number | null, location_lng: null as number | null,
    checkin_radius_m: 100, checkin_mode: 'qr_geo' as EventRow['checkin_mode'],
    checkin_opens_at: '', checkin_closes_at: '', require_checkin_for_connect: false,
    capacity: null as number | null, visibility: 'public' as EventRow['visibility'],
    status: 'published' as EventRow['status'],
  }
}

const form = reactive(initial())
const errors = ref<Record<string, string>>({})
const imagesUploading = ref(false)
const customWindow = ref(!!(form.checkin_opens_at || form.checkin_closes_at))

watch(() => props.event, () => Object.assign(form, initial()))
watch(() => form.org_id, (v) => { form.type = v ? 'group' : form.type })

const defaultWindowText = computed(() => {
  const s = localInputToIso(form.starts_at)
  if (!s) return ''
  const opens = new Date(new Date(s).getTime() - HOUR)
  const e = localInputToIso(form.ends_at)
  const closes = e ? new Date(e) : new Date(new Date(s).getTime() + 6 * HOUR)
  const f = (d: Date) => isoToLocalInput(d.toISOString()).replace('T', ' ')
  return `${f(opens)} 至 ${f(closes)}`
})

function validate() {
  const err: Record<string, string> = {}
  const title = form.title.trim()
  if (title.length < 2 || title.length > 80) err.title = '标题 2–80 个字'
  if (form.description.length > 2000) err.description = '简介最多 2000 字'
  const starts = localInputToIso(form.starts_at)
  const ends = localInputToIso(form.ends_at)
  if (!starts) err.starts_at = '请填写开始时间'
  else if (!isEdit.value && new Date(starts).getTime() < Date.now() - HOUR) err.starts_at = '开始时间不能早于现在'
  if (starts && ends && ends <= starts) err.ends_at = '结束时间需晚于开始时间'
  if (form.location_text.trim().length < 2) err.location_text = '请填写地点名称'
  if (form.location_text.length > 200) err.location_text = '地点最多 200 字'
  const r = Number(form.checkin_radius_m)
  if (!Number.isInteger(r) || r < 20 || r > 1000) err.checkin_radius_m = '签到半径需在 20–1000 米之间'
  if (form.checkin_mode === 'qr_geo' && (form.location_lat === null || form.location_lng === null))
    err.location = '扫码定位签到需要在地图上选定签到点'
  if (form.capacity !== null && (form.capacity as unknown) !== '') {
    const c = Number(form.capacity)
    if (!Number.isInteger(c) || c < 2 || c > 5000) err.capacity = '人数上限 2–5000，不限请留空'
  }
  if (customWindow.value) {
    const o = localInputToIso(form.checkin_opens_at)
    const c = localInputToIso(form.checkin_closes_at)
    if (!o || !c) err.checkin_window = '请同时填写签到开放和关闭时间，或改回默认'
    else if (c <= o) err.checkin_window = '签到关闭时间需晚于开放时间'
  }
  errors.value = err
  return Object.keys(err).length === 0
}

function submit() {
  if (imagesUploading.value) return
  if (!validate()) return
  const cap = form.capacity === null || (form.capacity as unknown) === '' ? null : Number(form.capacity)
  emit('submit', {
    ...(isEdit.value ? {} : { org_id: form.org_id, type: form.type }),
    category: form.category,
    title: form.title.trim(),
    description: form.description.trim(),
    image_paths: [...form.image_paths],
    starts_at: localInputToIso(form.starts_at)!,
    ends_at: localInputToIso(form.ends_at),
    location_text: form.location_text.trim(),
    location_lat: form.location_lat,
    location_lng: form.location_lng,
    checkin_radius_m: Number(form.checkin_radius_m),
    checkin_mode: form.checkin_mode,
    checkin_opens_at: customWindow.value ? localInputToIso(form.checkin_opens_at) : null,
    checkin_closes_at: customWindow.value ? localInputToIso(form.checkin_closes_at) : null,
    require_checkin_for_connect: form.require_checkin_for_connect,
    capacity: cap,
    visibility: form.visibility,
    status: form.status,
  })
}
</script>

<template>
  <form class="space-y-4" novalidate @submit.prevent="submit">
    <section class="card space-y-3">
      <h2 class="font-medium">基本信息</h2>
      <div v-if="!isEdit">
        <label class="label">主办方</label>
        <select v-model="form.org_id" class="input">
          <option v-for="o in creatableOrgs" :key="o.org_id" :value="o.org_id">{{ o.name }}</option>
          <option :value="null">以个人身份发起</option>
        </select>
        <p class="mt-1 text-xs text-stone-500">以组织名义发起后，组织的 organiser 和 staff 都能看到名单、协助签到。发起后不能更改。</p>
      </div>
      <div>
        <label class="label">活动标题</label>
        <input v-model="form.title" class="input" maxlength="80" placeholder="例如：G5 万圣节舞会">
        <p v-if="errors.title" class="mt-1 text-xs text-red-600">{{ errors.title }}</p>
      </div>
      <div class="grid gap-3 sm:grid-cols-2">
        <div>
          <label class="label">分类</label>
          <select v-model="form.category" class="input">
            <option v-for="[v, l] in CATEGORIES" :key="v" :value="v">{{ l }}</option>
          </select>
        </div>
        <div>
          <label class="label">谁能看到</label>
          <select v-model="form.visibility" class="input">
            <option value="public">所有用户</option>
            <option value="school">仅与发起人同校</option>
          </select>
        </div>
      </div>
      <div>
        <label class="label">简介</label>
        <textarea v-model="form.description" class="input min-h-24" maxlength="2000" placeholder="活动内容、着装、费用、注意事项" />
        <p v-if="errors.description" class="mt-1 text-xs text-red-600">{{ errors.description }}</p>
      </div>
      <EventImageUpload v-model="form.image_paths" :disabled="saving" @uploading="imagesUploading = $event" />
      <div class="grid gap-3 sm:grid-cols-3">
        <div>
          <label class="label">开始时间（伦敦时间）</label>
          <input v-model="form.starts_at" type="datetime-local" class="input">
          <p v-if="errors.starts_at" class="mt-1 text-xs text-red-600">{{ errors.starts_at }}</p>
        </div>
        <div>
          <label class="label">结束时间</label>
          <input v-model="form.ends_at" type="datetime-local" class="input">
          <p v-if="errors.ends_at" class="mt-1 text-xs text-red-600">{{ errors.ends_at }}</p>
        </div>
        <div>
          <label class="label">人数上限（不限请留空）</label>
          <input v-model.number="form.capacity" type="number" min="2" max="5000" class="input" placeholder="不限">
          <p v-if="errors.capacity" class="mt-1 text-xs text-red-600">{{ errors.capacity }}</p>
        </div>
      </div>
      <div>
        <label class="label">状态</label>
        <select v-model="form.status" class="input max-w-48" :disabled="form.status === 'cancelled'">
          <option value="draft">草稿（用户看不到）</option>
          <option value="published">已发布</option>
          <option v-if="isEdit" value="ended">已结束</option>
          <option v-if="form.status === 'cancelled'" value="cancelled">已取消</option>
        </select>
      </div>
    </section>

    <section class="card space-y-3">
      <h2 class="font-medium">地点</h2>
      <div>
        <label class="label">地点名称（显示给用户）</label>
        <input v-model="form.location_text" class="input" maxlength="200" placeholder="例如：UCL Student Centre, 16 Gordon St">
        <p v-if="errors.location_text" class="mt-1 text-xs text-red-600">{{ errors.location_text }}</p>
      </div>
      <ClientOnly>
        <OrganiserLocationPicker v-model:lat="form.location_lat" v-model:lng="form.location_lng" :radius="Number(form.checkin_radius_m) || 100" />
        <template #fallback><div class="h-72 animate-pulse rounded-xl bg-stone-100" /></template>
      </ClientOnly>
      <p v-if="errors.location" class="text-xs text-red-600">{{ errors.location }}</p>
    </section>

    <section class="card space-y-3">
      <h2 class="font-medium">签到</h2>
      <div class="grid gap-2 sm:grid-cols-3">
        <label v-for="m in ([['qr_geo', '扫码 + 定位', '用户扫入口的活动码并提交位置，自动签到'], ['manual', '仅手动确认', '由工作人员在名单里逐个确认'], ['none', '不签到', '活动不记录到场']] as const)"
               :key="m[0]" class="flex cursor-pointer gap-2 rounded-xl p-3 ring-1"
               :class="form.checkin_mode === m[0] ? 'bg-brand-50 ring-brand-500' : 'ring-stone-200'">
          <input v-model="form.checkin_mode" type="radio" :value="m[0]" class="mt-1">
          <span><span class="block text-sm font-medium">{{ m[1] }}</span><span class="text-xs text-stone-500">{{ m[2] }}</span></span>
        </label>
      </div>

      <template v-if="form.checkin_mode === 'qr_geo'">
        <div>
          <label class="label">签到半径：{{ form.checkin_radius_m }} 米</label>
          <input v-model.number="form.checkin_radius_m" type="range" min="20" max="500" step="10" class="w-full accent-brand-500">
          <div class="flex items-center gap-2 text-xs text-stone-500">
            <span>室内 GPS 误差常见 20–100 米，室内场地建议 100–150 米。</span>
            <input v-model.number="form.checkin_radius_m" type="number" min="20" max="1000" class="input w-24 py-1">
          </div>
          <p v-if="errors.checkin_radius_m" class="mt-1 text-xs text-red-600">{{ errors.checkin_radius_m }}</p>
        </div>
      </template>

      <div v-if="form.checkin_mode !== 'none'" class="space-y-2">
        <label class="flex items-center gap-2 text-sm">
          <input v-model="customWindow" type="checkbox"> 自定义签到时间
        </label>
        <p v-if="!customWindow" class="text-xs text-stone-500">默认：开始前 1 小时到结束（{{ defaultWindowText }}）</p>
        <div v-else class="grid gap-3 sm:grid-cols-2">
          <div><label class="label">开放签到</label><input v-model="form.checkin_opens_at" type="datetime-local" class="input"></div>
          <div><label class="label">关闭签到</label><input v-model="form.checkin_closes_at" type="datetime-local" class="input"></div>
        </div>
        <p v-if="errors.checkin_window" class="text-xs text-red-600">{{ errors.checkin_window }}</p>
      </div>

      <label class="flex items-start gap-2 text-sm">
        <input v-model="form.require_checkin_for_connect" type="checkbox" class="mt-1">
        <span>到场签到后才能在活动名单里加好友<span class="block text-xs text-stone-500">“附近 50 米加好友”始终需要双方已签到，不受这个开关影响。</span></span>
      </label>
    </section>

    <div class="flex justify-end gap-2">
      <slot name="extra-actions" />
      <button type="submit" class="btn-primary" :disabled="saving || imagesUploading">{{ saving ? '保存中…' : (submitLabel ?? '保存') }}</button>
    </div>
    <p v-if="Object.keys(errors).length" class="text-right text-xs text-red-600">请先修正上面标红的项目</p>
  </form>
</template>
