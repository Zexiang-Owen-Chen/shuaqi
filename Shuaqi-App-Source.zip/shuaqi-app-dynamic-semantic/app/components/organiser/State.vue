<script setup lang="ts">
// 加载中 / 出错 / 空状态的统一展示
defineProps<{ loading?: boolean, error?: string | null, empty?: boolean, emptyText?: string }>()
defineEmits<{ retry: [] }>()
</script>

<template>
  <div v-if="loading" class="card animate-pulse text-sm text-stone-400">加载中…</div>
  <div v-else-if="error" class="card text-sm text-red-700">
    {{ error }}
    <button class="ml-2 underline" @click="$emit('retry')">重试</button>
  </div>
  <div v-else-if="empty" class="card text-center text-sm text-stone-500">{{ emptyText ?? '暂无数据' }}</div>
  <slot v-else />
</template>
