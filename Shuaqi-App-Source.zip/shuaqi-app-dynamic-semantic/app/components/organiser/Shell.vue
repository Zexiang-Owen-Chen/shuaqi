<script setup lang="ts">
// 主办方后台和管理员后台共用的页面框架：顶部导航，比用户端更宽，方便在电脑上看名单。
defineProps<{ title?: string, back?: string }>()

const route = useRoute()
const rpc = useRpc()
const isAdmin = useState<boolean | null>('organiser-is-admin', () => null)
onMounted(async () => {
  if (isAdmin.value === null) isAdmin.value = await rpc('is_admin').catch(() => false)
})

const links = computed(() => [
  { to: '/organiser', label: '我的活动' },
  ...(isAdmin.value ? [{ to: '/admin', label: '管理员' }] : []),
  { to: '/', label: '回到 App' },
])
const active = (to: string) => to !== '/' && (to === '/organiser'
  ? route.path.startsWith('/organiser')
  : route.path.startsWith(to))
</script>

<template>
  <div class="min-h-dvh">
    <header class="sticky top-0 z-20 border-b border-stone-200 bg-white/95 backdrop-blur">
      <div class="mx-auto flex max-w-5xl items-center gap-3 px-4 py-3">
        <NuxtLink to="/organiser" class="font-semibold text-brand-600">SHUAQI 后台</NuxtLink>
        <nav class="ml-auto flex gap-1 text-sm">
          <NuxtLink v-for="l in links" :key="l.to" :to="l.to"
                    class="rounded-lg px-2.5 py-1.5"
                    :class="active(l.to) ? 'bg-brand-50 text-brand-700' : 'text-stone-600'">
            {{ l.label }}
          </NuxtLink>
        </nav>
      </div>
    </header>
    <main class="mx-auto max-w-5xl px-4 py-5">
      <div v-if="title || back || $slots.actions" class="mb-4 flex flex-wrap items-center gap-2">
        <NuxtLink v-if="back" :to="back" class="text-sm text-stone-500">‹ 返回</NuxtLink>
        <h1 v-if="title" class="text-xl font-semibold">{{ title }}</h1>
        <div class="ml-auto flex flex-wrap gap-2"><slot name="actions" /></div>
      </div>
      <slot />
    </main>
  </div>
</template>
