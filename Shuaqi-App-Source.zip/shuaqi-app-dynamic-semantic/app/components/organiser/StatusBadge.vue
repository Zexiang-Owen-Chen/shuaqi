<script setup lang="ts">
const props = defineProps<{ kind: 'event' | 'checkin' | 'report' | 'correction', value: string | null | undefined }>()

const MAP: Record<string, Record<string, [string, string]>> = {
  event: {
    draft: ['草稿', 'bg-stone-100 text-stone-600'],
    published: ['已发布', 'bg-green-50 text-green-700'],
    cancelled: ['已取消', 'bg-red-50 text-red-700'],
    ended: ['已结束', 'bg-stone-100 text-stone-500'],
  },
  checkin: {
    geo_verified: ['已到场（定位核验）', 'bg-sky-50 text-sky-700'],
    verified: ['主办方已确认', 'bg-green-50 text-green-700'],
    unverified: ['未核验', 'bg-stone-100 text-stone-600'],
    disputed: ['有争议', 'bg-amber-50 text-amber-700'],
    revoked: ['已撤销', 'bg-red-50 text-red-700'],
  },
  report: {
    open: ['待处理', 'bg-amber-50 text-amber-700'],
    reviewing: ['处理中', 'bg-sky-50 text-sky-700'],
    resolved: ['已解决', 'bg-green-50 text-green-700'],
    dismissed: ['已驳回', 'bg-stone-100 text-stone-500'],
  },
  correction: {
    pending: ['待处理', 'bg-amber-50 text-amber-700'],
    approved: ['已通过', 'bg-green-50 text-green-700'],
    rejected: ['已拒绝', 'bg-stone-100 text-stone-500'],
  },
}
const entry = computed(() => MAP[props.kind]?.[props.value ?? ''] ?? [props.value ?? '—', 'bg-stone-100 text-stone-500'])
</script>

<template>
  <span class="inline-flex items-center whitespace-nowrap rounded-full px-2 py-0.5 text-xs" :class="entry[1]">{{ entry[0] }}</span>
</template>
