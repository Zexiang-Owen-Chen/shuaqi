<script setup lang="ts">
// 活动报名与签到名单：查看定位签到结果、由工作人员确认到场、导出 CSV。
import type { Database } from '~/types/database.types'
import { downloadCsv, formatDateTime, formatTime, toCsv } from './-format'

const props = defineProps<{ eventId: string, eventTitle: string, canConfirm: boolean, capacity?: number | null }>()
const emit = defineEmits<{ stats: [s: { going: number, selfChecked: number, confirmed: number, absent: number }] }>()

type Attendee = Database['public']['Functions']['list_event_attendees']['Returns'][number]
interface Row extends Attendee {
  self_at: string | null
  distance_m: number | null
  accuracy_m: number | null
  confirmed_at: string | null
}

const supabase = useSupabaseClient<Database>()
const rpc = useRpc()

const rows = ref<Row[]>([])
const loading = ref(true)
const error = ref<string | null>(null)
const updatedAt = ref<Date | null>(null)
const busy = ref<Set<string>>(new Set())
const actionError = ref<string | null>(null)
const query = ref('')
const filter = ref<'all' | 'absent' | 'self' | 'confirmed' | 'cancelled'>('all')

async function load(silent = false) {
  if (!silent) loading.value = true
  try {
    const [list, ev] = await Promise.all([
      rpc('list_event_attendees', { p_event: props.eventId }),
      supabase.from('participation_evidence')
        .select('subject_user_id, type, geo_distance_m, geo_accuracy_m, occurred_at')
        .eq('event_id', props.eventId).neq('verification_status', 'revoked'),
    ])
    if (ev.error) throw new Error(messageFor(ev.error))
    const self = new Map<string, { at: string, d: number | null, a: number | null }>()
    const conf = new Map<string, string>()
    for (const e of ev.data ?? []) {
      if (e.type === 'self_reported_presence') self.set(e.subject_user_id, { at: e.occurred_at, d: e.geo_distance_m, a: e.geo_accuracy_m })
      if (e.type === 'organiser_confirmed_attendance') conf.set(e.subject_user_id, e.occurred_at)
    }
    rows.value = list.map(r => ({
      ...r,
      self_at: self.get(r.user_id)?.at ?? null,
      distance_m: self.get(r.user_id)?.d ?? null,
      accuracy_m: self.get(r.user_id)?.a ?? null,
      confirmed_at: conf.get(r.user_id) ?? null,
    }))
    error.value = null
    updatedAt.value = new Date()
  } catch (e) {
    if (!silent || !rows.value.length) error.value = (e as Error).message
  } finally {
    loading.value = false
  }
}

const isPresent = (r: Row) => r.organiser_confirmed || r.self_checkin === 'geo_verified' || r.self_checkin === 'verified'
const going = computed(() => rows.value.filter(r => r.rsvp_status === 'going'))
const counts = computed(() => ({
  going: going.value.length,
  selfChecked: going.value.filter(r => r.self_checkin === 'geo_verified' || r.self_checkin === 'verified').length,
  confirmed: going.value.filter(r => r.organiser_confirmed).length,
  absent: going.value.filter(r => !isPresent(r)).length,
}))
watch(counts, c => emit('stats', c), { immediate: true })


const shown = computed(() => {
  const q = query.value.trim().toLowerCase()
  return rows.value
    .filter((r) => {
      switch (filter.value) {
        case 'all': return r.rsvp_status === 'going'
        case 'absent': return r.rsvp_status === 'going' && !isPresent(r)
        case 'self': return r.rsvp_status === 'going' && !!r.self_checkin && !r.organiser_confirmed
        case 'confirmed': return r.rsvp_status === 'going' && r.organiser_confirmed
        case 'cancelled': return r.rsvp_status !== 'going'
      }
      return true
    })
    .filter(r => !q || (r.display_name ?? '').toLowerCase().includes(q) || (r.school_domain ?? '').includes(q))
})

const filters = computed(() => [
  ['all', `全部 ${counts.value.going}`],
  ['absent', `未到 ${counts.value.absent}`],
  ['self', `待确认 ${going.value.filter(r => r.self_checkin && !r.organiser_confirmed).length}`],
  ['confirmed', `已确认 ${counts.value.confirmed}`],
  ['cancelled', `取消报名 ${rows.value.length - counts.value.going}`],
] as const)

async function setConfirmed(r: Row, confirm: boolean) {
  if (!confirm && !window.confirm(`撤销对「${r.display_name || '该用户'}」的到场确认？`)) return
  actionError.value = null
  busy.value.add(r.user_id)
  try {
    await rpc('organiser_confirm_attendance', { p_event: props.eventId, p_user: r.user_id, p_confirm: confirm })
    r.organiser_confirmed = confirm
    r.confirmed_at = confirm ? new Date().toISOString() : null
  } catch (e) {
    actionError.value = (e as Error).message
  } finally {
    busy.value.delete(r.user_id)
  }
}

const pendingSelf = computed(() => going.value.filter(r => r.self_checkin === 'geo_verified' && !r.organiser_confirmed))
const bulkRunning = ref(false)
async function confirmAllSelf() {
  const list = pendingSelf.value
  if (!list.length || !window.confirm(`确认 ${list.length} 位已定位签到的人到场？请先确认他们确实在现场。`)) return
  bulkRunning.value = true
  for (const r of list) await setConfirmed(r, true)
  bulkRunning.value = false
}

function exportCsv() {
  const csv = toCsv(
    ['姓名', '学校邮箱域名', '报名状态', '报名时间', '定位签到', '定位签到时间', '距离(米)', '定位精度(米)', '主办方确认', '确认时间'],
    rows.value.map(r => [
      r.display_name, r.school_domain, r.rsvp_status === 'going' ? '已报名' : '已取消', formatDateTime(r.rsvp_at),
      r.self_checkin ?? '', r.self_at ? formatDateTime(r.self_at) : '',
      r.distance_m === null ? '' : Math.round(r.distance_m), r.accuracy_m === null ? '' : Math.round(r.accuracy_m),
      r.organiser_confirmed ? '是' : '否', r.confirmed_at ? formatDateTime(r.confirmed_at) : '',
    ]),
  )
  const safe = props.eventTitle.replace(/[\\/:*?"<>|]/g, '_').slice(0, 40)
  downloadCsv(`${safe}-名单-${new Date().toISOString().slice(0, 10)}.csv`, csv)
}

// 活动现场每 15 秒自动刷新一次（页面在后台时暂停）
let timer: ReturnType<typeof setInterval> | undefined
onMounted(() => {
  load()
  timer = setInterval(() => { if (document.visibilityState === 'visible') load(true) }, 15_000)
})
onBeforeUnmount(() => clearInterval(timer))
defineExpose({ reload: () => load(true) })
</script>

<template>
  <section class="space-y-3">
    <div class="flex flex-wrap items-center gap-2">
      <h2 class="font-medium">报名与签到名单</h2>
      <span v-if="updatedAt" class="text-xs text-stone-400">{{ formatTime(updatedAt.toISOString()) }} 更新 · 每 15 秒自动刷新</span>
      <div class="ml-auto flex flex-wrap gap-2">
        <button class="btn-secondary" @click="load()">刷新</button>
        <button class="btn-secondary" :disabled="!rows.length" @click="exportCsv">导出 CSV</button>
        <button v-if="canConfirm && pendingSelf.length" class="btn-primary" :disabled="bulkRunning" @click="confirmAllSelf">
          {{ bulkRunning ? '确认中…' : `一键确认定位已签到 ${pendingSelf.length} 人` }}
        </button>
      </div>
    </div>

    <div class="flex flex-wrap gap-2">
      <input v-model="query" class="input max-w-60" placeholder="搜索姓名或学校">
      <button v-for="f in filters" :key="f[0]" class="rounded-lg px-3 py-1.5 text-sm"
              :class="filter === f[0] ? 'bg-stone-800 text-white' : 'bg-stone-100 text-stone-600'"
              @click="filter = f[0]">{{ f[1] }}</button>
    </div>

    <p v-if="actionError" class="text-sm text-red-700">{{ actionError }}</p>

    <OrganiserState :loading="loading" :error="error" :empty="!shown.length"
                    :empty-text="rows.length ? '没有符合条件的人' : '还没有人报名'" @retry="load()">
      <ul class="divide-y divide-stone-100 overflow-hidden rounded-2xl bg-white ring-1 ring-stone-100">
        <li v-for="r in shown" :key="r.user_id" class="flex flex-wrap items-center gap-3 px-4 py-3">
          <ProfileAvatar :url="r.avatar_url" :name="r.display_name" :size="40" />
          <div class="min-w-0 flex-1">
            <p class="truncate font-medium">{{ r.display_name || '未填写昵称' }}</p>
            <p class="text-xs text-stone-500">{{ r.school_domain || '—' }} · {{ formatDateTime(r.rsvp_at) }} 报名</p>
          </div>
          <div class="flex flex-col items-end gap-1 text-right">
            <OrganiserStatusBadge v-if="r.organiser_confirmed" kind="checkin" value="verified" />
            <OrganiserStatusBadge v-if="r.self_checkin" kind="checkin" :value="r.self_checkin" />
            <span v-if="r.self_at" class="text-xs text-stone-400">
              {{ formatTime(r.self_at) }}<template v-if="r.distance_m !== null"> · 距离 {{ Math.round(r.distance_m) }}m</template><template v-if="r.accuracy_m !== null"> · 精度 ±{{ Math.round(r.accuracy_m) }}m</template>
            </span>
            <span v-if="!r.self_checkin && !r.organiser_confirmed && r.rsvp_status === 'going'" class="text-xs text-stone-400">未签到</span>
            <span v-if="r.rsvp_status !== 'going'" class="text-xs text-stone-400">已取消报名</span>
          </div>
          <div v-if="canConfirm && r.rsvp_status === 'going'" class="w-full sm:w-auto">
            <button v-if="!r.organiser_confirmed" class="btn-primary w-full sm:w-28" :disabled="busy.has(r.user_id)" @click="setConfirmed(r, true)">确认到场</button>
            <button v-else class="btn-secondary w-full sm:w-28" :disabled="busy.has(r.user_id)" @click="setConfirmed(r, false)">撤销确认</button>
          </div>
        </li>
      </ul>
    </OrganiserState>
    <p class="text-xs text-stone-400">
      “已到场（定位核验）”是用户扫码并通过定位校验，GPS 可能被伪造；只有工作人员点“确认到场”才算主办方核验。导出的名单含个人信息，请勿外传，活动结束后删除。
    </p>
  </section>
</template>
