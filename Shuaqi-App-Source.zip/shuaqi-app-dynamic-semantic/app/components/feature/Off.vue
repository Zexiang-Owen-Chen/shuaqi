<script setup lang="ts">
// Shown in place of a feature that has been switched off in 功能开关.
withDefaults(defineProps<{ title?: string; text?: string; backTo?: string; backLabel?: string }>(), {
  title: '这个功能暂时关闭了',
  text: '我们正在调整，稍后再来看看。其他功能不受影响。',
  backTo: '/',
  backLabel: '去发现活动',
})
</script>

<template>
  <div class="card py-10 text-center">
    <p class="mb-2 text-3xl" aria-hidden="true">🛠️</p>
    <p class="font-medium text-stone-800">{{ title }}</p>
    <p class="mt-1 text-sm text-stone-500">{{ text }}</p>
    <slot />
    <NuxtLink v-if="backTo" :to="backTo" class="btn-secondary mt-4">{{ backLabel }}</NuxtLink>
  </div>
</template>
