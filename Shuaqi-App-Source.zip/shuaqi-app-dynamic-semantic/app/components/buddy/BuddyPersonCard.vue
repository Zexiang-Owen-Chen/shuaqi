<script setup lang="ts">
export interface BuddyCard {
  id: string
  display_name: string | null
  avatar_url?: string | null
  school_domain?: string | null
  school_verified?: boolean
  connected?: boolean
  is_me?: boolean
  bio?: string | null
  interests?: string[] | null
  gender?: string | null
  age?: number | null
  region?: string | null
}

const props = defineProps<{ card: BuddyCard | null; highlight?: string[]; compact?: boolean }>()

const genderText: Record<string, string> = {
  female: '女', male: '男', non_binary: '非二元', prefer_not_to_say: '不愿透露',
}

const name = computed(() => props.card?.display_name || '同学')
const facts = computed(() => {
  const c = props.card
  if (!c) return []
  const out: string[] = []
  if (c.gender) out.push(genderText[c.gender] ?? c.gender)
  if (c.age != null) out.push(`${c.age} 岁`)
  if (c.region) out.push(c.region)
  return out
})
const isShared = (i: string) => (props.highlight ?? []).some((h) => h.toLowerCase() === i.toLowerCase())
</script>

<template>
  <div v-if="!card" class="flex items-center gap-3 text-sm text-stone-400">
    <div class="h-11 w-11 shrink-0 rounded-full bg-stone-100" />
    对方资料不可见
  </div>
  <div v-else class="flex gap-3">
    <ProfileAvatar :url="card.avatar_url" :name="name" :size="44" />
    <div class="min-w-0 flex-1">
      <div class="flex flex-wrap items-center gap-1.5">
        <span class="truncate font-medium text-stone-900">{{ name }}</span>
        <span v-if="card.is_me" class="text-xs text-stone-400">（我）</span>
        <span v-if="card.school_verified"
              class="rounded-full bg-emerald-50 px-1.5 py-0.5 text-[10px] font-medium text-emerald-700">
          已验证学校{{ card.school_domain ? ` · ${card.school_domain}` : '' }}
        </span>
        <span v-if="card.connected && !card.is_me" class="rounded-full bg-sky-50 px-1.5 py-0.5 text-[10px] text-sky-700">好友</span>
      </div>
      <p v-if="facts.length" class="mt-0.5 text-xs text-stone-500">{{ facts.join(' · ') }}</p>
      <p v-if="!compact && card.bio" class="mt-1 line-clamp-2 text-xs text-stone-600">{{ card.bio }}</p>
      <div v-if="!compact && card.interests?.length" class="mt-1.5 flex flex-wrap gap-1">
        <span v-for="i in card.interests" :key="i" class="chip !py-0.5"
              :class="isShared(i) ? '!bg-brand-50 !text-brand-700' : ''">{{ i }}</span>
      </div>
    </div>
  </div>
</template>
