import { describe, expect, it } from 'vitest'
import {
  csvCell, currentUserId, formatDateTime, formatTime, isoToLocalInput, localInputToIso, toCsv,
} from '../../app/components/organiser/-format'

describe('csvCell', () => {
  it('neutralises spreadsheet formulas (CSV injection)', () => {
    expect(csvCell('=HYPERLINK("http://x","点我")')).toBe(`"'=HYPERLINK(""http://x"",""点我"")"`)
    expect(csvCell('+44 7700 900000')).toBe("'+44 7700 900000")
    expect(csvCell('-1')).toBe("'-1")
    expect(csvCell('@SUM(A1)')).toBe("'@SUM(A1)")
    expect(csvCell('\tcmd')).toBe("'\tcmd")
  })

  it('quotes commas, quotes and newlines', () => {
    expect(csvCell('Smith, Jo')).toBe('"Smith, Jo"')
    expect(csvCell('say "hi"')).toBe('"say ""hi"""')
    expect(csvCell('line1\nline2')).toBe('"line1\nline2"')
  })

  it('empty values and non-strings', () => {
    expect(csvCell(null)).toBe('')
    expect(csvCell(undefined)).toBe('')
    expect(csvCell(0)).toBe('0')
    expect(csvCell(true)).toBe('true')
    expect(csvCell('张三')).toBe('张三')
  })
})

describe('toCsv', () => {
  it('joins header and rows with CRLF', () => {
    expect(toCsv(['姓名', '学校'], [['张三', 'ucl.ac.uk'], ['=1+1', null]]))
      .toBe("姓名,学校\r\n张三,ucl.ac.uk\r\n'=1+1,")
  })
})

describe('formatDateTime / formatTime', () => {
  it('missing values show a dash', () => {
    expect(formatDateTime(null)).toBe('—')
    expect(formatTime(undefined)).toBe('—')
  })

  it('shows London time whatever the browser zone', () => {
    expect(formatTime('2026-10-21T18:00:00Z')).toBe('19:00')
    expect(formatTime('2026-10-30T18:00:00Z')).toBe('18:00')
  })
})

describe('isoToLocalInput / localInputToIso', () => {
  it('empty and invalid values', () => {
    expect(isoToLocalInput(null)).toBe('')
    expect(isoToLocalInput('not a date')).toBe('')
    expect(localInputToIso('')).toBeNull()
    expect(localInputToIso('garbage')).toBeNull()
  })

  it('round-trips', () => {
    const iso = '2026-10-21T18:00:00.000Z'
    expect(localInputToIso(isoToLocalInput(iso))).toBe(iso)
  })

  // Events are in London; the organiser form must read and write London wall-clock time like the
  // core EventForm does (eventFormat.toLondonInput/fromLondonInput), not the browser's zone.
  it('reads the form in London time, not the browser time zone', () => {
    expect(isoToLocalInput('2026-10-21T18:00:00.000Z')).toBe('2026-10-21T19:00')
    expect(localInputToIso('2026-10-21T19:00')).toBe('2026-10-21T18:00:00.000Z')
  })
})

describe('currentUserId', () => {
  it('prefers sub, falls back to id', () => {
    expect(currentUserId({ sub: 'a', id: 'b' })).toBe('a')
    expect(currentUserId({ id: 'b' })).toBe('b')
    expect(currentUserId(null)).toBeNull()
  })
})
