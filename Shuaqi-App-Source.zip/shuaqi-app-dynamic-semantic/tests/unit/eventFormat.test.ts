import { afterEach, describe, expect, it, vi } from 'vitest'
import { currentUid, eventIsOver, formatEventTime, fromLondonInput, toLondonInput } from '../../app/utils/eventFormat'

afterEach(() => { vi.useRealTimers() })

describe('toLondonInput / fromLondonInput', () => {
  it('summer time (BST, UTC+1)', () => {
    expect(toLondonInput('2026-10-21T18:00:00.000Z')).toBe('2026-10-21T19:00')
    expect(fromLondonInput('2026-10-21T19:00')).toBe('2026-10-21T18:00:00.000Z')
  })

  it('winter time (GMT, UTC+0)', () => {
    expect(toLondonInput('2026-10-30T19:00:00.000Z')).toBe('2026-10-30T19:00')
    expect(fromLondonInput('2026-10-30T19:00')).toBe('2026-10-30T19:00:00.000Z')
  })

  it('does not depend on the browser time zone', () => {
    // fromLondonInput only uses Intl with an explicit zone, so the same input always gives the same instant.
    expect(fromLondonInput('2026-12-01T09:30')).toBe('2026-12-01T09:30:00.000Z')
    expect(fromLondonInput('2026-07-01T09:30')).toBe('2026-07-01T08:30:00.000Z')
  })

  it('round-trips every hour around the 25 Oct 2026 clock change', () => {
    // Pilot week straddles the BST -> GMT change at 01:00 UTC on 25 Oct.
    const start = Date.UTC(2026, 9, 24, 20)
    for (let h = 0; h < 12; h++) {
      const iso = new Date(start + h * 3600e3).toISOString()
      const wall = toLondonInput(iso)
      const back = fromLondonInput(wall)!
      // 01:xx happens twice that night; either instant is an acceptable reading of the wall clock.
      if (wall.startsWith('2026-10-25T01:')) {
        expect([iso, new Date(Date.parse(iso) - 3600e3).toISOString(), new Date(Date.parse(iso) + 3600e3).toISOString()])
          .toContain(back)
      } else {
        expect(back).toBe(iso)
      }
    }
  })

  it('round-trips around the 29 Mar 2026 clock change', () => {
    expect(fromLondonInput('2026-03-29T00:30')).toBe('2026-03-29T00:30:00.000Z')
    expect(fromLondonInput('2026-03-29T02:30')).toBe('2026-03-29T01:30:00.000Z')
  })

  it('a wall time skipped by the spring change still yields a valid instant', () => {
    const iso = fromLondonInput('2026-03-29T01:30')!
    expect(Number.isNaN(Date.parse(iso))).toBe(false)
    expect(['2026-03-29T00:30:00.000Z', '2026-03-29T01:30:00.000Z']).toContain(iso)
  })

  it('empty or malformed values', () => {
    expect(toLondonInput(null)).toBe('')
    expect(toLondonInput(undefined)).toBe('')
    expect(toLondonInput('')).toBe('')
    expect(fromLondonInput('')).toBeNull()
    expect(fromLondonInput('2026-10-21')).toBeNull()
    expect(fromLondonInput('tomorrow 7pm')).toBeNull()
  })

  it('ignores seconds on the input', () => {
    expect(fromLondonInput('2026-10-21T19:00:45')).toBe('2026-10-21T18:00:00.000Z')
  })
})

describe('formatEventTime', () => {
  it('same London day shows one date and a time range', () => {
    const s = formatEventTime('2026-10-21T18:00:00Z', '2026-10-21T20:00:00Z')
    expect(s).toContain('10月21日')
    expect(s).toMatch(/19:00–21:00$/)
  })

  it('no end time shows only the start', () => {
    expect(formatEventTime('2026-10-21T18:00:00Z')).toMatch(/10月21日.*19:00$/)
  })

  it('crossing London midnight shows both dates', () => {
    const s = formatEventTime('2026-10-21T21:00:00Z', '2026-10-22T00:30:00Z')
    expect(s).toContain('10月21日')
    expect(s).toContain('10月22日')
    expect(s).toMatch(/22:00 – .*01:30$/)
  })

  it('UTC-same-day but London-next-day is treated as crossing midnight', () => {
    // 23:30 UTC = 00:30 BST next day.
    const s = formatEventTime('2026-10-21T20:00:00Z', '2026-10-21T23:30:00Z')
    expect(s).toContain('10月22日')
  })
})

describe('eventIsOver', () => {
  it('uses ends_at when present', () => {
    vi.useFakeTimers({ now: new Date('2026-10-21T20:00:01Z') })
    expect(eventIsOver({ starts_at: '2026-10-21T18:00:00Z', ends_at: '2026-10-21T20:00:00Z' })).toBe(true)
    expect(eventIsOver({ starts_at: '2026-10-21T18:00:00Z', ends_at: '2026-10-21T21:00:00Z' })).toBe(false)
  })

  it('without ends_at the event lasts 6 hours (same rule as the check-in window)', () => {
    const e = { starts_at: '2026-10-21T18:00:00Z', ends_at: null }
    vi.useFakeTimers({ now: new Date('2026-10-21T23:59:59Z') })
    expect(eventIsOver(e)).toBe(false)
    vi.setSystemTime(new Date('2026-10-22T00:00:01Z'))
    expect(eventIsOver(e)).toBe(true)
  })

  it('an event that has not started is not over', () => {
    vi.useFakeTimers({ now: new Date('2026-10-01T00:00:00Z') })
    expect(eventIsOver({ starts_at: '2026-10-21T18:00:00Z', ends_at: null })).toBe(false)
  })
})

describe('currentUid', () => {
  it('prefers the JWT sub claim, falls back to id', () => {
    expect(currentUid({ sub: 'a', id: 'b' })).toBe('a')
    expect(currentUid({ id: 'b' })).toBe('b')
  })

  it('no user or empty ids give null', () => {
    expect(currentUid(null)).toBeNull()
    expect(currentUid(undefined)).toBeNull()
    expect(currentUid({})).toBeNull()
    expect(currentUid({ sub: '' })).toBeNull()
  })
})
