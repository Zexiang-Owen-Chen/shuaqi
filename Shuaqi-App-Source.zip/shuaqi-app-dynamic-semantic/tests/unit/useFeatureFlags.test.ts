import { describe, expect, it } from 'vitest'
import { FLAG_KEYS, flagOn, toFlagMap } from '../../app/composables/useFeatureFlags'

describe('toFlagMap', () => {
  it('maps rows by key', () => {
    expect(toFlagMap([{ key: 'intents', enabled: false }, { key: 'nearby', enabled: true }]))
      .toEqual({ intents: false, nearby: true })
  })

  it('handles no data', () => {
    expect(toFlagMap(null)).toEqual({})
  })
})

describe('flagOn', () => {
  it('reads the stored value', () => {
    const m = toFlagMap([{ key: 'intents', enabled: false }, { key: 'nearby', enabled: true }])
    expect(flagOn(m, 'intents')).toBe(false)
    expect(flagOn(m, 'nearby')).toBe(true)
  })

  it('treats a missing row as off, like flag_enabled() in the database', () => {
    expect(flagOn({}, 'trust_card')).toBe(false)
  })

  it('shows everything before flags have loaded; the server still enforces them', () => {
    for (const k of FLAG_KEYS) expect(flagOn(null, k)).toBe(true)
  })
})
