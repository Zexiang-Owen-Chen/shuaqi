import { describe, expect, it } from 'vitest'
import { eventImageError, MAX_EVENT_IMAGE_BYTES, MAX_EVENT_IMAGES } from '../../app/utils/eventImages'

describe('event image limits', () => {
  it('accepts the three supported image formats up to 5MB', () => {
    expect(MAX_EVENT_IMAGES).toBe(6)
    for (const type of ['image/png', 'image/jpeg', 'image/webp']) {
      expect(eventImageError({ type, size: MAX_EVENT_IMAGE_BYTES })).toBeNull()
    }
  })
  it('rejects oversized files and unsupported content types', () => {
    expect(eventImageError({ type: 'image/png', size: MAX_EVENT_IMAGE_BYTES + 1 })).toBe('每张图片不能超过 5MB')
    for (const type of ['image/svg+xml', 'text/html', 'application/pdf', '']) {
      expect(eventImageError({ type, size: 100 })).toBe('请选择 JPEG、PNG 或 WebP 图片')
    }
  })
})
