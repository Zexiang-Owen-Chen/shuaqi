import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { ref, toValue } from 'vue'
import { errorText, messageFor } from '../../app/utils/errors'
import { useRpc } from '../../app/composables/useRpc'

// useNearby relies on Nuxt auto-imports; provide them as globals with the real
// useRpc + messageFor so errors travel the same path they do in the app.
type RpcResult = { data?: unknown; error?: { message: string } | null }
let rpcImpl: (name: string, args?: Record<string, unknown>) => RpcResult
let consentRow: { policy_version: string; withdrawn_at: string | null } | null
let positionImpl: () => Promise<{ lat: number; lng: number; accuracy: number }>
const rpcCalls: string[] = []
const mounted: Array<() => void> = []
const unmounted: Array<() => void> = []

const supabase = {
  // Same shape as the Postgrest builder: rpc(...).abortSignal(signal) resolves to { data, error }.
  rpc: (name: string, args?: Record<string, unknown>) => ({
    abortSignal: async () => {
      rpcCalls.push(name)
      const r = rpcImpl(name, args)
      return { data: r.data ?? null, error: r.error ?? null }
    },
  }),
  from: () => ({
    select: () => ({ eq: () => ({ maybeSingle: async () => ({ data: consentRow, error: null }) }) }),
  }),
}

const doc = { visibilityState: 'visible', addEventListener: vi.fn(), removeEventListener: vi.fn() }

vi.stubGlobal('ref', ref)
vi.stubGlobal('toValue', toValue)
vi.stubGlobal('messageFor', messageFor)
vi.stubGlobal('errorText', errorText)
vi.stubGlobal('useSupabaseClient', () => supabase)
vi.stubGlobal('useRpc', useRpc)
vi.stubGlobal('getPosition', () => positionImpl())
vi.stubGlobal('onMounted', (fn: () => void) => mounted.push(fn))
vi.stubGlobal('onBeforeUnmount', (fn: () => void) => unmounted.push(fn))
vi.stubGlobal('document', doc)

const { useNearby, nearbyMessage, NEARBY_POLICY_VERSION } = await import('../../app/composables/useNearby')

const person = (id: string, request_status: string | null = null) => ({
  card: { id, display_name: id, avatar_url: null, school_domain: 'ucl.ac.uk', school_verified: true, connected: false },
  distance_m: 20,
  request_status,
})

beforeEach(() => {
  vi.useFakeTimers()
  rpcCalls.length = 0
  mounted.length = 0
  unmounted.length = 0
  consentRow = null
  positionImpl = async () => ({ lat: 51.5246, lng: -0.1340, accuracy: 12.4 })
  rpcImpl = (name) => (name === 'list_nearby' ? { data: [person('u1')] } : { data: null })
})
afterEach(() => { vi.useRealTimers() })

describe('nearbyMessage', () => {
  it('explains the consent requirement in Chinese', () => {
    expect(nearbyMessage({ message: 'location_consent_required' })).toBe('使用“附近的人”需要先同意使用你的位置')
  })

  it('other codes fall through to messageFor', () => {
    expect(nearbyMessage({ message: 'too_far' })).toBe(errorText.too_far)
    expect(nearbyMessage(new Error('随便什么'))).toBe('随便什么')
  })
})

describe('loadConsent', () => {
  it('no consent row means not consented', async () => {
    const n = useNearby('e1')
    await n.loadConsent()
    expect(n.consented.value).toBe(false)
  })

  it('withdrawn consent is not consent', async () => {
    consentRow = { policy_version: NEARBY_POLICY_VERSION, withdrawn_at: '2026-10-19T10:00:00Z' }
    const n = useNearby('e1')
    await n.loadConsent()
    expect(n.consented.value).toBe(false)
  })

  it('consent to an older policy wording must be asked again', async () => {
    consentRow = { policy_version: '2025-01-v0', withdrawn_at: null }
    const n = useNearby('e1')
    await n.loadConsent()
    expect(n.consented.value).toBe(false)
  })

  it('current, active consent counts', async () => {
    consentRow = { policy_version: NEARBY_POLICY_VERSION, withdrawn_at: null }
    const n = useNearby('e1')
    await n.loadConsent()
    expect(n.consented.value).toBe(true)
  })
})

describe('start / stop', () => {
  it('reports a fix, loads people and then reports every 30 seconds', async () => {
    const n = useNearby('e1')
    await n.start()
    expect(n.active.value).toBe(true)
    expect(n.accuracy.value).toBe(12)
    expect(n.people.value.map(p => p.card.id)).toEqual(['u1'])
    expect(rpcCalls).toEqual(['update_nearby_presence', 'list_nearby'])

    await vi.advanceTimersByTimeAsync(30_000)
    expect(rpcCalls).toEqual(['update_nearby_presence', 'list_nearby', 'update_nearby_presence', 'list_nearby'])
    n.stop()
  })

  it('does not report while the page is hidden', async () => {
    const n = useNearby('e1')
    await n.start()
    doc.visibilityState = 'hidden'
    await vi.advanceTimersByTimeAsync(90_000)
    expect(rpcCalls.filter(c => c === 'update_nearby_presence')).toHaveLength(1)
    doc.visibilityState = 'visible'
    n.stop()
  })

  it('stays off and shows why when the first fix fails', async () => {
    positionImpl = async () => { throw new Error('你拒绝了定位权限，请在浏览器设置中允许后重试') }
    const n = useNearby('e1')
    await n.start()
    expect(n.active.value).toBe(false)
    expect(n.error.value).toContain('拒绝')
    expect(rpcCalls).toEqual([])
    expect(n.busy.value).toBe(false)
  })

  it('stays off when the server rejects the position (e.g. not checked in)', async () => {
    rpcImpl = (name) => (name === 'update_nearby_presence' ? { error: { message: 'not_checked_in' } } : { data: [] })
    const n = useNearby('e1')
    await n.start()
    expect(n.active.value).toBe(false)
    expect(n.error.value).toBe(messageFor('not_checked_in'))
    await vi.advanceTimersByTimeAsync(60_000)
    expect(rpcCalls).toEqual(['update_nearby_presence'])
  })

  it('a double tap starts only once', async () => {
    const n = useNearby('e1')
    await Promise.all([n.start(), n.start()])
    expect(rpcCalls.filter(c => c === 'update_nearby_presence')).toHaveLength(1)
    n.stop()
  })

  it('stop clears the list, stops reporting and tolerates a failed stop_nearby', async () => {
    const n = useNearby('e1')
    await n.start()
    rpcImpl = () => ({ error: { message: 'network' } })
    await n.stop()
    expect(n.active.value).toBe(false)
    expect(n.people.value).toEqual([])
    const before = rpcCalls.length
    await vi.advanceTimersByTimeAsync(60_000)
    expect(rpcCalls.length).toBe(before)
  })

  it('leaving the page while on deletes the position', async () => {
    const n = useNearby('e1')
    await n.start()
    unmounted.forEach(fn => fn())
    await vi.advanceTimersByTimeAsync(0)
    expect(rpcCalls.at(-1)).toBe('stop_nearby')
  })
})

describe('consent withdrawn while running', () => {
  // The server raises location_consent_required when consent was withdrawn on another device
  // or NEARBY_POLICY_VERSION changed. The page must stop polling and show the consent step again.
  it('stops reporting and asks for consent again', async () => {
    consentRow = { policy_version: NEARBY_POLICY_VERSION, withdrawn_at: null }
    const n = useNearby('e1')
    await n.loadConsent()
    await n.start()
    rpcImpl = (name) => (name === 'update_nearby_presence' ? { error: { message: 'location_consent_required' } } : { data: [] })
    await vi.advanceTimersByTimeAsync(30_000)
    expect(n.error.value).toBe('使用“附近的人”需要先同意使用你的位置')
    expect(n.consented.value).toBe(false)
    expect(n.active.value).toBe(false)
    const before = rpcCalls.length
    await vi.advanceTimersByTimeAsync(60_000)
    expect(rpcCalls.length).toBe(before)
  })
})

describe('connect', () => {
  it('marks the person as pending after sending a nearby request', async () => {
    const n = useNearby('e1')
    await n.start()
    let args: Record<string, unknown> | undefined
    rpcImpl = (name, a) => { if (name === 'send_connection_request') args = a; return { data: null } }
    await n.connect('u1')
    expect(args).toMatchObject({ p_to: 'u1', p_context: 'nearby', p_context_id: 'e1' })
    expect(n.people.value[0]!.request_status).toBe('pending')
    n.stop()
  })

  it('a failed request leaves the status unchanged and throws readable text', async () => {
    const n = useNearby('e1')
    await n.start()
    rpcImpl = (name) => (name === 'send_connection_request' ? { error: { message: 'too_far' } } : { data: [] })
    await expect(n.connect('u1')).rejects.toThrow(errorText.too_far)
    expect(n.people.value[0]!.request_status).toBeNull()
    n.stop()
  })
})

describe('without an event (add friends nearby)', () => {
  it('uses the open presence functions and sends requests without a context id', async () => {
    rpcImpl = (name) => (name === 'list_open_nearby' ? { data: [person('u2')] } : { data: null })
    const n = useNearby(null)
    await n.start()
    expect(rpcCalls).toEqual(['update_open_presence', 'list_open_nearby'])
    expect(n.people.value.map(p => p.card.id)).toEqual(['u2'])

    let args: Record<string, unknown> | undefined
    rpcImpl = (name, a) => { if (name === 'send_connection_request') args = a; return { data: null } }
    await n.connect('u2')
    expect(args).toMatchObject({ p_to: 'u2', p_context: 'nearby' })
    expect(args?.p_context_id).toBeUndefined()

    await n.stop()
    expect(rpcCalls.at(-1)).toBe('stop_open_presence')
  })
})
