import { describe, expect, it } from 'vitest'
import { buildExpansion, conflictsWithSport, expansionScore, matchesExclusion } from '../../server/utils/reco/expansion'
import { haystack } from '../../server/utils/reco/text'
import { rank } from '../../server/utils/reco/score'
import { EMPTY_QUERY, type Candidate } from '../../server/utils/reco/types'

const expansion = (raw: string, interests: string[] = [], ai: unknown = []) => buildExpansion(raw, EMPTY_QUERY, interests, ai)
describe('semantic activity expansion', () => {
  it('finds badminton, tennis and table tennis from ambiguous doubles without requiring all aliases', () => {
    const e = expansion('双打')
    expect(e.ambiguous).toBe(true)
    for (const title of ['羽毛球三缺一', 'Tennis club', 'Table tennis meetup']) expect(expansionScore(title, e)).toBeGreaterThan(0)
    expect(expansionScore('Chemistry revision', e)).toBe(0)
  })
  it('supports bilingual sport synonyms and pickup language', () => {
    expect(expansionScore('Badminton evening', expansion('羽毛球'))).toBeGreaterThan(.9)
    expect(expansionScore('羽毛球补位', expansion('badminton'))).toBeGreaterThan(.9)
    expect(expansionScore('one more player', expansion('找球友'))).toBeGreaterThan(0)
  })
  it('does not assume that table tennis means lawn tennis', () => {
    const e = expansion('table tennis doubles')
    expect(e.explicitSports).toEqual(['乒乓球'])
    expect(conflictsWithSport('Tennis doubles', e)).toBe(true)
    expect(conflictsWithSport('乒乓球局', e)).toBe(false)
  })
  it('explicit sport overrides a different stated interest and AI suggestion', () => {
    const e = expansion('网球双打', ['羽毛球'], ['badminton', 'tennis'])
    expect(e.ambiguous).toBe(false)
    expect(e.groups.flatMap(g => g.terms)).not.toContain('badminton')
    expect(conflictsWithSport('羽毛球双打', e)).toBe(true)
  })
  it('interests softly prioritize ambiguous possibilities without removing alternatives', () => {
    const e = expansion('doubles', ['羽毛球'])
    expect(expansionScore('Badminton club', e)).toBeGreaterThan(expansionScore('Tennis club', e)!)
    expect(expansionScore('Tennis club', e)).toBeGreaterThan(0)
  })
  it('expands explicit exclusions across languages', () => {
    const e = buildExpansion('双打，不要网球', { ...EMPTY_QUERY, exclude: ['网球'] }, [], ['tennis', 'badminton'])
    expect(e.excluded).toContain('tennis')
    expect(e.groups.flatMap(g => g.terms)).not.toContain('tennis')
  })
  it('excluding tennis does not accidentally exclude table tennis', () => {
    expect(matchesExclusion(haystack('Table tennis doubles'), 'tennis')).toBe(false)
    expect(matchesExclusion(haystack('Table tennis and tennis'), 'tennis')).toBe(true)
  })
  it('bounds and validates untrusted model suggestions', () => {
    const e = expansion('meet people', [], [null, {}, 4, '', 'x'.repeat(100), ...Array.from({ length: 40 }, (_, i) => `term${i}`)])
    expect(e.groups.flatMap(g => g.terms)).toHaveLength(12)
    expect(e.embeddingText.length).toBeLessThanOrEqual(1500)
    expect(e.excluded).toEqual([])
  })
  it('handles absent or unavailable model output with the same deterministic fallback', () => {
    expect(expansion('双打', [], null)).toEqual(expansion('双打', [], []))
    expect(expansion('', [], [])).toMatchObject({ groups: [], ambiguous: false })
  })
  it('applies expanded exclusions and explicit sport guards in the actual ranking', () => {
    const c: Candidate = { id: 'badminton', title: 'Badminton doubles', description: '', category: '运动',
      starts_at: '2026-10-28T12:00:00Z', ends_at: null, location_text: 'London', location_lat: null,
      location_lng: null, capacity: null, going: 0, org_verified: false, embedding_hash: null, similarity: null }
    const input = { candidates: [c, { ...c, id: 'tennis', title: 'Tennis doubles' }],
      query: { ...EMPTY_QUERY }, interests: [], signals: [], origin: null, hasQueryEmbedding: false,
      now: new Date('2026-10-27T12:00:00Z'), limit: 20 }
    expect(rank({ ...input, expansion: expansion('网球双打') }).ranked.map(r => r.candidate.id)).toEqual(['tennis'])
    const q = { ...EMPTY_QUERY, exclude: ['网球'] }
    expect(rank({ ...input, query: q, expansion: buildExpansion('双打，不要网球', q, []) }).ranked.map(r => r.candidate.id)).toEqual(['badminton'])
  })
})
