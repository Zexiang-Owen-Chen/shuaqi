import { describe, expect, it } from 'vitest'
import { Constants } from '../../app/types/database.types'
import { CHECKIN_MODE_LABEL, EVENT_STATUS_LABEL } from '../../app/utils/eventFormat'
import { EVIDENCE_TYPE_TEXT, VERIFICATION_TEXT } from '../../app/components/organiser/-format'

// Every database enum value shown to users needs Chinese text; a new enum value without a label
// would otherwise show up as a raw code like "geo_verified".
const enums = Constants.public.Enums

describe('labels cover every enum value', () => {
  it.each([
    ['checkin_mode', CHECKIN_MODE_LABEL, enums.checkin_mode],
    ['event_status', EVENT_STATUS_LABEL, enums.event_status],
    ['evidence_type', EVIDENCE_TYPE_TEXT, enums.evidence_type],
    ['verification_status', VERIFICATION_TEXT, enums.verification_status],
  ] as const)('%s', (_name, labels, values) => {
    expect(Object.keys(labels).sort()).toEqual([...values].sort())
  })
})
