import { afterEach, describe, expect, it, vi } from 'vitest'
import { messageFor } from '../../app/utils/errors'

// A builder whose request only ends when its signal aborts, like a fetch on a dead connection.
const hanging = {
  rpc: () => ({
    abortSignal: (signal: AbortSignal) => new Promise((resolve) => {
      signal.addEventListener('abort', () => resolve({ data: null, error: { message: 'AbortError: The operation was aborted.', code: '' } }))
    }),
  }),
}
const failing = {
  rpc: () => ({ abortSignal: async () => ({ data: null, error: { message: 'event_full', code: 'P0001' } }) }),
}

let client: unknown
vi.stubGlobal('useSupabaseClient', () => client)
vi.stubGlobal('messageFor', messageFor)
const { useRpc, RPC_TIMEOUT_MS, RPC_TIMEOUT_MESSAGE } = await import('../../app/composables/useRpc')

afterEach(() => { vi.useRealTimers() })

describe('useRpc', () => {
  it('gives up on a request that never answers and says the network timed out', async () => {
    vi.useFakeTimers()
    client = hanging
    const p = useRpc()('join_event' as never, { p_event: 'e1' } as never)
    const check = expect(p).rejects.toThrow(RPC_TIMEOUT_MESSAGE)
    await vi.advanceTimersByTimeAsync(RPC_TIMEOUT_MS + 10)
    await check
  })

  it('still maps server errors to readable text', async () => {
    client = failing
    await expect(useRpc()('join_event' as never, { p_event: 'e1' } as never)).rejects.toThrow(messageFor({ message: 'event_full', code: 'P0001' }))
  })
})
