import { describe, expect, it } from 'vitest'
import { outcomeFor, rowOutcome, safePath, sameSecret, toPushMessage } from '../../server/utils/push/payload'
import { pushSupport, sameKey, urlBase64ToUint8Array } from '../../app/composables/usePush'
import type { PwaPlatform } from '../../app/composables/useInstallPrompt'

const caps = { serviceWorker: true, pushManager: true, notification: true }
const none = { serviceWorker: true, pushManager: false, notification: false }
const p = (o: Partial<PwaPlatform>): PwaPlatform => ({ os: 'android', browser: 'chromium', safariVersion: null, standalone: false, ...o })

describe('pushSupport', () => {
  it('Android and desktop browsers can subscribe in the browser', () => {
    expect(pushSupport(p({}), caps)).toBe('supported')
    expect(pushSupport(p({ os: 'desktop', browser: 'firefox' }), caps)).toBe('supported')
  })

  it('iPhone in Safari must add to home screen first', () => {
    expect(pushSupport(p({ os: 'ios', browser: 'safari' }), none)).toBe('needs-install')
    expect(pushSupport(p({ os: 'ios', browser: 'ios-other' }), caps)).toBe('needs-install')
  })

  it('iPhone home-screen app works on iOS 16.4+, and says so when too old', () => {
    expect(pushSupport(p({ os: 'ios', browser: 'safari', standalone: true }), caps)).toBe('supported')
    expect(pushSupport(p({ os: 'ios', browser: 'safari', standalone: true }), none)).toBe('ios-too-old')
  })

  it('never offers notifications inside WeChat or other in-app browsers', () => {
    expect(pushSupport(p({ browser: 'wechat' }), caps)).toBe('in-app')
    expect(pushSupport(p({ os: 'ios', browser: 'inapp' }), caps)).toBe('in-app')
  })

  it('browsers without push are unsupported', () => {
    expect(pushSupport(p({ browser: 'other' }), none)).toBe('unsupported')
  })
})

describe('VAPID key helpers', () => {
  it('decodes base64url', () => {
    expect([...urlBase64ToUint8Array('AQID_-8')]).toEqual([1, 2, 3, 255, 239])
  })

  it('compares an existing subscription key', () => {
    const k = urlBase64ToUint8Array('AQID')
    expect(sameKey(new Uint8Array([1, 2, 3]).buffer, k)).toBe(true)
    expect(sameKey(new Uint8Array([1, 2, 4]).buffer, k)).toBe(false)
    expect(sameKey(null, k)).toBe(false)
  })
})

describe('toPushMessage', () => {
  it('passes a single notification through', () => {
    expect(toPushMessage({ title: 'Alice', body: 'Hi', url: '/messages/1', tag: 'msg:1', count: 1 }))
      .toEqual({ title: 'Alice', body: 'Hi', url: '/messages/1', tag: 'msg:1' })
  })

  it('shows how many chat messages were merged', () => {
    expect(toPushMessage({ title: 'Alice', body: 'Hi', count: 3 }).body).toBe('[3 条] Hi')
  })

  it('only ever links inside the app', () => {
    expect(safePath('https://evil.example')).toBe('/')
    expect(safePath('//evil.example')).toBe('/')
    expect(safePath('/\\evil.example')).toBe('/')
    expect(toPushMessage({ title: 'x' }).url).toBe('/')
  })

  it('falls back to a title', () => {
    expect(toPushMessage({}).title).toBe('SHUAQI')
  })
})

describe('delivery outcomes', () => {
  it('classifies push service responses', () => {
    expect(outcomeFor(201)).toBe('ok')
    expect(outcomeFor(410)).toBe('gone')
    expect(outcomeFor(404)).toBe('gone')
    expect(outcomeFor(429)).toBe('retry')
    expect(outcomeFor(503)).toBe('retry')
    expect(outcomeFor(undefined)).toBe('retry')
    expect(outcomeFor(400)).toBe('drop')
  })

  it('a row is done once any device took it, retried only when worth it', () => {
    expect(rowOutcome(['gone', 'ok'])).toBe('done')
    expect(rowOutcome(['gone', 'retry'])).toBe('retry')
    expect(rowOutcome(['gone', 'drop'])).toBe('done')
    expect(rowOutcome([])).toBe('done')
  })
})

describe('sameSecret', () => {
  it('matches only the exact secret', () => {
    expect(sameSecret('abc', 'abc')).toBe(true)
    expect(sameSecret('abc', 'abd')).toBe(false)
    expect(sameSecret('', '')).toBe(false)
    expect(sameSecret('abc', 'abcd')).toBe(false)
  })
})
