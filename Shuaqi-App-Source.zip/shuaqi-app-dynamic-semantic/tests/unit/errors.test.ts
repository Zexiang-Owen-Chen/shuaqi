import { describe, expect, it } from 'vitest'
import { errorText, messageFor } from '../../app/utils/errors'

describe('messageFor', () => {
  it('maps database error codes to Chinese text', () => {
    expect(messageFor({ message: 'event_full' })).toBe(errorText.event_full)
    expect(messageFor('too_far')).toBe(errorText.too_far)
  })

  it('explains the school e-mail gate when auth wraps the trigger error', () => {
    expect(messageFor({ message: 'Database error saving new user' })).toBe(errorText.school_email_required)
  })

  it('falls back to the raw message or a generic one', () => {
    expect(messageFor({ message: 'something else' })).toBe('something else')
    expect(messageFor(undefined)).toBe('出了点问题，请稍后再试')
  })
})
