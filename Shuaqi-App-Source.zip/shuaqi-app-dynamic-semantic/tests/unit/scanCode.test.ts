import { describe, expect, it } from 'vitest'
import { parseCheckinCode } from '../../app/utils/scanCode'

describe('parseCheckinCode', () => {
  it('reads the code from an event QR link on any SHUAQI host', () => {
    expect(parseCheckinCode('https://shuaqi-app.vercel.app/checkin/0123456789abcdef0123456789abcdef'))
      .toBe('0123456789abcdef0123456789abcdef')
    expect(parseCheckinCode('http://localhost:3000/checkin/seed-live-boardgames/')).toBe('seed-live-boardgames')
    expect(parseCheckinCode('  https://example.org/checkin/abcd1234?utm=x  ')).toBe('abcd1234')
  })

  it('accepts a bare code', () => {
    expect(parseCheckinCode('seed-lse-networking')).toBe('seed-lse-networking')
  })

  it('rejects anything that is not a check-in link', () => {
    expect(parseCheckinCode('')).toBeNull()
    expect(parseCheckinCode('https://evil.example/login')).toBeNull()
    expect(parseCheckinCode('https://shuaqi-app.vercel.app/events/123')).toBeNull()
    expect(parseCheckinCode('https://x.test/checkin/a/b')).toBeNull()
    expect(parseCheckinCode('javascript:alert(1)')).toBeNull()
    expect(parseCheckinCode('https://x.test/checkin/%3Cscript%3E')).toBeNull()
    expect(parseCheckinCode('hello world')).toBeNull()
  })
})
