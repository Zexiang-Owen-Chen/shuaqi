import { describe, expect, it, vi } from 'vitest'

vi.stubGlobal('useRuntimeConfig', () => ({ public: { supabase: { url: 'https://abc.supabase.co' } } }))
const { genderLabel, publicUrl, SCHOOL_NAMES, SCOPES, VISIBILITY_FIELDS } = await import('../../app/utils/profile')

describe('genderLabel', () => {
  it('maps known values and hides unknown ones', () => {
    expect(genderLabel('female')).toBe('女')
    expect(genderLabel('prefer_not_to_say')).toBe('不透露')
    expect(genderLabel(null)).toBe('')
    expect(genderLabel('other')).toBe('')
  })
})

describe('publicUrl', () => {
  it('builds a public storage URL from a path', () => {
    expect(publicUrl('avatars', 'u1/a.jpg')).toBe('https://abc.supabase.co/storage/v1/object/public/avatars/u1/a.jpg')
  })

  it('keeps full URLs and empty paths as they are', () => {
    expect(publicUrl('photos', 'https://cdn.example/p.jpg')).toBe('https://cdn.example/p.jpg')
    expect(publicUrl('photos', null)).toBe('')
    expect(publicUrl('photos', '')).toBe('')
  })
})

describe('profile constants', () => {
  it('lists the G5 schools, KCL and UAL', () => {
    expect(Object.keys(SCHOOL_NAMES).sort()).toEqual(['cam.ac.uk', 'imperial.ac.uk', 'kcl.ac.uk', 'lse.ac.uk', 'ox.ac.uk', 'ual.ac.uk', 'ucl.ac.uk'])
    expect(SCHOOL_NAMES['kcl.ac.uk']).toBe('伦敦国王学院')
    expect(SCHOOL_NAMES['ual.ac.uk']).toBe('伦敦艺术大学')
  })

  it('visibility scopes and fields match the database values', () => {
    // profiles.visibility jsonb: public | connections | hidden per field (core_schema.sql).
    expect(SCOPES.map(s => s.value)).toEqual(['public', 'connections', 'hidden'])
    expect(VISIBILITY_FIELDS.map(f => f.key)).toEqual(['bio', 'interests', 'photos', 'gender', 'age'])
  })
})
