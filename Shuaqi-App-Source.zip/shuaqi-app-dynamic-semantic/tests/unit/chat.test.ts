import { describe, expect, it } from 'vitest'
import { formatChatTime, formatDividerTime, mergeMessages, showTimeDivider, unreadLabel } from '../../app/utils/chat'

const msg = (id: string, created_at: string, sender_id = 'a') => ({ id, sender_id, body: id, created_at })

describe('mergeMessages', () => {
  it('adds new messages in time order without duplicates', () => {
    const list = [msg('1', '2026-10-19T10:00:00+00:00'), msg('3', '2026-10-19T10:02:00+00:00')]
    const merged = mergeMessages(list, [msg('2', '2026-10-19T10:01:00+00:00'), msg('3', '2026-10-19T10:02:00+00:00')])
    expect(merged.map(m => m.id)).toEqual(['1', '2', '3'])
  })

  it('orders Realtime and REST timestamp formats together', () => {
    const merged = mergeMessages([msg('b', '2026-10-19T10:00:01.5+00:00')], [msg('a', '2026-10-19 10:00:01Z')])
    expect(merged.map(m => m.id)).toEqual(['a', 'b'])
  })

  it('reverses a newest-first page', () => {
    const page = [msg('2', '2026-10-19T10:01:00Z'), msg('1', '2026-10-19T10:00:00Z')]
    expect(mergeMessages([], page).map(m => m.id)).toEqual(['1', '2'])
  })
})

describe('formatChatTime (London time)', () => {
  const now = new Date('2026-10-19T15:00:00Z') // Monday 16:00 BST
  it('shows the clock for today', () => expect(formatChatTime('2026-10-19T08:05:00Z', now)).toBe('09:05'))
  it('shows 昨天 for yesterday', () => expect(formatChatTime('2026-10-18T20:00:00Z', now)).toBe('昨天'))
  it('shows the weekday within a week', () => expect(formatChatTime('2026-10-15T12:00:00Z', now)).toBe('周四'))
  it('shows the date after a week', () => expect(formatChatTime('2026-10-01T12:00:00Z', now)).toBe('10月1日'))
  it('uses the London day, not UTC', () => {
    // 23:30 UTC on the 18th is 00:30 BST on the 19th: today.
    expect(formatChatTime('2026-10-18T23:30:00Z', now)).toBe('00:30')
  })
  it('divider adds the clock to older days', () => expect(formatDividerTime('2026-10-18T20:00:00Z', now)).toBe('昨天 21:00'))
})

describe('showTimeDivider', () => {
  it('shows before the first message and after a 5-minute gap', () => {
    const a = msg('1', '2026-10-19T10:00:00Z')
    expect(showTimeDivider(undefined, a)).toBe(true)
    expect(showTimeDivider(a, msg('2', '2026-10-19T10:04:59Z'))).toBe(false)
    expect(showTimeDivider(a, msg('3', '2026-10-19T10:05:00Z'))).toBe(true)
  })
})

it('caps the unread label', () => {
  expect(unreadLabel(7)).toBe('7')
  expect(unreadLabel(120)).toBe('99+')
})
