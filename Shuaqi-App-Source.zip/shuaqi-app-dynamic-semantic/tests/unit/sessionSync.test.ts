import { describe, expect, it, vi } from 'vitest'
import { createSessionSync } from '../../app/utils/sessionSync'

const fixture = () => {
  const session = { account: 'a' }, claims = { sub: 'a' }
  const client = { auth: {
    getSession: vi.fn(async () => ({ data: { session: session as typeof session | null }, error: null as unknown })),
    getClaims: vi.fn(async () => ({ data: { claims } as { claims: typeof claims } | null, error: null as unknown })),
  } }
  const apply = vi.fn()
  return { session, claims, client, apply, sync: createSessionSync(client, apply) }
}

describe('session reconciliation', () => {
  it('uses current storage and verified claims together', async () => {
    const f = fixture()
    expect(await f.sync()).toBe(true)
    expect(f.apply).toHaveBeenCalledWith(f.session, f.claims)
  })
  it('clears confirmed signed-out state without requesting claims', async () => {
    const f = fixture()
    f.client.auth.getSession.mockResolvedValueOnce({ data: { session: null }, error: null })
    expect(await f.sync()).toBe(true)
    expect(f.apply).toHaveBeenCalledWith(null, null)
    expect(f.client.auth.getClaims).not.toHaveBeenCalled()
  })
  it('preserves state on network failure or unverified claims, then allows retry', async () => {
    const f = fixture()
    f.client.auth.getSession.mockRejectedValueOnce(new Error('offline'))
    expect(await f.sync()).toBe(false)
    f.client.auth.getClaims.mockResolvedValueOnce({ data: null, error: { code: 'network' } })
    expect(await f.sync()).toBe(false)
    expect(f.apply).not.toHaveBeenCalled()
    expect(await f.sync()).toBe(true)
    expect(f.apply).toHaveBeenCalledTimes(1)
  })
  it('coalesces concurrent resume events into a single read', async () => {
    const f = fixture()
    let release!: () => void
    const gate = new Promise<void>(resolve => { release = resolve })
    f.client.auth.getSession.mockImplementationOnce(async () => { await gate; return { data: { session: f.session }, error: null } })
    const first = f.sync(), second = f.sync()
    expect(first === second).toBe(true)
    release()
    await Promise.all([first, second])
    expect(f.client.auth.getSession).toHaveBeenCalledTimes(1)
    expect(f.apply).toHaveBeenCalledTimes(1)
  })
})
