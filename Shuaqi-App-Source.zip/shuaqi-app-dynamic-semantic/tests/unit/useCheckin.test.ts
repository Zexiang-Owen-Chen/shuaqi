import { describe, expect, it } from 'vitest'
import { bestFix, checkinWindow, describeCheckin, formatDistance, isWeChat } from '../../app/composables/useCheckin'

const fix = (accuracy: number) => ({ lat: 51.5, lng: -0.12, accuracy })

describe('bestFix', () => {
  it('stops at the first good fix', async () => {
    let calls = 0
    const r = await bestFix(async () => { calls++; return fix(20) })
    expect(r.accuracy).toBe(20)
    expect(calls).toBe(1)
  })

  it('keeps the most accurate of several poor fixes', async () => {
    const seq = [300, 120, 180]
    const r = await bestFix(async () => fix(seq.shift()!))
    expect(r.accuracy).toBe(120)
  })

  it('retries after a failed first attempt', async () => {
    const seq: Array<number | Error> = [new Error('定位超时，请重试'), 40]
    const r = await bestFix(async () => {
      const v = seq.shift()!
      if (v instanceof Error) throw v
      return fix(v)
    })
    expect(r.accuracy).toBe(40)
  })

  it('keeps the fix it has when a retry fails', async () => {
    const seq: Array<number | Error> = [150, new Error('定位超时，请重试'), 40]
    const attempts: number[] = []
    const r = await bestFix(async (i) => {
      attempts.push(i)
      const v = seq.shift()!
      if (v instanceof Error) throw v
      return fix(v)
    })
    expect(r.accuracy).toBe(150)
    expect(attempts).toEqual([0, 1])
  })

  it('does not retry after permission is denied', async () => {
    let calls = 0
    await expect(bestFix(async () => { calls++; throw new Error('你拒绝了定位权限，请在浏览器设置中允许后重试') }))
      .rejects.toThrow('拒绝')
    expect(calls).toBe(1)
  })
})

describe('describeCheckin', () => {
  it('success and repeat scans', () => {
    expect(describeCheckin({ ok: true, already: false, status: 'geo_verified' }).title).toBe('签到成功')
    const again = describeCheckin({ ok: true, already: true, status: 'geo_verified' })
    expect(again.title).toBe('你已经签到过了')
    expect(again.detail).toBe('已到场（定位核验）')
  })

  it('too far shows distance and radius, and allows retry', () => {
    const m = describeCheckin({ ok: false, reason: 'too_far', distance_m: 1530 }, 150)
    expect(m.detail).toContain('1.5 公里')
    expect(m.detail).toContain('150 米')
    expect(m.retry).toBe(true)
  })

  it('inaccurate location shows the accuracy', () => {
    const m = describeCheckin({ ok: false, reason: 'location_inaccurate', accuracy_m: 164.4 })
    expect(m.detail).toContain('164 米')
  })

  it('outside window shows London times and no retry', () => {
    const m = describeCheckin({
      ok: false, reason: 'outside_window',
      opens_at: '2026-10-30T18:00:00Z', closes_at: '2026-10-30T23:00:00Z',
    })
    expect(m.retry).toBe(false)
    expect(m.detail).toContain('18:00')
  })

  it('unknown reason falls back', () => {
    expect(describeCheckin({ ok: false }).title).toBe('签到失败')
  })
})

describe('checkinWindow', () => {
  it('defaults to one hour before start until the end', () => {
    const w = checkinWindow({ starts_at: '2026-10-30T19:00:00Z', ends_at: '2026-10-30T23:00:00Z' })
    expect(w.opensAt.toISOString()).toBe('2026-10-30T18:00:00.000Z')
    expect(w.closesAt.toISOString()).toBe('2026-10-30T23:00:00.000Z')
  })

  it('without an end time closes six hours after start', () => {
    const w = checkinWindow({ starts_at: '2026-10-30T19:00:00Z' })
    expect(w.closesAt.toISOString()).toBe('2026-10-31T01:00:00.000Z')
  })

  it('event overrides win', () => {
    const w = checkinWindow({
      starts_at: '2026-10-30T19:00:00Z',
      checkin_opens_at: '2026-10-30T18:30:00Z',
      checkin_closes_at: '2026-10-30T20:00:00Z',
    })
    expect(w.opensAt.toISOString()).toBe('2026-10-30T18:30:00.000Z')
    expect(w.closesAt.toISOString()).toBe('2026-10-30T20:00:00.000Z')
  })
})

describe('small helpers', () => {
  it('formatDistance', () => {
    expect(formatDistance(87.6)).toBe('88 米')
    expect(formatDistance(2400)).toBe('2.4 公里')
  })
  it('isWeChat', () => {
    expect(isWeChat('Mozilla/5.0 (iPhone) MicroMessenger/8.0.50')).toBe(true)
    expect(isWeChat('Mozilla/5.0 (iPhone) Safari/604.1')).toBe(false)
  })
})

describe('bestFix when the location request stalls', () => {
  it('gives up after one stalled attempt instead of retrying', async () => {
    const { STALLED_MESSAGE } = await import('../../app/composables/useGeo')
    let calls = 0
    await expect(bestFix(async () => { calls++; throw new Error(STALLED_MESSAGE) })).rejects.toThrow(STALLED_MESSAGE)
    expect(calls).toBe(1)
  })
})
