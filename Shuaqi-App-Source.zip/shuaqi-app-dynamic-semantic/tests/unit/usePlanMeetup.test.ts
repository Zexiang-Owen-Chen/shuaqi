import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { ref, toValue } from 'vue'
import { errorText, messageFor } from '../../app/utils/errors'
import { useRpc } from '../../app/composables/useRpc'

// usePlanMeetup relies on Nuxt auto-imports; provide them as globals with the real
// useRpc + messageFor so errors travel the same path they do in the app.
type RpcResult = { data?: unknown; error?: { message: string } | null }
let rpcImpl: (name: string, args?: Record<string, unknown>) => RpcResult
let consentRow: { policy_version: string; withdrawn_at: string | null } | null
let positionImpl: () => Promise<{ lat: number; lng: number; accuracy: number }>
const rpcCalls: string[] = []
const mounted: Array<() => void> = []
const unmounted: Array<() => void> = []

const supabase = {
  // Same shape as the Postgrest builder: rpc(...).abortSignal(signal) resolves to { data, error }.
  rpc: (name: string, args?: Record<string, unknown>) => ({
    abortSignal: async () => {
      rpcCalls.push(name)
      const r = rpcImpl(name, args)
      return { data: r.data ?? null, error: r.error ?? null }
    },
  }),
  from: () => ({
    select: () => ({ eq: () => ({ maybeSingle: async () => ({ data: consentRow, error: null }) }) }),
  }),
}

const doc = { visibilityState: 'visible', addEventListener: vi.fn(), removeEventListener: vi.fn() }

vi.stubGlobal('ref', ref)
vi.stubGlobal('toValue', toValue)
vi.stubGlobal('messageFor', messageFor)
vi.stubGlobal('errorText', errorText)
vi.stubGlobal('useSupabaseClient', () => supabase)
vi.stubGlobal('useRpc', useRpc)
vi.stubGlobal('getPosition', () => positionImpl())
vi.stubGlobal('onMounted', (fn: () => void) => mounted.push(fn))
vi.stubGlobal('onBeforeUnmount', (fn: () => void) => unmounted.push(fn))
vi.stubGlobal('document', doc)

const nearbyMod = await import('../../app/composables/useNearby')
vi.stubGlobal('useLocationConsent', nearbyMod.useLocationConsent)
vi.stubGlobal('nearbyMessage', nearbyMod.nearbyMessage)
vi.stubGlobal('isConsentError', nearbyMod.isConsentError)
const { usePlanMeetup } = await import('../../app/composables/usePlanMeetup')



beforeEach(() => {
  vi.useFakeTimers()
  rpcCalls.length = 0
  unmounted.length = 0
  consentRow = null
  positionImpl = async () => ({ lat: 51.5226, lng: -0.1257, accuracy: 9.6 })
})
afterEach(() => { vi.useRealTimers() })

describe('usePlanMeetup', () => {
  it('waits for the other person, then reports when they are within 50 m', async () => {
    rpcImpl = () => ({ data: { nearby: false, distance_m: null } })
    const m = usePlanMeetup('p1')
    await m.start()
    expect(m.active.value).toBe(true)
    expect(m.nearby.value).toBe(false)
    expect(m.accuracy.value).toBe(10)

    rpcImpl = () => ({ data: { nearby: true, distance_m: 30 } })
    await vi.advanceTimersByTimeAsync(30_000)
    expect(m.nearby.value).toBe(true)
    expect(m.distance.value).toBe(30)
    expect(rpcCalls).toEqual(['update_plan_presence', 'update_plan_presence'])
    await m.stop()
    expect(rpcCalls.at(-1)).toBe('stop_plan_presence')
  })

  it('stays off and explains when it is too early', async () => {
    rpcImpl = () => ({ error: { message: 'meetup_not_open' } })
    const m = usePlanMeetup('p1')
    await m.start()
    expect(m.active.value).toBe(false)
    expect(m.error.value).toBe(errorText.meetup_not_open)
  })

  it('asks for consent again when the server says consent is missing', async () => {
    consentRow = { policy_version: nearbyMod.NEARBY_POLICY_VERSION, withdrawn_at: null }
    rpcImpl = () => ({ data: { nearby: false } })
    const m = usePlanMeetup('p1')
    await m.loadConsent()
    await m.start()
    rpcImpl = () => ({ error: { message: 'location_consent_required' } })
    await vi.advanceTimersByTimeAsync(30_000)
    expect(m.consented.value).toBe(false)
    expect(m.active.value).toBe(false)
  })

  it('leaving the page while on deletes the position', async () => {
    rpcImpl = () => ({ data: { nearby: false } })
    const m = usePlanMeetup('p1')
    await m.start()
    unmounted.forEach(fn => fn())
    await vi.advanceTimersByTimeAsync(0)
    expect(rpcCalls.at(-1)).toBe('stop_plan_presence')
  })
})
