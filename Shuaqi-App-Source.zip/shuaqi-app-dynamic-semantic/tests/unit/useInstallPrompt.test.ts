import { describe, expect, it } from 'vitest'
import { detectPlatform, guideKind, installGuide } from '../../app/composables/useInstallPrompt'

const UA = {
  iphoneSafari26: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1',
  iphoneSafari17: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1',
  iphoneChrome: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/141.0.7390.41 Mobile/15E148 Safari/604.1',
  ipadOs: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Safari/605.1.15',
  macSafari: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Safari/605.1.15',
  androidChrome: 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36',
  androidSamsung: 'Mozilla/5.0 (Linux; Android 14; SM-S921B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/28.0 Chrome/130.0.0.0 Mobile Safari/537.36',
  androidFirefox: 'Mozilla/5.0 (Android 14; Mobile; rv:143.0) Gecko/143.0 Firefox/143.0',
  wechatIos: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 MicroMessenger/8.0.61(0x18003d2e) NetType/WIFI Language/zh_CN',
  wechatAndroid: 'Mozilla/5.0 (Linux; Android 14; 23127PN0CC Build/UKQ1.230804.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/130.0.6723.103 Mobile Safari/537.36 XWEB/1300289 MMWEBSDK/20241103 MMWEBID/1234 MicroMessenger/8.0.55.2780(0x28003737) WeChat/arm64 Weixin NetType/WIFI Language/zh_CN ABI/arm64',
  instagram: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 Instagram 400.0.0.0.0 (iPhone15,2; iOS 18_6; en_GB; en-GB; scale=3.00; 1179x2556; 0)',
  desktopChrome: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',
}

describe('detectPlatform', () => {
  it('iPhone Safari 26 reads Safari version, not frozen OS version', () => {
    const p = detectPlatform(UA.iphoneSafari26)
    expect(p).toMatchObject({ os: 'ios', browser: 'safari', safariVersion: 26 })
    expect(guideKind(p)).toBe('ios')
  })

  it('older iPhone Safari', () => {
    expect(detectPlatform(UA.iphoneSafari17).safariVersion).toBe(17)
  })

  it('Chrome on iOS is ios-other', () => {
    expect(detectPlatform(UA.iphoneChrome)).toMatchObject({ os: 'ios', browser: 'ios-other' })
  })

  it('iPadOS desktop UA is iOS only when it has touch', () => {
    expect(detectPlatform(UA.ipadOs, { maxTouchPoints: 5 }).os).toBe('ios')
    expect(detectPlatform(UA.macSafari, { maxTouchPoints: 0 }).os).toBe('desktop')
  })

  it('Android Chromium browsers', () => {
    expect(detectPlatform(UA.androidChrome)).toMatchObject({ os: 'android', browser: 'chromium' })
    expect(detectPlatform(UA.androidSamsung)).toMatchObject({ os: 'android', browser: 'chromium' })
    expect(guideKind(detectPlatform(UA.androidChrome))).toBe('android')
  })

  it('Android Firefox', () => {
    expect(detectPlatform(UA.androidFirefox)).toMatchObject({ os: 'android', browser: 'firefox' })
  })

  it('WeChat on both platforms wins over OS', () => {
    for (const ua of [UA.wechatIos, UA.wechatAndroid]) {
      const p = detectPlatform(ua)
      expect(p.browser).toBe('wechat')
      expect(guideKind(p)).toBe('wechat')
      expect(guideKind(p)).toBe('wechat')
    }
    expect(detectPlatform(UA.wechatIos).os).toBe('ios')
    expect(detectPlatform(UA.wechatAndroid).os).toBe('android')
  })

  it('other in-app browsers', () => {
    const p = detectPlatform(UA.instagram)
    expect(p.browser).toBe('inapp')
    expect(guideKind(p)).toBe('inapp')
  })

  it('desktop Chrome', () => {
    expect(guideKind(detectPlatform(UA.desktopChrome))).toBe('desktop')
  })

  it('standalone overrides everything', () => {
    expect(guideKind(detectPlatform(UA.iphoneSafari26, { standalone: true }))).toBe('installed')
  })
})

describe('installGuide', () => {
  it('uses the ··· menu flow on Safari 26 and the share button before that', () => {
    expect(installGuide('ios', detectPlatform(UA.iphoneSafari26)).steps[0]).toContain('···')
    expect(installGuide('ios', detectPlatform(UA.iphoneSafari17)).steps[0]).toContain('分享')
  })

  it('tells iOS users the home-screen app needs its own login', () => {
    expect(installGuide('ios', detectPlatform(UA.iphoneSafari26)).note).toContain('登录')
  })

  it('has steps for every kind', () => {
    for (const k of ['ios', 'android', 'wechat', 'inapp', 'desktop'] as const)
      expect(installGuide(k).steps.length).toBeGreaterThan(0)
  })
})
