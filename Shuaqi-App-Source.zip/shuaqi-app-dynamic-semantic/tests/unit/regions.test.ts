import { describe, expect, it } from 'vitest'
import { isRegion, regionCity, LONDON_REGIONS, REGION_CITIES } from '../../app/utils/regions'

describe('coarse public regions', () => {
  it('supports the three cities and all nine London options', () => {
    expect(REGION_CITIES).toEqual(['London', 'Oxford', 'Cambridge'])
    expect(LONDON_REGIONS).toHaveLength(9)
    for (const { value } of LONDON_REGIONS) {
      expect(isRegion(value)).toBe(true)
      expect(regionCity(value)).toBe('London')
      expect(value.length).toBeLessThanOrEqual(60)
    }
    for (const city of ['Oxford', 'Cambridge']) {
      expect(isRegion(city)).toBe(true)
      expect(regionCity(city)).toBe(city)
    }
  })

  it('rejects incomplete London selection, arbitrary text and precise addresses', () => {
    for (const value of ['', 'London', 'South Ken', 'SW7 2AZ', '123 Example Street', 'Manchester']) {
      expect(isRegion(value)).toBe(false)
      expect(regionCity(value)).toBe('')
    }
  })
})
