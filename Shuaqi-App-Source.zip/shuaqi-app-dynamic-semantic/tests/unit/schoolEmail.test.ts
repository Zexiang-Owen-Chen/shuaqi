import { describe, expect, it } from 'vitest'
import { normalizeSchoolEmail } from '../../app/utils/schoolEmail'

describe('normalizeSchoolEmail', () => {
  it('uses the same address for Imperial full and short domains', () => {
    expect(normalizeSchoolEmail('student@ic.ac.uk')).toBe('student@imperial.ac.uk')
    expect(normalizeSchoolEmail('student@imperial.ac.uk')).toBe('student@imperial.ac.uk')
  })

  it('normalizes casing and surrounding whitespace', () => {
    expect(normalizeSchoolEmail(' Student@IC.AC.UK ')).toBe('student@imperial.ac.uk')
    expect(normalizeSchoolEmail(' Student@IMPERIAL.AC.UK ')).toBe('student@imperial.ac.uk')
  })

  it.each(['student@fakeic.ac.uk', 'student@ic.ac.uk.evil.com', 'student@doc.ic.ac.uk', 'student@ic.com'])('does not rewrite the unrecognized domain in %s', (email) => {
    expect(normalizeSchoolEmail(email)).toBe(email)
  })

  it('keeps other schools and empty values unchanged', () => {
    expect(normalizeSchoolEmail('student@ucl.ac.uk')).toBe('student@ucl.ac.uk')
    expect(normalizeSchoolEmail(' Student@KCL.AC.UK ')).toBe('student@kcl.ac.uk')
    expect(normalizeSchoolEmail(' Student@UAL.AC.UK ')).toBe('student@ual.ac.uk')
    expect(normalizeSchoolEmail('')).toBe('')
  })
})
