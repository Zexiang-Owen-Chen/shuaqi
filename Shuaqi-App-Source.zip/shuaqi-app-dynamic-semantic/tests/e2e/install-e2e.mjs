import { chromium } from 'playwright-core'
const OUT = process.argv[2]
const BASE = 'http://localhost:3123'
const UA = {
  iphone: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1',
  android: 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36',
  wechat: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 MicroMessenger/8.0.61(0x18003d2e) NetType/WIFI Language/zh_CN',
  desktop: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',
}
const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' })
const results = []
const check = (name, ok) => { results.push(`${ok ? 'PASS' : 'FAIL'} ${name}`) }
async function ctx(ua, extra = {}) {
  const c = await browser.newContext({ userAgent: ua, viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: ua !== UA.desktop, hasTouch: true, ...extra })
  const errors = []
  const p = await c.newPage()
  p.on('pageerror', e => errors.push(e.message))
  p.on('console', m => { if (m.type() === 'error' || /hydrat/i.test(m.text())) errors.push(m.text()) })
  return { c, p, errors }
}
// Fake beforeinstallprompt like Chrome would fire it.
const fakeBip = `(() => { window.__promptCalls = 0; setTimeout(() => { const e = new Event('beforeinstallprompt', { cancelable: true }); e.prompt = async () => { window.__promptCalls++ }; e.userChoice = Promise.resolve({ outcome: 'accepted' }); window.dispatchEvent(e) }, 300) })()`

// iPhone S13
{ const { c, p, errors } = await ctx(UA.iphone)
  await p.goto(BASE + '/install'); await p.waitForSelector('text=你的设备')
  check('iphone: shows iPhone card highlighted', await p.locator('section.ring-2 h2').innerText() === 'iPhone')
  check('iphone: Safari 26 steps use ··· menu', (await p.locator('section.ring-2 ol').innerText()).includes('···'))
  check('iphone: no install button', await p.locator('button:has-text("安装 SHUAQI")').count() === 0)
  await p.screenshot({ path: OUT + '/s13-iphone.png', fullPage: true })
  // banner after RSVP
  await p.goto(BASE + '/__nudge'); await p.click('#rsvp')
  await p.waitForSelector('text=报名成功！把 SHUAQI 放到桌面')
  await p.click('text=看看怎么添加')
  await p.screenshot({ path: OUT + '/banner-iphone.png' })
  await p.click('[aria-label="7 天内不再提示"]')
  await p.reload(); await p.waitForTimeout(500); await p.click('#rsvp'); await p.waitForTimeout(300)
  check('iphone: dismissed banner stays hidden after reload', await p.locator('text=把 SHUAQI 放到桌面').count() === 0)
  check('iphone: no console errors', errors.length === 0 || (console.log(errors), false))
  await c.close() }

// Android S13 with prompt
{ const { c, p, errors } = await ctx(UA.android)
  await p.addInitScript(fakeBip)
  await p.goto(BASE + '/install'); await p.waitForSelector('text=你的设备')
  await p.waitForSelector('button:has-text("安装 SHUAQI")')
  check('android: Android card highlighted', await p.locator('section.ring-2 h2').innerText() === 'Android')
  await p.screenshot({ path: OUT + '/s13-android.png', fullPage: true })
  await p.click('button:has-text("安装 SHUAQI")')
  await p.waitForSelector('text=安装成功')
  check('android: install button calls prompt()', await p.evaluate('window.__promptCalls') === 1)
  // banner
  await p.goto(BASE + '/__nudge'); await p.waitForTimeout(600); await p.click('#rsvp')
  await p.waitForSelector('button:has-text("安装 SHUAQI")')
  await p.screenshot({ path: OUT + '/banner-android.png' })
  check('android: banner has install button', true)
  check('android: no console errors', errors.length === 0 || (console.log(errors), false))
  await c.close() }

// Android without prompt event (e.g. Firefox / criteria unmet): no banner
{ const { c, p } = await ctx(UA.android)
  await p.goto(BASE + '/__nudge'); await p.waitForTimeout(500); await p.click('#rsvp'); await p.waitForTimeout(300)
  check('android no-prompt: banner not shown', await p.locator('text=把 SHUAQI 放到桌面').count() === 0)
  await c.close() }

// WeChat
{ const { c, p, errors } = await ctx(UA.wechat)
  await p.goto(BASE + '/install'); await p.waitForSelector('text=你的设备')
  check('wechat: WeChat card highlighted', await p.locator('section.ring-2 h2').innerText() === '微信内打开')
  await p.screenshot({ path: OUT + '/s13-wechat.png', fullPage: true })
  check('wechat: hint bar shown on normal page', await p.locator('text=签到和定位请在浏览器打开').count() === 1)
  await p.goto(BASE + '/checkin/abc'); await p.waitForSelector('text=请在浏览器中打开')
  await p.screenshot({ path: OUT + '/wechat-checkin-mask.png' })
  await p.click('text=先在这里看看')
  check('wechat: mask closable, page still usable', await p.locator('text=checkin page').isVisible())
  await p.goto(BASE + '/__nudge'); await p.click('#rsvp'); await p.waitForTimeout(300)
  check('wechat: no install banner in WeChat', await p.locator('text=把 SHUAQI 放到桌面').count() === 0)
  check('wechat: no console errors', errors.length === 0 || (console.log(errors), false))
  await c.close() }

// Standalone (installed)
{ const { c, p } = await ctx(UA.android)
  await p.addInitScript(`window.matchMedia = (q) => ({ matches: q.includes('standalone'), addEventListener(){}, removeEventListener(){} })`)
  await p.goto(BASE + '/install'); await p.waitForSelector('text=已经装好了')
  check('standalone: shows installed, button says 进入 SHUAQI', await p.locator('text=进入 SHUAQI').count() === 1)
  await p.goto(BASE + '/__nudge'); await p.click('#rsvp'); await p.waitForTimeout(300)
  check('standalone: no banner', await p.locator('text=把 SHUAQI 放到桌面').count() === 0)
  await c.close() }

// Desktop
{ const { c, p } = await ctx(UA.desktop, { viewport: { width: 1200, height: 900 }, isMobile: false, hasTouch: false })
  await p.goto(BASE + '/install?redirect=//evil.com'); await p.waitForSelector('img[alt="用手机扫码打开 SHUAQI"]')
  check('desktop: QR shown', true)
  check('desktop: external redirect ignored', await p.locator('a:has-text("先直接使用 Web App")').getAttribute('href') === '/')
  await p.screenshot({ path: OUT + '/s13-desktop.png', fullPage: true })
  await c.close() }

// Service worker registers
{ const { c, p } = await ctx(UA.android)
  await p.goto(BASE + '/install')
  const sw = await p.evaluate(async () => { const r = await navigator.serviceWorker.ready; return r.active?.scriptURL })
  check('sw: registered ' + sw, !!sw)
  await c.close() }

console.log(results.join('\n'))
await browser.close()
