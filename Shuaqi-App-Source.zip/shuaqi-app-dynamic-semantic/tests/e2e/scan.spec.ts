import { expect, test, type BrowserContext } from '@playwright/test'
import QRCode from 'qrcode'
import { AT_VENUE, checkinCode, contextAs, createEvent, createUser, evidenceFor, rpcAs, type EventRow, type TestUser } from './support/backend'

// In-app scanner (/scan): the camera is unavailable in headless Chromium, so these tests use the
// "pick a photo" fallback, which runs the same decoder and the same hand-off to /checkin/<code>.

test.describe.serial('in-app QR scan', () => {
  let host: TestUser, guest: TestUser
  let event: EventRow
  let code = ''
  const contexts: BrowserContext[] = []

  test.beforeAll(async () => {
    ;[host, guest] = await Promise.all([createUser('ScanHost'), createUser('ScanGuest')])
    event = await createEvent(host, { title: `E2E 扫码活动 ${host.name}` })
    await rpcAs(guest, 'join_event', { p_event: event.id })
    code = await checkinCode(host, event.id)
  })
  test.afterAll(async () => { await Promise.all(contexts.map((c) => c.close())) })

  test('the event page links a going user to the scanner', async ({ browser }) => {
    const ctx = await contextAs(browser, guest); contexts.push(ctx)
    const page = await ctx.newPage()
    await page.goto(`/events/${event.id}`)
    await expect(page.getByRole('link', { name: '📷 扫码签到' })).toHaveAttribute('href', '/scan')
  })

  test('a QR code that is not a SHUAQI check-in link is refused', async ({ browser }) => {
    const ctx = await contextAs(browser, guest, { geolocation: AT_VENUE }); contexts.push(ctx)
    const page = await ctx.newPage()
    await page.goto('/scan')
    await page.waitForLoadState('networkidle')
    await page.locator('input[type=file]').setInputFiles({
      name: 'other.png', mimeType: 'image/png', buffer: await QRCode.toBuffer('https://example.com/hello', { width: 400 }),
    })
    await expect(page.getByText('这不是 SHUAQI 活动签到码')).toBeVisible()
    await expect(page).toHaveURL(/\/scan$/)
  })

  test('scanning the event QR checks in straight away as geo_verified', async ({ browser }) => {
    const ctx = await contextAs(browser, guest, { geolocation: AT_VENUE }); contexts.push(ctx)
    const page = await ctx.newPage()
    await page.goto('/scan')
    await page.waitForLoadState('networkidle')
    await page.locator('input[type=file]').setInputFiles({
      name: 'event.png', mimeType: 'image/png',
      buffer: await QRCode.toBuffer(`https://shuaqi.example/checkin/${code}`, { width: 400 }),
    })
    await expect(page).toHaveURL(new RegExp(`/checkin/${code}$`))
    await expect(page.getByRole('heading', { name: '签到成功' })).toBeVisible()
    const ev = await evidenceFor(event.id, guest.id)
    expect(ev).toHaveLength(1)
    expect(ev[0]).toMatchObject({ verification_status: 'geo_verified' })
  })
})
