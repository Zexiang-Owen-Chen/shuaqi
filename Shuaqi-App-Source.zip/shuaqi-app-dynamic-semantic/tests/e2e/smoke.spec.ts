import { expect, test, type Browser, type BrowserContext, type Page } from '@playwright/test'

// End-to-end smoke tests against a running app + local Supabase (Mailpit for e-mail).
// Each run creates fresh, unique users so it can share a database with other work.

const MAILPIT = process.env.MAILPIT_URL ?? 'http://127.0.0.1:54324'
const IMPERIAL = { latitude: 51.4988, longitude: -0.1749, accuracy: 10 }
const SCHOOL_EMAIL_MSG = '请使用已支持的学校邮箱（牛津、剑桥、帝国理工、UCL、LSE、KCL、UAL）注册'

const run = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`
const A = { email: `e2e-a-${run}@ucl.ac.uk`, name: `Alice${run}` }
const B = { email: `e2e-b-${run}@imperial.ac.uk`, name: `Bob${run}` }
const EVENT_TITLE = `E2E 晨跑 ${run}`
const ACTIVITY = `e2e攀岩${run}`

// --- helpers -----------------------------------------------------------------

type MailSummary = { ID: string; To: { Address: string }[]; Created: string }

/** Polls Mailpit for the newest message to `email`. */
async function latestMail(email: string, timeoutMs = 20_000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    const res = await fetch(`${MAILPIT}/api/v1/search?query=${encodeURIComponent(`to:"${email}"`)}&limit=5`)
    if (res.ok) {
      const { messages } = await res.json() as { messages: MailSummary[] }
      if (messages?.length) {
        const msg = await (await fetch(`${MAILPIT}/api/v1/message/${messages[0]!.ID}`)).json() as { Text: string; HTML: string }
        return msg
      }
    }
    await new Promise((r) => setTimeout(r, 500))
  }
  throw new Error(`No e-mail for ${email} in Mailpit after ${timeoutMs}ms`)
}

/** Signs in through /login with the OTP from Mailpit and returns once the app has navigated away. */
async function signIn(page: Page, email: string) {
  await page.goto('/login')
  // Wait for the allowed-domain list so the client-side check is active.
  await expect(page.getByText('目前支持：')).not.toContainText('支持的英国院校')
  await page.locator('#email').fill(email)
  await page.getByRole('button', { name: '发送验证码' }).click()
  await expect(page.locator('#code')).toBeVisible()

  const mail = await latestMail(email)
  const code = /\b(\d{6})\b/.exec(mail.Text)?.[1]
  expect(code, `OTP e-mail to ${email} has no 6-digit code:\n${mail.Text}`).toBeTruthy()
  await page.locator('#code').fill(code!)
  await page.getByRole('button', { name: '登录', exact: true }).click()
}

async function onboard(page: Page, name: string) {
  await expect(page).toHaveURL(/\/onboarding/)
  await page.locator('#pf-name').fill(name)
  await page.locator('#pf-gender').selectOption('prefer_not_to_say')
  await page.locator('#pf-year').fill('2002')
  await page.locator('#pf-region-city').selectOption('London')
  await page.locator('#pf-region').selectOption('London / South Kensington / Chelsea')
  await page.getByRole('button', { name: '跑步' }).click()
  await page.getByRole('button', { name: '开始使用' }).click()
  await expect(page).toHaveURL(/\/$|\/\?/)
  await expect(page.getByRole('heading', { name: /SHUAQI/ })).toBeVisible()
}

function londonInput(d: Date) {
  const p = Object.fromEntries(new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Europe/London', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
  }).formatToParts(d).map((x) => [x.type, x.value]))
  return `${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}`
}

async function newUserContext(browser: Browser): Promise<BrowserContext> {
  return browser.newContext({ geolocation: IMPERIAL, permissions: ['geolocation'] })
}

// --- independent checks ------------------------------------------------------------

test('1. sign-up gate rejects a non-school (gmail) address', async ({ page }) => {
  await page.goto('/login')
  await page.locator('#email').fill(`e2e-${run}@gmail.com`)
  await page.getByRole('button', { name: '发送验证码' }).click()
  await expect(page.getByRole('alert')).toHaveText(SCHOOL_EMAIL_MSG)
  await expect(page.locator('#code')).toHaveCount(0)
})

test('7. / and /install render without console errors for an anonymous user', async ({ page }) => {
  const errors: string[] = []
  page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`))
  page.on('console', (m) => { if (m.type() === 'error' || /hydration/i.test(m.text())) errors.push(`${m.type()}: ${m.text()}`) })

  await page.goto('/')
  await expect(page.getByRole('heading', { name: /SHUAQI/ })).toBeVisible()
  await expect(page.getByText('用学校邮箱登录，报名活动、认识同学')).toBeVisible()
  await page.waitForLoadState('networkidle')

  await page.goto('/install')
  await expect(page.locator('h1')).toBeVisible()
  await page.waitForLoadState('networkidle')

  expect(errors).toEqual([])
})

// --- two-user journey ------------------------------------------------------------

test.describe.serial('two users: events, connections, buddy', () => {
  let ctxA: BrowserContext, ctxB: BrowserContext
  let a: Page, b: Page
  let eventPath = ''
  const journeyErrors: string[] = []

  test.beforeAll(async ({ browser }) => {
    ctxA = await newUserContext(browser)
    ctxB = await newUserContext(browser)
    a = await ctxA.newPage()
    b = await ctxB.newPage()
    for (const [who, p] of [['A', a], ['B', b]] as const) {
      p.on('pageerror', (e) => journeyErrors.push(`${who} ${p.url()} pageerror: ${e.message}`))
      // The Docker-free native stack (tests/e2e/native-stack) has no Realtime server; chat falls back to polling there.
      p.on('console', (m) => {
        if (m.type() === 'error' && !/realtime\/v1\/websocket.*failed/.test(m.text())) journeyErrors.push(`${who} ${p.url()} console: ${m.text()}`)
      })
    }
  })
  test.afterAll(async () => { await ctxA?.close(); await ctxB?.close() })

  test('2. login with G5 e-mail via Mailpit OTP, onboarding, home', async () => {
    await signIn(a, A.email)
    await onboard(a, A.name)
    await signIn(b, B.email)
    await onboard(b, B.name)
  })

  test('3. A creates an event at /create using "my location"', async () => {
    await a.goto('/create')
    await a.locator('#ev-title').fill(EVENT_TITLE)
    await a.locator('#ev-category').selectOption('运动')
    await a.locator('#ev-desc').fill('E2E smoke test event')
    const start = new Date(Date.now() + 24 * 3600e3)
    start.setUTCMinutes(0, 0, 0)
    await a.locator('#ev-starts').fill(londonInput(start))
    await a.locator('#ev-ends').fill(londonInput(new Date(start.getTime() + 2 * 3600e3)))
    await a.locator('#ev-loc').fill('Imperial College Queen\'s Lawn')
    await a.getByRole('button', { name: /使用我当前位置/ }).click()
    await expect(a.getByText(/已获取位置/)).toBeVisible()
    await expect(a.locator('#ev-lat')).toHaveValue('51.498800')
    await expect(a.locator('#ev-lng')).toHaveValue('-0.174900')
    await expect(a.locator('#ev-mode')).toHaveValue('qr_geo')
    await a.getByRole('button', { name: '发布活动' }).click()

    await expect(a).toHaveURL(/\/events\/[0-9a-f-]{36}$/)
    eventPath = new URL(a.url()).pathname
    await expect(a.getByRole('heading', { name: EVENT_TITLE })).toBeVisible()
    await expect(a.getByText('扫码 + 定位签到')).toBeVisible()
    await expect(a.getByText(`${A.name}（我）`)).toBeVisible()
    await expect(a.getByText('已报名 1 人')).toBeVisible()
  })

  test('4. B finds the event on / and joins; A sees the going count', async () => {
    await b.goto('/')
    await b.getByRole('searchbox', { name: '搜索活动' }).fill(run)
    await b.getByRole('link', { name: new RegExp(EVENT_TITLE) }).click()
    await expect(b).toHaveURL(new RegExp(`${eventPath}$`))
    await b.getByRole('button', { name: '报名参加' }).click()
    await expect(b.getByText('✓ 你已报名')).toBeVisible()
    await expect(b.getByText('报名成功！').first()).toBeVisible()

    await a.reload()
    await expect(a.getByText('已报名 2 人')).toBeVisible()
  })

  test('5. both opt in; B requests A; A accepts; both see each other as connections', async () => {
    for (const p of [a, b]) {
      await p.goto(`${eventPath}/people`)
      await p.getByRole('switch', { name: '让同活动的人看到我' }).check()
      await p.getByRole('button', { name: '保存设置' }).click()
      await expect(p.getByText('已开启，同活动的人现在可以看到你')).toBeVisible()
    }

    await b.getByRole('button', { name: '刷新' }).click()
    const aRow = b.locator('li', { hasText: A.name })
    await expect(aRow).toBeVisible()
    await aRow.getByRole('button', { name: /加好友/ }).click()
    await expect(aRow.getByText('已发送请求')).toBeVisible()

    await a.goto('/me/requests')
    const req = a.locator('.card', { hasText: B.name })
    await expect(req).toBeVisible()
    await expect(req.getByText('来自同一活动')).toBeVisible()
    await req.getByRole('button', { name: '接受' }).click()
    await expect(a.getByText('已成为好友')).toBeVisible()

    await a.goto('/me/connections')
    await expect(a.getByText(B.name)).toBeVisible()
    await b.goto('/me/connections')
    await expect(b.getByText(A.name)).toBeVisible()
  })

  test('6. buddy: intents match, A invites B, B accepts, plan shows both', async () => {
    // B posts first.
    await b.goto('/buddy/new')
    await b.locator('#custom-type').fill(ACTIVITY)
    await b.getByRole('button', { name: '发布并查看候选人' }).click()
    await expect(b).toHaveURL(/\/buddy\/intents\/[0-9a-f-]{36}$/)
    await expect(b.getByRole('heading', { name: ACTIVITY })).toBeVisible()

    // A posts a compatible one and sees B.
    await a.goto('/buddy/new')
    await a.locator('#custom-type').fill(ACTIVITY)
    await a.getByRole('button', { name: '发布并查看候选人' }).click()
    await expect(a).toHaveURL(/\/buddy\/intents\/[0-9a-f-]{36}$/)
    const cand = a.locator('.card', { hasText: B.name }).filter({ hasText: '时间重叠' })
    await expect(cand).toBeVisible()
    await expect(cand.getByText(/时间重叠/)).toBeVisible()
    await cand.getByRole('button', { name: '邀请', exact: true }).click()
    await cand.getByRole('textbox').fill('一起去攀岩吧')
    await cand.getByRole('button', { name: '发送邀请' }).click()
    await expect(cand.getByText('已邀请，等对方回应')).toBeVisible()

    // B accepts from /buddy.
    await b.goto('/buddy')
    const inv = b.locator('.card', { hasText: '一起去攀岩吧' })
    await expect(inv).toBeVisible()
    await expect(inv.getByText(A.name)).toBeVisible()
    await inv.getByRole('button', { name: '接受并建立计划' }).click()
    await expect(b).toHaveURL(/\/buddy\/plans\/[0-9a-f-]{36}$/)
    const planPath = new URL(b.url()).pathname
    const bParticipants = b.locator('section', { has: b.getByRole('heading', { name: '参与者' }) })
    await expect(bParticipants.getByText(A.name)).toBeVisible()
    await expect(bParticipants.getByText(B.name)).toBeVisible()

    // A sees the same plan from /buddy.
    await a.goto('/buddy')
    await a.locator(`a[href="${planPath}"]`).first().click()
    await expect(a).toHaveURL(new RegExp(`${planPath}$`))
    const aParticipants = a.locator('section', { has: a.getByRole('heading', { name: '参与者' }) })
    await expect(aParticipants.getByText(A.name)).toBeVisible()
    await expect(aParticipants.getByText(B.name)).toBeVisible()
  })

  test('8. no uncaught page errors or console errors during the journey', () => {
    expect(journeyErrors).toEqual([])
  })
})
