import { expect, test, type BrowserContext } from '@playwright/test'
import { AT_VENUE, RUN, contextAs, createEvent, createUser, db, env, rpcAs, signInSession } from './support/backend'

const DAY = 86400
async function storedSession(ctx: BrowserContext) {
  const cookies = (await ctx.cookies()).filter(c => /auth-token(?:\.\d+)?$/.test(c.name))
  const prefix = cookies[0]?.name.replace(/\.\d+$/, '')
  if (!prefix) throw new Error('Session cookie missing')
  const value = cookies.sort((a, b) => Number(a.name.split('.').pop()) - Number(b.name.split('.').pop())).map(c => c.value).join('')
  return { prefix, cookies, session: JSON.parse(Buffer.from(value.replace(/^base64-/, ''), 'base64url').toString()) }
}
async function expireAccessToken(ctx: BrowserContext) {
  const saved = await storedSession(ctx)
  saved.session.expires_at = Math.floor(Date.now() / 1000) - 60
  const encoded = 'base64-' + Buffer.from(JSON.stringify(saved.session)).toString('base64url')
  await ctx.clearCookies({ name: new RegExp(`^${saved.prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(?:\\.\\d+)?$`) })
  const chunks = encoded.length <= 3180 ? [encoded] : encoded.match(/.{1,3180}/g)!
  await ctx.addCookies(chunks.map((value, i) => ({
    name: chunks.length === 1 ? saved.prefix : `${saved.prefix}.${i}`, value,
    domain: saved.cookies[0]!.domain, path: '/', sameSite: 'Lax' as const, expires: Math.floor(Date.now() / 1000) + DAY,
  })))
  return saved.session.refresh_token as string
}
async function assertDurableCookie(ctx: BrowserContext) {
  const saved = await storedSession(ctx)
  // Assert booleans only: never print auth cookies or tokens on a failed test.
  expect(saved.cookies.every(c => c.expires > Date.now() / 1000 + 29 * DAY)).toBe(true)
  return saved
}

test('SSR renewal writes a durable cookie back and the browser stays on the same account', async ({ browser }) => {
  const user = await createUser('SessionSSR')
  const ctx = await contextAs(browser, user)
  const oldRefresh = await expireAccessToken(ctx)
  const page = await ctx.newPage()
  try {
    const response = await page.goto('/me')
    await expect(page.getByRole('heading', { name: user.name, exact: true })).toBeVisible()
    const saved = await assertDurableCookie(ctx)
    expect(saved.session.refresh_token !== oldRefresh).toBe(true)
    expect(saved.session.user.id === user.id).toBe(true)
    expect((await response!.allHeaders())['cache-control']?.includes('no-store')).toBe(true)
    const reopenedResponse = await page.reload()
    expect((await reopenedResponse!.allHeaders())['cache-control']?.includes('no-store')).toBe(true)
    await expect(page.getByRole('heading', { name: user.name, exact: true })).toBeVisible()
  } finally { await ctx.close() }
})

test('the active browser renews from the cookie before client navigation without logging out', async ({ browser }) => {
  const user = await createUser('SessionBrowser')
  const ctx = await contextAs(browser, user)
  const page = await ctx.newPage()
  try {
    await page.goto('/my-events')
    await expect(page.getByRole('tab', { name: /我报名的/ })).toBeVisible()
    const oldRefresh = await expireAccessToken(ctx)
    let browserRefreshes = 0
    page.on('response', response => { if (response.url().includes('/auth/v1/token?grant_type=refresh_token') && response.ok()) browserRefreshes++ })
    await page.locator('a[href="/me"]').last().click()
    await expect(page.getByRole('heading', { name: user.name, exact: true })).toBeVisible()
    expect(browserRefreshes > 0).toBe(true)
    const saved = await assertDurableCookie(ctx)
    expect(saved.session.refresh_token !== oldRefresh).toBe(true)
    await page.getByRole('link', { name: '好友请求', exact: true }).click()
    await expect(page).toHaveURL(/\/me\/requests$/)
  } finally { await ctx.close() }
})

test('a restored page reconciles stale UI auth state with the current cookie on pageshow and online', async ({ browser }) => {
  const user = await createUser('SessionResume')
  const ctx = await contextAs(browser, user)
  const page = await ctx.newPage()
  try {
    await page.goto('/my-events')
    await expect(page.getByRole('tab', { name: /我报名的/ })).toBeVisible()
    await page.waitForLoadState('networkidle')
    expect(await page.evaluate(() => !!(window as any).useNuxtApp().payload.state['$ssupabase_user']?.sub)).toBe(true)
    for (const event of ['pageshow', 'online', 'visibilitychange']) {
      await page.evaluate((name) => {
        const app = (window as any).useNuxtApp()
        app.payload.state['$ssupabase_session'] = null
        app.payload.state['$ssupabase_user'] = null
        if (name === 'visibilitychange') document.dispatchEvent(new Event(name))
        else window.dispatchEvent(new Event(name))
      }, event)
      await expect.poll(() => page.evaluate(() => !!(window as any).useNuxtApp().payload.state['$ssupabase_user']?.sub), { timeout: 5000 }).toBe(true)
      await expect(page.getByRole('tab', { name: /我报名的/ })).toBeVisible()
    }
  } finally { await ctx.close() }
})

test('concurrent tabs renew successfully and a reopened browser restores the same account', async ({ browser }) => {
  const user = await createUser('SessionTabs')
  const event = await createEvent(user, { title: `Session tabs ${RUN}` })
  const ctx = await contextAs(browser, user)
  await expireAccessToken(ctx)
  const [one, two] = await Promise.all([ctx.newPage(), ctx.newPage()])
  try {
    await Promise.all([one.goto('/me'), two.goto('/my-events')])
    await expect(one.getByRole('heading', { name: user.name, exact: true })).toBeVisible()
    await expect(two.locator(`a[href="/events/${event.id}"]`)).toBeVisible()
    await assertDurableCookie(ctx)
    const state = await ctx.storageState()
    await ctx.close()
    const reopened = await browser.newContext({ storageState: state })
    try {
      const page = await reopened.newPage()
      await page.goto('/me')
      await expect(page.getByRole('heading', { name: user.name, exact: true })).toBeVisible()
      await page.goto('/my-events')
      await expect(page.locator(`a[href="/events/${event.id}"]`)).toBeVisible()
    } finally { await reopened.close() }
  } finally { await ctx.close() }
})

test('a revoked session requires login and the same email restores profile, events and participation history', async ({ browser }) => {
  const user = await createUser('SessionHistory')
  const title = `Persisted history ${RUN}`
  const event = await createEvent(user, { title })
  const code = await rpcAs<string>(user, 'get_checkin_code', { p_event: event.id })
  const checkin = await rpcAs<{ ok: boolean }>(user, 'event_checkin', { p_code: code, p_lat: AT_VENUE.latitude, p_lng: AT_VENUE.longitude, p_accuracy: 10 })
  expect(checkin.ok).toBe(true)
  const ctx = await contextAs(browser, user)
  const page = await ctx.newPage()
  try {
    await page.goto('/me/history')
    await expect(page.getByText(title, { exact: true })).toBeVisible()
    const { url, anon } = env()
    const revoked = await fetch(`${url}/auth/v1/logout?scope=global`, { method: 'POST', headers: { apikey: anon, authorization: `Bearer ${user.session.access_token}` } })
    expect(revoked.ok).toBe(true)
    await expireAccessToken(ctx)
    await page.goto('/me/history')
    await expect(page).toHaveURL(/\/login/)
    await expect(page.getByText(title, { exact: true })).toHaveCount(0)
    const fresh = await signInSession(user.email)
    expect(fresh.user.id === user.id).toBe(true)
    const restored = await contextAs(browser, { ...user, session: fresh })
    try {
      const restoredPage = await restored.newPage()
      await restoredPage.goto('/me')
      await expect(restoredPage.getByRole('heading', { name: user.name, exact: true })).toBeVisible()
      await restoredPage.goto('/my-events')
      await expect(restoredPage.locator(`a[href="/events/${event.id}"]`)).toBeVisible()
      await restoredPage.goto('/me/history')
      await expect(restoredPage.getByText(title, { exact: true })).toBeVisible()
      expect((await db.select('profiles', `id=eq.${user.id}&select=id`)).length).toBe(1)
      expect((await db.select('event_rsvps', `event_id=eq.${event.id}&user_id=eq.${user.id}&select=event_id`)).length).toBe(1)
      expect((await db.select('participation_evidence', `event_id=eq.${event.id}&subject_user_id=eq.${user.id}&select=id`)).length).toBe(1)
    } finally { await restored.close() }
  } finally { await ctx.close() }
})
