-- Run after GoTrue has migrated the auth schema, before the app migrations.
grant usage on schema auth to postgres;
grant all on all tables in schema auth to postgres;
grant execute on all functions in schema auth to anon, authenticated, service_role, postgres;
grant select on auth.users to postgres;
