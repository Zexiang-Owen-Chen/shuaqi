// Tiny stand-in for Kong: one origin (default :54321) that routes like Supabase does.
//   /auth/v1/*  -> GoTrue     /rest/v1/* -> PostgREST     /storage/v1/* -> 404 (not provided)
//   /__templates/<file> -> supabase/templates/<file>, so GoTrue can fetch the e-mail templates.
import http from 'node:http'
import { readFile } from 'node:fs/promises'
import { basename, join } from 'node:path'

const PORT = Number(process.env.GATEWAY_PORT ?? 54321)
const TEMPLATES = process.env.TEMPLATES_DIR ?? ''
const ROUTES = [
  ['/auth/v1', Number(process.env.GOTRUE_PORT ?? 9999)],
  ['/rest/v1', Number(process.env.PGRST_PORT ?? 3001)],
]

// Kong answers CORS for every service in hosted Supabase; do the same here.
function cors(req) {
  return {
    'access-control-allow-origin': req.headers.origin ?? '*',
    'access-control-allow-credentials': 'true',
    'access-control-allow-methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS',
    'access-control-allow-headers': req.headers['access-control-request-headers'] ?? '*',
    'access-control-expose-headers': 'content-range,content-profile,x-supabase-api-version',
    'access-control-max-age': '3600',
  }
}

http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') { res.writeHead(204, cors(req)); res.end(); return }
  if (req.url.startsWith('/__templates/') && TEMPLATES) {
    try { res.end(await readFile(join(TEMPLATES, basename(req.url)))) } catch { res.writeHead(404); res.end() }
    return
  }
  const route = ROUTES.find(([p]) => req.url === p || req.url.startsWith(p + '/') || req.url.startsWith(p + '?'))
  if (!route) {
    res.writeHead(404, { ...cors(req), 'content-type': 'application/json' })
    res.end(JSON.stringify({ message: 'not provided by native stack' }))
    return
  }
  const [prefix, port] = route
  const up = http.request({ host: '127.0.0.1', port, method: req.method, path: req.url.slice(prefix.length) || '/', headers: req.headers }, (r) => {
    const headers = { ...r.headers }
    for (const k of Object.keys(headers)) if (k.startsWith('access-control-')) delete headers[k]
    res.writeHead(r.statusCode ?? 502, { ...headers, ...cors(req) })
    r.pipe(res)
  })
  up.on('error', (e) => { res.writeHead(502); res.end(String(e)) })
  req.pipe(up)
}).listen(PORT, '127.0.0.1', () => console.log(`gateway on :${PORT}`))
