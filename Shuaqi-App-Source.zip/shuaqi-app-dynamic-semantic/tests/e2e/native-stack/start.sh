#!/usr/bin/env bash
# Starts a Docker-free local Supabase subset for the e2e tests (Postgres + GoTrue + PostgREST + Mailpit + gateway).
# Use it only where `npx supabase start` cannot run (no Docker / registry blocked). CI should use the real CLI.
#
#   tests/e2e/native-stack/start.sh            # from the repo root; prints the env to export
#   tests/e2e/native-stack/start.sh stop
#
# Needs: Postgres server binaries (initdb, pg_ctl; 16+) with pgvector (e.g. postgresql-16-pgvector), and these on PATH or in $STACK_BIN:
#   postgrest (PostgREST >= 12), gotrue (github.com/supabase/auth release), mailpit.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../../.." && pwd)"
STATE="${STACK_STATE:-$ROOT/.e2e-stack}"
BIN="${STACK_BIN:-$STATE/bin}"
PGBIN="${PGBIN:-$(ls -d /usr/lib/postgresql/*/bin 2>/dev/null | sort -V | tail -1)}"
PGPORT="${PGPORT:-54322}"
export JWT_SECRET="${JWT_SECRET:-super-secret-jwt-token-with-at-least-32-characters-long}"
export PATH="$BIN:$PGBIN:$PATH"
mkdir -p "$STATE/logs"

# Postgres refuses to run as root.
as_pg() { if [ "$(id -u)" = 0 ]; then runuser -u "${PG_OS_USER:-nobody}" -- "$@"; else "$@"; fi; }

stop() {
  for p in gateway gotrue postgrest mailpit; do [ -f "$STATE/$p.pid" ] && kill "$(cat "$STATE/$p.pid")" 2>/dev/null || true; rm -f "$STATE/$p.pid"; done
  [ -d "$STATE/pg" ] && as_pg pg_ctl -D "$STATE/pg" -m fast stop >/dev/null 2>&1 || true
}
if [ "${1:-}" = stop ]; then stop; exit 0; fi
stop

# --- Postgres (fresh every run, like `supabase db reset`) ---
rm -rf "$STATE/pg"; mkdir -p "$STATE/pg" "$STATE/run"
[ "$(id -u)" = 0 ] && chown -R "${PG_OS_USER:-nobody}" "$STATE/pg" "$STATE/run" "$STATE/logs"
as_pg initdb -D "$STATE/pg" -U postgres --auth=trust -E UTF8 --locale=C.UTF-8 >/dev/null
as_pg pg_ctl -D "$STATE/pg" -l "$STATE/logs/postgres.log" -o "-p $PGPORT -k $STATE/run -c listen_addresses=127.0.0.1" -w start >/dev/null
PSQL=(psql -h 127.0.0.1 -p "$PGPORT" -U postgres -d postgres -v ON_ERROR_STOP=1 -q)
"${PSQL[@]}" -f "$HERE/bootstrap.sql"

# --- Mailpit (SMTP 54325, API/UI 54324) ---
mailpit --listen 127.0.0.1:54324 --smtp 127.0.0.1:54325 --smtp-auth-accept-any --smtp-auth-allow-insecure >"$STATE/logs/mailpit.log" 2>&1 &
echo $! >"$STATE/mailpit.pid"

# --- Gateway on :54321 (also serves the e-mail templates to GoTrue) ---
TEMPLATES_DIR="$ROOT/supabase/templates" node "$HERE/gateway.mjs" >"$STATE/logs/gateway.log" 2>&1 &
echo $! >"$STATE/gateway.pid"

# --- GoTrue (migrates the auth schema itself) ---
eval "$(node "$HERE/jwt.mjs")"
export GOTRUE_API_HOST=127.0.0.1 PORT=9999 API_EXTERNAL_URL=http://127.0.0.1:54321/auth/v1
export GOTRUE_DB_DRIVER=postgres DATABASE_URL="postgres://supabase_auth_admin:postgres@127.0.0.1:$PGPORT/postgres?sslmode=disable"
export GOTRUE_DB_MIGRATIONS_PATH="${GOTRUE_MIGRATIONS:-$BIN/migrations}"
export GOTRUE_SITE_URL="${SITE_URL:-http://localhost:3000}" GOTRUE_URI_ALLOW_LIST="*"
export GOTRUE_JWT_SECRET="$JWT_SECRET" GOTRUE_JWT_EXP=3600 GOTRUE_JWT_AUD=authenticated GOTRUE_JWT_DEFAULT_GROUP_NAME=authenticated GOTRUE_JWT_ADMIN_ROLES=service_role
export GOTRUE_EXTERNAL_EMAIL_ENABLED=true GOTRUE_MAILER_AUTOCONFIRM=false GOTRUE_MAILER_OTP_LENGTH=6 GOTRUE_MAILER_OTP_EXP=3600
export GOTRUE_SMTP_HOST=127.0.0.1 GOTRUE_SMTP_PORT=54325 GOTRUE_SMTP_ADMIN_EMAIL=admin@shuaqi.test GOTRUE_SMTP_SENDER_NAME=SHUAQI GOTRUE_SMTP_MAX_FREQUENCY=1s
export GOTRUE_RATE_LIMIT_EMAIL_SENT=10000 GOTRUE_RATE_LIMIT_VERIFY=10000 GOTRUE_RATE_LIMIT_OTP=10000 GOTRUE_RATE_LIMIT_TOKEN_REFRESH=10000
export GOTRUE_MAILER_URLPATHS_CONFIRMATION=/auth/v1/verify GOTRUE_MAILER_URLPATHS_RECOVERY=/auth/v1/verify GOTRUE_MAILER_URLPATHS_EMAIL_CHANGE=/auth/v1/verify GOTRUE_MAILER_URLPATHS_INVITE=/auth/v1/verify
for t in magic_link confirmation; do
  if [ -f "$ROOT/supabase/templates/$t.html" ]; then
    export "GOTRUE_MAILER_TEMPLATES_${t^^}=http://127.0.0.1:54321/__templates/$t.html" "GOTRUE_MAILER_SUBJECTS_${t^^}=SHUAQI 登录验证码"
  fi
done
export GOTRUE_DISABLE_SIGNUP=false GOTRUE_LOG_LEVEL=warn
gotrue migrate >"$STATE/logs/gotrue-migrate.log" 2>&1 || { tail -20 "$STATE/logs/gotrue-migrate.log"; exit 1; }
gotrue serve >"$STATE/logs/gotrue.log" 2>&1 &
echo $! >"$STATE/gotrue.pid"
for i in $(seq 60); do curl -sf http://127.0.0.1:9999/health >/dev/null && break; sleep 0.5; done
curl -sf http://127.0.0.1:9999/health >/dev/null || { tail -20 "$STATE/logs/gotrue.log"; exit 1; }

# --- App migrations ---
"${PSQL[@]}" -f "$HERE/post-auth.sql"
for f in "$ROOT"/supabase/migrations/*.sql; do "${PSQL[@]}" -f "$f"; done
[ -f "$ROOT/supabase/seed.sql" ] && "${PSQL[@]}" -f "$ROOT/supabase/seed.sql"
"${PSQL[@]}" -f "$HERE/post-migrate.sql"

# --- PostgREST ---
PGRST_DB_URI="postgres://authenticator:postgres@127.0.0.1:$PGPORT/postgres" PGRST_DB_SCHEMAS=public PGRST_DB_ANON_ROLE=anon \
PGRST_JWT_SECRET="$JWT_SECRET" PGRST_SERVER_HOST=127.0.0.1 PGRST_SERVER_PORT=3001 PGRST_DB_CHANNEL_ENABLED=true PGRST_LOG_LEVEL=warn \
  postgrest >"$STATE/logs/postgrest.log" 2>&1 &
echo $! >"$STATE/postgrest.pid"

for i in $(seq 40); do curl -sf "http://127.0.0.1:54321/rest/v1/feature_flags?select=key" -H "apikey: $ANON_KEY" >/dev/null && break; sleep 0.5; done

cat <<ENV
# native stack is up. Export these for the app and the tests:
SUPABASE_URL=http://127.0.0.1:54321
SUPABASE_KEY=$ANON_KEY
SUPABASE_SERVICE_KEY=$SERVICE_ROLE_KEY
DATABASE_URL=postgres://postgres@127.0.0.1:$PGPORT/postgres
MAILPIT_URL=http://127.0.0.1:54324
ENV
