// Prints anon and service_role keys signed with JWT_SECRET (HS256), like `supabase status`.
import { createHmac } from 'node:crypto'
const secret = process.env.JWT_SECRET
const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url')
const sign = (role) => {
  const body = `${b64({ alg: 'HS256', typ: 'JWT' })}.${b64({ iss: 'supabase-demo', role, exp: 1983812996 })}`
  return `${body}.${createHmac('sha256', secret).update(body).digest('base64url')}`
}
console.log(`ANON_KEY=${sign('anon')}\nSERVICE_ROLE_KEY=${sign('service_role')}`)
