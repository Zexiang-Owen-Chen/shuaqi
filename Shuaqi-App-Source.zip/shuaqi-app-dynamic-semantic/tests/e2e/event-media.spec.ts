import { randomUUID } from 'node:crypto'
import { expect, test, type Locator, type Page } from '@playwright/test'
import { AT_VENUE, RUN, contextAs, createEvent, createUser, db, env, rpcAs, type TestUser } from './support/backend'
import { toLondonInput } from '../../app/utils/eventFormat'

const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAEklEQVR4nGN4FcHzHx9mGBkKAPQNk0GBQIzgAAAAAElFTkSuQmCC', 'base64')
const file = (name = 'event.png') => ({ name, mimeType: 'image/png', buffer: PNG })
const picker = (page: Page) => page.getByTestId('event-image-upload').locator('input[type=file]')
async function loaded(image: Locator) {
  await expect(image).toBeVisible()
  await expect.poll(() => image.evaluate((img: HTMLImageElement) => img.complete && img.naturalWidth > 0)).toBe(true)
}
async function upload(user: TestUser, bucket: 'avatars' | 'event-images') {
  const { url, anon } = env()
  const path = `${user.id}/${randomUUID()}.png`
  const response = await fetch(`${url}/storage/v1/object/${bucket}/${path}`, {
    method: 'POST', headers: { apikey: anon, authorization: `Bearer ${user.session.access_token}`, 'content-type': 'image/png' }, body: PNG,
  })
  expect(response.ok).toBe(true)
  return path
}
async function fillEvent(page: Page, title: string) {
  await page.locator('#ev-title').fill(title)
  await page.locator('#ev-category').selectOption('运动')
  await page.locator('#ev-starts').fill(toLondonInput(new Date(Date.now() + 86400_000).toISOString()))
  await page.locator('#ev-loc').fill('London meeting point')
}

test('cancelled events leave discovery but keep their detail records', async ({ browser }) => {
  const host = await createUser('CancelMedia')
  const shown = await createEvent(host, { title: `Visible ${RUN}` })
  const hidden = await createEvent(host, { title: `Cancelled ${RUN}` })
  await rpcAs(host, 'cancel_event', { p_event: hidden.id })
  const ctx = await contextAs(browser, host)
  const page = await ctx.newPage()
  try {
    await page.goto('/')
    await page.getByRole('searchbox', { name: '搜索活动' }).fill(RUN)
    await expect(page.locator(`a[href="/events/${shown.id}"]`)).toBeVisible()
    await expect(page.locator(`a[href="/events/${hidden.id}"]`)).toHaveCount(0)
    await page.goto(`/events/${shown.id}`)
    page.once('dialog', dialog => dialog.accept())
    await page.getByRole('button', { name: '取消活动', exact: true }).click()
    await expect(page.getByText('这个活动已被取消')).toBeVisible()
    await page.locator('a[href="/"]').last().click()
    await expect(page.locator(`a[href="/events/${shown.id}"]`)).toHaveCount(0)
    await page.goto(`/events/${shown.id}`)
    await expect(page.getByText('这个活动已被取消')).toBeVisible()
  } finally { await ctx.close() }
})

test('personal event pictures upload, appear on cards and persist through editing', async ({ browser }) => {
  const host = await createUser('EventPictures')
  const ctx = await contextAs(browser, host)
  const page = await ctx.newPage()
  const title = `Pictures ${RUN}`
  try {
    await page.goto('/create')
    await page.waitForLoadState('networkidle')
    await fillEvent(page, title)
    await picker(page).setInputFiles([file('first.png'), file('second.png')])
    await expect(page.getByTestId('event-image-upload').locator('img')).toHaveCount(2)
    await loaded(page.getByTestId('event-image-upload').locator('img').first())
    await page.getByRole('button', { name: '发布活动', exact: true }).click()
    await expect(page).toHaveURL(/\/events\/[0-9a-f-]+$/)
    const id = page.url().split('/').pop()!
    await expect(page.getByTestId('event-images').locator('img')).toHaveCount(2)
    await loaded(page.getByTestId('event-images').locator('img').last())
    await page.goto('/')
    await page.getByRole('searchbox', { name: '搜索活动' }).fill(title)
    await loaded(page.locator(`a[href="/events/${id}"] img`))
    await page.goto(`/events/${id}/edit`)
    await page.getByRole('button', { name: '移除图片 1', exact: true }).click()
    const webp = await page.evaluate(() => {
      const canvas = document.createElement('canvas'); canvas.width = canvas.height = 8
      canvas.getContext('2d')!.fillRect(0, 0, 8, 8)
      return canvas.toDataURL('image/webp').split(',')[1]!
    })
    await picker(page).setInputFiles({ name: 'replacement.webp', mimeType: 'image/webp', buffer: Buffer.from(webp, 'base64') })
    await expect(page.getByTestId('event-image-upload').locator('img')).toHaveCount(2)
    await page.getByRole('button', { name: '保存修改', exact: true }).click()
    await expect(page).toHaveURL(new RegExp(`/events/${id}$`))
    await page.reload()
    await expect(page.getByTestId('event-images').locator('img')).toHaveCount(2)
    await loaded(page.getByTestId('event-images').locator('img').last())
    await page.screenshot({ path: 'test-results/event-images-verified.png', fullPage: true })
    const [saved] = await db.select<{ image_paths: string[] }>('events', `id=eq.${id}&select=image_paths`)
    expect(saved!.image_paths).toHaveLength(2)
    expect(saved!.image_paths[1]).toMatch(/\.webp$/)
    await page.goto(`/events/${id}/edit`)
    await page.getByRole('button', { name: '移除图片 1', exact: true }).click()
    await page.getByRole('button', { name: '移除图片 1', exact: true }).click()
    await page.getByRole('button', { name: '保存修改', exact: true }).click()
    await expect(page).toHaveURL(new RegExp(`/events/${id}$`))
    await expect(page.getByTestId('event-images')).toHaveCount(0)
  } finally { await ctx.close() }
})

test('organiser create and edit forms also save event pictures', async ({ browser }) => {
  const host = await createUser('OrganiserPictures')
  const ctx = await contextAs(browser, host, { geolocation: AT_VENUE })
  const page = await ctx.newPage()
  try {
    await page.goto('/organiser/events/new')
    await page.getByPlaceholder('例如：G5 万圣节舞会').fill(`Organiser pictures ${RUN}`)
    await page.getByPlaceholder('例如：UCL Student Centre, 16 Gordon St').fill('London')
    await page.getByRole('radio', { name: /不签到/ }).check()
    await picker(page).setInputFiles(file())
    await expect(page.getByTestId('event-image-upload').locator('img')).toHaveCount(1)
    await page.getByRole('button', { name: '创建活动', exact: true }).click()
    await expect(page).toHaveURL(/\/organiser\/events\/[0-9a-f-]+$/)
    const id = page.url().split('/').pop()!
    await page.goto(`/organiser/events/${id}/edit`)
    await loaded(page.getByTestId('event-image-upload').locator('img'))
    await page.getByRole('button', { name: '移除图片 1', exact: true }).click()
    await picker(page).setInputFiles(file('replacement.png'))
    await expect(page.getByTestId('event-image-upload').locator('img')).toHaveCount(1)
    await page.getByRole('button', { name: '保存修改', exact: true }).click()
    await expect(page).toHaveURL(new RegExp(`/organiser/events/${id}$`))
    await page.goto(`/events/${id}`)
    await loaded(page.getByTestId('event-images').locator('img'))
  } finally { await ctx.close() }
})

test('picture validation and server failures recover without losing the form', async ({ browser }) => {
  const user = await createUser('PictureRetry')
  const ctx = await contextAs(browser, user)
  const page = await ctx.newPage()
  try {
    await page.goto('/create')
    await page.waitForLoadState('networkidle')
    await picker(page).setInputFiles({ name: 'large.png', mimeType: 'image/png', buffer: Buffer.alloc(5 * 1024 * 1024 + 1) })
    await expect(page.getByRole('alert')).toHaveText('每张图片不能超过 5MB')
    await picker(page).setInputFiles({ name: 'wrong.svg', mimeType: 'image/svg+xml', buffer: Buffer.from('<svg/>') })
    await expect(page.getByRole('alert')).toHaveText('请选择 JPEG、PNG 或 WebP 图片')
    await page.route('**/storage/v1/object/event-images/**', route => route.fulfill({ status: 403, contentType: 'application/json', body: '{"message":"test failure"}' }))
    await picker(page).setInputFiles(file())
    await expect(page.getByRole('alert')).toContainText('图片上传失败')
    await page.unroute('**/storage/v1/object/event-images/**')
    let release!: () => void
    const gate = new Promise<void>(resolve => { release = resolve })
    await page.route('**/storage/v1/object/event-images/**', async route => { await gate; await route.continue() })
    await picker(page).setInputFiles(file('retry.png'))
    try { await expect(page.getByRole('button', { name: '发布活动', exact: true })).toBeDisabled() }
    finally { release() }
    await expect(page.getByTestId('event-image-upload').locator('img')).toHaveCount(1)
    await page.unroute('**/storage/v1/object/event-images/**')
    await expect(page.getByRole('alert')).toHaveCount(0)
    await picker(page).setInputFiles(Array.from({ length: 6 }, (_, i) => file(`extra-${i}.png`)))
    await expect(page.getByRole('alert')).toHaveText('最多上传 6 张活动图片')
    await expect(page.getByTestId('event-image-upload').locator('img')).toHaveCount(1)
  } finally { await ctx.close() }
})

test('uploaded avatars load in organiser, check-in and buddy candidate lists', async ({ browser }) => {
  const host = await createUser('AvatarHost')
  const attendee = await createUser('AvatarAttendee')
  const path = await upload(attendee, 'avatars')
  await db.update('profiles', `id=eq.${attendee.id}`, { avatar_url: path })
  const event = await createEvent(host)
  await rpcAs(attendee, 'join_event', { p_event: event.id })
  const ctx = await contextAs(browser, host)
  const page = await ctx.newPage()
  try {
    await page.goto(`/organiser/events/${event.id}`)
    const row = page.locator('li').filter({ hasText: attendee.name })
    await loaded(row.locator('img'))
    await expect(row.locator('img')).toHaveAttribute('src', new RegExp(`/storage/v1/object/public/avatars/${attendee.id}/`))
    await page.goto(`/events/${event.id}/checkin-qr`)
    await loaded(page.locator('li').filter({ hasText: attendee.name }).locator('img'))
    const intent = (user: TestUser) => db.insert<{ id: string }>('intents', {
      user_id: user.id, activity_type: `avatar-${RUN}`, window_start: new Date().toISOString(),
      window_end: new Date(Date.now() + 7200_000).toISOString(), expires_at: new Date(Date.now() + 3600_000).toISOString(), region: '',
    })
    const own = await intent(host)
    await intent(attendee)
    await page.goto(`/buddy/intents/${own.id}`)
    const candidate = page.locator('div.card').filter({ hasText: attendee.name }).first()
    await loaded(candidate.locator('img'))
    await page.screenshot({ path: 'test-results/buddy-avatar-verified.png', fullPage: true })
    await db.update('profiles', `id=eq.${attendee.id}`, { avatar_url: `${env().url}/storage/v1/object/public/avatars/${path}` })
    await page.reload()
    await loaded(page.locator('div.card').filter({ hasText: attendee.name }).first().locator('img'))
  } finally { await ctx.close() }
})

test('private event media is signed only for eligible event viewers', async ({ browser }) => {
  const host = await createUser('PrivateImageHost')
  const peer = await createUser('PrivateImagePeer')
  const outsider = await createUser('PrivateImageOther', { domain: 'imperial.ac.uk' })
  const privatePath = await upload(host, 'event-images')
  const publicPath = await upload(host, 'event-images')
  const schoolEvent = await createEvent(host, { visibility: 'school', image_paths: [privatePath] })
  const publicEvent = await createEvent(host, { image_paths: [publicPath] })
  const anon = await contextAs(browser, null)
  const same = await contextAs(browser, peer)
  const other = await contextAs(browser, outsider)
  try {
    const page = await anon.newPage()
    await page.goto(`/events/${publicEvent.id}`)
    await loaded(page.getByTestId('event-images').locator('img'))
    await page.goto(`/events/${schoolEvent.id}`)
    await expect(page.getByText('活动不存在，或者你没有权限查看')).toBeVisible()
    const peerPage = await same.newPage()
    await peerPage.goto(`/events/${schoolEvent.id}`)
    await loaded(peerPage.getByTestId('event-images').locator('img'))
    const otherPage = await other.newPage()
    await otherPage.goto(`/events/${schoolEvent.id}`)
    await expect(otherPage.getByText('活动不存在，或者你没有权限查看')).toBeVisible()
    const { url, anon: key } = env()
    const response = await fetch(`${url}/storage/v1/object/sign/event-images`, {
      method: 'POST', headers: { apikey: key, authorization: `Bearer ${outsider.session.access_token}`, 'content-type': 'application/json' },
      body: JSON.stringify({ paths: [privatePath], expiresIn: 60 }),
    })
    const data = await response.json() as { signedURL?: string; signedUrl?: string }[]
    expect(response.ok && Array.isArray(data) && data.some(item => item.signedURL || item.signedUrl)).toBe(false)
  } finally { await anon.close(); await same.close(); await other.close() }
})
