import { expect, test, type BrowserContext } from '@playwright/test'
import {
  AT_VENUE, FAR_AWAY, POOR_FIX, checkinCode, contextAs, createEvent, createUser, evidenceFor, rpcAs,
  type EventRow, type TestUser,
} from './support/backend'

// Journey 3 (Join Event -> credential -> authorised check-in -> evidence -> history) and B-17/B-09/B-10 in
// the browser: static event QR + GPS, every failure reason the page explains, organiser confirmation,
// and code rotation.

test.describe.serial('check-in: static QR + GPS', () => {
  let host: TestUser, guest: TestUser, stranger: TestUser
  let event: EventRow
  let code = ''
  const contexts: BrowserContext[] = []

  test.beforeAll(async () => {
    ;[host, guest, stranger] = await Promise.all([createUser('Host'), createUser('Guest'), createUser('Stranger', { domain: 'lse.ac.uk' })])
    event = await createEvent(host, { title: `E2E 签到活动 ${host.name}` })
    await rpcAs(guest, 'join_event', { p_event: event.id })
    code = await checkinCode(host, event.id)
  })
  test.afterAll(async () => { await Promise.all(contexts.map((c) => c.close())) })

  test('host sees the static QR and the attendee list', async ({ browser }) => {
    const ctx = await contextAs(browser, host); contexts.push(ctx)
    const page = await ctx.newPage()
    await page.goto(`/events/${event.id}`)
    await page.getByRole('link', { name: '🔳 签到码' }).click()
    await expect(page).toHaveURL(new RegExp(`/events/${event.id}/checkin-qr$`))
    await expect(page.getByRole('heading', { name: event.title })).toBeVisible()
    await expect(page.getByText('用手机相机扫码签到')).toBeVisible()
    await expect(page.getByText('需要先在 SHUAQI 报名，并在活动地点 100 米内')).toBeVisible()
    await expect(page.getByRole('button', { name: '复制签到链接' })).toBeVisible()
    await expect(page.getByRole('button', { name: '重置二维码' })).toBeVisible()
    // Host + guest are going, nobody has checked in yet.
    await expect(page.getByText(/已到\s*0\s*\/\s*报名 2/)).toBeVisible()
    await expect(page.getByText(guest.name)).toBeVisible()
  })

  test('signed-out visitor sees the event and is asked to log in (redirect keeps the code)', async ({ browser }) => {
    const ctx = await contextAs(browser, null); contexts.push(ctx)
    const page = await ctx.newPage()
    await page.goto(`/checkin/${code}`)
    await expect(page.getByText(event.title)).toBeVisible()
    const login = page.getByRole('link', { name: '登录后签到' })
    await expect(login).toHaveAttribute('href', `/login?redirect=${encodeURIComponent(`/checkin/${code}`)}`)
  })

  test('a user who has not joined is sent to sign up first (B-17 not_registered)', async ({ browser }) => {
    const ctx = await contextAs(browser, stranger, { geolocation: AT_VENUE }); contexts.push(ctx)
    const page = await ctx.newPage()
    await page.goto(`/checkin/${code}`)
    await expect(page.getByRole('heading', { name: '你还没有报名这个活动' })).toBeVisible()
    await expect(page.getByRole('link', { name: '去报名' })).toHaveAttribute('href', `/events/${event.id}`)
    await expect(page.getByRole('button', { name: '定位并签到' })).toHaveCount(0)
  })

  test('too far, then at the venue: fails with advice, retry succeeds as geo_verified (B-17, B-10)', async ({ browser }) => {
    const ctx = await contextAs(browser, guest, { geolocation: FAR_AWAY }); contexts.push(ctx)
    const page = await ctx.newPage()
    await page.goto(`/checkin/${code}`)
    await expect(page.getByRole('heading', { name: '到达现场后点下面的按钮签到' })).toBeVisible()
    await page.waitForLoadState('networkidle') // the button only works once the page has hydrated
    await page.getByRole('button', { name: '定位并签到' }).click()

    const alert = page.getByRole('alert')
    await expect(alert.getByRole('heading', { name: '你离活动地点太远了' })).toBeVisible()
    await expect(alert).toContainText('走到活动入口附近再试')
    expect(await evidenceFor(event.id, guest.id)).toEqual([])

    await ctx.setGeolocation(AT_VENUE)
    await page.getByRole('button', { name: '重新定位签到' }).click()
    await expect(page.getByRole('heading', { name: '签到成功' })).toBeVisible()
    await expect(page.getByText('已到场（定位核验）')).toBeVisible()
    await expect(page.getByText(/距离活动地点约/)).toBeVisible()

    // Self check-in is never "verified".
    const ev = await evidenceFor(event.id, guest.id)
    expect(ev).toHaveLength(1)
    expect(ev[0]).toMatchObject({ verification_status: 'geo_verified' })
  })

  test('scanning again does not add evidence (B-09) and the event page shows 已签到', async ({ browser }) => {
    const ctx = await contextAs(browser, guest, { geolocation: AT_VENUE }); contexts.push(ctx)
    const page = await ctx.newPage()
    await page.goto(`/checkin/${code}`)
    await expect(page.getByRole('heading', { name: '你已经签到过了' })).toBeVisible()
    // Same code submitted again through the API (e.g. a double tap) is idempotent.
    const again = await rpcAs<{ ok: boolean; already?: boolean }>(guest, 'event_checkin', { p_code: code, p_lat: AT_VENUE.latitude, p_lng: AT_VENUE.longitude, p_accuracy: 10 })
    expect(again).toMatchObject({ ok: true, already: true })
    expect(await evidenceFor(event.id, guest.id)).toHaveLength(1)

    await page.goto(`/events/${event.id}`)
    await expect(page.getByText('✓ 你已报名')).toBeVisible()
    await expect(page.getByText('已签到', { exact: true })).toBeVisible()
  })

  test('a poor GPS fix is refused with indoor tips (B-17 location_inaccurate)', async ({ browser }) => {
    const late = await createUser('Late')
    await rpcAs(late, 'join_event', { p_event: event.id })
    const ctx = await contextAs(browser, late, { geolocation: POOR_FIX }); contexts.push(ctx)
    const page = await ctx.newPage()
    await page.goto(`/checkin/${code}`)
    await page.waitForLoadState('networkidle') // the button only works once the page has hydrated
    await page.getByRole('button', { name: '定位并签到' }).click()
    await expect(page.getByRole('heading', { name: '定位精度不够' })).toBeVisible({ timeout: 45_000 })
    await expect(page.getByRole('alert')).toContainText('打开 Wi-Fi')
    await expect(page.getByRole('button', { name: '重新定位签到' })).toBeVisible()
    expect(await evidenceFor(event.id, late.id)).toEqual([])
  })

  test('denied location permission explains how to turn it on', async ({ browser }) => {
    const noGps = await createUser('NoGps')
    await rpcAs(noGps, 'join_event', { p_event: event.id })
    const ctx = await contextAs(browser, noGps); contexts.push(ctx)
    // Headless Chromium would leave the permission prompt pending; behave like a user who tapped "Don't allow".
    await ctx.addInitScript(() => {
      const denied = { code: 1, message: 'User denied Geolocation', PERMISSION_DENIED: 1, POSITION_UNAVAILABLE: 2, TIMEOUT: 3 }
      navigator.geolocation.getCurrentPosition = (_ok, fail) => { setTimeout(() => fail?.(denied as GeolocationPositionError), 50) }
      const query = navigator.permissions.query.bind(navigator.permissions)
      navigator.permissions.query = (d) => (d.name === 'geolocation' ? Promise.resolve({ state: 'denied' } as PermissionStatus) : query(d))
    })
    const page = await ctx.newPage()
    await page.goto(`/checkin/${code}`)
    await page.waitForLoadState('networkidle') // the button only works once the page has hydrated
    await page.getByRole('button', { name: '定位并签到' }).click()
    await expect(page.getByRole('heading', { name: '你拒绝了定位权限，请在浏览器设置中允许后重试' })).toBeVisible()
    await expect(page.getByText('如何重新允许定位')).toBeVisible()
    await expect(page.getByRole('button', { name: '重新定位签到' })).toBeVisible()
    expect(await evidenceFor(event.id, noGps.id)).toEqual([])
  })

  test('host confirms attendance; only that creates verified evidence', async ({ browser }) => {
    const ctx = await contextAs(browser, host); contexts.push(ctx)
    const page = await ctx.newPage()
    await page.goto(`/events/${event.id}/checkin-qr`)
    await expect(page.getByText(/已到\s*1\s*\/\s*报名 4/)).toBeVisible()
    const row = page.locator('li').filter({ hasText: guest.name })
    await expect(row).toContainText('定位')
    await row.getByRole('button', { name: '确认到场' }).click()
    await expect(row).toContainText('主办方已确认')
    await expect(row.getByRole('button', { name: '撤销' })).toBeVisible()
    // The host's own row has no confirm button (cannot self-verify).
    await expect(page.locator('li').filter({ hasText: host.name }).getByRole('button')).toHaveCount(0)

    const statuses = (await evidenceFor(event.id, guest.id)).map((e) => e.verification_status)
    expect(statuses).toContain('geo_verified')
    expect(statuses).toContain('verified')
  })

  test('guest sees both records in their participation history', async ({ browser }) => {
    const ctx = await contextAs(browser, guest); contexts.push(ctx)
    const page = await ctx.newPage()
    await page.goto('/me/history')
    await expect(page.getByRole('heading', { name: '参与记录' })).toBeVisible()
    const cards = page.locator('.card').filter({ hasText: event.title })
    await expect(cards).toHaveCount(2)
    await expect(cards.filter({ hasText: '扫码签到' })).toContainText('定位核验')
    await expect(cards.filter({ hasText: '主办方核验到场' })).toContainText('已核验')
  })

  test('only staff can open the QR page', async ({ browser }) => {
    const ctx = await contextAs(browser, guest); contexts.push(ctx)
    const page = await ctx.newPage()
    await page.goto(`/events/${event.id}/checkin-qr`)
    await expect(page.getByText('只有活动的发起人和组织工作人员可以查看签到二维码。')).toBeVisible()
    await expect(page.getByRole('button', { name: '复制签到链接' })).toHaveCount(0)
  })

  test('rotating the code kills the old QR immediately (B-17 rotated)', async ({ browser }) => {
    const hostCtx = await contextAs(browser, host); contexts.push(hostCtx)
    const hp = await hostCtx.newPage()
    await hp.goto(`/events/${event.id}/checkin-qr`)
    hp.once('dialog', (d) => d.accept())
    await hp.getByRole('button', { name: '重置二维码' }).click()
    await expect.poll(() => checkinCode(host, event.id)).not.toBe(code)
    const fresh = await checkinCode(host, event.id)

    const ctx = await contextAs(browser, stranger); contexts.push(ctx)
    const page = await ctx.newPage()
    await page.goto(`/checkin/${code}`)
    await expect(page.getByRole('heading', { name: '签到码无效' })).toBeVisible()
    await page.goto(`/checkin/${fresh}`)
    await expect(page.getByText(event.title)).toBeVisible()
    code = fresh
  })
})

test('outside the check-in window the page says when it opens (B-17 outside_window)', async ({ browser }) => {
  const [host, guest] = await Promise.all([createUser('WinHost'), createUser('WinGuest')])
  const startsAt = new Date(Date.now() + 3 * 24 * 3600e3)
  const event = await createEvent(host, { title: `E2E 下周活动 ${host.name}`, starts_at: startsAt.toISOString(), ends_at: new Date(startsAt.getTime() + 3600e3).toISOString() })
  await rpcAs(guest, 'join_event', { p_event: event.id })
  const code = await checkinCode(host, event.id)

  const ctx = await contextAs(browser, guest, { geolocation: AT_VENUE })
  const page = await ctx.newPage()
  await page.goto(`/checkin/${code}`)
  await page.waitForLoadState('networkidle') // the button only works once the page has hydrated
  await page.getByRole('button', { name: '定位并签到' }).click()
  await expect(page.getByRole('heading', { name: '现在不在签到时间内' })).toBeVisible()
  expect(await evidenceFor(event.id, guest.id)).toEqual([])
  await ctx.close()
})
