import { expect, test, type Page } from '@playwright/test'
import { RUN, contextAs, createEvent, createUser, db, rpcAs } from './support/backend'

const card = (page: Page, id: string) => page.locator(`a[href="/events/${id}"]`)
const tab = (page: Page, name: string, count: number) => page.getByRole('tab', { name: new RegExp(`^${name}\\s*${count}$`) })

test('cancelled hosting and joined activities have one dedicated, deduplicated list', async ({ browser }) => {
  const viewer = await createUser('MyEventsViewer'), other = await createUser('MyEventsOther')
  const [ownActive, ownPast, ownCancelled, ownPastCancelled, joinedActive, joinedPast, joinedCancelled, joinedPastCancelled, unrelated, withdrawn] = await Promise.all([
    createEvent(viewer, { title: `Own active ${RUN}` }), createEvent(viewer, { title: `Own past ${RUN}` }),
    createEvent(viewer, { title: `Own cancelled ${RUN}` }), createEvent(viewer, { title: `Own past cancelled ${RUN}` }),
    createEvent(other, { title: `Joined active ${RUN}` }), createEvent(other, { title: `Joined past ${RUN}` }),
    createEvent(other, { title: `Joined cancelled ${RUN}`, starts_at: new Date(Date.now() + 3600_000).toISOString() }),
    createEvent(other, { title: `Joined past cancelled ${RUN}` }), createEvent(other, { title: `Unrelated cancelled ${RUN}` }),
    createEvent(other, { title: `Withdrawn RSVP ${RUN}` }),
  ])
  for (const event of [joinedActive, joinedPast, joinedCancelled, joinedPastCancelled, withdrawn])
    await rpcAs(viewer, 'join_event', { p_event: event.id })
  await rpcAs(viewer, 'leave_event', { p_event: withdrawn.id })
  for (const event of [ownPast, ownPastCancelled, joinedPast, joinedPastCancelled]) {
    await db.update('events', `id=eq.${event.id}`, { starts_at: new Date(Date.now() - 86400_000).toISOString(), ends_at: new Date(Date.now() - 82800_000).toISOString() })
  }
  await db.update('events', `id=eq.${ownPast.id}`, { status: 'ended' })
  for (const event of [ownCancelled, ownPastCancelled]) await rpcAs(viewer, 'cancel_event', { p_event: event.id })
  for (const event of [joinedCancelled, joinedPastCancelled, unrelated]) await rpcAs(other, 'cancel_event', { p_event: event.id })
  const cancelled = [ownCancelled, ownPastCancelled, joinedCancelled, joinedPastCancelled]
  const ctx = await contextAs(browser, viewer)
  const page = await ctx.newPage()
  try {
    await page.goto('/my-events')
    await expect(tab(page, '我报名的', 4)).toHaveAttribute('aria-selected', 'true')
    await expect(tab(page, '我发起的', 2)).toBeVisible()
    await expect(tab(page, '已取消', 4)).toBeVisible()
    for (const event of [ownActive, ownPast, joinedActive, joinedPast]) await expect(card(page, event.id)).toBeVisible()
    for (const event of [...cancelled, unrelated, withdrawn]) await expect(card(page, event.id)).toHaveCount(0)
    await expect(page.getByRole('heading', { name: '即将开始 / 进行中' })).toBeVisible()
    await expect(page.getByRole('heading', { name: '已结束', exact: true })).toBeVisible()
    await tab(page, '我发起的', 2).click()
    for (const event of [ownActive, ownPast]) await expect(card(page, event.id)).toBeVisible()
    for (const event of [...cancelled, joinedActive, joinedPast]) await expect(card(page, event.id)).toHaveCount(0)
    await tab(page, '已取消', 4).click()
    await expect(tab(page, '已取消', 4)).toHaveAttribute('aria-selected', 'true')
    for (const event of cancelled) await expect(card(page, event.id)).toHaveCount(1)
    for (const event of [ownActive, ownPast, joinedActive, joinedPast, unrelated, withdrawn]) await expect(card(page, event.id)).toHaveCount(0)
    await expect(page.getByRole('heading', { name: '已结束', exact: true })).toHaveCount(0)
    await expect(page.getByRole('heading', { name: '即将开始 / 进行中' })).toHaveCount(0)
    await expect(page.locator('section a[href^="/events/"]').first()).toHaveAttribute('href', `/events/${joinedCancelled.id}`)
    await page.screenshot({ path: 'test-results/my-events-cancelled.png', fullPage: true })
    await card(page, ownCancelled.id).click()
    await expect(page.getByText('这个活动已被取消')).toBeVisible()
    await page.goto('/my-events')
    await tab(page, '已取消', 4).click()
    for (const event of cancelled) await expect(card(page, event.id)).toHaveCount(1)
    expect(await db.select('events', `id=in.(${cancelled.map(e => e.id).join(',')})&select=id,status`)).toHaveLength(4)
  } finally { await ctx.close() }
})

test('cancelling an activity moves it out of both original tabs on in-app navigation', async ({ browser }) => {
  const host = await createUser('MyEventsCancelFlow')
  const event = await createEvent(host)
  const ctx = await contextAs(browser, host)
  const page = await ctx.newPage()
  try {
    await page.goto('/my-events')
    await expect(tab(page, '我报名的', 1)).toBeVisible()
    await card(page, event.id).click()
    page.once('dialog', dialog => dialog.accept())
    await page.getByRole('button', { name: '取消活动', exact: true }).click()
    await expect(page.getByText('这个活动已被取消')).toBeVisible()
    await page.getByRole('link', { name: '我的活动', exact: true }).click()
    await expect(tab(page, '我报名的', 0)).toBeVisible()
    await expect(page.getByText('你还没有报名活动', { exact: true })).toBeVisible()
    await expect(card(page, event.id)).toHaveCount(0)
    await tab(page, '我发起的', 0).click()
    await expect(page.getByText('你还没有发起过活动', { exact: true })).toBeVisible()
    await expect(card(page, event.id)).toHaveCount(0)
    await tab(page, '已取消', 1).click()
    await expect(card(page, event.id)).toHaveCount(1)
  } finally { await ctx.close() }
})

test('the cancelled tab has its own empty state', async ({ browser }) => {
  const user = await createUser('MyEventsEmpty')
  const ctx = await contextAs(browser, user)
  const page = await ctx.newPage()
  try {
    await page.goto('/my-events')
    await tab(page, '已取消', 0).click()
    await expect(page.getByText('暂无已取消的活动', { exact: true })).toBeVisible()
    await expect(page.getByText('你还没有发起过活动', { exact: true })).toHaveCount(0)
  } finally { await ctx.close() }
})
