import { expect, test, type Browser } from '@playwright/test'
import { contextAs, createUser, rpcAs, setFlag, type TestUser } from './support/backend'

// Web push opt-in and settings. Real delivery needs a browser push service, which a CI browser
// does not have; the database side (queueing, preferences, permissions) is covered in
// supabase/tests/10_push.test.sql.

const ANDROID = 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36'
// An Android phone that has not been asked about notifications yet. Headless Chromium reports
// Notification.permission as 'denied' whatever the context grants, so the fresh state is simulated.
async function androidPage(browser: Browser, user: TestUser) {
  const ctx = await contextAs(browser, user, { userAgent: ANDROID })
  await ctx.addInitScript(() => Object.defineProperty(Notification, 'permission', { get: () => 'default' }))
  return ctx.newPage()
}
const WECHAT = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 MicroMessenger/8.0.50(0x1800322d) NetType/WIFI Language/zh_CN'

test.describe.serial('push notifications', () => {
  let user: TestUser
  test.beforeAll(async () => { user = await createUser('PushUser') })

  test('iPhone in Safari is sent to the install guide first', async ({ browser }) => {
    // The default device in playwright.config.ts is an iPhone in the browser.
    const page = await (await contextAs(browser, user)).newPage()
    await page.goto('/me/notifications')
    await expect(page.getByTestId('push-device')).toContainText('添加到主屏幕')
    await expect(page.getByTestId('push-enable')).toHaveCount(0)

    await page.goto('/me')
    await expect(page.getByText('iPhone 需要先把 SHUAQI 添加到主屏幕')).toBeVisible()
    await expect(page.getByRole('link', { name: '通知设置' })).toBeVisible()
  })

  test('WeChat never offers notifications', async ({ browser }) => {
    const page = await (await contextAs(browser, user, { userAgent: WECHAT })).newPage()
    await page.goto('/me/notifications')
    await expect(page.getByTestId('push-device')).toContainText('在微信或其他 App 里打开时收不到通知')
    await expect(page.getByTestId('push-enable')).toHaveCount(0)
  })

  test('Android shows the opt-in card, and "以后再说" hides it', async ({ browser }) => {
    const page = await androidPage(browser, user)
    await page.goto('/me')
    const card = page.getByTestId('push-opt-in')
    await expect(card).toBeVisible()
    await card.getByRole('button', { name: '以后再说' }).click()
    await expect(card).toHaveCount(0)
    await page.reload()
    await expect(page.getByRole('heading', { name: user.name })).toBeVisible()
    await expect(page.getByTestId('push-opt-in')).toHaveCount(0)

    await page.goto('/me/notifications')
    await expect(page.getByTestId('push-enable')).toBeVisible()
  })

  test('categories can be switched off and stay off', async ({ browser }) => {
    const page = await androidPage(browser, user)
    await page.goto('/me/notifications')
    const reminders = page.getByTestId('push-categories').getByRole('checkbox', { name: /活动提醒/ })
    await expect(reminders).toBeChecked()
    await reminders.uncheck()
    await expect.poll(async () => ((await rpcAs(user, 'my_notification_preferences')) as Record<string, boolean>).event_reminder)
      .toBe(false)
    await page.reload()
    await expect(page.getByTestId('push-categories').getByRole('checkbox', { name: /活动提醒/ })).not.toBeChecked()
    await expect(page.getByTestId('push-categories').getByRole('checkbox', { name: /新消息/ })).toBeChecked()
  })

  test('the server refuses test pushes without a device and dispatch without the secret', async ({ request }) => {
    const res = await rpcAs(user, 'send_test_push').then(() => 'ok', (e: Error) => e.message)
    expect(res).toContain('push_not_subscribed')
    expect((await request.post('/api/push/dispatch')).status()).toBe(401)
    expect((await request.post('/api/push/dispatch', { headers: { Authorization: 'Bearer wrong' } })).status()).toBe(401)
  })

  test('switched off by the flag, the settings page says so', async ({ browser }) => {
    await setFlag('push', false)
    try {
      const page = await androidPage(browser, user)
      await page.goto('/me/notifications')
      await expect(page.getByText('通知暂时关闭了')).toBeVisible()
      await page.goto('/me')
      await expect(page.getByRole('link', { name: '通知设置' })).toHaveCount(0)
      await expect(page.getByTestId('push-opt-in')).toHaveCount(0)
    }
    finally { await setFlag('push', true) }
  })
})
