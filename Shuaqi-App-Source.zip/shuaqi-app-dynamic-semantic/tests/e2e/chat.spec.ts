import { expect, test } from '@playwright/test'
import { RUN, contextAs, createUser, db, restAs, rpcAs, setFlag, type TestUser } from './support/backend'

// One-to-one chat between friends: send and receive, unread badge, report a message, and the
// database refusing strangers and blocked users.

const befriend = (x: TestUser, y: TestUser) =>
  db.insert('connections', { user_a: x.id < y.id ? x.id : y.id, user_b: x.id < y.id ? y.id : x.id })

test.describe.serial('chat between friends', () => {
  let alice: TestUser, bob: TestUser, carol: TestUser, admin: TestUser
  test.beforeAll(async () => {
    ;[alice, bob, carol, admin] = await Promise.all([
      createUser('ChatAlice'), createUser('ChatBob', { domain: 'lse.ac.uk' }), createUser('ChatCarol'),
      createUser('ChatAdmin', { role: 'admin' }),
    ])
    await befriend(alice, bob)
  })

  test('Alice messages Bob from the friends list; Bob sees it with an unread badge and replies', async ({ browser }) => {
    const a = await (await contextAs(browser, alice)).newPage()
    await a.goto('/me/connections')
    await a.getByRole('link', { name: '发消息' }).click()
    await expect(a).toHaveURL(new RegExp(`/messages/${bob.id}$`))
    await expect(a.getByText('打个招呼吧')).toBeVisible()
    const box = a.getByRole('textbox', { name: '消息内容' })
    await box.fill(`你好 Bob ${RUN}`)
    await a.getByRole('button', { name: '发送' }).click()
    await expect(a.getByTestId('message').filter({ hasText: `你好 Bob ${RUN}` })).toBeVisible()
    await expect(box).toHaveValue('')

    const b = await (await contextAs(browser, bob)).newPage()
    await b.goto('/me')
    await expect(b.getByRole('link', { name: /消息\s*1/ })).toBeVisible()
    await b.getByRole('link', { name: /消息/ }).first().click()
    const row = b.getByTestId('conversation').filter({ hasText: alice.name })
    await expect(row).toContainText(`你好 Bob ${RUN}`)
    await row.click()
    await expect(b.getByTestId('message').filter({ hasText: `你好 Bob ${RUN}` })).toBeVisible()
    await b.getByRole('textbox', { name: '消息内容' }).fill('你好 Alice')
    await b.getByRole('textbox', { name: '消息内容' }).press('Enter')
    await expect(b.getByTestId('message').filter({ hasText: '你好 Alice' })).toBeVisible()

    // Opening the conversation marked it read.
    expect(await rpcAs<number>(bob, 'unread_message_count')).toBe(0)
    // Alice's open page picks up the reply (Realtime, or the polling fallback).
    await expect(a.getByTestId('message').filter({ hasText: '你好 Alice' })).toBeVisible({ timeout: 20_000 })
    await a.context().close()
    await b.context().close()
  })

  test('Bob reports one of Alice\'s messages; the admin sees the excerpt', async ({ browser }) => {
    await rpcAs(alice, 'send_message', { p_to: bob.id, p_body: `不当内容 ${RUN}` })
    const b = await (await contextAs(browser, bob)).newPage()
    await b.goto(`/messages/${alice.id}`)
    await b.getByTestId('message').filter({ hasText: `不当内容 ${RUN}` }).click()
    await b.getByRole('button', { name: '举报这条消息' }).click()
    await b.getByRole('button', { name: '骚扰或不当言行' }).click()
    await b.getByRole('button', { name: '提交举报' }).click()
    await expect(b.getByText('已收到你的举报')).toBeVisible()
    await b.getByRole('button', { name: '好的' }).click()
    await expect(b.getByRole('button', { name: '拉黑对方' })).toBeVisible()
    await b.context().close()

    const ad = await (await contextAs(browser, admin)).newPage()
    await ad.goto('/admin/reports')
    const card = ad.getByRole('listitem').filter({ hasText: `${alice.name}` }).filter({ hasText: '聊天消息' })
    await expect(card.getByTestId('report-snapshot')).toContainText(`不当内容 ${RUN}`)
    await expect(card.getByTestId('report-snapshot')).toContainText('你好 Alice')
    await ad.context().close()
  })

  test('strangers cannot message or read, even with the API', async ({ browser }) => {
    const c = await (await contextAs(browser, carol)).newPage()
    await c.goto(`/messages/${alice.id}`)
    await expect(c.getByText('你们还不是好友')).toBeVisible()
    await expect(c.getByRole('textbox', { name: '消息内容' })).toHaveCount(0)
    await c.context().close()

    const send = await restAs(carol, 'rpc/send_message', { method: 'POST', body: { p_to: alice.id, p_body: 'hi' } })
    expect(send.status).toBe(400)
    expect((await restAs(carol, 'messages?select=id')).data).toEqual([])
    const direct = await restAs(carol, 'messages', { method: 'POST', body: { conversation_id: crypto.randomUUID(), sender_id: carol.id, body: 'x' } })
    expect([401, 403]).toContain(direct.status)
  })

  test('switching the chat flag off hides chat', async ({ browser }) => {
    await setFlag('chat', false)
    try {
      const a = await (await contextAs(browser, alice)).newPage()
      await a.goto('/messages')
      await expect(a.getByText('聊天暂时关闭了')).toBeVisible()
      await a.goto('/me')
      await expect(a.getByRole('link', { name: /^消息/ })).toHaveCount(0)
      await a.context().close()
    } finally {
      await setFlag('chat', true)
    }
  })

  test('after Bob blocks Alice neither can see the conversation', async ({ browser }) => {
    await rpcAs(bob, 'block_user', { p_target: alice.id })
    const a = await (await contextAs(browser, alice)).newPage()
    await a.goto('/messages')
    await expect(a.getByText('还没有聊天')).toBeVisible()
    await a.goto(`/messages/${bob.id}`)
    await expect(a.getByText('你们还不是好友')).toBeVisible()
    await a.context().close()
    expect((await restAs(alice, 'messages?select=id')).data).toEqual([])
    expect((await restAs(bob, 'messages?select=id')).data).toEqual([])
  })
})
