import { expect, test, type BrowserContext } from '@playwright/test'
import { AT_VENUE, RUN, checkinCode, contextAs, createEvent, createUser, db, restAs, rpcAs, setFlag, type EventRow, type TestUser } from './support/backend'

// Module H (safety back office) in the browser: reports (B-12), evidence corrections (B-11),
// feature flags and the audit log. Admin pages must stay closed to everyone else.

test.describe.serial('admin back office', () => {
  let admin: TestUser, host: TestUser, reporter: TestUser, bystander: TestUser
  let event: EventRow
  const contexts: BrowserContext[] = []
  const DETAILS = `E2E 举报说明 ${RUN}`

  test.beforeAll(async () => {
    ;[admin, host, reporter, bystander] = await Promise.all([
      createUser('Boss', { role: 'admin' }), createUser('Hoster'), createUser('Reporter'), createUser('Bystander', { domain: 'ox.ac.uk' }),
    ])
    event = await createEvent(host, { title: `E2E 被举报活动 ${RUN}` })
  })
  test.afterAll(async () => { await Promise.all(contexts.map((c) => c.close())) })

  test('non-admins get a closed door on every admin page', async ({ browser }) => {
    const ctx = await contextAs(browser, bystander); contexts.push(ctx)
    const page = await ctx.newPage()
    for (const path of ['/admin', '/admin/reports', '/admin/corrections', '/admin/flags', '/admin/audit', '/admin/orgs', '/admin/events']) {
      await page.goto(path)
      await expect(page.getByText('这个页面只对管理员开放。'), path).toBeVisible()
    }
    await expect(page.getByRole('link', { name: '管理员' })).toHaveCount(0)
  })

  test('a user reports an event from the event page', async ({ browser }) => {
    const ctx = await contextAs(browser, reporter); contexts.push(ctx)
    const page = await ctx.newPage()
    await page.goto(`/events/${event.id}`)
    await page.getByRole('button', { name: '举报这个活动' }).click()
    const dialog = page.getByRole('dialog')
    await dialog.getByRole('button', { name: '提交举报' }).click()
    await expect(dialog.getByText('请选择举报原因')).toBeVisible()
    await dialog.getByRole('button', { name: '广告或诈骗' }).click()
    await dialog.getByLabel('补充说明（可选）').fill(DETAILS)
    await dialog.getByRole('button', { name: '提交举报' }).click()
    await expect(dialog.getByText('已收到你的举报，我们会尽快处理。')).toBeVisible()
  })

  test('other users cannot read the report; the reporter can (B-12)', async () => {
    const theirs = await restAs(bystander, `reports?target_id=eq.${event.id}&select=id`)
    expect(theirs.data).toEqual([])
    const hosts = await restAs(host, `reports?target_id=eq.${event.id}&select=id`)
    expect(hosts.data).toEqual([])
    const own = await restAs(reporter, `reports?target_id=eq.${event.id}&select=id,status`)
    expect(own.data).toEqual([expect.objectContaining({ status: 'open' })])
    // Reporters cannot close their own report.
    const close = await rpcAs(reporter, 'admin_update_report', { p_report: (own.data as { id: string }[])[0]!.id, p_status: 'dismissed' }).then(() => 'ok', (e: Error) => e.message)
    expect(close).toContain('forbidden')
  })

  test('admin handles the report and it lands in the audit log', async ({ browser }) => {
    const ctx = await contextAs(browser, admin); contexts.push(ctx)
    const page = await ctx.newPage()
    await page.goto('/admin')
    await page.getByRole('navigation').getByRole('link', { name: '举报', exact: true }).click()
    const card = page.locator('li').filter({ hasText: DETAILS })
    await expect(card).toContainText('广告或诈骗')
    await expect(card).toContainText(event.title)
    await expect(card).toContainText(reporter.name)
    await card.getByPlaceholder('处理备注（仅管理员可见）').fill('已联系发起人')
    await card.getByRole('button', { name: '已解决' }).click()
    await expect(card).toContainText('备注：已联系发起人')
    await page.reload()
    await expect(page.locator('li').filter({ hasText: DETAILS })).toHaveCount(0) // no longer in "待处理"
    await page.getByRole('button', { name: '全部' }).click()
    await expect(page.locator('li').filter({ hasText: DETAILS })).toContainText('已联系发起人')

    const [r] = await db.select<{ status: string; handled_by: string }>('reports', `target_id=eq.${event.id}&select=status,handled_by`)
    expect(r).toMatchObject({ status: 'resolved', handled_by: admin.id })

    await page.getByRole('navigation').getByRole('link', { name: '审计日志', exact: true }).click()
    await page.locator('select').selectOption('reports')
    await expect(page.locator('li').filter({ hasText: admin.name }).first()).toBeVisible()
  })

  test('a user asks to correct a record; admin revokes it and the trust card follows (B-11)', async ({ browser }) => {
    await rpcAs(reporter, 'join_event', { p_event: event.id })
    const code = await checkinCode(host, event.id)
    await rpcAs(reporter, 'event_checkin', { p_code: code, p_lat: AT_VENUE.latitude, p_lng: AT_VENUE.longitude, p_accuracy: 10 })
    expect(await rpcAs<{ self_reported_presence: number }>(reporter, 'trust_summary')).toMatchObject({ self_reported_presence: 1 })

    const userCtx = await contextAs(browser, reporter); contexts.push(userCtx)
    const up = await userCtx.newPage()
    await up.goto('/me/history')
    const record = up.locator('.card').filter({ hasText: event.title })
    await record.getByRole('button', { name: '申请更正' }).click()
    await record.getByPlaceholder('请说明哪里不对').fill(`E2E 我当天没去 ${RUN}`)
    await record.getByRole('button', { name: '提交' }).click()
    await expect(up.getByText('更正申请已提交，管理员处理后会更新记录')).toBeVisible()
    await expect(record).toContainText('更正申请处理中')

    const adminCtx = await contextAs(browser, admin); contexts.push(adminCtx)
    const ap = await adminCtx.newPage()
    await ap.goto('/admin/corrections')
    const item = ap.locator('li').filter({ hasText: `E2E 我当天没去 ${RUN}` })
    await expect(item).toContainText(reporter.name)
    await item.locator('select').selectOption('revoked')
    await item.getByPlaceholder('处理说明（必填）').fill('用户本人确认未到场')
    await item.getByRole('button', { name: '通过' }).click()
    await expect(ap.locator('li').filter({ hasText: `E2E 我当天没去 ${RUN}` })).toHaveCount(0)

    // Summary and history agree with the corrected evidence.
    expect(await rpcAs<{ self_reported_presence: number }>(reporter, 'trust_summary')).toMatchObject({ self_reported_presence: 0 })
    await up.reload()
    await expect(up.locator('.card').filter({ hasText: event.title })).toContainText('已撤销')
    await up.goto('/me')
    await expect(up.locator('section').filter({ hasText: '参与记录' }).locator('div').filter({ hasText: '扫码 + 定位签到' }).locator('dd')).toHaveText('0')
  })

  test('admin switches a feature off and on from the flags page', async ({ browser }) => {
    const ctx = await contextAs(browser, admin); contexts.push(ctx)
    const page = await ctx.newPage()
    try {
      await page.goto('/admin/flags')
      const toggle = page.getByRole('button', { name: '附近 50 米加好友' })
      await expect(toggle).toHaveAttribute('aria-pressed', 'true')
      page.once('dialog', (d) => { expect(d.message()).toContain('关闭「附近 50 米加好友」'); void d.accept() })
      await toggle.click()
      await expect(toggle).toHaveAttribute('aria-pressed', 'false')
      expect((await db.select<{ enabled: boolean }>('feature_flags', 'key=eq.nearby&select=enabled'))[0]!.enabled).toBe(false)

      page.once('dialog', (d) => d.accept())
      await toggle.click()
      await expect(toggle).toHaveAttribute('aria-pressed', 'true')

      await page.goto('/admin/audit')
      await page.locator('select').selectOption('feature_flags')
      const entry = page.locator('li').filter({ hasText: admin.name }).first()
      await entry.getByRole('button').click()
      await expect(entry.locator('td', { hasText: 'enabled' })).toBeVisible()
    } finally {
      await setFlag('nearby', true)
    }
  })

  test('non-admins cannot flip flags or resolve corrections through the API', async () => {
    const flip = await restAs(bystander, 'feature_flags?key=eq.qr_checkin', { method: 'PATCH', body: { enabled: false } })
    expect(flip.data).toEqual([]) // RLS: zero rows updated
    expect((await db.select<{ enabled: boolean }>('feature_flags', 'key=eq.qr_checkin&select=enabled'))[0]!.enabled).toBe(true)
    const audit = await restAs(bystander, 'audit_log?select=id&limit=1')
    expect(audit.data).toEqual([])
    const resolve = await rpcAs(bystander, 'admin_set_evidence_status', { p_evidence: '00000000-0000-0000-0000-000000000000', p_status: 'verified', p_note: 'x' }).then(() => 'ok', (e: Error) => e.message)
    expect(resolve).toContain('forbidden')
  })
})
