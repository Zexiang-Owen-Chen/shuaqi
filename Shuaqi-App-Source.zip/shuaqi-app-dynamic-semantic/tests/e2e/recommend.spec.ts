import { expect, test, type BrowserContext } from '@playwright/test'
import { RUN, contextAs, createEvent, createUser, db, type TestUser } from './support/backend'

// 为你推荐: the server route ranks events for the signed-in user; the database enforces who may
// see what, rate limits and the flag. Runs without any AI provider configured (keyword rules only).

test.describe.serial('recommendations', () => {
  let user: TestUser, host: TestUser, admin: TestUser
  const contexts: BrowserContext[] = []
  const inDays = (d: number) => new Date(Date.now() + d * 86_400_000).toISOString()

  test.beforeAll(async () => {
    ;[user, host, admin] = await Promise.all([createUser('RecoUser'), createUser('RecoHost'), createUser('RecoAdmin', { role: 'admin' })])
    await createEvent(host, {
      title: `羽毛球双打 ${RUN}`, category: '运动', description: '新手友好的羽毛球局，球拍可以借。',
      starts_at: inDays(2), ends_at: inDays(2.1), checkin_mode: 'none',
    })
    await createEvent(host, {
      title: `Knitting circle ${RUN}`, category: '其他', description: 'Yarn and tea.',
      starts_at: inDays(2), ends_at: inDays(2.1), checkin_mode: 'none',
    })
  })
  test.afterAll(async () => { await Promise.all(contexts.map((c) => c.close())) })

  test('a search ranks the matching event first and explains why', async ({ browser }) => {
    const ctx = await contextAs(browser, user)
    contexts.push(ctx)
    const page = await ctx.newPage()
    await page.goto('/recommend')
    await page.getByLabel('说说你想做什么').fill(`羽毛球 ${RUN}`)
    await page.getByRole('button', { name: '找' }).click()
    const first = page.locator('ul > li').first()
    await expect(first).toContainText(`羽毛球双打 ${RUN}`)
    await expect(first).toContainText('符合你的搜索')
    await expect(page.getByText('已理解：运动')).toBeVisible()

    const shown = await db.select('recommendation_events', `user_id=eq.${user.id}&kind=eq.impression&select=event_id`)
    expect(shown.length).toBeGreaterThan(0)
  })

  test('不感兴趣 hides an event from later recommendations', async ({ browser }) => {
    const ctx = await contextAs(browser, user)
    contexts.push(ctx)
    const page = await ctx.newPage()
    await page.goto(`/recommend?q=${encodeURIComponent(`Knitting ${RUN}`)}`)
    const item = page.locator('ul > li', { hasText: `Knitting circle ${RUN}` })
    await expect(item).toBeVisible()
    await item.getByRole('button', { name: '不感兴趣' }).click()
    await expect(item).toHaveCount(0)
    await expect.poll(async () => (await db.select('recommendation_events', `user_id=eq.${user.id}&kind=eq.dismiss`)).length).toBe(1)
    await page.reload()
    await expect(page.locator('ul > li').first().or(page.getByText('没有找到合适的活动'))).toBeVisible()
    await expect(page.locator('ul > li', { hasText: `Knitting circle ${RUN}` })).toHaveCount(0)
  })

  test('the API needs a session and limits request rate', async ({ browser, request }) => {
    const anon = await request.post('/api/recommendations', { data: { query: 'x' } })
    expect(anon.status()).toBe(401)

    const busy = await createUser('RecoBusy')
    const ctx = await contextAs(browser, busy)
    contexts.push(ctx)
    const statuses: number[] = []
    for (let i = 0; i < 11; i++) statuses.push((await ctx.request.post('/api/recommendations', { data: { query: 'football' } })).status())
    expect(statuses.slice(0, 10).every((s) => s === 200)).toBe(true)
    expect(statuses[10]).toBe(429)
  })

  test('an admin picks the language model; keys stay on the server', async ({ browser }) => {
    const ctx = await contextAs(browser, admin)
    contexts.push(ctx)
    const page = await ctx.newPage()
    await page.goto('/admin/recommendations')
    await page.getByLabel('提供方').first().selectOption('anthropic')
    await expect(page.getByLabel('模型').first()).toHaveAttribute('placeholder', 'claude-haiku-5-5')
    await page.getByRole('button', { name: '保存' }).click()
    await expect(page.getByText('已保存')).toBeVisible()
    try {
      expect((await db.select('recommendation_settings', 'select=llm_provider,updated_by'))[0])
        .toEqual({ llm_provider: 'anthropic', updated_by: admin.id })
      const providers = await ctx.request.get('/api/recommendations/providers')
      expect(JSON.stringify(await providers.json())).not.toMatch(/sk-|key":"/)
    } finally {
      await db.update('recommendation_settings', 'id=eq.true', { llm_provider: 'none', llm_model: '' })
    }

    const userCtx = await contextAs(browser, user)
    contexts.push(userCtx)
    expect((await userCtx.request.get('/api/recommendations/providers')).status()).toBe(403)
  })
})
