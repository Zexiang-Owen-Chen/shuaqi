import { expect, test, type Page } from '@playwright/test'
import { RUN, contextAs, createEvent, createUser, db, type TestUser } from './support/backend'

// People within 50 m: the standalone "加好友" page, event nearby without check-in, and the
// arrival prompt on a confirmed shared plan. Each test uses its own spot, shifted at random per
// run, so positions left by other tests or earlier runs (kept up to 5 minutes) never show up.

const jitter = () => (Math.random() - 0.5) * 0.04 // up to ~2 km, per test
const spot = (lat: number, lng: number, northMetres = 0) =>
  ({ latitude: lat + northMetres / 111_320, longitude: lng, accuracy: 10 })

async function switchOn(page: Page, button: string | RegExp) {
  await page.getByRole('button', { name: button }).click()
  // First time: the consent step appears; afterwards it switches on straight away.
  const agree = page.getByRole('button', { name: '同意并继续' })
  const off = page.getByRole('button', { name: '关闭', exact: true })
  await expect(agree.or(off)).toBeVisible()
  if (await agree.isVisible()) await agree.click()
  await expect(off).toBeVisible()
}

test.describe.serial('people within 50 m', () => {
  let alice: TestUser, bob: TestUser, carol: TestUser
  test.beforeAll(async () => {
    ;[alice, bob, carol] = await Promise.all([
      createUser('NearAlice'), createUser('NearBob', { domain: 'lse.ac.uk' }), createUser('NearCarol'),
    ])
  })

  test('add friends nearby without any event', async ({ browser }) => {
    const [lat, lng] = [51.5226 + jitter(), -0.1257] // Russell Square
    const a = await (await contextAs(browser, alice, { geolocation: spot(lat, lng) })).newPage()
    await a.goto('/me/connections')
    await a.getByRole('link', { name: '＋ 加附近的人' }).click()
    await expect(a).toHaveURL(/\/nearby$/)
    await a.getByRole('button', { name: '开启附近的人' }).click()
    await expect(a.getByText('使用你的位置找附近的人')).toBeVisible()
    await a.getByRole('button', { name: '同意并继续' }).click()
    await expect(a.getByText('已开启')).toBeVisible()

    const c = await (await contextAs(browser, carol, { geolocation: spot(lat, lng, 90) })).newPage()
    await c.goto('/nearby')
    await switchOn(c, '开启附近的人')
    await expect(c.getByText('50 米内暂时没有开启的人')).toBeVisible()

    const b = await (await contextAs(browser, bob, { geolocation: spot(lat, lng, 30) })).newPage()
    await b.goto('/nearby')
    await switchOn(b, '开启附近的人')
    const row = b.getByRole('listitem').filter({ hasText: alice.name })
    await expect(row).toContainText('约 30 米')
    await expect(b.getByRole('listitem').filter({ hasText: carol.name })).toHaveCount(0)
    await row.getByRole('button', { name: '加好友' }).click()
    await expect(b.getByText('已发送好友请求')).toBeVisible()
    await expect(row).toContainText('请求待处理')

    const req = await db.select('connection_requests', `from_user=eq.${bob.id}&to_user=eq.${alice.id}&select=context,context_id`)
    expect(req).toEqual([{ context: 'nearby', context_id: null }])
    for (const p of [a, b, c]) await p.context().close()
  })

  test('event nearby works without checking in', async ({ browser }) => {
    const [lat, lng] = [51.5246 + jitter(), -0.134] // UCL Main Quad
    const ev = await createEvent(alice, { title: `附近测试 ${RUN}`, location_lat: lat, location_lng: lng })
    const c = await (await contextAs(browser, carol, { geolocation: spot(lat, lng) })).newPage()
    await c.goto(`/events/${ev.id}/nearby`)
    await expect(c.getByText('签到后才能使用')).toHaveCount(0)
    await switchOn(c, '开启附近的人')
    await expect(c.getByText('已开启')).toBeVisible()

    const a = await (await contextAs(browser, alice, { geolocation: spot(lat, lng, 20) })).newPage()
    await a.goto(`/events/${ev.id}/nearby`)
    await switchOn(a, '开启附近的人')
    await expect(a.getByRole('listitem').filter({ hasText: carol.name })).toContainText('约 20 米')
    await a.context().close()
    await c.context().close()
  })

  test('shared plan prompts both people to add each other once they are within 50 m', async ({ browser }) => {
    const [lat, lng] = [51.5033 + jitter(), -0.1196] // South Bank
    const now = Date.now()
    const intent = (u: TestUser) => db.insert<{ id: string }>('intents', {
      user_id: u.id, activity_type: 'coffee', region: 'London',
      window_start: new Date(now).toISOString(), window_end: new Date(now + 2 * 3600e3).toISOString(),
      expires_at: new Date(now + 3600e3).toISOString(), status: 'matched',
    })
    const [ia, ic] = await Promise.all([intent(alice), intent(carol)])
    const inv = await db.insert<{ id: string }>('match_invitations', {
      from_intent_id: ia.id, to_intent_id: ic.id, from_user: alice.id, to_user: carol.id, status: 'accepted',
    })
    const plan = await db.insert<{ id: string }>('shared_plans', {
      invitation_id: inv.id, user_a: alice.id, user_b: carol.id, title: `咖啡 ${RUN}`,
      planned_at: new Date(now + 10 * 60_000).toISOString(), place: 'South Bank', status: 'confirmed',
      a_confirmed_at: new Date(now).toISOString(), b_confirmed_at: new Date(now).toISOString(),
    })

    const a = await (await contextAs(browser, alice, { geolocation: spot(lat, lng) })).newPage()
    await a.goto(`/buddy/plans/${plan.id}`)
    await switchOn(a, /我到了/)
    await expect(a.getByText(`正在等${carol.name}到达`)).toBeVisible()

    const c = await (await contextAs(browser, carol, { geolocation: spot(lat, lng, 28) })).newPage()
    await c.goto(`/buddy/plans/${plan.id}`)
    await switchOn(c, /我到了/)
    await expect(c.getByText(`${alice.name}就在你附近（约 30 米）`)).toBeVisible()
    await c.getByRole('button', { name: `加 ${alice.name} 为好友` }).first().click()
    await expect(c.getByRole('button', { name: '已发送好友请求' }).first()).toBeVisible()

    // Alice's page picks Carol up on its next 30-second report.
    await expect(a.getByText(`${carol.name}就在你附近`)).toBeVisible({ timeout: 40_000 })
    for (const p of [a, c]) await p.context().close()
  })
})
