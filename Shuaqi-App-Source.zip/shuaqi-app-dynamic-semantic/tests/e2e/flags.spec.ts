import { expect, test, type BrowserContext, type Page } from '@playwright/test'
import {
  AT_VENUE, RUN, checkinCode, contextAs, createEvent, createUser, db, evidenceFor, rpcAs, setFlag,
  type EventRow, type FlagKey, type TestUser,
} from './support/backend'

// B-16: on launch day any module can be switched off in feature_flags. With each flag off the
// affected page still loads, explains in Chinese what is unavailable, and the server refuses the
// action (the switch is not just a hidden button). Every test restores its flag.

function londonInput(d: Date) {
  const p = Object.fromEntries(new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Europe/London', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
  }).formatToParts(d).map((x) => [x.type, x.value]))
  return `${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}`
}

/** Fails the test on uncaught page errors: "page still usable" means no crash, not just no blank screen. */
function watchErrors(page: Page) {
  const errors: string[] = []
  page.on('pageerror', (e) => errors.push(e.message))
  return errors
}

test.describe.serial('feature flags switched off (B-16)', () => {
  let host: TestUser, guest: TestUser
  let event: EventRow
  let code = ''
  const contexts: BrowserContext[] = []

  async function withFlagOff(key: FlagKey, body: () => Promise<void>) {
    await setFlag(key, false)
    try { await body() } finally { await setFlag(key, true) }
  }

  test.beforeAll(async () => {
    ;[host, guest] = await Promise.all([createUser('FlagHost'), createUser('FlagGuest')])
    event = await createEvent(host, { title: `E2E 开关活动 ${RUN}` })
    await rpcAs(guest, 'join_event', { p_event: event.id })
    code = await checkinCode(host, event.id)
  })
  test.afterAll(async () => {
    await Promise.all(contexts.map((c) => c.close()))
    // Belt and braces: never leave a flag off for the next spec.
    await db.update('feature_flags', 'enabled=eq.false', { enabled: true })
  })

  test('qr_checkin off: scanning explains to find staff, no evidence is written', async ({ browser }) => {
    await withFlagOff('qr_checkin', async () => {
      const ctx = await contextAs(browser, guest, { geolocation: AT_VENUE }); contexts.push(ctx)
      const page = await ctx.newPage()
      const errors = watchErrors(page)
      await page.goto(`/checkin/${code}`)
      await expect(page.getByText(event.title)).toBeVisible()
      // With the flag off the page says so up front; there is no button to press.
      await expect(page.getByRole('heading', { name: '扫码签到暂时关闭了' })).toBeVisible()
      await expect(page.getByText('请到入口找工作人员确认到场')).toBeVisible()
      await expect(page.getByRole('button', { name: '定位并签到' })).toHaveCount(0)
      expect(await evidenceFor(event.id, guest.id)).toEqual([])
      expect(errors).toEqual([])
    })
    // The paper-list fallback still works: staff confirmation is not behind the flag.
    await rpcAs(host, 'organiser_confirm_attendance', { p_event: event.id, p_user: guest.id, p_confirm: true })
    expect((await evidenceFor(event.id, guest.id)).map((e) => e.verification_status)).toEqual(['verified'])
  })

  test('nearby off: the nearby page says it is closed and points to the participant list', async ({ browser }) => {
    await withFlagOff('nearby', async () => {
      const ctx = await contextAs(browser, guest, { geolocation: AT_VENUE }); contexts.push(ctx)
      const page = await ctx.newPage()
      const errors = watchErrors(page)
      await page.goto(`/events/${event.id}/nearby`)
      await expect(page.getByText('“附近的人”暂时关闭了，可以在活动页的参与者名单里添加好友。')).toBeVisible()
      const refused = await rpcAs(guest, 'update_nearby_presence', { p_event: event.id, p_lat: AT_VENUE.latitude, p_lng: AT_VENUE.longitude, p_accuracy: 10 })
        .then(() => 'ok', (e: Error) => e.message)
      expect(refused).toContain('feature_disabled')
      expect(errors).toEqual([])
    })
  })

  test('event_discovery off: people page keeps working but the list shows the closed message', async ({ browser }) => {
    await withFlagOff('event_discovery', async () => {
      const ctx = await contextAs(browser, guest); contexts.push(ctx)
      const page = await ctx.newPage()
      const errors = watchErrors(page)
      await page.goto(`/events/${event.id}/people`)
      await expect(page.getByRole('heading', { name: '活动内找人' })).toBeVisible()
      await expect(page.getByText('活动内找人暂时关闭了')).toBeVisible()
      await expect(page.getByText('报名和签到不受影响')).toBeVisible()
      expect(errors).toEqual([])
    })
  })

  test('intents off: publishing a buddy request fails with a readable message', async ({ browser }) => {
    await withFlagOff('intents', async () => {
      const ctx = await contextAs(browser, guest); contexts.push(ctx)
      const page = await ctx.newPage()
      const errors = watchErrors(page)
      await page.goto('/buddy/new')
      // The form is replaced by an explanation; the database refuses inserts too.
      await expect(page.getByText('找搭子暂时关闭了')).toBeVisible()
      await expect(page.getByRole('button', { name: '发布并查看候选人' })).toHaveCount(0)
      const denied = await rpcAs(guest, 'match_candidates', { p_intent: '00000000-0000-0000-0000-000000000000' }).catch((e: Error) => e.message)
      expect(String(denied)).toMatch(/intent_not_found|feature_disabled/)
      await expect(page).toHaveURL(/\/buddy\/new$/)
      expect(await db.select('intents', `user_id=eq.${guest.id}&select=id`)).toEqual([])
      expect(errors).toEqual([])
    })
  })

  test('peer_event_creation off: students cannot publish, organisers still can', async ({ browser }) => {
    await withFlagOff('peer_event_creation', async () => {
      const ctx = await contextAs(browser, guest, { geolocation: AT_VENUE }); contexts.push(ctx)
      const page = await ctx.newPage()
      const errors = watchErrors(page)
      const title = `E2E 关闭后发起 ${RUN}`
      await page.goto('/create')
      await expect(page.getByText('暂时只有组织者可以发布活动')).toBeVisible()
      await expect(page.getByRole('button', { name: '发布活动' })).toHaveCount(0)
      // The server refuses too, not just the page.
      const refused = await createEvent(guest, { title }).then(() => 'created', (e: Error) => e.message)
      expect(refused).toContain('feature_disabled')
      await expect(page).toHaveURL(/\/create$/)
      expect(await db.select('events', `title=eq.${encodeURIComponent(title)}&select=id`)).toEqual([])
      expect(errors).toEqual([])

      const org = await db.insert<{ id: string }>('organisations', { name: `E2E 开关组织 ${RUN}` })
      await db.insert('org_members', { org_id: org.id, user_id: host.id, role: 'organiser' })
      const orgEvent = await createEvent(host, { org_id: org.id, title: `E2E 组织照常发起 ${RUN}` })
      expect(orgEvent.org_id).toBe(org.id)
    })
  })

  test('trust_card off: other people no longer see my record, I still see mine', async ({ browser }) => {
    const ctx = await contextAs(browser, host); contexts.push(ctx)
    const page = await ctx.newPage()
    await page.goto(`/u/${guest.id}`)
    await expect(page.getByText('主办方核验到场')).toBeVisible() // shown while the flag is on
    await withFlagOff('trust_card', async () => {
      const errors = watchErrors(page)
      await page.reload()
      await expect(page.getByText(guest.name)).toBeVisible()
      await expect(page.getByText('主办方核验到场')).toHaveCount(0)

      const own = await contextAs(browser, guest); contexts.push(own)
      const mine = await own.newPage()
      await mine.goto('/me')
      // Degraded mode: my own page keeps a single line with the verified attendance count.
      await expect(mine.locator('section').filter({ hasText: '已核验到场' })).toContainText('已核验到场 1 次')
      expect(errors).toEqual([])
    })
  })
})
