import { execSync } from 'node:child_process'
import type { Browser, BrowserContext, Geolocation } from '@playwright/test'

// Test-side access to the local Supabase used by the e2e run.
//
// Users are created through the Auth admin API and signed in by putting a real session into the
// browser's auth cookie, so these specs do not send e-mail (local Auth limits OTP mails per hour;
// the OTP login screen itself is covered by smoke.spec.ts). Everything a test asserts on still goes
// through the app's pages; this file only does setup and reads back what the database recorded.
//
// Env: SUPABASE_URL, SUPABASE_KEY (anon) and SUPABASE_SERVICE_KEY. When unset they are read from
// `npx supabase status -o env`.

type Env = { url: string; anon: string; service: string }
let cached: Env | null = null

export function env(): Env {
  if (cached) return cached
  let url = process.env.SUPABASE_URL
  let anon = process.env.SUPABASE_KEY ?? process.env.SUPABASE_ANON_KEY
  let service = process.env.SUPABASE_SERVICE_KEY ?? process.env.SUPABASE_SERVICE_ROLE_KEY ?? process.env.NUXT_SUPABASE_SERVICE_KEY
  if (!url || !anon || !service) {
    const out = execSync('npx supabase status -o env', { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] })
    const v = Object.fromEntries(out.split('\n').map((l) => /^(\w+)="?(.*?)"?$/.exec(l.trim())).filter(Boolean).map((m) => [m![1], m![2]]))
    url ??= v.API_URL
    anon ??= v.ANON_KEY
    service ??= v.SERVICE_ROLE_KEY
  }
  if (!url || !anon || !service) throw new Error('Set SUPABASE_URL, SUPABASE_KEY and SUPABASE_SERVICE_KEY for the e2e run')
  cached = { url: url.replace(/\/$/, ''), anon, service }
  return cached
}

/** Unique per test run, so runs can share a database. */
export const RUN = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 5)}`

export type Session = { access_token: string; refresh_token: string; expires_at: number; expires_in: number; token_type: string; user: { id: string; email: string } }
export type TestUser = { id: string; email: string; name: string; session: Session }

async function call<T>(path: string, init: { method?: string; token?: string; body?: unknown; prefer?: string } = {}): Promise<T> {
  const { url, anon, service } = env()
  const token = init.token ?? service
  const res = await fetch(url + path, {
    method: init.method ?? (init.body === undefined ? 'GET' : 'POST'),
    headers: {
      apikey: token === service ? service : anon,
      authorization: `Bearer ${token}`,
      'content-type': 'application/json',
      ...(init.prefer ? { prefer: init.prefer } : {}),
    },
    body: init.body === undefined ? undefined : JSON.stringify(init.body),
  })
  const text = await res.text()
  const data = text ? JSON.parse(text) : null
  if (!res.ok) throw Object.assign(new Error(`${init.method ?? 'POST'} ${path} -> ${res.status}: ${text}`), { status: res.status, data })
  return data as T
}

/** PostgREST as the service role (bypasses RLS). For setup and read-back only. */
export const db = {
  select: <T = Record<string, unknown>>(table: string, query: string) => call<T[]>(`/rest/v1/${table}?${query}`),
  insert: <T = Record<string, unknown>>(table: string, row: object) =>
    call<T[]>(`/rest/v1/${table}`, { body: row, prefer: 'return=representation' }).then((r) => r[0]!),
  update: (table: string, query: string, patch: object) =>
    call(`/rest/v1/${table}?${query}`, { method: 'PATCH', body: patch, prefer: 'return=minimal' }),
}

/** Calls a Postgres function as `user` (or anonymously with `null`), exactly like the app does. */
export function rpcAs<T = unknown>(user: TestUser | null, fn: string, args: object = {}) {
  return call<T>(`/rest/v1/rpc/${fn}`, { body: args, token: user ? user.session.access_token : env().anon })
}

/** Raw PostgREST request as `user`; returns status and body instead of throwing. */
export async function restAs(user: TestUser | null, path: string, init: { method?: string; body?: unknown } = {}) {
  try {
    return { status: 200, data: await call<unknown>(`/rest/v1/${path}`, { ...init, token: user ? user.session.access_token : env().anon, prefer: 'return=representation' }) }
  } catch (e) {
    const err = e as Error & { status?: number; data?: unknown }
    return { status: err.status ?? 0, data: err.data }
  }
}

export async function signInSession(email: string): Promise<Session> {
  const link = await call<{ email_otp: string }>('/auth/v1/admin/generate_link', { body: { type: 'magiclink', email } })
  return call<Session>('/auth/v1/verify', { body: { type: 'email', email, token: link.email_otp }, token: env().anon })
}

/** Creates a confirmed G5 user with a finished profile and returns a signed-in session. */
export async function createUser(label: string, opts: { domain?: string; role?: 'user' | 'admin'; onboarded?: boolean } = {}): Promise<TestUser> {
  const email = `e2e-${label.toLowerCase()}-${RUN}@${opts.domain ?? 'ucl.ac.uk'}`
  const name = `${label}${RUN.slice(-4)}`
  const created = await call<{ id: string }>('/auth/v1/admin/users', { body: { email, email_confirm: true } })
  await db.update('profiles', `id=eq.${created.id}`, {
    display_name: name,
    gender: 'prefer_not_to_say',
    birth_year: 2002,
    region: 'South Kensington',
    interests: ['跑步'],
    onboarded: opts.onboarded ?? true,
    role: opts.role ?? 'user',
  })
  return { id: created.id, email, name, session: await signInSession(email) }
}

const CHUNK = 3180 // @supabase/ssr MAX_CHUNK_SIZE

/**
 * A browser context signed in as `user`: writes the session into the cookie @nuxtjs/supabase reads
 * (`sb-<host>-auth-token`, base64url, chunked like @supabase/ssr), so SSR and the client agree.
 */
export async function contextAs(browser: Browser, user: TestUser | null, opts: { geolocation?: Geolocation; baseURL?: string; userAgent?: string } = {}): Promise<BrowserContext> {
  const ctx = await browser.newContext({
    ...(opts.geolocation ? { geolocation: opts.geolocation, permissions: ['geolocation'] } : {}),
    ...(opts.userAgent ? { userAgent: opts.userAgent } : {}),
  })
  if (!user) return ctx
  const base = new URL(opts.baseURL ?? process.env.E2E_BASE_URL ?? `http://localhost:${process.env.E2E_PORT ?? 3000}`)
  // The cookie name is derived from the Supabase URL the app was built with; ask the app.
  const page = await ctx.newPage()
  await page.goto(new URL('/install', base).toString())
  const prefix = await page.evaluate(() => (window as unknown as { __NUXT__?: { config?: { public?: { supabase?: { cookiePrefix?: string } } } } })
    .__NUXT__?.config?.public?.supabase?.cookiePrefix)
  await page.close()
  const name = prefix ?? `sb-${new URL(env().url).hostname.split('.')[0]}-auth-token`
  const value = 'base64-' + Buffer.from(JSON.stringify(user.session)).toString('base64url')
  const parts = value.length <= CHUNK ? [[name, value]] : Array.from({ length: Math.ceil(value.length / CHUNK) }, (_, i) => [`${name}.${i}`, value.slice(i * CHUNK, (i + 1) * CHUNK)])
  await ctx.addCookies(parts.map(([n, v]) => ({ name: n!, value: v!, domain: base.hostname, path: '/', sameSite: 'Lax' as const, expires: Math.floor(Date.now() / 1000) + 3600 })))
  return ctx
}

// --- Places ---------------------------------------------------------------------------

/** Imperial College, Queen's Lawn. Events are placed here. */
export const VENUE = { latitude: 51.4988, longitude: -0.1749 }
/** About 40 m from the venue, good fix. */
export const AT_VENUE: Geolocation = { latitude: 51.49915, longitude: -0.1749, accuracy: 12 }
/** Hyde Park Corner, about 2.7 km away. */
export const FAR_AWAY: Geolocation = { latitude: 51.5027, longitude: -0.1527, accuracy: 12 }
/** At the venue but with a poor (indoor, Wi-Fi off) fix. */
export const POOR_FIX: Geolocation = { latitude: 51.4988, longitude: -0.1749, accuracy: 450 }

// --- Domain setup --------------------------------------------------------------------

export type EventRow = { id: string; title: string; host_user_id: string; org_id: string | null }

/** Creates an event as `host` (through RLS and the events guard, like the create page). */
export async function createEvent(host: TestUser, fields: Record<string, unknown> = {}): Promise<EventRow> {
  const startsAt = new Date(Date.now() + 30 * 60_000) // check-in opens 1 h before start, so it is open now
  const rows = await call<EventRow[]>('/rest/v1/events', {
    token: host.session.access_token,
    prefer: 'return=representation',
    body: {
      host_user_id: host.id,
      category: '运动',
      title: `E2E 活动 ${RUN}`,
      description: 'Playwright e2e',
      starts_at: startsAt.toISOString(),
      ends_at: new Date(startsAt.getTime() + 2 * 3600e3).toISOString(),
      location_text: "Imperial College Queen's Lawn",
      location_lat: VENUE.latitude,
      location_lng: VENUE.longitude,
      checkin_mode: 'qr_geo',
      checkin_radius_m: 100,
      ...fields,
    },
  })
  return rows[0]!
}

export async function checkinCode(host: TestUser, eventId: string) {
  return rpcAs<string>(host, 'get_checkin_code', { p_event: eventId })
}

export async function evidenceFor(eventId: string, userId: string) {
  return db.select<{ type: string; verification_status: string }>('participation_evidence',
    `event_id=eq.${eventId}&subject_user_id=eq.${userId}&select=type,verification_status&order=occurred_at`)
}

export type FlagKey = 'intents' | 'event_discovery' | 'nearby' | 'qr_checkin' | 'trust_card' | 'peer_event_creation' | 'chat' | 'push'

export async function setFlag(key: FlagKey, enabled: boolean) {
  await db.update('feature_flags', `key=eq.${key}`, { enabled })
}
