import { expect, test, type BrowserContext, type Page } from '@playwright/test'
import { AT_VENUE, RUN, contextAs, createEvent, createUser, db, rpcAs, type TestUser } from './support/backend'

// Module D (organisations, roles, organiser back office) and B-08 in the browser:
// admin creates an organisation -> owner adds staff -> owner creates an org event -> staff confirms
// attendance -> an organiser from another organisation cannot see the roster.

function londonInput(d: Date) {
  const p = Object.fromEntries(new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Europe/London', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
  }).formatToParts(d).map((x) => [x.type, x.value]))
  return `${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}`
}

/** The form's labels are not bound to inputs; find the control in the same field block. */
const field = (page: Page, label: string) => page.locator('div').filter({ has: page.locator('label', { hasText: label }) }).last()

test.describe.serial('organiser back office', () => {
  const ORG = `E2E 学联 ${RUN}`
  let admin: TestUser, owner: TestUser, staff: TestUser, attendee: TestUser, rival: TestUser
  let orgId = '', eventId = ''
  const title = `E2E 组织活动 ${RUN}`
  const contexts: BrowserContext[] = []

  test.beforeAll(async () => {
    ;[admin, owner, staff, attendee, rival] = await Promise.all([
      createUser('Admin', { role: 'admin' }), createUser('Owner'), createUser('Staff', { domain: 'imperial.ac.uk' }),
      createUser('Attendee'), createUser('Rival', { domain: 'cam.ac.uk' }),
    ])
  })
  test.afterAll(async () => { await Promise.all(contexts.map((c) => c.close())) })

  test('admin creates the organisation with its owner', async ({ browser }) => {
    const ctx = await contextAs(browser, admin); contexts.push(ctx)
    const page = await ctx.newPage()
    await page.goto('/admin/orgs')
    await page.getByPlaceholder('组织名称，如 UCL CSSA').fill(ORG)
    await page.getByPlaceholder('负责人邮箱（可选，需已注册）').fill(owner.email)
    await page.getByRole('button', { name: '创建' }).click()
    const row = page.locator('li').filter({ hasText: ORG })
    await expect(row).toBeVisible()
    const org = await db.select<{ id: string }>('organisations', `name=eq.${encodeURIComponent(ORG)}&select=id`)
    orgId = org[0]!.id
    const members = await db.select<{ user_id: string; role: string }>('org_members', `org_id=eq.${orgId}&select=user_id,role`)
    expect(members).toEqual([{ user_id: owner.id, role: 'owner' }])
  })

  test('owner sees the organisation and adds a staff member by e-mail', async ({ browser }) => {
    const ctx = await contextAs(browser, owner); contexts.push(ctx)
    const page = await ctx.newPage()
    await page.goto('/organiser')
    await page.getByRole('link', { name: `${ORG} · 负责人` }).click()
    await expect(page).toHaveURL(new RegExp(`/organiser/orgs/${orgId}$`))
    await page.getByPlaceholder('对方注册 SHUAQI 用的邮箱').fill(staff.email)
    await page.locator('section').filter({ hasText: '添加成员' }).locator('select').selectOption('staff')
    await page.getByRole('button', { name: '添加', exact: true }).click()
    const row = page.locator('li').filter({ hasText: staff.name })
    await expect(row).toBeVisible()
    await expect(row.locator('select')).toHaveValue('staff')
  })

  test('owner creates an organisation event with QR + GPS check-in', async ({ browser }) => {
    const ctx = await contextAs(browser, owner, { geolocation: AT_VENUE }); contexts.push(ctx)
    const page = await ctx.newPage()
    await page.goto('/organiser/events/new')
    await expect(field(page, '主办方').locator('select')).toHaveValue(orgId)
    await field(page, '活动标题').locator('input').fill(title)
    await field(page, '简介').locator('textarea').fill('E2E organiser test')
    const start = new Date(Date.now() + 30 * 60_000)
    await field(page, '开始时间（伦敦时间）').locator('input').fill(londonInput(start))
    await field(page, '结束时间').locator('input').fill(londonInput(new Date(start.getTime() + 2 * 3600e3)))
    await field(page, '地点名称（显示给用户）').locator('input').fill("Imperial College Queen's Lawn")
    await page.getByRole('button', { name: '用我现在的位置' }).click()
    await page.getByRole('button', { name: '创建活动' }).click()

    await expect(page).toHaveURL(/\/organiser\/events\/[0-9a-f-]{36}$/)
    eventId = page.url().split('/').pop()!
    await expect(page.getByText(ORG, { exact: true })).toBeVisible()
    await expect(page.getByText(/签到方式：扫码 \+ 定位/)).toBeVisible()
    await expect(page.getByRole('link', { name: '展示签到码' })).toBeVisible()
    const [ev] = await db.select<{ org_id: string; host_user_id: string; checkin_mode: string; location_lat: number }>('events', `id=eq.${eventId}&select=org_id,host_user_id,checkin_mode,location_lat`)
    expect(ev).toMatchObject({ org_id: orgId, host_user_id: owner.id, checkin_mode: 'qr_geo' })
    expect(ev!.location_lat).toBeCloseTo(AT_VENUE.latitude, 3)
  })

  test('staff sees the roster, confirms a GPS check-in, but cannot manage the event', async ({ browser }) => {
    await rpcAs(attendee, 'join_event', { p_event: eventId })
    const code = await rpcAs<string>(owner, 'get_checkin_code', { p_event: eventId })
    const r = await rpcAs<{ ok: boolean }>(attendee, 'event_checkin', { p_code: code, p_lat: AT_VENUE.latitude, p_lng: AT_VENUE.longitude, p_accuracy: 12 })
    expect(r.ok).toBe(true)

    const ctx = await contextAs(browser, staff); contexts.push(ctx)
    const page = await ctx.newPage()
    await page.goto('/organiser')
    await page.getByRole('link', { name: new RegExp(title) }).click()
    await expect(page).toHaveURL(new RegExp(`/organiser/events/${eventId}$`))
    const row = page.locator('li').filter({ hasText: attendee.name })
    await expect(row).toBeVisible()
    await expect(row).toContainText(/定位/)
    await row.getByRole('button', { name: '确认到场' }).click()
    await expect(row.getByRole('button', { name: '撤销确认' })).toBeVisible()

    // Staff role: no edit / cancel / rotate.
    await expect(page.getByRole('heading', { name: '活动管理' })).toHaveCount(0)
    await expect(page.getByRole('link', { name: '编辑' })).toHaveCount(0)
    const rotate = await rpcAs(staff, 'rotate_checkin_code', { p_event: eventId }).then(() => 'ok', (e: Error) => e.message)
    expect(rotate).toContain('forbidden')

    const ev = await db.select<{ verification_status: string; operator_id: string }>('participation_evidence',
      `event_id=eq.${eventId}&subject_user_id=eq.${attendee.id}&type=eq.organiser_confirmed_attendance&select=verification_status,operator_id`)
    expect(ev).toEqual([{ verification_status: 'verified', operator_id: staff.id }])
  })

  test('an organiser of another organisation cannot read this roster (B-08)', async ({ browser }) => {
    const rivalOrg = await db.insert<{ id: string }>('organisations', { name: `E2E 对手社团 ${RUN}` })
    await db.insert('org_members', { org_id: rivalOrg.id, user_id: rival.id, role: 'owner' })
    // A rival event so the rival really is an organiser somewhere.
    await createEvent(rival, { org_id: rivalOrg.id, title: `E2E 对手活动 ${RUN}` })

    const ctx = await contextAs(browser, rival); contexts.push(ctx)
    const page = await ctx.newPage()
    await page.goto(`/organiser/events/${eventId}`)
    await expect(page.getByText('你不是这个活动的发起人或工作人员')).toBeVisible()
    await expect(page.getByText(attendee.name)).toHaveCount(0)
    await expect(page.getByRole('button', { name: '确认到场' })).toHaveCount(0)

    const direct = await rpcAs(rival, 'list_event_attendees', { p_event: eventId }).then(() => 'ok', (e: Error) => e.message)
    expect(direct).toContain('forbidden')
    const confirm = await rpcAs(rival, 'organiser_confirm_attendance', { p_event: eventId, p_user: attendee.id, p_confirm: false }).then(() => 'ok', (e: Error) => e.message)
    expect(confirm).toContain('forbidden')
  })

  test('owner removes the staff member, who then loses roster access', async ({ browser }) => {
    const ctx = await contextAs(browser, owner); contexts.push(ctx)
    const page = await ctx.newPage()
    await page.goto(`/organiser/orgs/${orgId}`)
    page.once('dialog', (d) => d.accept())
    await page.locator('li').filter({ hasText: staff.name }).getByRole('button', { name: '移出' }).click()
    await expect(page.locator('li').filter({ hasText: staff.name })).toHaveCount(0)
    const after = await rpcAs(staff, 'list_event_attendees', { p_event: eventId }).then(() => 'ok', (e: Error) => e.message)
    expect(after).toContain('forbidden')
  })
})
