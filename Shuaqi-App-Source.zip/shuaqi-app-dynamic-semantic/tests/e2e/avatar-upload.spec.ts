import { expect, test } from '@playwright/test'
import { contextAs, createUser, db } from './support/backend'

test('profile uploads PNG, JPEG and WebP avatars and saves the latest image', async ({ browser }) => {
  const user = await createUser('AvatarUpload')
  const ctx = await contextAs(browser, user)
  const page = await ctx.newPage()
  try {
    await page.goto('/me/edit')
    await page.waitForLoadState('networkidle')
    const paths: string[] = []
    for (const mimeType of ['image/png', 'image/jpeg', 'image/webp']) {
      const image = await page.evaluate((type) => {
        const canvas = document.createElement('canvas')
        canvas.width = canvas.height = 8
        const context = canvas.getContext('2d')!
        context.fillStyle = '#ea580c'
        context.fillRect(0, 0, 8, 8)
        return canvas.toDataURL(type).split(',')[1]!
      }, mimeType)
      const response = page.waitForResponse(r => r.url().includes('/storage/v1/object/avatars/') && r.request().method() === 'POST', { timeout: 15_000 })
      await page.locator('form input[type=file]').setInputFiles({
        name: `avatar.${mimeType.split('/')[1]}`, mimeType,
        buffer: Buffer.from(image, 'base64'),
      })
      const upload = await response
      expect(upload.ok()).toBe(true)
      expect(upload.request().headers()['x-upsert']).not.toBe('true')
      paths.push(new URL(upload.url()).pathname)
      await expect(page.getByText('上传中…')).toHaveCount(0)
      await expect(page.getByRole('alert')).toHaveCount(0)
      await expect.poll(() => page.locator('form img').first().evaluate((img: HTMLImageElement) => img.complete && img.naturalWidth > 0)).toBe(true)
    }
    expect(new Set(paths).size).toBe(3)
    await page.getByRole('button', { name: '保存', exact: true }).click()
    await expect(page).toHaveURL(/\/me$/)
    const [profile] = await db.select<{ avatar_url: string }>('profiles', `id=eq.${user.id}&select=avatar_url`)
    expect(profile?.avatar_url).toBeTruthy()
    expect(paths.at(-1)).toContain(profile!.avatar_url)
    await page.goto('/me/edit')
    await page.reload()
    const avatar = page.locator('form img').first()
    await expect(avatar).toHaveAttribute('src', new RegExp(profile!.avatar_url.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')))
    await expect.poll(() => avatar.evaluate((img: HTMLImageElement) => img.complete && img.naturalWidth > 0)).toBe(true)
    await page.screenshot({ path: 'test-results/avatar-upload-verified.png', fullPage: true })
  } finally {
    await ctx.close()
  }
})

test('avatar upload shows a server failure and recovers on retry', async ({ browser }) => {
  const user = await createUser('AvatarServerRetry')
  const ctx = await contextAs(browser, user)
  const page = await ctx.newPage()
  try {
    await page.goto('/me/edit')
    await page.waitForLoadState('networkidle')
    const image = {
      name: 'retry.png', mimeType: 'image/png',
      buffer: Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=', 'base64'),
    }
    await page.route('**/storage/v1/object/avatars/**', route => route.fulfill({
      status: 403, contentType: 'application/json', body: JSON.stringify({ message: 'test upload denied' }),
    }))
    await page.locator('form input[type=file]').setInputFiles(image)
    await expect(page.getByRole('alert')).toContainText('上传失败')
    await expect(page.getByText('上传中…')).toHaveCount(0)
    await page.unroute('**/storage/v1/object/avatars/**')
    const response = page.waitForResponse(r => r.url().includes('/storage/v1/object/avatars/') && r.request().method() === 'POST', { timeout: 15_000 })
    await page.locator('form input[type=file]').setInputFiles({ ...image, name: 'retry-success.png' })
    expect((await response).ok()).toBe(true)
    await expect(page.getByRole('alert')).toHaveCount(0)
  } finally {
    await ctx.close()
  }
})

test('avatar upload recovers after rejecting an oversized image', async ({ browser }) => {
  const user = await createUser('AvatarRetry')
  const ctx = await contextAs(browser, user)
  const page = await ctx.newPage()
  try {
    await page.goto('/me/edit')
    await page.waitForLoadState('networkidle')
    await page.locator('form input[type=file]').setInputFiles({
      name: 'too-large.png', mimeType: 'image/png', buffer: Buffer.alloc(5 * 1024 * 1024 + 1),
    })
    await expect(page.getByRole('alert')).toHaveText('图片不能超过 5MB')
    const response = page.waitForResponse(r => r.url().includes('/storage/v1/object/avatars/') && r.request().method() === 'POST', { timeout: 15_000 })
    await page.locator('form input[type=file]').setInputFiles({
      name: 'valid.png', mimeType: 'image/png',
      buffer: Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=', 'base64'),
    })
    expect((await response).ok()).toBe(true)
    await expect(page.getByRole('alert')).toHaveCount(0)
    await expect(page.getByRole('button', { name: '保存', exact: true })).toBeEnabled()
  } finally {
    await ctx.close()
  }
})
