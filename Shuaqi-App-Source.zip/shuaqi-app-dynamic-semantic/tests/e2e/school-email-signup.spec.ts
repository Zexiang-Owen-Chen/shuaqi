import { expect, test, type Page } from '@playwright/test'
import { db, env, RUN } from './support/backend'

const MAILPIT = process.env.MAILPIT_URL ?? 'http://127.0.0.1:54324'

async function signIn(page: Page, input: string, canonical: string) {
  await page.goto('/login')
  await expect(page.getByText('目前支持：')).not.toContainText('支持的英国院校')
  await page.locator('#email').fill(input)
  const sent = page.waitForResponse(r => r.url().includes('/auth/v1/otp') && r.request().method() === 'POST')
  await page.getByRole('button', { name: '发送验证码' }).click()
  const otpResponse = await sent
  expect(otpResponse.request().postDataJSON().email).toBe(canonical)
  expect(otpResponse.ok()).toBe(true)
  await expect(page.locator('#code')).toBeVisible()
  await expect(page.getByText('验证码已发送到')).toContainText(canonical)

  let code: string | undefined
  await expect.poll(async () => {
    const res = await fetch(`${MAILPIT}/api/v1/search?query=${encodeURIComponent(`to:"${canonical}"`)}&limit=1`)
    if (!res.ok) return false
    const { messages } = await res.json() as { messages?: { ID: string }[] }
    if (!messages?.[0]) return false
    const mail = await (await fetch(`${MAILPIT}/api/v1/message/${messages[0].ID}`)).json() as { Text: string }
    code = /\b(\d{6})\b/.exec(mail.Text)?.[1]
    return Boolean(code)
  }, { timeout: 20_000 }).toBe(true)

  await page.locator('#code').fill(code!)
  const verified = page.waitForResponse(r => r.url().includes('/auth/v1/verify') && r.request().method() === 'POST')
  await page.getByRole('button', { name: '登录', exact: true }).click()
  const response = await verified
  expect(response.request().postDataJSON().email).toBe(canonical)
  expect(response.ok()).toBe(true)
  const session = await response.json() as { user: { id: string; email: string } }
  expect(session.user.email).toBe(canonical)
  return session.user.id
}

for (const domain of ['ic.ac.uk', 'imperial.ac.uk', 'kcl.ac.uk', 'ual.ac.uk']) {
  test(`new school user can register with ${domain}`, async ({ page }) => {
    const localPart = `e2e-school-${domain.split('.')[0]}-${RUN}`
    const canonicalDomain = domain === 'ic.ac.uk' ? 'imperial.ac.uk' : domain
    const id = await signIn(page, `${localPart}@${domain}`, `${localPart}@${canonicalDomain}`)
    await expect(page).toHaveURL(/\/onboarding/)
    const [profile] = await db.select<{ school_domain: string; school_verified_at: string | null }>('profiles', `id=eq.${id}&select=school_domain,school_verified_at`)
    expect(profile?.school_domain).toBe(canonicalDomain)
    expect(profile?.school_verified_at).toBeTruthy()
    if (domain === 'kcl.ac.uk' || domain === 'ual.ac.uk') {
      await page.locator('#pf-name').fill(domain === 'ual.ac.uk' ? 'UAL Student' : 'KCL Student')
      await page.locator('#pf-gender').selectOption('prefer_not_to_say')
      await page.locator('#pf-year').fill('2002')
      await page.locator('#pf-region-city').selectOption('London')
      await page.locator('#pf-region').selectOption('London / South Bank / Southwark')
      await page.getByRole('button', { name: '跑步', exact: true }).click()
      await page.getByRole('button', { name: '开始使用', exact: true }).click()
      await expect(page).toHaveURL(/\/$/)
      await page.goto('/me')
      await expect(page.getByText(`${domain === 'ual.ac.uk' ? '伦敦艺术大学' : '伦敦国王学院'} 邮箱已验证`, { exact: false })).toBeVisible()
      await page.screenshot({ path: `test-results/${domain.split('.')[0]}-school-verified.png`, fullPage: false })
    }
  })
}

test('short email logs into an existing full-domain account', async ({ page }) => {
  // Create the existing account without generating a login code during setup.
  const { url, service } = env()
  const email = `e2e-imperial-existing-${RUN}@imperial.ac.uk`
  const created = await fetch(`${url}/auth/v1/admin/users`, {
    method: 'POST',
    headers: { apikey: service, authorization: `Bearer ${service}`, 'content-type': 'application/json' },
    body: JSON.stringify({ email, email_confirm: true }),
  })
  expect(created.ok).toBe(true)
  const user = await created.json() as { id: string }
  await db.update('profiles', `id=eq.${user.id}`, { display_name: 'Imperial Existing', region: 'Oxford', onboarded: true })
  const id = await signIn(page, email.replace('@imperial.ac.uk', '@ic.ac.uk'), email)
  expect(id).toBe(user.id)
  await expect(page).toHaveURL(/\/$/)
})

test('look-alike school domains are still rejected before requesting an OTP', async ({ page }) => {
  await page.goto('/login')
  await expect(page.getByText('目前支持：')).not.toContainText('支持的英国院校')
  let otpRequests = 0
  page.on('request', r => { if (r.url().includes('/auth/v1/otp') && r.method() === 'POST') otpRequests++ })
  for (const domain of ['fakeic.ac.uk', 'ic.ac.uk.evil.com', 'fakekcl.ac.uk', 'kcl.ac.uk.evil.com', 'fakeual.ac.uk', 'ual.ac.uk.evil.com']) {
    await page.locator('#email').fill(`e2e-${RUN}@${domain}`)
    await page.getByRole('button', { name: '发送验证码' }).click()
    await expect(page.getByRole('alert')).toContainText('请使用已支持的学校邮箱')
    await expect(page.locator('#code')).toHaveCount(0)
  }
  expect(otpRequests).toBe(0)
})
