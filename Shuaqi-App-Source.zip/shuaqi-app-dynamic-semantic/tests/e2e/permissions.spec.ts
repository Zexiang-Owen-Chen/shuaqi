import { expect, test } from '@playwright/test'
import { AT_VENUE, RUN, checkinCode, contextAs, createEvent, createUser, db, env, restAs, rpcAs, type TestUser } from './support/backend'

// Principle 10: every permission is enforced by the database, not by hidden buttons. Each test
// tries the forbidden thing the way a curious user would (in the browser, then straight against
// the API with their own token) and checks nothing changed.

test.describe('signed-out visitors', () => {
  for (const path of ['/me', '/me/history', '/my-events', '/buddy', '/organiser', '/admin']) {
    test(`${path} sends them to log in`, async ({ page }) => {
      await page.goto(path)
      await expect(page).toHaveURL((u) => u.pathname === '/login')
      await expect(page.getByRole('button', { name: '发送验证码' })).toBeVisible()
    })
  }

  test('anonymous API calls cannot read people or records', async () => {
    for (const table of ['profiles', 'event_rsvps', 'participation_evidence', 'connections', 'reports', 'audit_log']) {
      const r = await restAs(null, `${table}?select=*&limit=1`)
      expect(r.status === 401 || (Array.isArray(r.data) && r.data.length === 0), `${table}: ${JSON.stringify(r)}`).toBe(true)
    }
  })

  test('the school-domain gate is enforced by Auth, not just the login form', async () => {
    const { url, anon } = env()
    const res = await fetch(`${url}/auth/v1/otp`, {
      method: 'POST',
      headers: { apikey: anon, 'content-type': 'application/json' },
      body: JSON.stringify({ email: `e2e-${RUN}@gmail.com`, create_user: true }),
    })
    expect(res.ok).toBe(false)
    const users = await fetch(`${url}/auth/v1/admin/users?per_page=1000`, { headers: { apikey: env().service, authorization: `Bearer ${env().service}` } })
    const { users: list } = await users.json() as { users: { email: string }[] }
    expect(list.some((u) => u.email === `e2e-${RUN}@gmail.com`)).toBe(false)
  })
})

test.describe('signed-in users cannot reach past their role', () => {
  let alice: TestUser, bob: TestUser, carol: TestUser
  test.beforeAll(async () => {
    ;[alice, bob, carol] = await Promise.all([createUser('Alice'), createUser('Bob'), createUser('Carol', { domain: 'cam.ac.uk' })])
  })

  test('region stays public while optional hidden fields stay hidden (B-01)', async ({ browser }) => {
    await restAs(bob, `profiles?id=eq.${bob.id}`, {
      method: 'PATCH',
      body: { region: 'Camden', bio: `E2E秘密介绍${RUN}`, visibility: { bio: 'hidden', interests: 'public', photos: 'public', gender: 'public', age: 'public', region: 'hidden' } },
    })
    const ctx = await contextAs(browser, alice)
    const page = await ctx.newPage()
    await page.goto(`/u/${bob.id}`)
    await expect(page.getByText(bob.name)).toBeVisible()
    await expect(page.getByText(`E2E秘密介绍${RUN}`)).toHaveCount(0)
    await expect(page.getByText('London / Camden', { exact: false })).toBeVisible()
    // Reading the table directly returns nothing about Bob.
    expect((await restAs(alice, `profiles?id=eq.${bob.id}&select=region`)).data).toEqual([])
    const card = await rpcAs<Record<string, unknown>>(alice, 'get_profile_card', { p_target: bob.id })
    expect(card.region).toBe('London / Camden')
    expect(card.bio).toBeUndefined()
    await ctx.close()
  })

  test('users cannot make themselves admin or verified', async () => {
    const role = await restAs(alice, `profiles?id=eq.${alice.id}`, { method: 'PATCH', body: { role: 'admin' } })
    expect(role.status).toBeGreaterThanOrEqual(400)
    const verified = await restAs(alice, `profiles?id=eq.${alice.id}`, { method: 'PATCH', body: { school_verified_at: null, school_domain: 'ox.ac.uk' } })
    expect(verified.status).toBeGreaterThanOrEqual(400)
    const [me] = await db.select<{ role: string; school_domain: string }>('profiles', `id=eq.${alice.id}&select=role,school_domain`)
    expect(me).toEqual({ role: 'user', school_domain: 'ucl.ac.uk' })
  })

  test("another student's event cannot be edited, cancelled or managed", async ({ browser }) => {
    const event = await createEvent(bob, { title: `E2E 别人的活动 ${RUN}` })
    const ctx = await contextAs(browser, alice)
    const page = await ctx.newPage()
    await page.goto(`/events/${event.id}`)
    await expect(page.getByRole('heading', { name: '管理活动' })).toHaveCount(0)
    await page.goto(`/events/${event.id}/edit`)
    await expect(page.getByText('只有发起人或组织者可以编辑这个活动')).toBeVisible()
    await ctx.close()

    expect((await restAs(alice, `events?id=eq.${event.id}`, { method: 'PATCH', body: { title: 'hacked' } })).data).toEqual([])
    for (const [fn, args] of [
      ['cancel_event', { p_event: event.id }],
      ['get_checkin_code', { p_event: event.id }],
      ['rotate_checkin_code', { p_event: event.id }],
      ['list_event_attendees', { p_event: event.id }],
    ] as const) {
      const r = await rpcAs(alice, fn, args).then(() => 'ok', (e: Error) => e.message)
      expect(r, fn).toContain('forbidden')
    }
    const [after] = await db.select<{ title: string; status: string }>('events', `id=eq.${event.id}&select=title,status`)
    expect(after).toEqual({ title: event.title, status: 'published' })
  })

  test('nobody can host as someone else or write evidence directly (B-07)', async () => {
    const asBob = await restAs(alice, 'events', {
      method: 'POST',
      body: { host_user_id: bob.id, category: '运动', title: 'fake', starts_at: new Date(Date.now() + 864e5).toISOString(), checkin_mode: 'none' },
    })
    expect(asBob.status).toBeGreaterThanOrEqual(400)

    const event = await createEvent(bob, { title: `E2E 证据保护 ${RUN}` })
    await rpcAs(alice, 'join_event', { p_event: event.id })
    const forged = await restAs(alice, 'participation_evidence', {
      method: 'POST',
      body: { event_id: event.id, subject_user_id: alice.id, type: 'organiser_confirmed_attendance', source: 'organiser', verification_status: 'verified' },
    })
    expect(forged.status).toBeGreaterThanOrEqual(400)
    const self = await rpcAs(alice, 'organiser_confirm_attendance', { p_event: event.id, p_user: alice.id, p_confirm: true }).then(() => 'ok', (e: Error) => e.message)
    expect(self).toContain('forbidden')
    // Checking in someone else is impossible: event_checkin only ever records the caller.
    const code = await checkinCode(bob, event.id)
    await rpcAs(carol, 'join_event', { p_event: event.id })
    await rpcAs(carol, 'event_checkin', { p_code: code, p_lat: AT_VENUE.latitude, p_lng: AT_VENUE.longitude, p_accuracy: 10 })
    const rows = await db.select<{ subject_user_id: string }>('participation_evidence', `event_id=eq.${event.id}&select=subject_user_id`)
    expect(rows.map((r) => r.subject_user_id)).toEqual([carol.id])
    // ...and people cannot read each other's evidence.
    expect((await restAs(alice, `participation_evidence?event_id=eq.${event.id}&select=id`)).data).toEqual([])
  })

  test('a school-only event is invisible to other schools', async ({ browser }) => {
    const event = await createEvent(alice, { title: `E2E 仅本校 ${RUN}`, visibility: 'school' })
    const ctx = await contextAs(browser, carol)
    const page = await ctx.newPage()
    await page.goto(`/events/${event.id}`)
    await expect(page.getByText('活动不存在，或者你没有权限查看')).toBeVisible()
    await page.goto('/')
    await expect(page.getByText(event.title)).toHaveCount(0)
    const join = await rpcAs(carol, 'join_event', { p_event: event.id }).then(() => 'ok', (e: Error) => e.message)
    expect(join).toContain('event_not_found')
    await ctx.close()

    const same = await contextAs(browser, bob) // also UCL
    const p2 = await same.newPage()
    await p2.goto(`/events/${event.id}`)
    await expect(p2.getByRole('heading', { name: event.title })).toBeVisible()
    await same.close()
  })

  test('blocking hides people from each other and stops requests (B-02 family)', async ({ browser }) => {
    const event = await createEvent(alice, { title: `E2E 拉黑 ${RUN}`, checkin_mode: 'none', location_lat: null, location_lng: null })
    await rpcAs(bob, 'join_event', { p_event: event.id })
    for (const u of [alice, bob]) await rpcAs(u, 'set_event_optin', { p_event: event.id, p_opted_in: true, p_visible_fields: ['interests'] })

    const ctx = await contextAs(browser, alice)
    const page = await ctx.newPage()
    await page.goto(`/events/${event.id}/people`)
    const row = page.locator('li').filter({ hasText: bob.name })
    await expect(row).toBeVisible()
    page.once('dialog', (d) => d.accept())
    await row.getByRole('button', { name: '更多操作' }).click()
    await row.getByRole('button', { name: '拉黑' }).click()
    await expect(page.locator('li').filter({ hasText: bob.name })).toHaveCount(0)
    await page.reload()
    await expect(page.getByRole('heading', { name: '愿意认识新朋友的同学' })).toBeVisible()
    await expect(page.getByText(bob.name)).toHaveCount(0)
    await ctx.close()

    const bobsView = await rpcAs<{ card: { id: string } | null }[]>(bob, 'list_event_participants', { p_event: event.id })
    expect(bobsView.filter((r) => r.card?.id === alice.id)).toEqual([])
    const req = await rpcAs(bob, 'send_connection_request', { p_to: alice.id, p_context: 'event', p_context_id: event.id }).then(() => 'ok', (e: Error) => e.message)
    expect(req).toContain('blocked')
  })
})
