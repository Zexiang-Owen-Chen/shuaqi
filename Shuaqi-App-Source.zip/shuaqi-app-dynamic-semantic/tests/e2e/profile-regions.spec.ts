import { expect, test } from '@playwright/test'
import { contextAs, createUser, db } from './support/backend'
import { LONDON_REGIONS } from '../../app/utils/regions'

test('profile uploads two avatars and saves a public coarse region', async ({ browser }) => {
  const user = await createUser('RegionAvatar')
  const ctx = await contextAs(browser, user)
  const page = await ctx.newPage()
  try {
    await page.goto('/me/edit')
    await page.waitForLoadState('networkidle')
    await expect(page.locator('#pf-region-city')).toHaveValue('London')
    const paths: string[] = []
    for (let i = 0; i < 2; i++) {
      const response = page.waitForResponse(r => r.url().includes('/storage/v1/object/avatars/') && r.request().method() === 'POST', { timeout: 15_000 })
      await page.locator('form input[type=file]').setInputFiles({
        name: `avatar-${i}.png`, mimeType: 'image/png',
        buffer: Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=', 'base64'),
      })
      const upload = await response
      expect(upload.ok()).toBe(true)
      expect(upload.request().headers()['x-upsert']).not.toBe('true')
      paths.push(new URL(upload.url()).pathname)
      await expect(page.getByText('上传中…')).toHaveCount(0)
    }
    expect(paths[0]).not.toBe(paths[1])
    await page.locator('#pf-region-city').selectOption('Oxford')
    await expect(page.locator('#pf-region')).toHaveCount(0)
    await page.locator('#pf-region-city').selectOption('London')
    await page.locator('#pf-region').selectOption('London / Camden')
    await expect(page.getByText('地区对其他登录用户公开展示', { exact: false })).toBeVisible()
    await page.screenshot({ path: 'test-results/profile-public-regions.png', fullPage: true })
    await page.getByRole('button', { name: '保存', exact: true }).click()
    await expect(page).toHaveURL(/\/me$/)
    const [profile] = await db.select<{ region: string; avatar_url: string }>('profiles', `id=eq.${user.id}&select=region,avatar_url`)
    expect(profile?.region).toBe('London / Camden')
    expect(paths[1]).toContain(profile!.avatar_url)
  } finally {
    await ctx.close()
  }
})

test('new user must choose a complete region and can upload an avatar during onboarding', async ({ browser }) => {
  const user = await createUser('RegionOnboarding', { onboarded: false })
  await db.update('profiles', `id=eq.${user.id}`, { region: null })
  const ctx = await contextAs(browser, user)
  const page = await ctx.newPage()
  try {
    await page.goto('/onboarding')
    await page.waitForLoadState('networkidle')
    await page.getByRole('button', { name: '开始使用' }).click()
    await expect(page.getByRole('alert')).toHaveText('请选择所在城市和地区')
    await page.locator('#pf-region-city').selectOption('London')
    await page.getByRole('button', { name: '开始使用' }).click()
    await expect(page).toHaveURL(/\/onboarding/)
    await expect.poll(() => page.locator('#pf-region').evaluate((el: HTMLSelectElement) => el.validity.valueMissing)).toBe(true)
    const [incomplete] = await db.select<{ onboarded: boolean }>('profiles', `id=eq.${user.id}&select=onboarded`)
    expect(incomplete?.onboarded).toBe(false)
    await page.locator('#pf-region').selectOption('London / Camden')
    await page.locator('#pf-region-city').selectOption('Cambridge')
    await expect(page.locator('#pf-region')).toHaveCount(0)
    const response = page.waitForResponse(r => r.url().includes('/storage/v1/object/avatars/') && r.request().method() === 'POST', { timeout: 15_000 })
    await page.locator('form input[type=file]').setInputFiles({
      name: 'onboarding.png', mimeType: 'image/png',
      buffer: Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=', 'base64'),
    })
    expect((await response).ok()).toBe(true)
    await expect(page.getByText('上传中…')).toHaveCount(0)
    await page.getByRole('button', { name: '开始使用' }).click()
    await expect(page).toHaveURL(/\/$/)
    const [saved] = await db.select<{ onboarded: boolean; region: string; avatar_url: string }>('profiles', `id=eq.${user.id}&select=onboarded,region,avatar_url`)
    expect(saved?.onboarded).toBe(true)
    expect(saved?.region).toBe('Cambridge')
    expect(saved?.avatar_url).toContain(user.id + '/')
  } finally {
    await ctx.close()
  }
})

test('all supported regions persist and reappear after reloading the profile', async ({ browser }) => {
  const user = await createUser('EveryRegion')
  const ctx = await contextAs(browser, user)
  const page = await ctx.newPage()
  try {
    for (const region of ['Oxford', 'Cambridge', ...LONDON_REGIONS.map(r => r.value)]) {
      await page.goto('/me/edit')
      await page.waitForLoadState('networkidle')
      await page.locator('#pf-region-city').selectOption(region.startsWith('London / ') ? 'London' : region)
      if (region.startsWith('London / ')) await page.locator('#pf-region').selectOption(region)
      await page.getByRole('button', { name: '保存', exact: true }).click()
      await expect(page).toHaveURL(/\/me$/)
      const [profile] = await db.select<{ region: string }>('profiles', `id=eq.${user.id}&select=region`)
      expect(profile?.region).toBe(region)
      await page.goto('/me/edit')
      await page.reload()
      await expect(page.locator('#pf-region-city')).toHaveValue(region.startsWith('London / ') ? 'London' : region)
      if (region.startsWith('London / ')) await expect(page.locator('#pf-region')).toHaveValue(region)
      else await expect(page.locator('#pf-region')).toHaveCount(0)
    }
  } finally {
    await ctx.close()
  }
})

for (const region of ['', 'Cambridge']) {
  test(`buddy region supports ${region || 'explicit unrestricted matching'}`, async ({ browser }) => {
    const user = await createUser(region ? 'BuddyCity' : 'BuddyAny')
    const ctx = await contextAs(browser, user)
    const page = await ctx.newPage()
    try {
      await page.goto('/buddy/new')
      await page.waitForLoadState('networkidle')
      await page.getByRole('button', { name: '跑步', exact: true }).click()
      await page.locator('#region-city').selectOption('London')
      await page.getByRole('button', { name: '发布并查看候选人' }).click()
      await expect(page.getByText('请选择有效地区', { exact: true })).toBeVisible()
      await page.locator('#region').selectOption('London / Camden')
      await page.locator('#region-city').selectOption(region)
      await expect(page.locator('#region')).toHaveCount(0)
      await page.getByRole('button', { name: '发布并查看候选人' }).click()
      await expect(page).toHaveURL(/\/buddy\/intents\/[0-9a-f-]+$/)
      const [intent] = await db.select<{ region: string }>('intents', `user_id=eq.${user.id}&select=region`)
      expect(intent?.region).toBe(region)
    } finally {
      await ctx.close()
    }
  })
}
