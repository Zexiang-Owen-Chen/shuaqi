// Dependency-free regression tests: Node >= 24. Uses real TypeScript source.
import fs from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'
import { pathToFileURL, fileURLToPath } from 'node:url'
import { stripTypeScriptTypes } from 'node:module'
import assert from 'node:assert/strict'
import { test, after } from 'node:test'

const root = fileURLToPath(new URL('../', import.meta.url))
const runtime = await fs.mkdtemp(path.join(os.tmpdir(), 'shuaqi-adaptive-'))
after(() => fs.rm(runtime, { recursive: true, force: true }))
await fs.writeFile(path.join(runtime, 'package.json'), '{"type":"module"}')
for (const name of ['score', 'adaptive', 'types', 'text', 'expansion']) {
  const file = `server/utils/reco/${name}.ts`
  let js = stripTypeScriptTypes(await fs.readFile(path.join(root, file), 'utf8'), { mode: 'transform' })
  js = js.replace(/from\s+(['"])(\.[^'"]+)\1/g, (_, q, spec) => `from ${q}${spec}.js${q}`)
  const out = path.join(runtime, file.replace(/\.ts$/, '.js'))
  await fs.mkdir(path.dirname(out), { recursive: true })
  await fs.writeFile(out, js)
}
const { learnPersonalWeights: learn, defaultPersonalWeights, nominalWeights, adaptiveScore } =
  await import(pathToFileURL(path.join(runtime, 'server/utils/reco/adaptive.js')))
const { rank, combine } = await import(pathToFileURL(path.join(runtime, 'server/utils/reco/score.js')))
const { EMPTY_QUERY, PREFERENCE_KEYS } = await import(pathToFileURL(path.join(runtime, 'server/utils/reco/types.js')))
const now = new Date('2026-10-27T12:00:00Z')
const shown = '2026-10-26T10:00:00Z', action = '2026-10-26T11:00:00Z'
const base = { query: .5, semantic: .5, interest: .5, time: .5, distance: .5, quality: .5, seats: 1 }
function history(key, count = 12, feedback = 'join', inverse = false) {
  return Array.from({ length: count }, (_, i) => [
    { request_id: `r${i}`, event_id: `chosen${i}`, shown_at: shown, position: 0,
      features: { ...base, [key]: inverse ? .1 : .9 }, feedback, feedback_at: action },
    { request_id: `r${i}`, event_id: `other${i}`, shown_at: shown, position: 1,
      features: { ...base, [key]: inverse ? .9 : .1 }, feedback: null, feedback_at: null },
  ]).flat()
}
test('new users and impressions alone retain defaults', () => {
  assert.deepEqual(learn([], now), defaultPersonalWeights())
  assert.equal(learn(history('distance').map(r => ({ ...r, feedback: null })), now).status, 'cold_start')
})
test('small samples do not change weights', () => {
  const p = learn(history('distance', 7), now)
  assert.equal(p.status, 'learning'); assert.equal(p.multipliers.distance, 1)
})
test('distance preference changes independently of time', () => {
  const p = learn(history('distance'), now)
  assert.equal(p.status, 'personalised'); assert(p.multipliers.distance > 1)
  assert.equal(p.multipliers.time, 1)
  assert(learn(history('time'), now).multipliers.time > 1)
})
test('each available preference factor can be learned', () => {
  for (const key of PREFERENCE_KEYS) assert(learn(history(key), now).multipliers[key] > 1, key)
})
test('repeated preference for farther or later options reduces the corresponding factor', () => {
  assert(learn(history('distance', 12, 'join', true), now).multipliers.distance < 1)
  assert(learn(history('time', 12, 'join', true), now).multipliers.time < 1)
})
test('negative feedback reverses the update', () => {
  assert(learn(history('distance', 12, 'dismiss'), now).multipliers.distance < 1)
  assert(learn(history('time', 12, 'cancel_join'), now).multipliers.time < 1)
})
test('clicks carry less evidence than verified attendance', () => {
  assert(learn(history('distance', 30, 'click'), now).multipliers.distance < learn(history('distance', 30, 'attend'), now).multipliers.distance)
})
test('duplicates do not increase confidence', () => {
  const rows = history('time')
  assert.deepEqual(learn([...rows, ...rows, ...rows], now), learn(rows, now))
})
test('one outcome copied across requests is not counted repeatedly', () => {
  const rows = history('time').map(r => r.feedback ? { ...r, event_id: 'same-event' } : r)
  assert.equal(learn(rows, now).requestCount, 1)
})
test('missing distance and comparisons with no variation cannot invent a preference', () => {
  const rows = history('distance').map(r => ({ ...r, features: { ...base, distance: null } }))
  assert.equal(learn(rows, now).multipliers.distance, 1)
  assert.equal(learn(rows, now).status, 'cold_start')
})
test('evidence about one dimension cannot unlock a sparsely observed different dimension', () => {
  const rows = [...history('time'), ...history('distance', 1).map(r => ({ ...r, request_id: 'distance-only', event_id: `d-${r.event_id}` }))]
  const p = learn(rows, now)
  assert(p.multipliers.time > 1); assert.equal(p.multipliers.distance, 1)
})
test('old, future, malformed and single-option histories do not train', () => {
  assert.equal(learn(history('time').map(r => ({ ...r, shown_at: '2026-01-01' })), now).status, 'cold_start')
  assert.equal(learn(history('time').map(r => ({ ...r, feedback_at: '2027-01-01' })), now).status, 'cold_start')
  assert.equal(learn([null, {}, { features: 'invalid' }], now).status, 'cold_start')
  assert.equal(learn(history('time').filter(r => r.feedback), now).status, 'cold_start')
})
test('older evidence has less influence', () => {
  const old = history('distance').map(r => ({ ...r, shown_at: '2026-09-01T10:00:00Z', feedback_at: '2026-09-01T11:00:00Z' }))
  assert(learn(old, now).multipliers.distance < learn(history('distance'), now).multipliers.distance)
})
test('multipliers are bounded and normalized; absent dimensions are excluded', () => {
  const p = learn(history('time', 400), now)
  assert(Object.values(p.multipliers).every(v => v >= .6 && v <= 1.4))
  const weights = nominalWeights(p, true)
  assert(Math.abs(Object.values(weights).reduce((a,b) => a+b,0) - 1) < 1e-12)
  assert.equal(nominalWeights(p, false).distance, 0)
  assert.equal(adaptiveScore({ ...base, query: null, semantic: null, interest: null, time: 1, distance: null, seats: 1, quality: 1 }, p, false), 1)
})
const candidate = { id: 'a', title: 'Chess', category: 'Games', description: 'A friendly chess session for students of all levels.',
  starts_at: '2026-10-28T12:00:00Z', ends_at: null, location_text: 'London', location_lat: 51.5,
  location_lng: -.1, capacity: 10, going: 1, org_verified: false, similarity: null, embedding_hash: null }
const input = { candidates: [candidate], query: { ...EMPTY_QUERY }, interests: [], signals: [], origin: { lat: 51.5, lng: -.1 }, hasQueryEmbedding: false, now, limit: 10 }
test('cold start, disabled and unavailable states preserve original scores exactly', () => {
  const original = rank(input).ranked[0]
  for (const state of ['cold_start', 'learning', 'disabled', 'unavailable']) {
    const r = rank({ ...input, personalWeights: defaultPersonalWeights(state) }).ranked[0]
    assert.equal(r.score, original.score); assert.equal(r.score, combine(r.breakdown))
  }
})
test('learned distance preference can change the actual ranking', () => {
  const candidates = [
    { ...candidate, id: 'near', starts_at: '2026-11-07T12:00:00Z' },
    { ...candidate, id: 'soon', location_lat: 51.54, starts_at: '2026-10-28T12:00:00Z' },
  ]
  const baseline = rank({ ...input, candidates }).ranked
  const personalised = rank({ ...input, candidates, personalWeights: learn(history('distance', 100), now) }).ranked
  assert.equal(baseline[0].candidate.id, 'soon')
  assert.equal(personalised[0].candidate.id, 'near')
})
test('explicit distance constraint remains a hard filter after personalisation', () => {
  const p = learn(history('distance', 100, 'join', true), now)
  const r = rank({ ...input, candidates: [{ ...candidate, location_lat: 52 }], query: { ...EMPTY_QUERY, maxDistanceKm: 1 }, personalWeights: p })
  assert.equal(r.eligible, 0)
})
