// Pure helpers for the push dispatcher (unit-tested in tests/unit/push.test.ts).

export interface OutboxPayload {
  title?: string
  body?: string
  url?: string
  tag?: string
  /** Messages merged into this notification while it waited (chat). */
  count?: number
}

/** What the service worker receives (public/push-sw.js). */
export interface PushMessage {
  title: string
  body: string
  url: string
  tag: string
}

/** Same-origin paths only, so a notification can never open another site. */
export function safePath(url: unknown): string {
  return typeof url === 'string' && url.startsWith('/') && !url.startsWith('//') && !url.includes('\\') ? url : '/'
}

export function toPushMessage(p: OutboxPayload): PushMessage {
  const count = Number(p.count) || 1
  const body = (p.body ?? '').trim()
  return {
    title: (p.title ?? '').trim() || 'SHUAQI',
    body: count > 1 ? `[${count} 条] ${body}` : body,
    url: safePath(p.url),
    tag: (p.tag ?? '').slice(0, 100) || 'shuaqi',
  }
}

export type SendOutcome = 'ok' | 'gone' | 'retry' | 'drop'

/** How to treat a push service response. 404/410: the device unsubscribed for good. */
export function outcomeFor(statusCode: number | undefined): SendOutcome {
  if (statusCode !== undefined && statusCode >= 200 && statusCode < 300) return 'ok'
  if (statusCode === 404 || statusCode === 410) return 'gone'
  // 429, 5xx and network errors (no status) are worth another try.
  if (statusCode === undefined || statusCode === 429 || statusCode >= 500) return 'retry'
  // 400/401/403/413: our request is wrong for this device; retrying will not help.
  return 'drop'
}

/** A row is done if any device took it or none is worth retrying; otherwise retry it later. */
export function rowOutcome(outcomes: SendOutcome[]): 'done' | 'retry' {
  if (outcomes.includes('ok')) return 'done'
  return outcomes.includes('retry') ? 'retry' : 'done'
}

/** Constant-time string comparison for the dispatch secret. */
export function sameSecret(a: string, b: string): boolean {
  if (!a || !b || a.length !== b.length) return false
  let diff = 0
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i)
  return diff === 0
}
