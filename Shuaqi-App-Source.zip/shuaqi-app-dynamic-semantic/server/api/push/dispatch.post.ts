// POST /api/push/dispatch — delivers queued web push notifications.
// Called by the database (pg_net, right after a notification is queued, and every minute from
// pg_cron) with `Authorization: Bearer <NUXT_PUSH_DISPATCH_SECRET>`. Rows are claimed and reported
// back through service-role-only functions in 20261020000500_web_push.sql; the VAPID private key
// never leaves the server.
import webpush from 'web-push'
import { serverSupabaseServiceRole } from '#supabase/server'
import type { Database } from '../../../app/types/database.types'
import { outcomeFor, rowOutcome, sameSecret, toPushMessage, type OutboxPayload, type SendOutcome } from '../../utils/push/payload'

interface Sub { endpoint: string, p256dh: string, auth: string }

const BATCH = 100
// Stop claiming new batches after this long; Vercel functions are cut off soon after.
const BUDGET_MS = 8_000
// Push services keep an undelivered notification (phone offline) for up to 6 hours.
const TTL_S = 6 * 60 * 60

export default defineEventHandler(async (event) => {
  const config = useRuntimeConfig(event)
  const auth = getHeader(event, 'authorization') ?? ''
  if (!sameSecret(auth.replace(/^Bearer\s+/i, ''), config.pushDispatchSecret)) {
    throw createError({ statusCode: 401, statusMessage: 'unauthorized' })
  }
  if (!config.public.vapidPublicKey || !config.vapidPrivateKey) {
    throw createError({ statusCode: 503, statusMessage: 'push_not_configured' })
  }
  const vapidDetails = {
    subject: config.vapidSubject || 'mailto:support@shuaqi.app',
    publicKey: config.public.vapidPublicKey,
    privateKey: config.vapidPrivateKey,
  }

  const db = serverSupabaseServiceRole<Database>(event)
  const started = Date.now()
  let sent = 0

  while (Date.now() - started < BUDGET_MS) {
    const { data: rows, error } = await db.rpc('claim_push_batch', { p_limit: BATCH })
    if (error) throw createError({ statusCode: 500, statusMessage: 'claim_failed' })
    if (!rows?.length) break

    const done: number[] = []
    const retry: number[] = []
    const gone = new Set<string>()
    const ok = new Set<string>()

    await Promise.all(rows.map(async (row) => {
      const body = JSON.stringify(toPushMessage(row.payload as OutboxPayload))
      const subs = (row.subscriptions ?? []) as unknown as Sub[]
      const outcomes = await Promise.all(subs.map(async (s): Promise<SendOutcome> => {
        try {
          const res = await webpush.sendNotification(
            { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
            body, { vapidDetails, TTL: TTL_S, timeout: 5_000 })
          return outcomeFor(res.statusCode)
        }
        catch (e) {
          return outcomeFor((e as { statusCode?: number }).statusCode)
        }
      }))
      subs.forEach((s, i) => {
        if (outcomes[i] === 'ok') ok.add(s.endpoint)
        if (outcomes[i] === 'gone') gone.add(s.endpoint)
      })
      if (rowOutcome(outcomes) === 'done') done.push(row.id)
      else retry.push(row.id)
      sent += outcomes.filter(o => o === 'ok').length
    }))

    const { error: e2 } = await db.rpc('complete_push_batch', {
      p_done: done, p_retry: retry, p_gone: [...gone], p_ok: [...ok],
    })
    if (e2) throw createError({ statusCode: 500, statusMessage: 'complete_failed' })
    if (rows.length < BATCH || retry.length) break
  }

  return { sent }
})
