// GET /api/recommendations/providers — admin only: which AI providers have keys configured on
// the server (true/false, never the keys) and the default model for each.
import { serverSupabaseClient } from '#supabase/server'
import { configuredProviders, DEFAULT_EMBEDDING_MODEL, DEFAULT_LLM_MODEL } from '../../utils/reco/llm'

export default defineEventHandler(async (event) => {
  const db = await serverSupabaseClient(event)
  const { data: isAdmin } = await db.rpc('is_admin')
  if (!isAdmin) throw createError({ statusCode: 403, statusMessage: 'forbidden', data: { error: 'forbidden' } })
  return {
    configured: configuredProviders(),
    serviceKey: Boolean(process.env.NUXT_SUPABASE_SECRET_KEY || process.env.SUPABASE_SECRET_KEY
      || process.env.NUXT_SUPABASE_SERVICE_KEY || process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY),
    defaults: { llm: DEFAULT_LLM_MODEL, embedding: DEFAULT_EMBEDDING_MODEL },
  }
})
