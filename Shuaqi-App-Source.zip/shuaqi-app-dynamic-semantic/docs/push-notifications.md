# Push notifications (通知推送)

Web push for the PWA. Users get a notification, even with SHUAQI closed, for:

| Category (`notification_preferences`) | When | Opens |
|---|---|---|
| `message` 新消息 | A friend sends a chat message. Several messages waiting in one chat merge into one notification ("[3 条] …"). | `/messages/<friend>` |
| `friend_request` 好友请求 | Someone sends you a friend request; someone accepts yours. | `/me/requests`, `/u/<id>` |
| `buddy` 搭子 | You receive a buddy invitation; your invitation is accepted (搭子匹配成功); the shared plan is confirmed by both. | `/buddy`, `/buddy/plans/<id>` |
| `event_reminder` 活动提醒 | About an hour before an event you are going to (one reminder per event). | `/events/<id>` |

Each category can be switched off in 我的 → 通知设置 (applies to all the user's devices). The whole feature is behind the `push` feature flag.

## Where it works

| Device | Works? |
|---|---|
| Android (Chrome, Edge, Samsung Internet, Firefox) | Yes, in the browser or the installed app. |
| iPhone / iPad, iOS 16.4+ | Only from the home-screen app. The settings page and the opt-in card send iPhone users in Safari to the install guide (S13) first. |
| Desktop Chrome, Edge, Firefox, Safari | Yes. |
| WeChat and other in-app browsers | No. We never ask there; the settings page says to open SHUAQI in a browser. |

We never call the browser's permission prompt on page load. The app shows its own "开启通知" card (on 我的, 消息, and the install page once installed) and asks the browser only after a tap; "以后再说" hides the card for 14 days. Signing out removes the device's subscription.

## How it works

1. Database triggers (`supabase/migrations/20261020000500_web_push.sql`) queue a row in `push_outbox` when a message, request, invitation or plan changes, but only for users who have a subscribed device and want that category. A failure here never blocks the original write.
2. `pg_cron` runs `push_tick()` every minute: it queues event reminders, clears rows older than 7 days, and retries anything still waiting.
3. Queuing a row makes the database call `POST /api/push/dispatch` through `pg_net` with a shared secret, so notifications go out within seconds.
4. The dispatcher claims rows with `claim_push_batch()`, encrypts each one with the VAPID keys (`web-push`), sends it to the browser's push service, and reports back with `complete_push_batch()`. Devices the push service says are gone (404/410) are deleted. Failed sends are retried up to 3 times; anything older than 6 hours is dropped as stale.
5. `public/push-sw.js` (imported into the generated service worker) shows the notification and opens the right page when it is tapped.

Only the service role can read `push_subscriptions` and `push_outbox`; users reach their own data through the RPCs (`save_push_subscription`, `delete_push_subscription`, `has_push_subscription`, `my_notification_preferences`, `set_notification_preference`, `send_test_push`).

Payloads are end-to-end encrypted between our server and the browser; Google/Apple/Mozilla's push services cannot read them. A message notification shows the friend's display name and the first 200 characters of the message.

## Setup per environment

Do this once for staging and once for production (different keys and secrets for each).

1. **VAPID keys**: `npx web-push generate-vapid-keys`. Keep the private key secret; changing keys later means every device has to turn notifications on again (the app re-subscribes automatically when the user taps 开启).
2. **Dispatch secret**: any long random string, e.g. `openssl rand -hex 32`.
3. **Vercel** environment variables (Preview → staging values, Production → prod values):
   - `NUXT_PUBLIC_VAPID_PUBLIC_KEY` — public key (sent to browsers)
   - `NUXT_VAPID_PRIVATE_KEY` — private key, server only
   - `NUXT_VAPID_SUBJECT` — `mailto:` address push services can contact, e.g. `mailto:support@<domain>`
   - `NUXT_PUSH_DISPATCH_SECRET` — the dispatch secret
   - `NUXT_SUPABASE_SERVICE_KEY` — already used by recommendations; the dispatcher needs it too
4. **Supabase** (Dashboard → Database → Extensions): enable `pg_net` and `pg_cron`. Then in the SQL editor:
   ```sql
   select vault.create_secret('https://<domain>/api/push/dispatch', 'push_dispatch_url');
   select vault.create_secret('<dispatch secret>', 'push_dispatch_secret');
   select public.schedule_push_jobs();   -- returns true once pg_cron is on
   ```
   Staging should point at a stable staging URL (a Vercel branch alias), not a per-PR preview URL. To change a value later: `select vault.update_secret((select id from vault.secrets where name = 'push_dispatch_url'), '<new url>');`

Without the Vault secrets nothing is sent and nothing breaks; without `NUXT_PUBLIC_VAPID_PUBLIC_KEY` the app hides the notification settings.

## Checking it works

- 我的 → 通知设置 → 开启通知 → 发一条测试通知. It should arrive within a few seconds (iPhone: from the home-screen app).
- Queue state: `select status, count(*) from push_outbox group by 1;` — rows stuck in `pending` mean the dispatcher is not being reached (check the Vault URL/secret and `select * from net._http_response order by created desc limit 5;`).
