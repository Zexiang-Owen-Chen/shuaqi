# Semantic expansion

`expansion.ts` builds soft synonym/alternative groups, keeping original filters separate.
It supports bilingual sport names, doubles and pickup phrases. Ambiguous doubles retains
badminton, tennis and table tennis; stated interests can softly prioritize one. Explicit
sports override those guesses, and titles clearly naming a different sport are excluded.
Table tennis is not treated as lawn tennis. Explicit sport exclusions expand across languages.
Suggestions are alternatives, not additional required keywords; adding translations does not
dilute a match by expanding a keyword denominator. This is a bounded initial vocabulary,
not a claim of universal language understanding.

The existing optional LLM parser now also returns `relatedTerms` (max 12 short terms).
These are validated, bounded and filtered against explicit sports/exclusions. Model suggestions
can improve retrieval and ranking, never create events. Existing rule-parsed constraints are
preserved when merging model output. No extra chat-model call is introduced. The existing
query embedding call receives the original query plus related activity alternatives.
AI failure/no credentials falls back to deterministic expansion. Live providers were not called
during validation. No additional AI candidate reranker has been added.

The new `recommendation_search_candidates` RPC ranks across visible eligible events by
related text hits/cached vector similarity BEFORE limiting to 300. Category filtering also
runs before that limit. Visibility, blocked users, availability, dismissed events and joined
events retain the original eligibility checks. Empty search retains time ordering. Model
vectors are compared only when model key and dimensions match. Missing/stale embeddings
still use the existing bounded refresh of up to 24 events/request; not all database events
will immediately have semantic coverage. Relevance ordering scans eligible candidates and
is suitable for this initial app scale; measure query latency as the catalogue grows.

If the new RPC is absent during rollout, the server falls back to the old candidate RPC.
This fallback has the old time-ordered candidate-pool limitation. Expansion remains active
within that pool. `diagnostics.expansion` reports ambiguous/groups/retrieval, and algorithm
version is `reco-v3-adaptive-semantic`. Both new migration files must be applied for all features.
Dynamic weighting operates after relevance scores are calculated; it learns the relative
importance of features rather than replacing semantic understanding.
