# B-15 Preview 不连生产

目的：确认每个 PR 的 Preview 部署和 `staging` 分支只连 staging 数据库，生产密钥只在 Production 环境里，测试数据不会进生产。

先记下两个 Supabase 项目的 ref（控制台 Project Settings → General）：

- staging：`________________`（`shuaqi-staging`）
- production：`________________`（`shuaqi-prod`）

## 1. Vercel 环境变量

Vercel → 项目 → Settings → Environment Variables。

| # | 检查 | 预期 | 结果 | 备注 |
|---|---|---|---|---|
| 15.1 | `SUPABASE_URL` 的 Production 值 | 包含 production ref | | |
| 15.2 | `SUPABASE_URL` 的 Preview 值 | 包含 staging ref | | |
| 15.3 | `SUPABASE_KEY`（anon key）Production 与 Preview 两个值 | 不相同，分别属于两个项目（在 jwt.io 解码看 `ref` 字段，不要粘贴 service key） | | |
| 15.4 | `NUXT_SUPABASE_SERVICE_KEY` | Production 只有 production 的 key；Preview 要么没有，要么是 staging 的 | | |
| 15.5 | 没有任何变量勾选“All Environments”却填的是生产值 | 每个 Supabase 相关变量都按环境分开 | | |
| 15.6 | 没有以 `NUXT_PUBLIC_` 开头的 service key 变量 | service key 不会进浏览器 | | |
| 15.7 | Development 环境（`vercel env pull`）的值 | 指向 staging 或本地，不是生产 | | |

## 2. 实际请求

| # | 检查 | 预期 | 结果 | 备注 |
|---|---|---|---|---|
| 15.8 | 打开任意一个 PR 的 Preview 地址，开发者工具 Network 筛选 `supabase.co` | 所有请求都发往 `https://<staging ref>.supabase.co` | | |
| 15.9 | 在 Preview 用测试账号登录 | 账号出现在 staging 的 Authentication → Users，不出现在生产 | | |
| 15.10 | 打开 `staging` 分支的部署，重复 15.8 | 同样只连 staging | | |
| 15.11 | 打开 Production 地址，重复 15.8 | 只连 production | | |
| 15.12 | 在 Preview 页面“查看源代码”和加载的 JS 里搜索 production ref 和 `service_role` | 都搜不到 | | |

## 3. 登录回调

Supabase 控制台 → Authentication → URL Configuration。

| # | 检查 | 预期 | 结果 | 备注 |
|---|---|---|---|---|
| 15.13 | production 的 Site URL | 正式域名（未提供前为 Vercel 生产地址） | | |
| 15.14 | production 的 Redirect URLs | 只有正式域名的 `/confirm`，没有 `*.vercel.app` 通配 | | |
| 15.15 | staging 的 Redirect URLs | 包含 Preview 地址通配（如 `https://*-<团队>.vercel.app/**`）和 localhost | | |

## 4. 数据库迁移与测试数据

| # | 检查 | 预期 | 结果 | 备注 |
|---|---|---|---|---|
| 15.16 | GitHub → Settings → Environments：`staging`、`production` 两个环境的 `SUPABASE_PROJECT_REF` | 分别是 staging ref 和 production ref | | |
| 15.17 | `production` 环境设置了必需审批人 | 合并后要人工批准才会改生产库 | | |
| 15.18 | CI 的 pull request 任务（`ci.yml`） | 只用本地 Supabase，不使用任何生产密钥 | | |
| 15.19 | 生产库执行 `select count(*) from auth.users where email like '%test%';` 和测试活动标题检查 | 没有测试账号和种子数据（`supabase db push` 不执行 `seed.sql`） | | |
| 15.20 | 邮件：staging 用测试发信域名，production 用 Resend 正式域名 | 两个项目的 SMTP 设置不同 | | |

## 注意

- 检查时只看 key 的项目 ref，不要把任何 service key 复制到聊天、截图或文档里。
- 任何一项失败都阻塞上线：先修正环境变量，再重新部署 Preview 并复查 15.8。
