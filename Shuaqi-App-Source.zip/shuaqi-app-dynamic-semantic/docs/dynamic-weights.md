# Per-user dynamic ranking

The combined build now also includes semantic expansion; see `semantic-expansion.md`.
Apply both 20261027000001 and 20261027000002 migrations for the complete feature set.

## Behaviour

The recommender now learns a separate multiplier for time, distance, query relevance,
semantic relevance, interest match and listing quality. It is a conservative preference
heuristic, not an LLM-generated weight or a trained causal model.

On every request, the server stores the normalized feature scores of the returned events.
The next request reads only the signed-in user's snapshots and subsequent feedback.
Within a recommendation request, it compares the selected/dismissed event with alternatives.
A user who repeatedly joins closer events gains distance importance; consistently choosing
farther events reduces it. Time works independently, using the existing soonness buckets.
An unselected event is only a weak comparison, not a negative label. If alternatives do not
vary on a factor, that request provides no evidence about that factor.

Feedback strengths: verified attendance +1, joining +0.8, clicking +0.15, dismissing -0.6,
cancelling -0.4. For each snapshot the database prefers attendance, then current RSVP state,
then dismiss, then click. Joins/cancellations/attendance attach only to the latest preceding
snapshot of that event, within 30 days. Duplicate clicks collapse; the learner counts at
most one strongest informative action per request and deduplicates identical business outcomes.

Learning starts after at least 8 informative requests AND 2 units of decayed feedback.
Until then the original scoring function runs unchanged. Evidence has a 30-day half-life;
snapshots older than 90 days are excluded. Factor multipliers stay between 0.6 and 1.4,
with a prior toward 1. Available weights are normalized for each event. Missing location
never trains distance; missing scores do not contribute to adaptive scoring. Seats stay static.
Explicit time-window, category and distance constraints remain filters. Category diversity
reranking still runs after scoring, so returned numeric scores need not be strictly descending.

Base weights when location is known: query .30, semantic .25, interest .20,
time .0675, distance .06, seats .0225, quality .10. Without location, time .1125,
distance 0, seats .0375. These split the existing context weight .15.
When adaptive scoring is active, an unknown event location is omitted instead of the old
context score's neutral distance value. Returned `breakdown` remains the original diagnostic
scores; it is not itself the weighted sum. Own-user `diagnostics.personalisation` reports the
learning state, multipliers, nominal weights and whether snapshots were recorded.

## Apply to the live codebase

This directory is a separate implementation based on the supplied 26 October archive.
Merge/review the changes against the currently deployed repository first. It has not been deployed.

1. Apply `supabase/migrations/20261027000001_adaptive_recommendations.sql` to a staging
   database with all previous migrations already applied. Review and run the SQL tests there.
2. Keep `NUXT_SUPABASE_SERVICE_KEY` server-only. Existing frontend click/dismiss logging
   already carries request_id and event_id; no frontend changes are required.
3. Set `NUXT_DYNAMIC_RECOMMENDATIONS_ENABLED=true` (default). Set it to `false` to stop
   snapshot collection and immediately use the original static scoring.
4. Install the locked dependencies; run `pnpm test:unit`, `pnpm test:adaptive`,
   `pnpm typecheck`, `pnpm test:db`, `pnpm build`, and the recommendation e2e tests against
   the staging environment. The standalone adaptive tests need Node 24 or newer.
5. Inspect two different test accounts: their history must remain separate. After real
   interactions accumulate, inspect `diagnostics.personalisation.status` for `personalised`.

The new table permits authenticated users to read only their own rows; browser snapshot
writes are denied. The server writes features calculated from candidates, never browser
feature values. No raw GPS or query text is added to this table. user_id comes from the
authenticated session. Requests records may expire after 2 days without deleting snapshots.
Snapshots older than 90 days are deleted for each user on a successful new snapshot write.
Inactive users require an operator's scheduled cleanup if strict physical retention is needed:
`delete from public.recommendation_observations where shown_at < now() - interval '90 days';`
Run that with the database owner/service role, never in the browser.

Missing migration/service key/history access falls back to static weights. Snapshot write
failures do not fail recommendations and are visible as `snapshotsRecorded=false`.
Old historical records still inform the existing category-interest score, but cannot reliably
teach time/distance importance because they lack the original comparison context and origin.
New snapshot collection is required; do not invent those missing values.

## Limits

Exposure order and correlated factors can confound this heuristic. For example, if all nearby
events also start sooner, history cannot establish which factor caused the choice. Caps,
minimum samples and weak implicit comparisons reduce overreaction but do not establish
causality. There is no claim of proven recommendation uplift; measure that after deployment.
Time preferences remain the existing buckets, not a learned day-of-week/hour schedule.
Quality is the existing listing completeness / verified-organisation score. It does not
implement host attendance or recruitment ratios; those require a separate feature pipeline.
No new AI API calls or history-to-LLM sharing are introduced.
