# SHUAQI V0 种子数据

交付文件（按 core 仓库相对路径）：

- `supabase/seed.sql` → 放到 `core/supabase/seed.sql`（`config.toml` 的 `[db.seed]` 已指向它）
- `core-tests-seed-safe.patch` → 给 `core/supabase/tests/` 的 3 处修改（见文末，必须一起合并，否则 CI 会红）

已在本地 Supabase CLI 2.x（Postgres 17）上验证：全部 6 个迁移（含 `20261020000102_checkin_hardening`）+ 种子 `db reset` 通过；种子重复执行 2 次结果不变；pgTAP 212 个测试在“有种子”和 `--no-seed` 两种情况下都通过（需打补丁）。

## 测试账号

邮箱都在 `shuaqi-seed.<学校域名>` 子域下，没有真实收件箱，不会误发邮件给真人。

| 账号 | 邮箱 | 身份 |
|---|---|---|
| SHUAQI 管理员 | admin@shuaqi-seed.ucl.ac.uk | `role = admin` |
| 王社长 | owner@shuaqi-seed.imperial.ac.uk | ICL 桌游社 owner |
| 李组织 | organiser@shuaqi-seed.imperial.ac.uk | ICL 桌游社 organiser，e01/e05/e06/e07 的主办人 |
| 赵志愿 | staff@shuaqi-seed.imperial.ac.uk | ICL 桌游社 staff（可看名单、人工确认到场） |
| Priya (LSE) | organiser@shuaqi-seed.lse.ac.uk | LSE Networking Club owner（跨组织权限测试 B-08） |
| Alice 陈 | alice@shuaqi-seed.imperial.ac.uk | e01 已签到 + 已人工确认；与 Ben 是好友；有待处理的 Chloe 好友请求 |
| Ben 刘 | ben@shuaqi-seed.ucl.ac.uk | UCL；e04（仅 UCL 可见）主办人；举报了 Harry |
| Chloe 张 | chloe@shuaqi-seed.lse.ac.uk | 和飞飞完成过一次找搭子见面（双方确认） |
| Daniel 吴 | daniel@shuaqi-seed.queens.ox.ac.uk | 牛津学院子域；e07 到场记录申诉中 |
| Emma 林 | emma@shuaqi-seed.cam.ac.uk | e01 已报名未签到；向 Grace 发了待回应的找搭子邀请 |
| 飞飞 | fei@shuaqi-seed.imperial.ac.uk | 部分资料仅好友可见；e01 未开启活动内发现 |
| Grace 周 | grace@shuaqi-seed.ucl.ac.uk | 资料大部分隐藏；拉黑了 Harry；e01 已报名未签到 |
| Harry 何 | harry@shuaqi-seed.imperial.ac.uk | 被拉黑、被举报；e01 已签到但位置在 ~80m 外 |
| Ivy 孙 | ivy@shuaqi-seed.imperial.ac.uk | e01 已签到；向飞飞发了“附近的人”请求 |
| （空） | pending@shuaqi-seed.ucl.ac.uk | 邮箱未确认、未完成资料 |

### 登录

- **本地**：在 `/login` 输入邮箱，验证码在 Mailpit（http://localhost:54324）里。
- **staging**：这些邮箱收不到信。用 service key 生成验证码（不发邮件），再到 `/login` 输入：

  ```bash
  curl -s -X POST "$SUPABASE_URL/auth/v1/admin/generate_link" \
    -H "apikey: $SERVICE_KEY" -H "Authorization: Bearer $SERVICE_KEY" -H 'content-type: application/json' \
    -d '{"type":"magiclink","email":"alice@shuaqi-seed.imperial.ac.uk"}' | jq -r .email_otp
  ```

  Playwright 也可以用同样的方法登录。真人测试员也可以用自己的 G5 邮箱注册，再报名 e01 等公开活动。

## 活动场景

时间都相对执行种子的时刻。staging 上活动过期后，重新执行一次种子即可（会刷新时间，不会重复插入）。

| id 尾号 | 活动 | 用来测 |
|---|---|---|
| 01 | 【进行中】ICL 桌游之夜（Imperial，签到码 `seed-live-boardgames`） | 扫码签到成功/重复扫码；附近 50m；活动内发现；`require_checkin_for_connect = true` |
| 02 | LSE 华人职场 Networking（3 小时后，码 `seed-lse-networking`） | `outside_window` |
| 03 | 周六下午茶（容量 3，已满） | `event_full` |
| 04 | UCL 期中自习小组（`visibility = school`） | 非 UCL 用户看不到 |
| 05 | 剧本杀专场 | 已取消 |
| 06 | 新生桌游入门 | 草稿，只有组织成员和 admin 能看到 |
| 07 | 上周桌游之夜（码 `seed-past-boardgames`） | 到场记录、信任卡、申诉（admin 待处理 1 条） |
| 08 | 读书会 | `checkin_mode = manual` |
| 09–12 | 下周的羽毛球、徒步、爵士、火锅 | 首页列表、报名 |

签到二维码内容 = `${origin}/checkin/<签到码>`，其他活动的码是随机的（主办方页面可看）。

### 附近 50m

种子执行时会给 e01 的 Alice、Ben、飞飞、Ivy（10–40m）和 Harry（~80m）写入位置，但位置 2 分钟后就不算“新鲜”。测试前用 postgres（SQL 编辑器或 psql）刷新：

```sql
select dev.simulate_nearby('e0000000-0000-4000-8000-000000000001');                 -- 围绕活动地点
select dev.simulate_nearby('e0000000-0000-4000-8000-000000000001', 51.50, -0.12);   -- 围绕你现在的位置
```

`dev` schema 不在 API 暴露列表里，只有 postgres 能调用。以 Alice 登录、刷新后打开 e01 的“附近的人”，应看到 Ben（20m，已是好友）、Ivy、飞飞（30m），看不到 Harry。

## 在 staging 执行

`supabase db push` 不会执行种子，需要手动：

```bash
psql "$STAGING_DB_URL" -v ON_ERROR_STOP=1 -f supabase/seed.sql
```

**不要在 production 执行**（会创建 admin 账号）。

## 需要核心线程合并的测试修改

`03_connections_nearby`、`05_checkin`、`06_admin_reports` 各有一条断言统计整张表的行数，默认数据库是空的。`supabase db start/reset` 会自动执行种子，这 3 条就会失败。补丁把这 3 条改成只统计测试自己创建的用户，含义不变；打补丁后有无种子都是 212/212 通过。

```bash
cd core && patch -p1 < ../seed/core-tests-seed-safe.patch
```
