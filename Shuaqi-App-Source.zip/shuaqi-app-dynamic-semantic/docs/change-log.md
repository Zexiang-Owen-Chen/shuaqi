# SHUAQI v0.1 修改与发布日志

## 基线与记录规则

- 原版基线：`f2c4b6c919a819ac60f26f883d704dda029cb947`（`main`，PR #6 合并后）。下表全部以此提交为比较对象。
- 本地工作目录：`shuaqi_v0.1`。日期按 Europe/London 记录。
- 本次发布范围：头像上传、地区选择及其数据库规则、测试和说明文档。
- 后续每次修改都应在同一批操作中更新本日志：记录完整文件路径、修改前后行为、原因、验证结果、发布状态。新增、删除、重命名同样记录。
- 后台设置没有对应文件时，记录服务、项目、页面/配置项及旧值与新值。不得记录密钥、密码、验证码、连接凭证或用户私密资料。
- “本地验证通过”不代表“已部署”。GitHub 提交、数据库迁移、Vercel 部署和线上复测分别记录。

## 当前发布状态

- 2026-10-23：头像和地区修复已在本地验证，PR #7 已合并，staging 地区迁移和正式网站部署均完成，发布提交 `ff7b06c0e41aaf1e3716debb1f644f139820fed0`。
- 发布前远端 `main` 为原版基线；早期头像单独分支曾推送被拒绝，此次整合发布已通过 PR #7 完成。
- GitHub Write 权限已核实：`push: true`；发布分支检查通过，已推送。
- 网站 `www.shuaqi.uk` 当前按交接记录使用 `shuaqi-staging`。本次不切换正式库 `shuaqi-prod`。
- 原部署工作流：含迁移的 main 推送自动运行 staging 迁移；手动运行还会触发 production。不能把“两个任务同时触发”当作数据库先于网站部署的保证，发布时须核实执行顺序。

## A. 本次头像与地区发布：逐文件差异

以下文件已通过 PR #7 合并；数据库和网站均已发布。

| 文件 | 原版行为 | 本地修改与原因 | 验证/影响 |
|---|---|---|---|
| `app/components/profile/ProfileForm.vue` | 头像用 `upsert: true` 上传；上一次错误不随重新选图清除；地区为自由文本 | 头像改为普通 INSERT，保持每次新文件名；重新选图清空旧错误；地区改用固定选项及必填校验，说明地区公开用途 | 修复 RLS 上传失败和成功重试后残留报错；新用户与编辑资料共用 |
| `app/components/RegionSelect.vue`（新增） | 无共享地区选择器 | London / Oxford / Cambridge；London 再选片区；支持搭子需求的“不限地区” | 城市切换、片区必选及回显已测 |
| `app/utils/regions.ts`（新增） | 无统一地区枚举与校验 | 定义三座城市、9 个伦敦片区和 `isRegion`、`regionCity` | 11 个持久化选项均已测；拒绝邮编、街道及任意文本 |
| `app/utils/profile.ts` | 地区有隐藏选项 | 从可隐藏字段中移除地区 | 其他字段的可见性选项保留 |
| `app/utils/errors.ts` | 无地区数据库错误说明 | 映射 `region_required`、`region_invalid` 为中文提示 | 前后端校验一致 |
| `app/pages/buddy/new.vue` | 搭子地区为自由文本 | 复用地区选择器；可明确选不限地区；说明同地区匹配规则 | 不完整 London 不能提交；不限地区和 Cambridge 发布已测 |
| `app/pages/events/[id]/people.vue` | 活动发现可选是否展示地区 | 地区从可选字段中移除，说明始终可见 | 保留活动 opt-in 和参与权限条件 |
| `app/components/nearby/NearbyPersonCard.vue` | 附近名片不显示粗粒度地区 | 有地区时显示地区 | 地区与实时距离分开展示 |
| `app/composables/useNearby.ts` | 附近名片类型没有地区 | 增加可空地区类型字段 | 与 RPC 返回结构一致 |
| `app/types/database.types.ts` | 无 `normalize_region` RPC 类型 | 增加该函数的类型定义 | 类型检查通过；发布前校验生成类型 |
| `supabase/migrations/20261023000001_public_regions.sql`（新增） | 地区自由文本、隐藏规则与匹配值不统一 | 统一已知地区别名；未知资料地区清空并要求重新完善；未知地区的开放需求撤回；新写入校验；调整名片、附近和匹配函数 | 迁移会影响现有资料及需求，必须先备份/核对再执行；保留拉黑与上下文权限 |
| `supabase/tests/01_signup_profiles.test.sql` | 断言隐藏地区不可见 | 改为断言粗粒度地区公开，其他隐藏字段继续隐藏 | 本地 31 项检查通过 |
| `supabase/tests/11_public_regions.test.sql`（新增） | 无地区迁移专项测试 | 覆盖别名、非法地址、必填、自己/他人头像目录权限、名片公开、搭子匹配、活动发现、附近和拉黑 | 本地 21 项检查通过，测试事务回滚 |
| `tests/e2e/avatar-upload.spec.ts`（新增） | 无独立头像回归测试 | 覆盖 PNG/JPEG/WebP、连续更换、保存刷新、超大图片和服务端失败后重试 | 3 个浏览器场景通过；服务端失败场景为模拟 403，正常上传走真实本地 Storage |
| `tests/e2e/profile-regions.spec.ts`（新增） | 无地区选择专项浏览器测试 | 覆盖头像与地区共同保存、新用户必填、全部选项逐一保存回显、搭子不限地区及指定城市 | 5 个浏览器场景通过 |
| `tests/e2e/permissions.spec.ts` | 断言地区可隐藏 | 改为断言地区公开、介绍仍可隐藏、直接读取他人资料仍被 RLS 阻止 | 与新可见性规则一致 |
| `tests/e2e/smoke.spec.ts` | 完善资料时填写地区文本 | 改为选择城市及片区 | 冒烟流程适配新 UI |
| `tests/unit/profile.test.ts` | 可隐藏字段包含地区 | 更新预期，地区不再属于可隐藏字段 | 相关单元测试通过 |
| `tests/unit/regions.test.ts`（新增） | 无地区单元测试 | 校验全部固定选项，拒绝不完整、未知或精确地址 | 相关单元测试通过 |
| `docs/public-regions.md`（新增） | 无此功能说明 | 说明公开范围、历史数据迁移、匹配行为与发布验证 | 供发布与维护参考 |
| `docs/change-log.md`（新增） | 无逐文件修改日志 | 记录本日志及后续所有文件/后台变更 | 随本次发布交付 |

### 本地验证记录（2026-10-23）

- 浏览器：`avatar-upload.spec.ts` 与 `profile-regions.spec.ts` 共 8 项通过；连接本地网站和本地 Supabase，使用独立测试账号。
- 单元：`regions.test.ts` 与 `profile.test.ts` 共 7 项通过。
- 数据库：注册/资料 31 项，地区/头像权限 21 项，共 52 项通过。
- `nuxi typecheck`、`git diff --check` 通过。
- 测试曾发现“拒绝超大图片后，正常上传仍显示旧错误”；在 `ProfileForm.vue` 修复后复测通过。
- 上述是本地工作区验证；整理发布目录后还须验证其最终内容，线上验收尚未进行。

## B. 本地存在、但不纳入本次发布的改动

| 文件 | 相对原版的改动 | 状态与范围 |
|---|---|---|
| `nuxt.config.ts` | 配置独立本地 Supabase cookie 前缀，避免 localhost 端口间会话串用 | 既有本地环境改动，保留，不随本次发布 |
| `package.json` | dev 服务固定 127.0.0.1:3003 | 既有本地环境改动，保留，不随本次发布 |
| `supabase/config.toml` | 本地项目名、端口、站点 URL 隔离；邮箱 OTP 有效期从 3600 改为 120 秒 | 本地配置；后台有效期另见 C，不整体覆盖远端 |
| `supabase/templates/magic_link.html` | 移除会消耗 OTP 的一次性登录链接；改为纯验证码；说明自发送起 2 分钟内有效 | 本地文件未上传 GitHub；对应 staging 模板已在后台保存 |
| `supabase/templates/confirmation.html` | 同上，适用于注册邮件 | 本地文件未上传 GitHub；对应 staging 模板已在后台保存 |
| `tests/unit/email-templates.test.ts`（新增） | 检查模板包含 OTP、没有自动验证链接 | 2 项通过；与本次头像/地区发布分开 |

## C. 线上后台配置历史（无对应 GitHub 文件修改）

| 日期/项目 | 配置位置 | 旧状态 → 新状态 | 验证与状态 |
|---|---|---|---|
| 2026-10-23 / Supabase staging | Authentication → Emails → SMTP | 默认发信 → Resend 自定义 SMTP；发件人 `noreply@shuaqi.uk`，名称 `SHUAQI 耍起`，主机 `smtp.resend.com`，端口 465，用户名 resend | 已保存；真实密钥由用户自行填写提交，日志不保存密钥 |
| 2026-10-23 / Supabase staging | Authentication → Rate Limits | 自定义 SMTP 开启后的 30 封/小时 → 200 封/小时 | 保存并重新打开确认；为项目所有者明确要求 |
| 2026-10-23 / Supabase staging | Confirm sign up 主题 | 默认英文主题 → `SHUAQI 登录验证码` | 已保存 |
| 2026-10-23 / Supabase staging | Magic link / Confirm sign up 正文 | 验证码 + 一次性登录链接 → 纯验证码 | 已保存；此前日志有链接先被访问、手工 OTP 后失效；疑似邮件安全扫描，未断言具体访问者 |
| 2026-10-23 / Supabase staging | Email OTP expiration | 3600 秒 → 120 秒 | 用户明确指定 2 分钟；这是缩短有效期；已保存并重新打开确认 |
| 2026-10-23 / Supabase staging | 两份邮件模板有效期说明 | 1 小时 → 自发送起 2 分钟 | 已保存 |
| 2026-10-23 / 登录验收 | 非团队成员学校邮箱测试 | 原先发信受限 → 用户确认正常收件箱收到、发件人正确并最终登录成功 | 第 1.6 步收信与登录已通过；不在本日志记录收件地址或验证码 |

只核对、未修改的配置：Email OTP 长度为 6；Site URL 与已有 redirect allowlist。Resend 域名未转移，未修改 DNS；地区数据迁移已执行，详见 LOG-006；Storage 策略未修改。正式库配置/切换未执行。

## D. 后续操作流水

### 2026-10-23 / LOG-001：建立基线修改日志

- 修改文件：新增 `docs/change-log.md`。
- 内容：补录相对原版的所有已跟踪/新增源码文件差异、邮件配置历史、本地验证与发布状态；明确预先存在的本地环境配置不属于此次上线。
- 发布准备：创建独立本地分支 `codex/profile-fixes-release`，尚未复制修复文件、提交或推送；原工作区保持原样。
- 权限：先前检查 `push: false`；用户随后告知已开通 Write，待复核。
- 后续：每次新增或调整文件、迁移/部署执行、复测结果都追加记录，不覆盖历史失败或将未执行项写成完成。

### 2026-10-23 / LOG-002：整理发布目录

- GitHub 权限已重新核实：`push: true`。
- 下列文件复制到独立发布分支，逐文件内容核对一致；不改动原工作区的其他文件：
  - `app/components/nearby/NearbyPersonCard.vue`
  - `app/components/profile/ProfileForm.vue`
  - `app/components/RegionSelect.vue`
  - `app/composables/useNearby.ts`
  - `app/pages/buddy/new.vue`
  - `app/pages/events/[id]/people.vue`
  - `app/types/database.types.ts`
  - `app/utils/errors.ts`
  - `app/utils/profile.ts`
  - `app/utils/regions.ts`
  - `supabase/migrations/20261023000001_public_regions.sql`
  - `supabase/tests/01_signup_profiles.test.sql`
  - `supabase/tests/11_public_regions.test.sql`
  - `tests/e2e/avatar-upload.spec.ts`
  - `tests/e2e/profile-regions.spec.ts`
  - `tests/e2e/permissions.spec.ts`
  - `tests/e2e/smoke.spec.ts`
  - `tests/unit/profile.test.ts`
  - `tests/unit/regions.test.ts`
  - `docs/public-regions.md`
  - `docs/change-log.md`
- `docs/change-log.md` 同步追加本条记录；本次复制未引入额外功能修改。
- 发布分支排除日志 B 节全部文件；复用现有本地 node_modules 作为测试依赖，该链接不纳入 Git。
- 发布目录的完整测试和构建待执行；尚未推送或执行远端迁移。

### 2026-10-23 / LOG-003：发布目录检查与提交准备

- 修改文件：`docs/change-log.md`（同步本地工作区与发布分支）。其余 A 节文件没有新增行为修改。
- 发布目录先执行 `nuxi prepare`，再执行全部单元测试：16 个测试文件、152 项通过；`nuxi typecheck` 与 `NITRO_PRESET=node-server nuxi build` 通过。
- 首次单元测试因新目录缺少 Nuxt 自动生成的 tsconfig 而未执行；生成后重跑通过。构建没有载入真实线上凭证，出现缺少 Supabase 配置的警告；不代表已完成线上运行验证。
- GitHub 现有 CI 最近通过，当前只有 staging 环境。现有手动迁移工作流还会触发 production，未运行。
- Supabase CLI 只读检查显示尚未登录；已请求用户在本机完成 CLI 登录或通过环境变量配置访问凭证，聊天和日志不接收凭证。
- 准备提交并推送 `codex/profile-fixes-release`、创建 PR；线上数据库迁移与网站部署仍未执行。

### 2026-10-23 / LOG-004：GitHub 推送、PR 与部署身份检查

- 修改文件：`docs/change-log.md`。
- 已成功推送 `codex/profile-fixes-release`，功能提交 `8ed537e`；创建 https://github.com/SHUAQI-Tech/shuaqi-app/pull/7 。没有修改 main。
- GitHub CI 已启动；Vercel 预览检查失败，提示无法验证提交作者账号。首个提交使用 Git 自动推断的本机邮箱。
- 后续日志提交显式使用已核实的当前 GitHub 账号 JayceChenn 及对应 GitHub noreply 邮箱；仅设置提交参数，不改全局 Git 配置、不重写已推送历史。
- 线上数据库、Storage 策略及正式网站尚未修改。待 CI 和 staging 访问配置完成后继续。

### 2026-10-23 / LOG-005：staging 备份与迁移前核对

- 修改文件：`docs/change-log.md`（同步本地与发布分支）。
- 用户完成终端 CLI 授权后，已确认 staging 项目 `gsaqzxoohokmpjxcewjw` 为 ACTIVE_HEALTHY；prod 未操作。
- 备份保存于本地忽略目录 `.local-dev/backups/staging-20261023-profile-release/`，目录仅当前用户访问、文件权限 0600；不上传 GitHub。备份范围是本次迁移涉及的 public 应用结构与数据，不包含 Auth 凭证或 Storage 文件内容。
- `public-schema.sql`：201167 字节；SHA-256 `4b518c9e7fe1e09dd641c5ed5d4b10544db132b63b992be01d7f071f776345a0`。
- `public-data.sql`：21418 字节；SHA-256 `71806d2406735672eb54eb6b4564a894d5678e42574a3a1d1e1c82cc76bc7156`。
- 数据备份中 profiles 7 行、intents 3 行，与线上只读汇总一致。
- 迁移前影响：4 份资料需要选择地区，均尚未完成注册（已完成注册需退回数量 0）；1 条无法识别地区的开放需求将撤回。
- 迁移历史与 dry-run 均确认仅缺少 `20261023000001_public_regions.sql`；使用 `--skip-vault`，不更新 Vault、种子数据或角色配置。
- PR 应用、数据库、生成类型、Vercel/Supabase 预览检查已通过；完整浏览器 CI 仍在运行。
- 即将执行上述版本化 staging 迁移；正式网站仍未发布，迁移结果在下一条补记。

### 2026-10-23 / LOG-006：staging 迁移完成及发布检查

- 修改文件：`docs/change-log.md`；功能代码与已通过完整 CI 的 `8ed537e` 相同。
- 后台变更：在 `shuaqi-staging` 执行版本化迁移 `20261023000001_public_regions.sql`，Supabase CLI 返回成功；prod、Vault、邮件设置和 Storage 策略均未修改。
- 迁移后核对：profiles 7、intents 3，总数不变；4 份未完成注册资料仍待选择地区；非法已完成资料 0、非标准地区 0、旧 region 可见性键 0、非法开放需求 0。迁移前需撤回的 1 条需求已纳入撤回状态，当前总撤回数 3。
- 两条地区触发器已启用，迁移历史记录 1 条；已知别名映射正确，精确地址拒绝，匿名函数权限未扩大。Storage 本人目录 INSERT/UPDATE/DELETE 规则仍存在。再次 dry-run 显示无待迁移项。
- 完整功能 CI：https://github.com/SHUAQI-Tech/shuaqi-app/actions/runs/39988382541 ：152 单元、382 数据库断言、82 浏览器测试全部通过；类型检查、生成类型和构建通过。
- 后续 `ca92289` 仅修改日志；应用、数据库及 Vercel/Supabase 预览检查通过，重复浏览器 CI 仍在依赖安装阶段。
- 本条仅文档提交使用 `[skip ci]`，不更改已验证的功能代码或仓库保护配置。main 核对仍为原版基线。接下来正常合并 PR #7，网站部署结果另行记录。

### 2026-10-23 / LOG-007：正式网站发布与日志归档

- 修改文件：`docs/change-log.md`。最终日志补记作为独立文档提交同步 main，不修改功能代码；`[skip ci]` 仅用于文档提交。
- PR #7 已于 2026-10-23 17:51:59（Europe/London）合并；发布提交 `ff7b06c0e41aaf1e3716debb1f644f139820fed0`。
- 自动 staging 迁移工作流成功：https://github.com/SHUAQI-Tech/shuaqi-app/actions/runs/39990316570 。迁移此前已通过 CLI 应用，复查无剩余迁移；没有运行手动 production 工作流。
- Vercel 正式部署返回 success / Deployment has completed：https://vercel.com/econ99macsfinance26-3951/shuaqi-app/2hxUqb3U8LNyFnai92v6iE31k6rx 。
- 线上 https://www.shuaqi.uk/onboarding 已核对新版城市选择器；选择 London 后显示 9 个片区，说明粗粒度地区公开。验收仅切换未提交的表单选项，没有替用户填写/保存个人资料。
- 本地验收截图：`.local-dev/backups/staging-20261023-profile-release/live-region-verification.png`（不上传 GitHub）。
- 头像修复已随同一版本部署；完整 CI 包含真实本地 Storage 的 PNG/JPEG/WebP、连续上传、保存回显和错误重试检查。线上数据库另行核实本人目录上传权限仍保留；本轮没有替用户上传真实头像。
- 本地原工作区与发布工作区日志同步。备份保留在本机私有忽略目录，未上传用户数据或凭证。

### 2026-10-24 / LOG-008：第 2 节正式数据库切换准备

- 修改文件：`docs/change-log.md`；新增 `docs/production-cutover.md`，同步本地工作区与独立交接分支。
- 本次基线：main `1a825ab0c6eca51d537f7d6eebdf6d261fb433ae`。用户授权执行交接文档第 2 节。
- 只读核对：prod `nzdqylsfpnqhmniyrpzz` 健康，0 个 public 应用表、0 个 Auth 用户，无迁移历史；pg_cron / pg_net 尚未开启。当前正式网站仍使用 staging，尚未切换。
- 正式库已有每日自动物理备份，后台最近一次显示 2026-10-24 02:59:56 UTC；组织为 Pro。未购买新套餐或 PITR。
- GitHub 只有 staging environment；当前账号为 Write，production environment 与三个迁移密钥待仓库负责人配置。已请求用户协助，不记录任何密钥或密码。
- 本次不复制 staging 用户或业务数据、不运行 seed.sql。应用当前共有 12 个版本化迁移（包含 20261023000001 地区修复），交接文档原来的 11 个迁移数量已过时。
- 接下来准备 prod 扩展、认证配置和迁移。管理员邮箱待用户指定。实际完成项逐次补记。

### 2026-10-24 / LOG-009：正式库扩展与验证码配置

- 修改文件：`docs/change-log.md`、`docs/production-cutover.md`；本条记录后台变更，没有功能代码修改。
- prod 扩展：无 pg_cron / pg_net → pg_cron 1.6.4（pg_catalog）、pg_net 0.20.4（extensions）。使用官方安装方式并通过 pg_extension 查询验证；执行时间早于任何应用迁移。
- prod Email OTP：长度 8 → 6；有效期 3600 → 120 秒，沿用用户先前明确要求。后台提示 Successfully updated settings，重新打开确认 6 和 120。
- 已有每日备份与 OTP 配置截图保存在本地忽略目录 `.local-dev/backups/prod-cutover-20261024/`，不含密码或 Token。
- 尚未运行正式库应用迁移，尚未切换 Vercel。

### 2026-10-24 / LOG-010：正式库 URL 与 Vercel 现状

- 修改文件：`docs/change-log.md`、`docs/production-cutover.md`。
- prod Authentication URL：Site URL 从 http://localhost:3000 改为 https://www.shuaqi.uk；空 Redirect allowlist 改为唯一 https://www.shuaqi.uk/confirm。保存后页面确认 Total URLs: 1，没有 vercel.app 或通配地址。
- Vercel 只读核对：现有 SUPABASE_URL / SUPABASE_KEY 均共享给 Production 和 Preview；NUXT_SUPABASE_SERVICE_KEY 尚不存在。未读取密钥值、未修改 Vercel 变量或触发新部署。切换前需拆分两环境。
- prod 仍使用默认发信服务；正在准备两份纯 OTP 模板及独立 SMTP。

### 2026-10-24 / LOG-011：正式库验证码模板及自动部署隔离

- 修改文件：`docs/change-log.md`、`docs/production-cutover.md`。
- prod Confirm sign up：默认英文主题/确认链接 → SHUAQI 登录验证码 / 纯 Token 正文；prod Magic link or OTP：默认英文登录链接 → 同样纯验证码模板。均使用本地已验证的两分钟模板，不含 ConfirmationURL；预览确认内容完整，保存后按钮禁用并出现 Reset template。注册模板另有成功提示。
- 本次只修改远端模板，不改仓库 supabase/templates 文件（本地这些既有改动仍保持原状）。
- 只读核对 prod GitHub 集成：Deploy to production=off、Automatic branching=off；未授权或扩大 GitHub 集成权限，保持仅手动正式迁移。
- 用户正在联系负责人配置 GitHub production environment/secrets。用户提出毕业后学校邮箱失效问题，已核实前端和数据库均限制 G5，待选择长期管理员邮箱受控登录方案；本条没有放宽注册或授予管理员。

### 2026-10-24 / LOG-012：正式库迁移预演与 SMTP 密钥交接

- 修改文件：`docs/change-log.md`、`docs/production-cutover.md`。
- prod dry-run 列出当前 12 个迁移，seeds=[]、roles=[]；使用 --skip-vault；尚未执行这些应用迁移。staging 同时做无变更预演核对。
- prod SMTP：展开未保存的配置表单，填入 noreply@shuaqi.uk / SHUAQI 耍起 / smtp.resend.com / 465 / resend；Password 留空，由用户填入独立 prod Resend Key 并亲自保存。未将未保存的 SMTP 表单记为已启用。
- SMTP 页面已交接用户，准备截图保存在本地忽略目录。200 封/小时限流等待 SMTP 保存后再配置。
- GitHub production environment/secrets 由用户联系负责人配置中；管理员邮箱方案仍待用户选择。正式网站未切换。

### 2026-10-24 / LOG-013：交接准备文档提交

- 修改文件：`docs/change-log.md`、`docs/production-cutover.md`。
- staging 预演确认 upToDate=true、无待迁移项；prod 仍等待手动 Actions。
- 两份文档整理到 `codex/production-cutover`，准备创建草稿 PR，清楚标明尚未切换。仅文档提交使用 [skip ci]，没有功能代码、测试或工作流修改。
- 后续依赖：负责人配置 GitHub production 的三个环境密钥；用户在已准备好的 prod SMTP 页面填写独立 Key 并保存；长期邮箱管理员方案待选择。未将其中任何待办记为完成。

### 2026-10-24 / LOG-014：IC 简写邮箱支持（仅本地）

- 用户已暂停正式库交接；本次不恢复交接、不修改 GitHub 或任何远端配置。
- 修改文件：`app/pages/login.vue`；新增 `app/utils/schoolEmail.ts`、`supabase/migrations/20261024000001_imperial_email_alias.sql`、`tests/unit/schoolEmail.test.ts`、`supabase/tests/12_imperial_email_alias.test.sql`、`tests/e2e/imperial-email-alias.spec.ts`；同步更新 `docs/change-log.md`。
- 原行为：前端和数据库只识别 Imperial 全称域名，ic.ac.uk 被拒绝。
- 新行为：注册页发送及校验 OTP 前把精确 @ic.ac.uk 统一到 @imperial.ac.uk，正常登录流程复用现有全称邮箱账号；页面显示兼容说明。数据库学校解析也把精确 ic.ac.uk 归为 imperial.ac.uk，不新增重复学校，不改历史迁移。
- 保持原有学校 active、子域与仿冒域名边界；不把 doc.ic.ac.uk 等其他域名自动改写，也不改已有 Auth 用户地址或授权。
- 测试覆盖：大小写/空白、两种写法注册、简写登录既有账号、学校验证及关闭状态、仿冒域名拒绝。验证待执行；新迁移尚未应用远端。

### 2026-10-24 / LOG-015：IC 邮箱首轮验证与测试账号调整

- 修改文件：`tests/e2e/imperial-email-alias.spec.ts`、`docs/change-log.md`。
- 新迁移已仅应用至本地隔离 Supabase；测试用迁移副本位于忽略目录 `.local-dev/backend/supabase/migrations/20261024000001_imperial_email_alias.sql`。
- 首轮结果：全部 161 项单元测试、类型检查通过；新邮箱专项 12 项及已有注册权限 31 项，共 43 项数据库断言通过。
- 浏览器首轮：简写注册、全称注册、仿冒域名拒绝通过；旧账号用例在测试准备后立即请求 OTP，触发本地 Auth 发送频率限制。
- 调整测试准备：只创建已验证的既有账号，不提前生成登录码；请求 OTP 后先断言响应成功，再进入验证码步骤。没有改变产品限流、验证码有效期或线上配置。复测待执行。
- 同一测试文件复测时修正原生 fetch Response.ok 为布尔属性的读取方式；此调整只影响新增测试准备代码，产品代码未再变动。

### 2026-10-24 / LOG-016：IC 简写邮箱本地验证完成

- 修改文件：`docs/change-log.md`，补记最终验证结果；本次产品文件清单见 LOG-014，测试准备调整见 LOG-015。
- 最终结果：全部 161 项单元测试通过（新增邮箱规范化 7 项）；邮箱专项 12 项和已有注册权限 31 项，共 43 项数据库断言通过；类型检查、生产构建、git diff --check 通过。
- 本地真实浏览器 + 本地 Supabase + Mailpit：4 项通过，覆盖 ic.ac.uk 注册、imperial.ac.uk 注册、简写登录已存在的全称邮箱账号（核对同一个用户 ID）、仿冒域名在请求 OTP 前拒绝。两种写法的 OTP 请求和验证码验证均使用统一的 imperial.ac.uk 地址。
- 本次只修改用户原本地 v0.1；未提交/推送 GitHub、未应用 staging/prod 迁移、未部署线上或发送真实邮件。正式数据库交接保持暂停。

### 2026-10-25 / LOG-017：KCL 邮箱支持与发布准备

- 用户要求加入 kcl.ac.uk 并推送上线，同时发布此前已验证的 IC 简写兼容；正式库交接仍暂停，当前网站继续使用 staging。发布基线 main `1a825ab0c6eca51d537f7d6eebdf6d261fb433ae`，独立分支 `codex/school-email-support`。
- 修改文件：`app/utils/profile.ts`（新增伦敦国王学院名称）、`app/utils/errors.ts`（学校邮箱提示包含 KCL）、`app/pages/login.vue`（学校列表加载提示不再仅称 G5）、`tests/unit/profile.test.ts`（六校与 KCL 名称断言）、`tests/unit/schoolEmail.test.ts`（KCL 大小写归一化不改域名）、`tests/e2e/smoke.spec.ts`（更新提示预期）、`README.md`（G5 + KCL 及 IC 别名说明）、`docs/change-log.md`。
- 新增文件：`supabase/migrations/20261025000001_kcl_school_domain.sql`（KCL 白名单，和既有学校一致支持子域、启用）、`supabase/tests/13_kcl_school_domain.test.sql`（注册、验证、仿冒域和停用规则）；上轮尚未提交的 `tests/e2e/imperial-email-alias.spec.ts` 整理为 `tests/e2e/school-email-signup.spec.ts`，覆盖 IC 两种写法、既有账号复用、KCL 注册完善资料与学校徽章。
- 同次发布包含 LOG-014 的 `app/utils/schoolEmail.ts`、IC 迁移与数据库测试及注册页规范化。没有改写历史迁移或测试种子；不纳入本地端口、Cookie、SMTP 模板和正式库切换文件。
- 后续：本地验证并核对白名单发布文件，CI 通过后备份 staging、先迁移数据库再发布网站，逐步补记结果。

### 2026-10-25 / LOG-018：学校邮箱发布验证与 staging 备份

- 修改文件：`docs/change-log.md`，同步发布分支；LOG-017 的发布文件已逐一复制核对，没有引入本地环境配置。
- 发布目录验证：159 项单元、类型检查和构建通过；本地注册权限/IC/KCL 数据库 56 项断言通过；浏览器 5 项通过，包含 KCL 注册、资料完善、已验证学校徽章、IC 两种写法和旧账号复用、仿冒域名拒绝。
- 本地截图：`test-results/kcl-school-verified.png`。浏览器测试仅使用本地 Supabase/Mailpit，不发送真实邮件。
- 线上公开配置只读核对：仍连接 staging `gsaqzxoohokmpjxcewjw`。dry-run 仅列出 20261024000001、20261025000001 两个迁移，seeds/roles 为空，跳过 Vault。尚未执行远端迁移。
- staging 的 public 结构与数据已备份到本机私有忽略目录 `.local-dev/backups/staging-school-email-20261025/`；文件 0600，不上传用户数据或凭证。
- `public-schema.sql`：205652 字节，SHA-256 `115ca67598a2990f0ea460204533e4503dd13429c4331b3ebcd92f8657d89d40`。
- `public-data.sql`：48979 字节，SHA-256 `cf71d862464580a97d4ef43a79115ad7c9833b0f74a026e971a9f1788b1c4d70`。
- 准备提交与推送本次发布分支并创建 PR；完整 CI、远端迁移及网站部署结果另行记录。正式库交接保持暂停。

### 2026-10-25 / LOG-019：GitHub 学校邮箱发布 PR

- 修改文件：`docs/change-log.md`，同步发布工作区；源码自功能提交 `5054a4a` 后未改动。
- 已推送 `codex/school-email-support` 并创建 PR #9：https://github.com/SHUAQI-Tech/shuaqi-app/pull/9 。CI：https://github.com/SHUAQI-Tech/shuaqi-app/actions/runs/40238704427 。
- Vercel 预览部署已成功。完整应用、数据库、浏览器 CI 运行中，尚未执行远端迁移或合并。
- 备份 COPY 行数核对：profiles 12、events 8、allowed_school_domains 5，与迁移前只读汇总一致。
- 只读线上 API 检查脚本已准备：从正式页面公开配置取客户端配置，仅在内存使用公开 key，输出学校白名单；不创建用户、不发邮件、不记录 key。迁移前公开白名单仍为 5 校。

### 2026-10-25 / LOG-020：完整 CI 通过，准备应用学校邮箱迁移

- 修改文件：`docs/change-log.md`，同步发布目录；功能代码仍为 `5054a4a`。
- CI 40238704427 全部成功：159 单元测试、407 数据库断言（13 个文件）、87 浏览器测试；类型、生成类型和构建通过。Vercel 与 Supabase 预览通过。
- 备份和预演已完成；即将仅在当前网站使用的 staging 应用 `20261024000001_imperial_email_alias.sql`、`20261025000001_kcl_school_domain.sql`，跳过 Vault，不执行 seed/额外角色。
- 迁移后通过数据库只读汇总和正式网站匿名 API 核对，再正常合并 PR #9。正式库切换继续暂停。

### 2026-10-25 / LOG-021：学校邮箱线上迁移与验证完成

- 修改文件：`docs/change-log.md`，同步发布目录；功能代码仍为完整 CI 通过的 `5054a4a`，其余文件没有测试后修改。
- staging 已成功应用 IC 与 KCL 两个版本化迁移，记录数 2；active 学校数 5 → 6。KCL 已启用，学校名 King's College London，子域规则与既有学校一致。
- 迁移后 profiles=12、events=8，与备份核对一致；IC 两种写法均解析为 imperial.ac.uk，KCL 解析为 kcl.ac.uk；fakekcl 和 kcl.ac.uk.evil.com 仍被拒绝。
- 正式网站公开配置仍指向 staging；匿名学校白名单读取验证通过，包含 KCL。诊断脚本最初尝试匿名调用内部学校解析 RPC 返回 401；该函数原有匿名访问限制保持，未扩大权限，解析正确性由内部只读 SQL 核对。脚本已改为只检查面向客户端的学校列表。
- 未修改 Auth 用户地址、资料、活动、SMTP、Vercel 变量或 prod；没有发送真实验证码邮件。
- 本条仅文档提交使用 [skip ci]，避免重复测试未变更的功能代码。接下来正常合并 PR #9 并核实正式部署，网站切库交接仍暂停。

### 2026-10-25 / LOG-022：KCL 与 IC 邮箱支持正式上线

- 修改文件：`docs/change-log.md`；本条发布结果归档同步 main，仅文档提交使用 [skip ci]，不改功能代码。
- PR #9 已合并：https://github.com/SHUAQI-Tech/shuaqi-app/pull/9 ，发布提交 `ee7aa68114d882804407b77e4131a7fbc8ebdc9e`。
- Vercel 正式部署 success / Deployment has completed：https://vercel.com/econ99macsfinance26-3951/shuaqi-app/4TUehSEmvgjjAMJKXxDiHDMLbU1j 。
- 自动 staging 迁移工作流成功：https://github.com/SHUAQI-Tech/shuaqi-app/actions/runs/40239430748 。两项迁移已先经 CLI 发布，再次 dry-run 确认无待迁移、无 seeds/roles。
- 线上 https://www.shuaqi.uk/login 的新 IC 兼容提示和学校列表加载文案已通过 HTTP 只读核对；网站实际连接仍为 staging。匿名客户端读取到 6 个有效学校域名，包含 kcl.ac.uk / King's College London。
- KCL 真实本地验证码注册、完善资料、中文已验证学校标识及 IC 旧账号复用均已通过 CI；完整结果 159 单元、407 数据库断言、87 浏览器测试。线上另行核对学校解析、白名单和仿冒域名拒绝，不向真实邮箱发送测试邮件。
- 所有本次代码、测试和 README 文件已随 PR #9 发布；逐文件清单见 LOG-014、LOG-017。备份保留在 `.local-dev/backups/staging-school-email-20261025/`，未将用户数据或密钥写入 GitHub。
- 原本地 v0.1 与发布工作区的日志同步；正式库切换交接及草稿 PR #8 保持暂停，未执行 prod 迁移或 Vercel 变量切换。

### 2026-10-25 / LOG-023：V0 问题总结前四项修复计划

- 用户授权修复并上线文档第 1–4 项：取消活动从发现列表移除、活动介绍图片、管理者报名头像、搭子候选头像；其他条目不在本次范围，正式库交接仍暂停。
- 基线 main `1f9928f739c05be97b839d17c6b3b21006265d11`，发布分支 `codex/event-media-avatar-fixes`。
- 已定位：发现查询显式包括 cancelled；多个卡片直接把 avatar_url 的 Storage 相对路径作为 img src；活动目前无图片列或上传入口。
- 计划修改：`app/pages/index.vue`、`app/components/event/EventForm.vue`、`app/components/event/Card.vue`、`app/components/organiser/EventForm.vue`、`app/pages/create.vue`、`app/pages/events/[id]/edit.vue`、`app/pages/events/[id]/index.vue`、`app/utils/eventFormat.ts`、`app/utils/errors.ts`、`app/types/database.types.ts`；新增 `app/utils/eventImages.ts`、`app/composables/useEventImageUrls.ts`、`app/components/event/ImageUpload.vue`、`app/components/event/Images.vue`、版本化图片迁移和对应测试/说明。
- 头像统一修改：`app/components/organiser/Roster.vue`、`app/components/buddy/BuddyPersonCard.vue`、`app/components/checkin/AttendeeList.vue`、`app/components/nearby/NearbyPersonCard.vue`。
- 设计：活动图片最多 6 张、每张 5MB，私有 bucket；图片跟随活动可见性，上传和新增关联限本人文件。旧活动默认空图片列表。上传期间禁用提交，移除表单图片在保存前不破坏原有活动图片。
- 本条修改文件仅 `docs/change-log.md`；后续实现、验证、备份、迁移、部署逐步补记。

### 2026-10-25 / LOG-024：活动图片与统一头像实现

- 已修改 LOG-023 列出的前端文件：发现只查 published；普通/后台表单传递 image_paths 并在上传时禁止提交；详情及卡片展示图片；四处原始 img 头像改为 ProfileAvatar。
- 新增：`app/utils/eventImages.ts`（6 张/5MB/格式校验）、`app/composables/useEventImageUrls.ts`（私有图片签名与失败重试）、`app/components/event/ImageUpload.vue`、`app/components/event/Images.vue`；新增 `supabase/migrations/20261025000002_event_images.sql`（图片列、私有 bucket、RLS 与关联校验）。
- 新增测试/文档：`tests/unit/eventImages.test.ts`、`supabase/tests/14_event_images.test.sql`、`docs/event-media.md`。未更改历史迁移。
- 当前尚待本地迁移、生成类型和完整验证；未推送或执行远端变更。

### 2026-10-25 / LOG-025：本地图片权限与类型验证

- 修改文件：`app/types/database.types.ts`（从本地迁移真实生成）、`app/composables/useEventImageUrls.ts`（空签名结果也显示失败）、`docs/change-log.md`；新增 `tests/e2e/event-media.spec.ts`。
- 图片迁移仅应用本地隔离库；图片权限 14 项断言通过，覆盖本人目录上传、跨用户拒绝、公开/学校/草稿/暂存图片读取、学校范围收紧和非法关联。
- 本地类型检查和全部 163 项单元测试通过（包含仅本地邮件模板测试，发布范围排除该既有测试文件）。
- 浏览器专项覆盖取消活动、两套表单图片创建编辑/移除/重试、图片权限、管理与签到名单及搭子头像相对路径和完整 URL。验证待执行，尚无远端变更。

### 2026-10-25 / LOG-026：图片浏览器回归与组织权限补测

- 修改文件：`tests/e2e/event-media.spec.ts`（候选卡片定位按实际 div.card 结构修正）、`supabase/tests/14_event_images.test.sql`（跨学校的组织者读图、保留原图片并添加本人图片、staff 不可编辑）、`docs/change-log.md`。
- 浏览器首轮 5 项通过，报名/签到头像也已加载；搭子用例使用了错误的 li 定位，未发现产品逻辑失败。修正后复测。
- 全部本地测试使用隔离数据，尚未发布。

### 2026-10-25 / LOG-027：四项问题专项验证与发布整理

- 图片权限补测后共 17 项断言通过；六项浏览器专项全部通过，含取消后发现页不显示且详情仍保留、两套表单图片上传/编辑/移除/失败重试、私有图片访问、管理/签到/搭子头像相对路径及完整 URL。
- 修改文件：`tests/e2e/event-media.spec.ts`（测试 PNG 从白色改为有色，便于验收截图辨识）、`docs/change-log.md`。功能代码未改动。
- 将 LOG-023–025 所列 24 个文件整理到独立发布分支，不复制本地端口、Cookie、邮件模板、暂停交接文件等其他改动。发布目录仍需类型、构建与完整 CI 验证。

### 2026-10-25 / LOG-028：四项修复发布前验证与备份

- 修改文件：`docs/change-log.md`，同步发布目录。功能代码冻结，发布目录 24 个白名单文件核对一致。
- 发布目录：161 项单元、类型检查、生产构建、diff 检查通过；本地图片权限 17 项断言、六项真实浏览器专项通过。
- 已备份 staging 的 public 结构和数据到本机私有忽略目录 `.local-dev/backups/staging-event-media-20261025/`，文件权限 0600；COPY 中 profiles 12 行、events 8 行与迁移前汇总一致。
- 迁移前线上：12 份资料、8 个活动，其中 4 个取消；没有 image_paths 列或 event-images bucket。dry-run 仅列出 `20261025000002_event_images.sql`，没有 seed/额外角色，跳过 Vault。
- `public-schema.sql`：205788 字节，SHA-256 `c2954fe2799349b9e841f0c95e645db7d86db500f7f801f465956d4eb0b4e58c`。
- `public-data.sql`：49015 字节，SHA-256 `e77fae53da1ffa313c3abf9a4f58d6c87745c0926a5488de3f846db59b9ead16`。
- 即将推送并创建 PR 运行完整 CI，尚未迁移线上或部署；正式库交接仍暂停。

### 2026-10-25 / LOG-029：四项修复 PR 与完整回归

- 修改文件：`docs/change-log.md`，同步发布工作区；功能提交 `e40b370c38f52cce465fc9b4660f3ea2d0dfefed` 已推送。
- PR #10：https://github.com/SHUAQI-Tech/shuaqi-app/pull/10 ，完整 CI：https://github.com/SHUAQI-Tech/shuaqi-app/actions/runs/40241761376 。Vercel 预览已成功，数据库和浏览器完整回归运行中。
- 首次 gh 创建命令受本地开发脚本 XDG_CONFIG_HOME 影响未找到登录；使用正常用户 GitHub CLI 登录后创建成功，没有修改凭证或环境配置。
- 尚未执行远端迁移或合并；仅在完整 CI 通过后更新当前线上 staging，正式库交接继续暂停。

### 2026-10-25 / LOG-030：完整 CI 通过，准备 staging 图片迁移

- 修改文件：`docs/change-log.md`，同步发布工作区；功能代码仍为 `e40b370`。
- PR #10 的 CI 40241761376 全部成功：161 单元测试、424 数据库断言（14 个文件）、93 浏览器测试，类型检查、生成类型及生产构建通过；Vercel 和 Supabase 预览通过。
- 执行前再次只读核对 staging：profiles 12、events 8、cancelled 4，与备份一致。首次内联 SQL 引号导致只读查询语法错误，改用临时 SQL 文件后成功，未写入任何业务记录。
- 即将仅应用 `20261025000002_event_images.sql`，随后核对图片列、私有 bucket、RLS、触发器和记录数，再正常合并 PR。prod 和数据库切换仍暂停。

### 2026-10-25 / LOG-031：staging 活动图片迁移完成

- 修改文件：`docs/change-log.md`，同步发布工作区；除文档外，功能代码与通过完整 CI 的 `e40b370` 一致。
- staging 已成功应用 `20261025000002_event_images.sql`，迁移记录 1；再次 dry-run 确认无待迁移、无 seeds/额外角色，跳过 Vault。
- 只读核对：profiles 12、events 8、cancelled 4；8 个旧活动 image_paths 均为空数组。新列非空且默认空数组，校验触发器 1。
- event-images bucket 为私有，限制 5242880 字节及 JPEG/PNG/WebP；新增策略仅本人目录 INSERT、按活动可见性 SELECT，无覆盖或删除权限。
- CLI 多条查询仅显示最后一个 SELECT，核对脚本已合并为单条 JSON 汇总后完整验证；未改业务记录。
- 准备以仅文档的 [skip ci] 提交保存 PR/CI/迁移记录，随后正常合并 PR #10；无测试后功能修改，无 prod 变更。

### 2026-10-25 / LOG-032：V0 前四项正式上线完成

- 修改文件：`docs/change-log.md`；本条结果归档同步 main，仅文档提交 [skip ci]，不改通过完整回归的功能代码。
- PR #10 已合并：https://github.com/SHUAQI-Tech/shuaqi-app/pull/10 ，发布提交 `ccbc0018ee81e2d188aaf555293117872f06c688`。第一次合并命令提交号不匹配被 GitHub 头部校验拒绝；核对真实完整 SHA 后正常合并，没有绕过检查或使用 admin。
- Vercel 正式部署 success / Deployment has completed：https://vercel.com/econ99macsfinance26-3951/shuaqi-app/9KNL5PiymrRB5UVa1xw5AkS69r22 。
- 自动迁移工作流成功：https://github.com/SHUAQI-Tech/shuaqi-app/actions/runs/40242389343 ，staging 成功、production skipped。迁移已先由 CLI 应用，后续无待迁移。
- 线上只读验收 https://www.shuaqi.uk/ 通过：匿名 API 仍读取 8 个活动，其中 4 个取消记录保留；发现页取消活动链接为 0，页面不再显示已取消卡片；image_paths 可读取，新版发布查询明确只取 published。网站连接仍为 staging。
- 首次前端资源脚本只匹配双引号，构建器实际使用反引号导致标记核对失败；按实际资源修正临时核验脚本后通过，没有修改功能代码。
- 完整发布验证：161 单元测试、424 数据库断言、93 浏览器测试，类型/生成类型/构建通过；六项新浏览器用例包含两套表单图片创建编辑、移除、失败重试、可见性以及报名/签到/搭子头像。线上不创建测试用户或活动。
- 24 个发布文件及用途见 LOG-023–027 和 PR；备份保留本机 `.local-dev/backups/staging-event-media-20261025/`，用户数据及凭证未上传。原本地 v0.1 与发布工作区日志同步；正式库切换交接和草稿 PR #8 继续暂停。

### 2026-10-26 / LOG-039：我的活动新增取消活动分类

- 用户要求将取消活动移出「我发起的」「我报名的」，集中展示并推送上线；本次基于 main b4ce361，独立分支 codex/my-events-cancelled，不包含等待真实 Google Key 的地图分支。
- 修改 `app/pages/my-events.vue`：增加「已取消」第三标签，两个原标签的列表/计数排除 cancelled；已取消汇总本人发起与有效报名的活动，按 id 去重，按开始时间倒序，提供独立空状态，保留详情与历史记录。
- 新增 `tests/e2e/my-events.spec.ts`：覆盖未来/过去的取消活动、本人发起与报名重叠去重、正常进行/结束活动保留、无关活动与退出报名不混入、取消后站内跳转和取消空状态。
- 本次不改数据库、迁移或部署环境；后续验证、PR 和上线结果继续补记。修改文件另含本日志。

### 2026-10-26 / LOG-040：我的活动分类本地验证通过

- 修改文件：`docs/change-log.md`，与本地 v0.1 同步本次条目；功能文件仍为 my-events.vue 和新增 my-events.spec.ts。
- 发布目录类型检查、161 单元测试、生产构建及 diff 检查通过。本地独立生产预览 9 浏览器测试全部通过：3 取消分类专项、6 原有活动取消/图片/头像/可见性回归。
- 专项确认：正常进行/结束活动保留；未来与过去取消活动从两个原标签及计数移出；本人发起与报名重复只展示一次；取消记录详情可打开且数据库保留；站内取消返回后分类即时正确；无取消时有独立提示。验收截图已查看。
- 即将仅提交这 3 个文件并创建 PR，待完整 CI 成功后正常合并上线；不包含本地地图分支或其他未提交内容。

### 2026-10-26 / LOG-041：我的活动取消分类正式上线

- 修改文件：`docs/change-log.md`；本条归档仅文档提交 [skip ci]，不改完整 CI 通过的功能源码。
- PR #11 已合并：https://github.com/SHUAQI-Tech/shuaqi-app/pull/11 ，功能提交 04ccaa848b702da77fa07767d9a4a1ac1bfe7220，合并发布提交 2d78978e090b8544105820ed749e1cecee0652f5。
- 完整 CI 成功：https://github.com/SHUAQI-Tech/shuaqi-app/actions/runs/40395346965 ，161 单元测试、424 数据库断言（14 文件）、96 浏览器测试；类型检查、生成类型与构建通过。本地 9 项浏览器专项通过并检查截图。
- Vercel 正式部署 success / Deployment has completed：https://vercel.com/econ99macsfinance26-3951/shuaqi-app/79HrcbXrQVC82PEP7y9RfY5MBwbw 。
- 只读线上核对成功：正式网站实际 /my-events 路由加载新组件 /_nuxt/DLxrpZYW.js，包含三个标签、两个原列表的 cancelled 排除、取消列表去重和独立空状态。该页面受登录保护，交互及真实数据分类由本地与 CI 的已登录隔离账号回归验证；线上未创建测试账号或活动，也未发送邮件。
- 发布范围仅 app/pages/my-events.vue、tests/e2e/my-events.spec.ts 和本日志。无数据库/迁移/部署变量变化，无需新增 Key 或所有者配置；等待 Google Key 的地图分支及正式库切换交接仍保持原状。
- 本次日志条目与原本地 v0.1 同步；本地尚未发布的地图日志 LOG-033–038 保留在原本地文件及独立地图分支，未混入本次功能发布。

### 2026-10-26 / LOG-042：七个问题第 4 项会话修复与基线

- 用户授权修复并验证上线。独立分支 codex/session-refresh-sync，基于 main ef0173d，不包含待 Google Key 的地图改动。
- 核查：线上公开 Nuxt Cookie 配置 maxAge=28800，但当前 @supabase/ssr 0.12.7 写 Cookie 时使用底层 400 天默认值；基线真实 SSR 续期及长期 Cookie 断言已经通过，不能把公开 8 小时配置直接当成真实写入期限。试改 30 天已撤掉，nuxt.config.ts 无本次发布修改。
- staging 配置经已登录 CLI 只读拉取到私有临时目录核对：JWT 3600 秒、令牌轮换开启、重用窗口 10 秒；导出未设置会话 timebox/inactivity。没有修改线上 Auth 参数。手册的旧令牌诊断仍按推断看待。
- 基线复现：有效 Cookie 与恢复后的页面认证状态不一致时，原版 pageshow 不会重新对齐，新增恢复用例失败；不声称复现原手机实际 8 小时掉线。
- 新增 app/plugins/session-sync.server.ts：页面复用认证辅助函数已续期的请求内客户端，避免第二客户端读取旧请求 Cookie；带会话 Cookie 的 HTML 设为 private, no-store。新增 app/plugins/session-sync.client.ts、app/utils/sessionSync.ts：启动、恢复可见、pageshow、online 时核对 Cookie 会话并验证 claims，并发事件去重，暂时网络失败不主动注销。
- 新增 tests/unit/sessionSync.test.ts（4 项通过）、tests/e2e/session-persistence.spec.ts（真实本地 Auth 续期、恢复、多标签、重开与撤销后数据保留）；修改 tests/e2e/support/backend.ts 仅导出既有测试登录辅助函数。修改 docs/qa/B-13_会话过期.md 与本日志，说明验证方法和真实手机实测边界。

### 2026-10-26 / LOG-043：会话同步本地对照与验证完成

- 修改文件仍限 LOG-042 的 8 个文件。服务端插件初次类型检查发现 Nuxt 注入值为 unknown，已增加运行时结构检查；构建发现 #supabase/server 为 Nitro 专用别名，不适用于应用插件，改为复用当前已安装 @nuxtjs/supabase 2.1 确认存在的 H3 请求上下文客户端，缺失时明确报错；不新增第二个认证实例。
- 恢复测试初次错误引用未加 $s 前缀的 Nuxt 状态键，其失败不作为证据。校正实际状态键、先确认初始有效状态后，独立导出 main ef0173d 到临时目录构建：原版 pageshow 恢复测试失败；同一用例在修复版通过。只复现受控的 UI/Cookie 状态不一致，不声称复现原手机历史掉线。
- 发布目录类型检查、165 单元测试、生产构建通过；最终 27 浏览器回归全部通过（5 会话专项、14 权限隔离、8 原有注册活动好友搭子链路）。真实本地 Auth 轮换、SSR Cookie 写回、刷新/非刷新认证 HTML no-store、多标签重开、会话撤销和同邮箱历史恢复均已验证。
- 功能代码冻结。真实手机锁屏/隔天 PWA 的长时间实机观察仍列在 QA，不用自动化模拟冒充完成。准备仅提交白名单 8 文件，推送后运行完整 CI，成功后上线。无数据库迁移、Auth 参数或环境变量更改。

### 2026-10-26 / LOG-044：手册第 4 项会话同步修复正式上线

- 修改文件：`docs/change-log.md`，本条仅文档归档 [skip ci]，功能源码自完整 CI 通过后未改。
- PR #12 已合并：https://github.com/SHUAQI-Tech/shuaqi-app/pull/12 ，功能提交 7f96a62e51977f411e0486f891856b9ab32d5a78；发布提交 f2b1c3300e6e88aabbb53c02dd8fb7685591165b。
- CI 全部通过：https://github.com/SHUAQI-Tech/shuaqi-app/actions/runs/40402874447 ，165 单元、424 数据库断言（14 文件）、101 浏览器测试，类型/生成类型/构建通过；本地最终 27 项会话/权限/原有注册链路通过，恢复用例原版失败、修复版通过。
- Vercel 正式部署成功：https://vercel.com/econ99macsfinance26-3951/shuaqi-app/5bMGFwVAyuhzkj2K6JLFJjNKkCN4 。只读线上核对：正式入口已加载 session-sync-client 与 visibilitychange/pageshow/online 恢复处理；携带合成无效 Cookie 的匿名 HTML 返回 private, no-store，页面正常渲染。未登录真实账号、未发邮件、未写线上业务数据。
- 已验证真实本地 Auth 自动续期、服务端 Cookie 写回、多标签重开、已撤销会话不能继续续期、同一邮箱重登返回原 user id 并保留资料/报名/签到历史。没有把自动化过期模拟当成真实手机连续放置 8 小时或跨天实测；此项边界已保留在 QA 文档。
- 本次仅 8 个白名单文件；没有数据库迁移、Auth 参数/窗口放宽、Cookie 名称或部署环境变量变化，无需所有者新增 Key/API。地图分支等待真实 Key，正式库切换交接继续保持原状。
- 本次日志与原本地 v0.1 同步；此前地图未发布日志仍只保留本地及对应分支。

### 2026-10-26 / LOG-045：UAL 学校邮箱支持计划与实现

- 用户授权增加 @ual.ac.uk 并验证后推送上线。基于 main 6da49a3，独立分支 codex/ual-school-email；地图分支仍等待真实 Key，正式库切换仍暂停。
- 新增 supabase/migrations/20261026000001_ual_school_domain.sql：启用 ual.ac.uk，校名 University of the Arts London，和既有学校一致允许子域，不扩大到所有 ac.uk。新增 supabase/tests/15_ual_school_domain.test.sql：15 项域名/注册/验证/停用/仿冒拒绝断言。
- 修改 app/utils/profile.ts（伦敦艺术大学）、app/utils/errors.ts（提示包含 UAL）；修改 tests/unit/profile.test.ts、tests/unit/schoolEmail.test.ts、tests/e2e/school-email-signup.spec.ts、tests/e2e/smoke.spec.ts 和 README.md，覆盖 UAL 注册完善资料/学校徽章与仿冒域拒绝。
- 本次共 10 个文件（另含本日志），不改邮件、Auth 参数、环境变量或历史迁移。计划先本地验证、备份当前线上 staging、完整 CI 后先迁移数据库再合并网站。

### 2026-10-26 / LOG-046：UAL 本地验证、备份和发布整理

- 修改文件：docs/change-log.md；发布目录 tests/e2e/smoke.spec.ts 排除原本地待地图分支的 GPS 按钮断言差异，只保留 UAL 邮箱提示变更。首轮本地注册/徽章 9 项通过，烟雾测试错误按钮文案导致 1 项失败、4 项未运行；修正发布目录后最终 14 项全部通过。原本地地图相关断言保留原状。
- 发布目录类型检查、165 单元、生产构建及 diff 检查通过；新增 UAL 数据库 15 项断言通过；14 浏览器回归通过，包含 UAL 本地真实验证码注册、完善资料、伦敦艺术大学已验证徽章，及 IC/KCL 和原有活动好友搭子链路。截图已检查。
- staging public 结构/数据备份至本机私有忽略目录 .local-dev/backups/staging-ual-email-20261026/，文件权限0600。备份 COPY 行数与只读汇总一致：profiles=12、events=10、allowed_school_domains=6，UAL 尚无记录。解析脚本已适配 pg_dump 带引号表名；没有更改备份内容。
- 迁移预演仅包含 20261026000001_ual_school_domain.sql，没有 seed/额外角色，跳过 Vault。远端尚未迁移，完整 CI 通过后再执行。
- public-schema.sql：207798 字节，SHA-256 c50ebece2bb343e46fa8927776df63bf96ff7e5498194c02cda6ee2355bf6425。
- public-data.sql：55113 字节，SHA-256 3c9150e86f923cf2cebb47d8d26b3567452a07ee6895ec141da82305c3eddb0f。

### 2026-10-26 / LOG-047：UAL 完整 CI 通过，准备数据库发布

- 修改文件：docs/change-log.md；功能提交526ecad053792f5945e926e60869bdd7322279ae已冻结。PR #13：https://github.com/SHUAQI-Tech/shuaqi-app/pull/13 。
- 完整 CI：https://github.com/SHUAQI-Tech/shuaqi-app/actions/runs/40406320606 全部成功：165 单元、439 数据库断言（15 文件）、102 浏览器测试；类型/生成类型/构建与预览通过。
- 正式网站公开配置再次核对仍为 staging gsaqzxoohokmpjxcewjw。备份、行数、权限和唯一迁移预演已确认；即将仅在该 staging 应用20261026000001_ual_school_domain.sql，不运行seed/额外角色，跳过Vault。随后核对并正常合并，不触碰prod。

### 2026-10-26 / LOG-048：UAL staging 迁移完成并核对

- 修改文件：docs/change-log.md；其余功能代码保持完整CI通过的526ecad。
- staging已应用20261026000001_ual_school_domain.sql，迁移记录1；再次dry-run无待迁移、无seed/额外角色，跳过Vault。有效学校6→7，UAL启用且支持学校子域，校名University of the Arts London。
- 迁移后profiles=12、events=10与备份一致；UAL标准/大写/子域均归属ual.ac.uk，fakeual与ual.ac.uk.evil.com被拒绝，IC仍归属imperial.ac.uk、KCL仍有效。
- 正式网站匿名学校列表读取到UAL，仍连接staging；未创建线上测试用户、未发送真实邮件，没有更改Auth参数或prod。准备正常合并PR #13触发前端部署。

### 2026-10-26 / LOG-049：UAL 邮箱支持正式上线

- 修改文件：docs/change-log.md；本条与LOG-047/048一同以仅文档的[skip ci]提交归档，不改完整CI通过的功能源码。
- PR #13已合并：https://github.com/SHUAQI-Tech/shuaqi-app/pull/13 ，发布提交478d99ebdb1c80bcc1fb535787acafae46a71cd7。完整CI40406320606通过：165单元、439数据库断言、102浏览器测试，类型/生成类型/构建通过；本地14浏览器及15新增数据库断言通过，UAL注册/资料/中文学校徽章截图已查看。
- Vercel正式部署成功：https://vercel.com/econ99macsfinance26-3951/shuaqi-app/vCQHjpeMyFeADqZ8QeWag8F8kJJs 。自动数据库工作流成功：https://github.com/SHUAQI-Tech/shuaqi-app/actions/runs/40407743697 ，staging成功、production skipped。
- 正式网站只读核对通过：公开学校列表有7所，包含ual.ac.uk / University of the Arts London；实际加载的前端含UAL注册提示，数据库仍为gsaqzxoohokmpjxcewjw。真实学校收信未由自动化冒充验证；全部验证码注册验收使用本地Supabase/Mailpit，不向真实邮箱发测试信。
- 线上UAL标准/大写/子域解析、仿冒域拒绝、IC/KCL保留和原profiles12/events10不变均已核对。没有修改其他Auth参数、邮件、环境变量或prod，无需新增API Key。
- 本次10个文件清单见LOG-045，备份保留本机私有忽略目录.local-dev/backups/staging-ual-email-20261026/，未上传用户数据/凭证；本次日志与原本地v0.1同步，原本地待地图分支测试文案保留不动。
