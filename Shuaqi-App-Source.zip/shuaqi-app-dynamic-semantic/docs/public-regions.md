# 公开地区与头像上传修复

## 用户可见规则

地区对其他有权查看名片的登录用户公开，包含个人主页、活动内找人、附近的人和搭子匹配。拉黑仍然使双方无法查看对方；活动发现仍须满足原有参与及 opt-in 条件。地区不提供隐藏开关，其他资料继续按各自的可见性设置处理。

用户只选择 London、Oxford、Cambridge。London 再选择 South Kensington / Chelsea、Bloomsbury / King's Cross、Holborn / Covent Garden、Camden、City / Shoreditch、Canary Wharf / East、South Bank / Southwark、West 或“伦敦其他 / 未细分”。不收集街道或邮编。表单直接告知公开用途；这与“附近的人”单独授权的实时 GPS 位置是不同的数据。

找搭子采用同一组选项，双方地区相同或任一方明确选择“不限地区”才可匹配。“伦敦其他 / 未细分”是独立选项，不等于全伦敦。

## 历史数据迁移

`20261023000001_public_regions.sql` 只映射明确的别名，例如 South Ken 和 South Kensington 归到同一片区；London 归到“伦敦其他 / 未细分”。无法识别的资料地区清空，并将 onboarded 设为 false，用户下次进入时重新选择。原先隐藏但可识别的地区会按新规则公开；上线前应向现有用户说明这一变化。

无法识别地区的开放需求改为 withdrawn，保留原有记录；不会将其改成“不限地区”。已经生成的计划和历史需求保留。新写入的未知地区由数据库拒绝。旧客户端提交明确别名仍可归一化；提交隐藏地区设置不会改变名片的公开规则。

## 部署与验证

先按项目现有迁移流程应用数据库迁移，再发布前端。可用 `pnpm test:unit`、`pnpm typecheck`、`pnpm test:db` 以及 Playwright 的 `profile-regions.spec.ts` 验证。不要对已有环境运行 `db reset`。

头像仍上传到用户自己的目录，使用新文件名、普通 INSERT；不再使用需要 SELECT 权限的 upsert，不增加存储读取授权。
