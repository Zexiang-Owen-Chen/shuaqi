// Web push handlers, loaded into the generated service worker with importScripts (nuxt.config.ts).
// The payload comes from /api/push/dispatch: { title, body, url, tag }.

self.addEventListener('push', (event) => {
  let data = {}
  try { data = event.data ? event.data.json() : {} }
  catch { data = { body: event.data ? event.data.text() : '' } }

  const url = typeof data.url === 'string' && data.url.startsWith('/') && !data.url.startsWith('//') ? data.url : '/'
  // Every push must show a notification: iOS and Chrome revoke the subscription of sites that stay silent.
  event.waitUntil(self.registration.showNotification(data.title || 'SHUAQI', {
    body: data.body || '',
    icon: '/icons/icon-192.png',
    badge: '/icons/icon-192.png',
    tag: data.tag || 'shuaqi',
    // A newer message in the same chat replaces the old notification and still alerts.
    renotify: !!data.tag,
    lang: 'zh-CN',
    data: { url },
  }))
})

// Open the page the notification is about, reusing an open SHUAQI window when there is one.
self.addEventListener('notificationclick', (event) => {
  event.notification.close()
  const target = new URL((event.notification.data && event.notification.data.url) || '/', self.location.origin).href
  event.waitUntil((async () => {
    const windows = await self.clients.matchAll({ type: 'window', includeUncontrolled: true })
    for (const client of windows) {
      if (new URL(client.url).origin !== self.location.origin) continue
      await client.focus()
      // The app routes in place (plugins/push.client.ts), keeping its state and sign-in.
      if (client.url !== target) client.postMessage({ type: 'shuaqi:navigate', url: target })
      return
    }
    await self.clients.openWindow(target)
  })())
})
