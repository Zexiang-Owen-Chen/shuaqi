begin;
create extension if not exists pgtap with schema extensions;
set local search_path = public, extensions;

-- ---- test helpers (rolled back with the transaction) ----
create schema tests;
grant usage on schema tests to anon, authenticated;
create table tests.ids (k text primary key, v text not null);
grant all on tests.ids to anon, authenticated;

create function tests.put(p_k text, p_v text) returns text language sql as $$
  insert into tests.ids (k, v) values (p_k, p_v) on conflict (k) do update set v = excluded.v returning v
$$;
create function tests.id(p_k text) returns uuid language sql stable as $$ select v::uuid from tests.ids where k = p_k $$;
create function tests.txt(p_k text) returns text language sql stable as $$ select v from tests.ids where k = p_k $$;

-- Creates an auth user (the sign-up trigger creates the profile) and stores its id under p_k.
create function tests.new_user(p_k text, p_email text, p_confirmed boolean default true) returns uuid
language plpgsql as $$
declare v uuid := gen_random_uuid();
begin
  insert into auth.users (id, instance_id, aud, role, email, email_confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
  values (v, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', p_email,
          case when p_confirmed then now() end, '{}', '{}', now(), now());
  perform tests.put(p_k, v::text);
  return v;
end $$;

-- Impersonate a user for the rest of the transaction (call while running as postgres).
create function tests.login(p_k text) returns void language plpgsql as $$
begin
  perform set_config('request.jwt.claims', json_build_object('sub', tests.id(p_k), 'role', 'authenticated')::text, true);
  perform set_config('role', 'authenticated', true);
end $$;

-- Forget the impersonated user's claims (run `reset role;` first).
create function tests.clear_claims() returns void language sql as $$
  select set_config('request.jwt.claims', '', true); select null::void
$$;

select plan(31);

-- ===========================================================================
-- Sign-up gate: only UK G5 school e-mail may create an auth user
-- ===========================================================================
select throws_ok(
  $$ insert into auth.users (id, instance_id, aud, role, email)
     values (gen_random_uuid(), '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', 'someone@gmail.com') $$,
  'P0001', 'school_email_required', 'gate: gmail address is rejected');
select throws_ok(
  $$ insert into auth.users (id, instance_id, aud, role, email)
     values (gen_random_uuid(), '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', 'x@fakeox.ac.uk') $$,
  'P0001', 'school_email_required', 'gate: look-alike domain fakeox.ac.uk is rejected');
select throws_ok(
  $$ insert into auth.users (id, instance_id, aud, role, email)
     values (gen_random_uuid(), '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', 'x@ox.ac.uk.evil.com') $$,
  'P0001', 'school_email_required', 'gate: G5 domain used as a prefix is rejected');
select throws_ok(
  $$ insert into auth.users (id, instance_id, aud, role, phone)
     values (gen_random_uuid(), '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', '447700900000') $$,
  'P0001', 'school_email_required', 'gate: user without e-mail is rejected');

select lives_ok($$ select tests.new_user('sub', 'abc@some.ox.ac.uk', false) $$, 'gate: Oxford college subdomain is allowed');
select is((select school_domain from profiles where id = tests.id('sub')), 'ox.ac.uk', 'gate: subdomain user gets a profile with school_domain ox.ac.uk');
select is((select school_verified_at from profiles where id = tests.id('sub')), null, 'gate: unconfirmed e-mail -> school_verified_at is null');
update auth.users set email_confirmed_at = now() where id = tests.id('sub');
select isnt((select school_verified_at from profiles where id = tests.id('sub')), null, 'gate: confirming e-mail sets school_verified_at');

select lives_ok($$ select tests.new_user('upper', 'Upper.Case@IMPERIAL.AC.UK', true) $$, 'gate: upper-case G5 address is allowed');
select ok((select school_verified_at is not null and school_domain = 'imperial.ac.uk' from profiles where id = tests.id('upper')),
  'gate: user confirmed at insert is school verified');

-- ===========================================================================
-- Column grants: users cannot change their own role / verification
-- ===========================================================================
select tests.new_user('alice', 'alice@imperial.ac.uk');
select tests.new_user('bob', 'bob@ucl.ac.uk');
update profiles set display_name = 'Bob', bio = 'secret bio', interests = '{chess,climbing}', gender = 'female',
                    region = 'Camden', birth_year = 2004,
                    visibility = '{"bio":"hidden","interests":"connections","photos":"public","gender":"public","age":"public","region":"hidden"}'
 where id = tests.id('bob');
update profiles set display_name = 'Alice' where id = tests.id('alice');

select tests.login('alice');
select throws_ok($$ update profiles set role = 'admin' where id = tests.id('alice') $$, '42501', null,
  'grants: user cannot update own profiles.role');
select throws_ok($$ update profiles set school_verified_at = null where id = tests.id('alice') $$, '42501', null,
  'grants: user cannot update own school_verified_at');
select throws_ok($$ update profiles set school_domain = 'cam.ac.uk' where id = tests.id('alice') $$, '42501', null,
  'grants: user cannot update own school_domain');
select lives_ok($$ update profiles set display_name = 'Alice B', bio = 'hi' where id = tests.id('alice') $$,
  'grants: user can update own editable fields');
select is((select display_name from profiles where id = tests.id('alice')), 'Alice B', 'grants: own display_name updated');
update profiles set display_name = 'hacked' where id = tests.id('bob');
reset role;
select is((select display_name from profiles where id = tests.id('bob')), 'Bob', 'grants: user cannot update another user''s profile');
select is((select role::text from profiles where id = tests.id('alice')), 'user', 'grants: role still user');

-- ===========================================================================
-- B-01: private profile rows and per-field visibility
-- ===========================================================================
select tests.login('alice');
select is((select count(*)::int from profiles where id = tests.id('bob')), 0, 'B-01: A cannot read B''s profiles row');
select is((select count(*)::int from profiles), 1, 'B-01: A sees only their own profiles row');
select tests.put('card', public.get_profile_card(tests.id('bob'))::text);
reset role;
select is((tests.txt('card')::jsonb) ->> 'display_name', 'Bob', 'B-01: card shows display name');
select ok(not (tests.txt('card')::jsonb ? 'bio'), 'B-01: hidden bio not in card');
select is(tests.txt('card')::jsonb ->> 'region', 'London / Camden', 'B-01: coarse region is public even with legacy hidden setting');
select ok(not (tests.txt('card')::jsonb ? 'interests'), 'B-01: connections-only interests hidden from non-connection');
select is((tests.txt('card')::jsonb) ->> 'gender', 'female', 'B-01: public gender shown');

-- Become connected: connections-scope fields appear, hidden stays hidden.
insert into connections (user_a, user_b) values (least(tests.id('alice'), tests.id('bob')), greatest(tests.id('alice'), tests.id('bob')));
select tests.login('alice');
select tests.put('card2', public.get_profile_card(tests.id('bob'))::text);
reset role;
select is((tests.txt('card2')::jsonb) -> 'interests', '["chess", "climbing"]'::jsonb, 'B-01: connection sees connections-scope interests');
select ok(not (tests.txt('card2')::jsonb ? 'bio'), 'B-01: connection still cannot see hidden bio');
select ok((tests.txt('card2')::jsonb ->> 'connected')::boolean, 'B-01: card reports connected');

-- Event context without opt-in and without connection -> null.
delete from connections;
select tests.login('alice');
select is(public.get_profile_card(tests.id('bob'), 'event', gen_random_uuid()), null,
  'B-01: event-context card of a non-opted-in stranger is null');
reset role;

-- Blocking: both directions get null.
insert into blocks (blocker_id, blocked_id) values (tests.id('bob'), tests.id('alice'));
select tests.login('alice');
select is(public.get_profile_card(tests.id('bob')), null, 'B-01: blocked viewer gets null card');
reset role;
select tests.login('bob');
select is(public.get_profile_card(tests.id('alice')), null, 'B-01: blocker also gets null card of blocked user');
select ok((public.get_profile_card(tests.id('bob')) ? 'bio'), 'B-01: user sees all own fields on own card');

select * from finish();
rollback;
