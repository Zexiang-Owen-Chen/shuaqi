begin;
create extension if not exists pgtap with schema extensions;
set local search_path = public, extensions;

-- ---- test helpers (rolled back with the transaction) ----
create schema tests;
grant usage on schema tests to anon, authenticated;
create table tests.ids (k text primary key, v text not null);
grant all on tests.ids to anon, authenticated;

create function tests.put(p_k text, p_v text) returns text language sql as $$
  insert into tests.ids (k, v) values (p_k, p_v) on conflict (k) do update set v = excluded.v returning v
$$;
create function tests.id(p_k text) returns uuid language sql stable as $$ select v::uuid from tests.ids where k = p_k $$;
create function tests.txt(p_k text) returns text language sql stable as $$ select v from tests.ids where k = p_k $$;

-- Creates an auth user (the sign-up trigger creates the profile) and stores its id under p_k.
create function tests.new_user(p_k text, p_email text, p_confirmed boolean default true) returns uuid
language plpgsql as $$
declare v uuid := gen_random_uuid();
begin
  insert into auth.users (id, instance_id, aud, role, email, email_confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
  values (v, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', p_email,
          case when p_confirmed then now() end, '{}', '{}', now(), now());
  perform tests.put(p_k, v::text);
  return v;
end $$;

-- Impersonate a user for the rest of the transaction (call while running as postgres).
create function tests.login(p_k text) returns void language plpgsql as $$
begin
  perform set_config('request.jwt.claims', json_build_object('sub', tests.id(p_k), 'role', 'authenticated')::text, true);
  perform set_config('role', 'authenticated', true);
end $$;

-- Forget the impersonated user's claims (run `reset role;` first).
create function tests.clear_claims() returns void language sql as $$
  select set_config('request.jwt.claims', '', true); select null::void
$$;

select plan(34);

select tests.new_user('host', 'host@imperial.ac.uk');
select tests.new_user('u1', 'u1@imperial.ac.uk');
select tests.new_user('u2', 'u2@ucl.ac.uk');
select tests.new_user('u3', 'u3@lse.ac.uk');
select tests.new_user('unverified', 'nov@cam.ac.uk', false);

-- Host creates events through the client path (insert into events, RLS + guard).
select tests.login('host');
select lives_ok($$
  with e as (
    insert into events (host_user_id, type, category, title, starts_at, checkin_mode)
    values (tests.id('host'), 'group', 'social', 'Freshers mixer', now() + interval '1 day', 'none') returning id) select tests.put('ev', id::text) from e $$, 'host can create an event');
with e as (
  insert into events (host_user_id, category, title, starts_at, checkin_mode, capacity)
  values (tests.id('host'), 'sport', 'Doubles', now() + interval '1 day', 'none', 2) returning id) select tests.put('full', id::text) from e;
with e as (
  insert into events (host_user_id, category, title, starts_at, checkin_mode)
  values (tests.id('host'), 'food', 'Dumplings', now() + interval '1 day', 'none') returning id) select tests.put('cancel', id::text) from e;
select throws_ok($$ insert into events (host_user_id, category, title, starts_at, checkin_mode)
                    values (tests.id('u1'), 'x', 'spoof', now() + interval '1 day', 'none') $$,
  'P0001', 'host_must_be_self', 'cannot create an event hosted by someone else');
reset role;
select is((select count(*)::int from event_rsvps where event_id = tests.id('ev') and user_id = tests.id('host') and status = 'going'),
  1, 'host is automatically going');

-- ===========================================================================
-- B-02: opt-out removes a user from list_event_participants
-- ===========================================================================
select tests.login('u1');
select lives_ok($$ select join_event(tests.id('ev')) $$, 'B-02: u1 joins');
select lives_ok($$ select set_event_optin(tests.id('ev'), true, '{interests}') $$, 'B-02: u1 opts in');
reset role;
select tests.login('u2');
select lives_ok($$ select join_event(tests.id('ev')) $$, 'B-02: u2 joins');
select lives_ok($$ select set_event_optin(tests.id('ev'), true, '{interests,bio}') $$, 'B-02: u2 opts in');
reset role;
select tests.login('u3');
select throws_ok($$ select set_event_optin(tests.id('ev'), true) $$, 'P0001', 'not_registered', 'B-02: cannot opt in without RSVP');
select throws_ok($$ select * from list_event_participants(tests.id('ev')) $$, 'P0001', 'not_registered',
  'B-02: non-attendee cannot list participants');
reset role;

select tests.login('u1');
select is((select count(*)::int from list_event_participants(tests.id('ev')) where card ->> 'id' = tests.txt('u2')), 1,
  'B-02: opted-in u2 is listed for u1');
select ok((select card ? 'bio' from list_event_participants(tests.id('ev')) where card ->> 'id' = tests.txt('u2')),
  'B-02: card shows the fields u2 chose for the event');
reset role;
select tests.login('u2');
select lives_ok($$ select set_event_optin(tests.id('ev'), false) $$, 'B-02: u2 opts out');
reset role;
select tests.login('u1');
select is((select count(*)::int from list_event_participants(tests.id('ev')) where card ->> 'id' = tests.txt('u2')), 0,
  'B-02: after opt-out u2 disappears from the list');
select is(get_profile_card(tests.id('u2'), 'event', tests.id('ev')), null,
  'B-02: event-context card of opted-out stranger is null');
reset role;

-- ===========================================================================
-- B-05: capacity (host counts as one of capacity 2)
-- ===========================================================================
select tests.login('u1');
select lives_ok($$ select join_event(tests.id('full')) $$, 'B-05: u1 takes the last seat');
select lives_ok($$ select join_event(tests.id('full')) $$, 'B-05: repeat join by u1 is idempotent');
reset role;
select tests.login('u2');
select throws_ok($$ select join_event(tests.id('full')) $$, 'P0001', 'event_full', 'B-05: join on a full event raises event_full');
reset role;
select is((select count(*)::int from event_rsvps where event_id = tests.id('full') and status = 'going'), 2,
  'B-05: going count never exceeds capacity');
select tests.login('u1');
select lives_ok($$ select leave_event(tests.id('full')) $$, 'B-05: u1 leaves');
reset role;
select tests.login('u2');
select lives_ok($$ select join_event(tests.id('full')) $$, 'B-05: freed seat can be taken');
reset role;
select tests.login('unverified');
select throws_ok($$ select join_event(tests.id('ev')) $$, 'P0001', 'school_verification_required',
  'unverified user cannot join');
reset role;

-- ===========================================================================
-- B-06: cancelled events cannot be joined
-- ===========================================================================
select tests.login('u1');
select throws_ok($$ select cancel_event(tests.id('cancel')) $$, 'P0001', 'forbidden', 'B-06: non-manager cannot cancel');
reset role;
select tests.login('host');
select lives_ok($$ select cancel_event(tests.id('cancel')) $$, 'B-06: host cancels');
reset role;
select tests.login('u3');
select throws_ok($$ select join_event(tests.id('cancel')) $$, 'P0001', 'event_cancelled',
  'B-06: join after cancel raises event_cancelled');
reset role;

-- ===========================================================================
-- B-08: organiser of org A cannot see org B attendees / RSVPs
-- ===========================================================================
select tests.new_user('owner_a', 'owner.a@cam.ac.uk');
select tests.new_user('owner_b', 'owner.b@cam.ac.uk');
select tests.new_user('staff_b', 'staff.b@cam.ac.uk');
with o as (insert into organisations (name) values ('Org A') returning id) select tests.put('org_a', id::text) from o;
with o as (insert into organisations (name) values ('Org B') returning id) select tests.put('org_b', id::text) from o;
insert into org_members (org_id, user_id, role) values
  (tests.id('org_a'), tests.id('owner_a'), 'organiser'),
  (tests.id('org_b'), tests.id('owner_b'), 'owner'),
  (tests.id('org_b'), tests.id('staff_b'), 'staff');
select tests.login('owner_b');
select lives_ok($$ with e as (
    insert into events (host_user_id, org_id, type, category, title, starts_at, checkin_mode)
    values (tests.id('owner_b'), tests.id('org_b'), 'group', 'society', 'Org B social', now() + interval '2 days', 'none') returning id) select tests.put('ev_b', id::text) from e $$, 'B-08: org B owner creates an org event');
select throws_ok($$ insert into events (host_user_id, org_id, category, title, starts_at, checkin_mode)
                    values (tests.id('owner_b'), tests.id('org_a'), 'x', 'not mine', now() + interval '2 days', 'none') $$,
  'P0001', 'not_org_organiser', 'B-08: cannot create events for an org you do not organise');
reset role;
select tests.login('u1');
select join_event(tests.id('ev_b'));
reset role;

select tests.login('owner_a');
select throws_ok($$ select * from list_event_attendees(tests.id('ev_b')) $$, 'P0001', 'forbidden',
  'B-08: org A organiser cannot list org B attendees');
select is((select count(*)::int from event_rsvps where event_id = tests.id('ev_b')), 0,
  'B-08: org A organiser reads no RSVPs of the org B event');
select throws_ok($$ select get_checkin_code(tests.id('ev_b')) $$, 'P0001', 'forbidden',
  'B-08: org A organiser cannot read org B check-in code');
select throws_ok($$ select organiser_confirm_attendance(tests.id('ev_b'), tests.id('u1')) $$, 'P0001', 'forbidden',
  'B-08: org A organiser cannot confirm attendance at org B event');
reset role;
select tests.login('owner_b');
select is((select count(*)::int from list_event_attendees(tests.id('ev_b'))), 2, 'B-08: org B owner lists host + u1');
reset role;
select tests.login('staff_b');
select is((select count(*)::int from event_rsvps where event_id = tests.id('ev_b')), 2, 'B-08: org B staff reads the RSVPs');
reset role;
select tests.login('u1');
select is((select count(*)::int from event_rsvps where event_id = tests.id('ev_b')), 1, 'B-08: attendee sees only their own RSVP');
select throws_ok($$ select * from list_event_attendees(tests.id('ev_b')) $$, 'P0001', 'forbidden',
  'B-08: attendee cannot list attendees');
reset role;

select * from finish();
rollback;
