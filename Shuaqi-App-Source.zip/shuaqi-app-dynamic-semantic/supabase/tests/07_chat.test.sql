begin;
create extension if not exists pgtap with schema extensions;
set local search_path = public, extensions;

-- ---- test helpers (rolled back with the transaction) ----
create schema tests;
grant usage on schema tests to anon, authenticated;
create table tests.ids (k text primary key, v text not null);
grant all on tests.ids to anon, authenticated;

create function tests.put(p_k text, p_v text) returns text language sql as $$
  insert into tests.ids (k, v) values (p_k, p_v) on conflict (k) do update set v = excluded.v returning v
$$;
create function tests.id(p_k text) returns uuid language sql stable as $$ select v::uuid from tests.ids where k = p_k $$;
create function tests.txt(p_k text) returns text language sql stable as $$ select v from tests.ids where k = p_k $$;

-- Creates an auth user (the sign-up trigger creates the profile) and stores its id under p_k.
create function tests.new_user(p_k text, p_email text, p_confirmed boolean default true) returns uuid
language plpgsql as $$
declare v uuid := gen_random_uuid();
begin
  insert into auth.users (id, instance_id, aud, role, email, email_confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
  values (v, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', p_email,
          case when p_confirmed then now() end, '{}', '{}', now(), now());
  perform tests.put(p_k, v::text);
  return v;
end $$;

-- Impersonate a user for the rest of the transaction (call while running as postgres).
create function tests.login(p_k text) returns void language plpgsql as $$
begin
  perform set_config('request.jwt.claims', json_build_object('sub', tests.id(p_k), 'role', 'authenticated')::text, true);
  perform set_config('role', 'authenticated', true);
end $$;

-- Forget the impersonated user's claims (run `reset role;` first).
create function tests.clear_claims() returns void language sql as $$
  select set_config('request.jwt.claims', '', true); select null::void
$$;

select plan(46);

select tests.new_user('a', 'a@imperial.ac.uk');
select tests.new_user('b', 'b@ucl.ac.uk');
select tests.new_user('c', 'c@lse.ac.uk');
select tests.new_user('d', 'd@cam.ac.uk');
select tests.new_user('unverified', 'u@ox.ac.uk', false);
insert into connections (user_a, user_b) values
  (least(tests.id('a'), tests.id('b')), greatest(tests.id('a'), tests.id('b'))),
  (least(tests.id('a'), tests.id('d')), greatest(tests.id('a'), tests.id('d'))),
  (least(tests.id('a'), tests.id('unverified')), greatest(tests.id('a'), tests.id('unverified')));

-- ===========================================================================
-- Sending: only to friends, with sane bodies
-- ===========================================================================
select tests.login('a');
select tests.put('m1', (send_message(tests.id('b'), '  Hi B!  ')).id::text);
select is((select body from messages where id = tests.id('m1')), 'Hi B!', 'chat: friend can send, body is trimmed');
select is((select count(*)::int from conversations), 1, 'chat: first message creates the conversation');
select is(open_conversation(tests.id('b')), (select id from conversations), 'chat: open_conversation returns the same conversation');
select throws_ok($$ select send_message(tests.id('c'), 'hello') $$, 'P0001', 'not_connected', 'chat: non-friend cannot be messaged');
select throws_ok($$ select open_conversation(tests.id('c')) $$, 'P0001', 'not_connected', 'chat: cannot open a conversation with a non-friend');
select throws_ok($$ select send_message(tests.id('a'), 'me') $$, 'P0001', 'not_connected', 'chat: cannot message yourself');
select throws_ok($$ select send_message(tests.id('b'), '   ') $$, 'P0001', 'message_empty', 'chat: blank message is rejected');
select throws_ok($$ select send_message(tests.id('b'), repeat('x', 1001)) $$, 'P0001', 'message_too_long', 'chat: over 1000 characters is rejected');
select lives_ok($$ select send_message(tests.id('b'), repeat('好', 1000)) $$, 'chat: 1000 characters is accepted');
select throws_ok($$ insert into messages (conversation_id, sender_id, body) select id, tests.id('a'), 'direct' from conversations $$,
  '42501', null, 'chat: clients cannot insert messages directly');
select throws_ok($$ update conversations set user_b_read_at = now() $$, '42501', null, 'chat: clients cannot update conversations directly');
select is((select count(*)::int from conversations where user_a_read_at is not null or user_b_read_at is not null), 1,
  'chat: sending marks the conversation read for the sender');
reset role;

select tests.login('unverified');
select throws_ok($$ select send_message(tests.id('a'), 'hi') $$, 'P0001', 'school_verification_required',
  'chat: unverified school e-mail cannot send');
reset role;

-- ===========================================================================
-- Reading: only the two people
-- ===========================================================================
select tests.login('b');
select is((select count(*)::int from messages), 2, 'chat: recipient reads the conversation');
select is((select unread from list_my_conversations()), 2, 'chat: recipient has 2 unread');
select is(unread_message_count(), 2, 'chat: unread total for recipient');
select is((select (card ->> 'id')::uuid from list_my_conversations()), tests.id('a'), 'chat: list shows the friend''s card');
select is((select last_sender_id from list_my_conversations()), tests.id('a'), 'chat: list shows the last sender');
select lives_ok($$ select mark_conversation_read((select id from conversations)) $$, 'chat: recipient marks read');
select is(unread_message_count(), 0, 'chat: unread is 0 after reading');
reset role;

select tests.login('a');
select is(unread_message_count(), 0, 'chat: sender has nothing unread');
reset role;

select tests.login('c');
select is((select count(*)::int from messages), 0, 'chat: outsider reads no messages');
select is((select count(*)::int from conversations), 0, 'chat: outsider sees no conversations');
select is((select count(*)::int from list_my_conversations()), 0, 'chat: outsider lists nothing');
select throws_ok($$ select mark_conversation_read(tests.id('m1')) $$, 'P0001', 'conversation_not_found',
  'chat: outsider cannot mark a conversation read');
select throws_ok($$ select can_chat(tests.id('a'), tests.id('b')) $$, '42501', null,
  'chat: can_chat is not callable (would reveal who is friends with whom)');
reset role;

set local role anon;
select throws_ok($$ select count(*) from messages $$, '42501', null, 'chat: anon cannot read messages');
reset role;

-- ===========================================================================
-- Reporting a message
-- ===========================================================================
select tests.login('b');
select tests.put('r1', report_message(tests.id('m1'), '骚扰或不当言行', 'rude')::text);
select is((select snapshot -> 'message' ->> 'body' from reports where id = tests.id('r1')), 'Hi B!', 'report: snapshot keeps the message');
select is((select (snapshot ->> 'reported_user_id')::uuid from reports where id = tests.id('r1')), tests.id('a'),
  'report: snapshot names the sender');
select is(report_message(tests.id('m1'), '骚扰或不当言行')::text, tests.txt('r1'), 'report: repeat click returns the open report');
select throws_ok($$ insert into reports (reporter_id, target_type, target_id, reason) values (tests.id('b'), 'message', tests.id('m1'), 'x') $$,
  '42501', null, 'report: message reports cannot be inserted directly');
reset role;

select tests.login('a');
select throws_ok($$ select report_message(tests.id('m1'), 'x') $$, 'P0001', 'cannot_report_own_message', 'report: cannot report own message');
reset role;
select tests.login('c');
select throws_ok($$ select report_message(tests.id('m1'), 'x') $$, 'P0001', 'message_not_found', 'report: outsider cannot report');
reset role;

-- ===========================================================================
-- Rate limit and feature flag
-- ===========================================================================
select tests.login('a');
select send_message(tests.id('d'), 'msg ' || i) from generate_series(1, 18) i;  -- 20 this minute with the two above
select throws_ok($$ select send_message(tests.id('d'), 'one too many') $$, 'P0001', 'rate_limited', 'chat: 21st message in a minute is limited');
reset role;
update messages set created_at = now() - interval '2 hours' where sender_id = tests.id('a');
insert into messages (conversation_id, sender_id, body, created_at)
  select c.id, tests.id('a'), 'old', now() - interval '3 hours' from conversations c, generate_series(1, 480)
  where tests.id('d') in (c.user_a, c.user_b);
select tests.login('a');
select throws_ok($$ select send_message(tests.id('d'), 'daily') $$, 'P0001', 'rate_limited', 'chat: 501st message in a day is limited');
reset role;
delete from messages where body = 'old';

update feature_flags set enabled = false where key = 'chat';
select tests.login('a');
select throws_ok($$ select send_message(tests.id('b'), 'off') $$, 'P0001', 'feature_disabled', 'chat: switched off by the flag');
reset role;
update feature_flags set enabled = true where key = 'chat';

-- ===========================================================================
-- Blocking and unfriending hide the conversation; reporting still works
-- ===========================================================================
select tests.login('a');
select tests.put('m2', (send_message(tests.id('b'), 'are you there?')).id::text);
reset role;
select tests.login('b');
select lives_ok($$ select block_user(tests.id('a')) $$, 'block: b blocks a');
select is((select count(*)::int from messages), 0, 'block: conversation hidden from the blocker');
select ok(report_message(tests.id('m2'), '骚扰或不当言行') is not null, 'block: blocker can still report the message');
reset role;
select tests.login('a');
select is((select count(*)::int from messages where conversation_id = (select conversation_id from messages where id = tests.id('m1'))), 0,
  'block: conversation hidden from the blocked user');
select throws_ok($$ select send_message(tests.id('b'), 'please') $$, 'P0001', 'not_connected', 'block: blocked user cannot send');
select lives_ok($$ select remove_connection(tests.id('d')) $$, 'unfriend: a removes d');
select is((select count(*)::int from list_my_conversations()), 0, 'unfriend: no conversations left to list');
reset role;

-- ===========================================================================
-- Retention and account deletion
-- ===========================================================================
update messages set created_at = now() - interval '13 months' where id = tests.id('m1');
select cmp_ok(purge_old_messages(), '>=', 1, 'retention: messages older than 12 months are purged');
select is((select count(*)::int from messages where id = tests.id('m1')), 0, 'retention: the old message is gone');
delete from auth.users where id = tests.id('d');
select is((select count(*)::int from conversations where tests.id('d') in (user_a, user_b)), 0,
  'deletion: deleting an account deletes its conversations and messages');

select * from finish();
rollback;
