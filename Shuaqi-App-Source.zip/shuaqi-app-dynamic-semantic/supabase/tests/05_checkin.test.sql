begin;
create extension if not exists pgtap with schema extensions;
set local search_path = public, extensions;

-- ---- test helpers (rolled back with the transaction) ----
create schema tests;
grant usage on schema tests to anon, authenticated;
create table tests.ids (k text primary key, v text not null);
grant all on tests.ids to anon, authenticated;

create function tests.put(p_k text, p_v text) returns text language sql as $$
  insert into tests.ids (k, v) values (p_k, p_v) on conflict (k) do update set v = excluded.v returning v
$$;
create function tests.id(p_k text) returns uuid language sql stable as $$ select v::uuid from tests.ids where k = p_k $$;
create function tests.txt(p_k text) returns text language sql stable as $$ select v from tests.ids where k = p_k $$;

-- Creates an auth user (the sign-up trigger creates the profile) and stores its id under p_k.
create function tests.new_user(p_k text, p_email text, p_confirmed boolean default true) returns uuid
language plpgsql as $$
declare v uuid := gen_random_uuid();
begin
  insert into auth.users (id, instance_id, aud, role, email, email_confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
  values (v, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', p_email,
          case when p_confirmed then now() end, '{}', '{}', now(), now());
  perform tests.put(p_k, v::text);
  return v;
end $$;

-- Impersonate a user for the rest of the transaction (call while running as postgres).
create function tests.login(p_k text) returns void language plpgsql as $$
begin
  perform set_config('request.jwt.claims', json_build_object('sub', tests.id(p_k), 'role', 'authenticated')::text, true);
  perform set_config('role', 'authenticated', true);
end $$;

-- Forget the impersonated user's claims (run `reset role;` first).
create function tests.clear_claims() returns void language sql as $$
  select set_config('request.jwt.claims', '', true); select null::void
$$;

select plan(40);

-- Imperial College (51.4988, -0.1749). 0.0045 deg lat ~ 500 m.
select tests.new_user('host', 'host@imperial.ac.uk');
select tests.new_user('staff', 'staff@imperial.ac.uk');
select tests.new_user('u1', 'u1@imperial.ac.uk');
select tests.new_user('u2', 'u2@imperial.ac.uk');   -- never registers
with o as (insert into organisations (name) values ('ICU Board Games') returning id) select tests.put('org', id::text) from o;
insert into org_members (org_id, user_id, role) values (tests.id('org'), tests.id('host'), 'organiser'), (tests.id('org'), tests.id('staff'), 'staff');

select tests.login('host');
with e as (insert into events (host_user_id, org_id, type, category, title, starts_at, checkin_mode, location_lat, location_lng)
           values (tests.id('host'), tests.id('org'), 'group', 'games', 'Board games now', now(), 'qr_geo', 51.4988, -0.1749) returning id)
select tests.put('ev', id::text) from e;
with e as (insert into events (host_user_id, category, title, starts_at, checkin_mode, location_lat, location_lng)
           values (tests.id('host'), 'games', 'Later tonight', now() + interval '3 hours', 'qr_geo', 51.4988, -0.1749) returning id)
select tests.put('later', id::text) from e;
select tests.put('code', get_checkin_code(tests.id('ev')));
select tests.put('later_code', get_checkin_code(tests.id('later')));
reset role;
select isnt(tests.txt('code'), null, 'host can read the check-in code');

select tests.login('u1');
select join_event(tests.id('ev'));
select join_event(tests.id('later'));

-- ===========================================================================
-- B-07: ordinary users cannot create or upgrade evidence
-- ===========================================================================
select throws_ok($$ select get_checkin_code(tests.id('ev')) $$, 'P0001', 'forbidden', 'B-07: attendee cannot read the code');
select throws_ok($$ select rotate_checkin_code(tests.id('ev')) $$, 'P0001', 'forbidden', 'B-07: attendee cannot rotate the code');
select throws_ok($$ select organiser_confirm_attendance(tests.id('ev'), tests.id('u1')) $$, 'P0001', 'forbidden',
  'B-07: attendee cannot confirm their own attendance');
select throws_ok($$ insert into participation_evidence (event_id, subject_user_id, type, source, verification_status)
                    values (tests.id('ev'), tests.id('u1'), 'organiser_confirmed_attendance', 'organiser_manual', 'verified') $$,
  '42501', null, 'B-07: attendee cannot insert evidence');
select is((select count(*)::int from event_checkin_codes), 0, 'B-07: attendee cannot read check-in codes table');

-- ===========================================================================
-- B-17: check-in failure reasons
-- ===========================================================================
select is(event_checkin('no-such-code', 51.4988, -0.1749, 10) ->> 'reason', 'invalid_code', 'B-17: unknown code -> invalid_code');
select is(event_checkin(tests.txt('code'), 51.4988, -0.1749, 150) ->> 'reason', 'location_inaccurate', 'B-17: accuracy 150 m -> location_inaccurate');
select is(event_checkin(tests.txt('code'), 51.4988 + 0.0045, -0.1749, 10) ->> 'reason', 'too_far', 'B-17: 500 m away -> too_far');
select is(event_checkin(tests.txt('code'), null, null, null) ->> 'reason', 'location_required', 'B-17: no position -> location_required');
select is(event_checkin(tests.txt('later_code'), 51.4988, -0.1749, 10) ->> 'reason', 'outside_window',
  'B-17: event starting in 3 h -> outside_window');
reset role;
select tests.login('u2');
select is(event_checkin(tests.txt('code'), 51.4988, -0.1749, 10) ->> 'reason', 'not_registered', 'B-17: no RSVP -> not_registered');
reset role;
select is((select count(*)::int from participation_evidence where subject_user_id::text in (select v from tests.ids)), 0,
  'B-17: failed check-ins write no evidence');

select tests.login('host');
select lives_ok($$ select tests.put('new_code', rotate_checkin_code(tests.id('ev'))) $$, 'B-17: host rotates the code');
reset role;
select isnt(tests.txt('new_code'), tests.txt('code'), 'B-17: rotated code differs');
select tests.login('u1');
select is(event_checkin(tests.txt('code'), 51.4988, -0.1749, 10) ->> 'reason', 'invalid_code', 'B-17: old code is invalid after rotation');

-- ===========================================================================
-- B-09 / B-10: repeated check-in, self check-in is geo_verified only
-- ===========================================================================
select tests.put('res1', event_checkin(tests.txt('new_code'), 51.4988 + 0.0003, -0.1749, 20)::text);
select tests.put('res2', event_checkin(tests.txt('new_code'), 51.4988, -0.1749, 5)::text);
reset role;
select is(tests.txt('res1')::jsonb ->> 'ok', 'true', 'B-09: first check-in succeeds');
select is(tests.txt('res1')::jsonb ->> 'already', 'false', 'B-09: first check-in already=false');
select is(tests.txt('res1')::jsonb ->> 'status', 'geo_verified', 'B-10: self check-in status is geo_verified');
select is(tests.txt('res2')::jsonb ->> 'already', 'true', 'B-09: repeat check-in returns already=true');
select is((select count(*)::int from participation_evidence
           where event_id = tests.id('ev') and subject_user_id = tests.id('u1') and verification_status <> 'revoked'), 1,
  'B-09: only one live evidence row after repeat check-in');
select is((select verification_status::text from participation_evidence
           where event_id = tests.id('ev') and subject_user_id = tests.id('u1')), 'geo_verified',
  'B-10: self check-in is never verified');
select is((select source::text from participation_evidence where event_id = tests.id('ev') and subject_user_id = tests.id('u1')), 'qr_geo',
  'B-10: self check-in source is qr_geo');

select tests.login('u1');
select is((select count(*)::int from participation_evidence where subject_user_id = tests.id('u1')), 1, 'B-07: user can read own evidence');
reset role;
select is((select verification_status::text from participation_evidence where subject_user_id = tests.id('u1')), 'geo_verified',
  'B-07: evidence still geo_verified');
select tests.login('u1');
select throws_ok($$ update participation_evidence set verification_status = 'verified' where subject_user_id = tests.id('u1') $$,
  '42501', null, 'B-07: user cannot update evidence');
select throws_ok($$ delete from participation_evidence where subject_user_id = tests.id('u1') $$,
  '42501', null, 'B-07: user cannot delete evidence');
reset role;

-- Organiser confirmation is the only path to verified.
select tests.login('staff');
select lives_ok($$ select organiser_confirm_attendance(tests.id('ev'), tests.id('u1'), true) $$, 'B-10: org staff confirms attendance');
select lives_ok($$ select organiser_confirm_attendance(tests.id('ev'), tests.id('u1'), true) $$, 'B-10: repeat confirmation is harmless');
select throws_ok($$ select organiser_confirm_attendance(tests.id('ev'), tests.id('u2'), true) $$, 'P0001', 'not_registered',
  'B-10: cannot confirm someone who is not registered');
select is((select self_checkin from list_event_attendees(tests.id('ev')) where user_id = tests.id('u1')), 'geo_verified',
  'B-10: attendee list shows geo_verified self check-in');
select ok((select organiser_confirmed from list_event_attendees(tests.id('ev')) where user_id = tests.id('u1')),
  'B-10: attendee list shows organiser confirmation');
reset role;
select is((select array_agg(verification_status::text) from participation_evidence
           where event_id = tests.id('ev') and subject_user_id = tests.id('u1') and type = 'organiser_confirmed_attendance'),
  '{verified}'::text[], 'B-10: organiser confirmation produces exactly one verified record');
select is((select operator_id from participation_evidence
           where event_id = tests.id('ev') and subject_user_id = tests.id('u1') and type = 'organiser_confirmed_attendance'),
  tests.id('staff'), 'B-10: confirmation records the operator');
select tests.login('u1');
select is(trust_summary() - 'intended_participation' - 'confirmed_rsvp' - 'disputed' - 'mutually_reported_interaction',
  '{"self_reported_presence": 1, "organiser_confirmed_attendance": 1}'::jsonb, 'B-10: trust summary counts both facts');
reset role;
select tests.login('host');
select lives_ok($$ select organiser_confirm_attendance(tests.id('ev'), tests.id('u1'), false) $$, 'B-10: organiser revokes confirmation');
select ok(not (select organiser_confirmed from list_event_attendees(tests.id('ev')) where user_id = tests.id('u1')),
  'B-10: revoked confirmation no longer shows');
reset role;

-- Hardening (20261020000102)
select tests.login('host');
select throws_ok($$ select organiser_confirm_attendance(tests.id('ev'), tests.id('host'), true) $$, 'P0001', 'cannot_confirm_self',
  'organiser cannot confirm their own attendance');
select is(event_checkin(tests.txt('new_code'), 51.4988, -0.1749, -5) ->> 'reason', 'location_required',
  'non-positive accuracy is rejected');
reset role;
select tests.login('u2');
select ok(not is_checked_in(tests.id('ev'), tests.id('u1')), 'is_checked_in does not reveal other users to non-staff');
reset role;

select * from finish();
rollback;
