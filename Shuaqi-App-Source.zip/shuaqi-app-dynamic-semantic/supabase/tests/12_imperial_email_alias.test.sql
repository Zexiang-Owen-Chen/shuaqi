begin;
create extension if not exists pgtap with schema extensions;
set local search_path = public, extensions;

select plan(12);

select is(school_domain_for_email('student@imperial.ac.uk'), 'imperial.ac.uk', 'full Imperial domain remains accepted');
select is(school_domain_for_email('student@ic.ac.uk'), 'imperial.ac.uk', 'short Imperial domain has the same canonical school');
select is(school_domain_for_email('Student@IC.AC.UK'), 'imperial.ac.uk', 'short domain is case insensitive');
select is(school_domain_for_email('student@fakeic.ac.uk'), null, 'look-alike domain remains rejected');
select is(school_domain_for_email('student@ic.ac.uk.evil.com'), null, 'domain suffix spoof remains rejected');
select is(school_domain_for_email('student@ic.com'), null, 'unrelated ic domain remains rejected');

select lives_ok($$
  insert into auth.users (id, instance_id, aud, role, email, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
  values ('b54b70ad-1e12-45c0-8b94-8c69e891596a', '00000000-0000-0000-0000-000000000000',
    'authenticated', 'authenticated', 'imperial-alias-regression@ic.ac.uk', '{}', '{}', now(), now())
$$, 'Auth sign-up gate accepts the short Imperial domain');
select is((select school_domain from profiles where id = 'b54b70ad-1e12-45c0-8b94-8c69e891596a'),
  'imperial.ac.uk', 'short-domain profile uses the canonical school for badges and school-only permissions');
select is((select school_verified_at from profiles where id = 'b54b70ad-1e12-45c0-8b94-8c69e891596a'),
  null, 'short-domain user still needs email verification');
update auth.users set email_confirmed_at = now() where id = 'b54b70ad-1e12-45c0-8b94-8c69e891596a';
select ok((select school_verified_at is not null and school_domain = 'imperial.ac.uk'
  from profiles where id = 'b54b70ad-1e12-45c0-8b94-8c69e891596a'), 'verified short-domain user stays in the same school');

update allowed_school_domains set active = false where domain = 'imperial.ac.uk';
select is(school_domain_for_email('student@ic.ac.uk'), null, 'short alias cannot bypass an inactive school');
select is(school_domain_for_email('student@imperial.ac.uk'), null, 'full domain is also denied for an inactive school');

select * from finish();
rollback;
