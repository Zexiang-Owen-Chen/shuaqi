begin;
create extension if not exists pgtap with schema extensions;
set local search_path = public, extensions;

-- ---- test helpers (rolled back with the transaction) ----
create schema tests;
grant usage on schema tests to anon, authenticated;
create table tests.ids (k text primary key, v text not null);
grant all on tests.ids to anon, authenticated;

create function tests.put(p_k text, p_v text) returns text language sql as $$
  insert into tests.ids (k, v) values (p_k, p_v) on conflict (k) do update set v = excluded.v returning v
$$;
create function tests.id(p_k text) returns uuid language sql stable as $$ select v::uuid from tests.ids where k = p_k $$;
create function tests.txt(p_k text) returns text language sql stable as $$ select v from tests.ids where k = p_k $$;

-- Creates an auth user (the sign-up trigger creates the profile) and stores its id under p_k.
create function tests.new_user(p_k text, p_email text, p_confirmed boolean default true) returns uuid
language plpgsql as $$
declare v uuid := gen_random_uuid();
begin
  insert into auth.users (id, instance_id, aud, role, email, email_confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
  values (v, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', p_email,
          case when p_confirmed then now() end, '{}', '{}', now(), now());
  perform tests.put(p_k, v::text);
  return v;
end $$;

-- Impersonate a user for the rest of the transaction (call while running as postgres).
create function tests.login(p_k text) returns void language plpgsql as $$
begin
  perform set_config('request.jwt.claims', json_build_object('sub', tests.id(p_k), 'role', 'authenticated')::text, true);
  perform set_config('role', 'authenticated', true);
end $$;

-- Forget the impersonated user's claims (run `reset role;` first).
create function tests.clear_claims() returns void language sql as $$
  select set_config('request.jwt.claims', '', true); select null::void
$$;

-- Pending notifications for a user, newest first.
create function tests.outbox(p_k text) returns setof public.push_outbox language sql stable as $$
  select * from public.push_outbox where user_id = tests.id(p_k) order by id desc
$$;

select plan(46);

select tests.new_user('a', 'a@imperial.ac.uk');
select tests.new_user('b', 'b@ucl.ac.uk');
select tests.new_user('c', 'c@lse.ac.uk');
update profiles set display_name = 'Alice' where id = tests.id('a');
update profiles set display_name = 'Bob' where id = tests.id('b');
insert into connections (user_a, user_b) values
  (least(tests.id('a'), tests.id('b')), greatest(tests.id('a'), tests.id('b')));

-- ===========================================================================
-- Subscriptions
-- ===========================================================================
select tests.login('b');
select throws_ok($$ select save_push_subscription('http://push.example/x', 'k', 'a') $$, 'P0001', 'invalid_subscription',
  'subscribe: endpoint must be https');
select throws_ok($$ select save_push_subscription('https://push.example/b', '', 'a') $$, 'P0001', 'invalid_subscription',
  'subscribe: keys are required');
select throws_ok($$ select send_test_push() $$, 'P0001', 'push_not_subscribed', 'test push: needs a subscribed device');
reset role;

-- Nothing is queued for someone with no device.
select tests.login('a');
select send_message(tests.id('b'), 'before subscribing');
reset role;
select is((select count(*)::int from push_outbox), 0, 'enqueue: nothing for a user with no subscribed device');

select tests.login('b');
select lives_ok($$ select save_push_subscription('https://push.example/b', 'p256-b', 'auth-b', 'test-agent') $$,
  'subscribe: B registers a device');
select lives_ok($$ select save_push_subscription('https://push.example/b', 'p256-b2', 'auth-b2') $$,
  'subscribe: repeat registration updates the keys');
select is(has_push_subscription('https://push.example/b'), true, 'subscribe: B sees the device is registered');
select throws_ok($$ select * from push_subscriptions $$, '42501', null, 'RLS: users cannot read subscriptions directly');
select throws_ok($$ select * from push_outbox $$, '42501', null, 'RLS: users cannot read the outbox');
select throws_ok($$ select claim_push_batch(10) $$, '42501', null, 'grants: users cannot claim the outbox');
select throws_ok($$ select complete_push_batch('{}', '{}', '{https://push.example/b}', '{}') $$, '42501', null,
  'grants: users cannot report deliveries');
reset role;
select is((select p256dh from push_subscriptions where endpoint = 'https://push.example/b'), 'p256-b2',
  'subscribe: keys were updated');

select tests.login('c');
select is(has_push_subscription('https://push.example/b'), false, 'subscribe: C does not see B''s device');
select lives_ok($$ select delete_push_subscription('https://push.example/b') $$, 'unsubscribe: C''s call runs');
reset role;
select is((select count(*)::int from push_subscriptions where user_id = tests.id('b')), 1,
  'unsubscribe: C cannot remove B''s device');

-- ===========================================================================
-- Chat messages
-- ===========================================================================
select tests.login('a');
select send_message(tests.id('b'), 'Hello Bob');
reset role;
select is((select count(*)::int from tests.outbox('b')), 1, 'message: B gets a notification');
select is((select payload->>'title' from tests.outbox('b') limit 1), 'Alice', 'message: titled with the sender''s name');
select is((select payload->>'body' from tests.outbox('b') limit 1), 'Hello Bob', 'message: body is the message');
select is((select payload->>'url' from tests.outbox('b') limit 1), '/messages/' || tests.id('a'), 'message: opens the chat');
select is((select count(*)::int from tests.outbox('a')), 0, 'message: the sender gets nothing');

select tests.login('a');
select send_message(tests.id('b'), 'Are you there?');
reset role;
select is((select count(*)::int from tests.outbox('b')), 1, 'message: a second message merges into the pending one');
select is((select (payload->>'count')::int || ' ' || (payload->>'body') from tests.outbox('b') limit 1), '2 Are you there?',
  'message: merged notification counts messages and shows the latest');

-- Preferences
select tests.login('b');
select is(my_notification_preferences()->>'message', 'true', 'preferences: everything is on by default');
select throws_ok($$ select set_notification_preference('spam', false) $$, 'P0001', 'invalid_category',
  'preferences: unknown category is rejected');
select is(set_notification_preference('message', false)->>'message', 'false', 'preferences: B turns message notifications off');
reset role;
update push_outbox set status = 'sent';
select tests.login('a');
select send_message(tests.id('b'), 'muted');
reset role;
select is((select count(*)::int from tests.outbox('b') where status = 'pending'), 0, 'preferences: muted category is not queued');

-- ===========================================================================
-- Friend requests
-- ===========================================================================
select tests.login('a');
select save_push_subscription('https://push.example/a', 'p256-a', 'auth-a');
reset role;
-- Inserted directly: the request rules themselves are covered in 03/09.
insert into connection_requests (from_user, to_user, context) values (tests.id('c'), tests.id('b'), 'nearby')
returning tests.put('req', id::text);
select is((select payload->>'title' from tests.outbox('b') where category = 'friend_request'), '新的好友请求',
  'friend request: recipient is notified');
select is((select payload->>'url' from tests.outbox('b') where category = 'friend_request'), '/me/requests',
  'friend request: opens the requests page');
select tests.login('c');
select save_push_subscription('https://push.example/c', 'p256-c', 'auth-c');
reset role;
select tests.login('b');
select respond_connection_request(tests.id('req'), true);
reset role;
select is((select payload->>'title' from tests.outbox('c') where category = 'friend_request'), '好友请求已通过',
  'friend request: the sender hears it was accepted');

-- ===========================================================================
-- Buddy matching
-- ===========================================================================
insert into intents (user_id, activity_type, window_start, window_end, region, expires_at) values
  (tests.id('a'), 'badminton', now() + interval '1 day', now() + interval '2 days', 'Camden', now() + interval '1 day')
returning tests.put('ia', id::text);
insert into intents (user_id, activity_type, window_start, window_end, region, expires_at) values
  (tests.id('b'), 'badminton', now() + interval '1 day', now() + interval '2 days', 'Camden', now() + interval '1 day')
returning tests.put('ib', id::text);
select tests.login('a');
select tests.put('inv', (send_match_invitation(tests.id('ia'), tests.id('ib'), 'play?')).id::text);
reset role;
select is((select payload->>'body' from tests.outbox('b') where category = 'buddy'), 'Alice 邀请你一起「badminton」：play?',
  'buddy: invitation is notified');
select tests.login('b');
select tests.put('plan', respond_match_invitation(tests.id('inv'), true)::text);
reset role;
select is((select payload->>'title' from tests.outbox('a') where category = 'buddy'), '搭子匹配成功',
  'buddy: the inviter hears the match');
select is((select payload->>'url' from tests.outbox('a') where category = 'buddy'), '/buddy/plans/' || tests.id('plan'),
  'buddy: opens the plan');
update push_outbox set status = 'sent';
update shared_plans set planned_at = now() + interval '1 day 2 hours' where id = tests.id('plan');
select tests.login('a');
select confirm_shared_plan(tests.id('plan'));
reset role;
select tests.login('b');
select confirm_shared_plan(tests.id('plan'));
reset role;
select is((select count(*)::int from tests.outbox('a') where status = 'pending' and payload->>'title' = '搭子计划已确定'), 1,
  'buddy: the other person hears the plan is confirmed');
select is((select count(*)::int from tests.outbox('b') where status = 'pending' and payload->>'title' = '搭子计划已确定'), 0,
  'buddy: the person who confirmed last is not notified');

-- ===========================================================================
-- Event reminders
-- ===========================================================================
select tests.clear_claims();
insert into events (host_user_id, category, title, starts_at, checkin_mode, location_text)
values (tests.id('c'), 'sport', 'Morning run', now() + interval '40 minutes', 'none', 'Hyde Park')
returning tests.put('soon', id::text);
insert into events (host_user_id, category, title, starts_at, checkin_mode)
values (tests.id('c'), 'sport', 'Next week', now() + interval '7 days', 'none')
returning tests.put('later', id::text);
insert into event_rsvps (event_id, user_id) values (tests.id('soon'), tests.id('a')), (tests.id('later'), tests.id('a')),
  (tests.id('soon'), tests.id('b'));
update event_rsvps set status = 'cancelled' where event_id = tests.id('soon') and user_id = tests.id('b');
select enqueue_event_reminders();
select enqueue_event_reminders();
select is((select count(*)::int from tests.outbox('a') where category = 'event_reminder'), 1,
  'reminder: one reminder for the event starting soon, even when run twice');
select is((select payload->>'url' from tests.outbox('a') where category = 'event_reminder'), '/events/' || tests.id('soon'),
  'reminder: opens the event');
select ok((select payload->>'body' from tests.outbox('a') where category = 'event_reminder') like '「Morning run」%开始 · Hyde Park',
  'reminder: names the event, time and place');
select is((select count(*)::int from tests.outbox('b') where category = 'event_reminder'), 0,
  'reminder: not for someone who cancelled');

-- ===========================================================================
-- Dispatcher (service role)
-- ===========================================================================
update push_outbox set status = 'sent';
select tests.login('a');
select send_message(tests.id('b'), 'unmuted?');  -- B muted messages: nothing
reset role;
select tests.login('b');
select send_message(tests.id('a'), 'For Alice');
reset role;
set local role service_role;
select is((select count(*)::int from claim_push_batch(10)), 1, 'dispatch: claims the pending row');
select is((select count(*)::int from claim_push_batch(10)), 0, 'dispatch: a claimed row is not claimed twice');
reset role;
select is((select status from tests.outbox('a') limit 1), 'sending', 'dispatch: claimed row is marked sending');
select set_config('tests.row', (select id::text from tests.outbox('a') limit 1), true);
set local role service_role;
select complete_push_batch(array[current_setting('tests.row')::bigint], '{}', '{https://push.example/a}', '{}');
reset role;
select is((select status from tests.outbox('a') limit 1), 'sent', 'dispatch: delivered row is marked sent');
select is((select count(*)::int from push_subscriptions where user_id = tests.id('a')), 0,
  'dispatch: a device the push service rejected is removed');

-- Feature flag off: nothing is queued and nobody can subscribe.
update feature_flags set enabled = false where key = 'push';
select tests.login('c');
select throws_ok($$ select save_push_subscription('https://push.example/c2', 'k', 'a') $$, 'P0001', 'feature_disabled',
  'flag: subscribing is refused while push is off');
reset role;
select is(push_wanted(tests.id('c'), 'friend_request'), false, 'flag: nothing is queued while push is off');
update feature_flags set enabled = true where key = 'push';

-- Account deletion removes devices and queued notifications.
select tests.new_user('d', 'd@cam.ac.uk');
select tests.login('d');
select save_push_subscription('https://push.example/d', 'p256-d', 'auth-d');
reset role;
delete from auth.users where id = tests.id('d');
select is((select count(*)::int from push_subscriptions where user_id = tests.id('d')), 0,
  'deletion: devices are deleted with the account');

select * from finish();
rollback;
