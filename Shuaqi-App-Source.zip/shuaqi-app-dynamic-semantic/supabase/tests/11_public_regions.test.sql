begin;
create extension if not exists pgtap with schema extensions;
set local search_path = public, extensions;

-- ---- test helpers (rolled back with the transaction) ----
create schema tests;
grant usage on schema tests to anon, authenticated;
create table tests.ids (k text primary key, v text not null);
grant all on tests.ids to anon, authenticated;

create function tests.put(p_k text, p_v text) returns text language sql as $$
  insert into tests.ids (k, v) values (p_k, p_v) on conflict (k) do update set v = excluded.v returning v
$$;
create function tests.id(p_k text) returns uuid language sql stable as $$ select v::uuid from tests.ids where k = p_k $$;
create function tests.txt(p_k text) returns text language sql stable as $$ select v from tests.ids where k = p_k $$;

-- Creates an auth user (the sign-up trigger creates the profile) and stores its id under p_k.
create function tests.new_user(p_k text, p_email text, p_confirmed boolean default true) returns uuid
language plpgsql as $$
declare v uuid := gen_random_uuid();
begin
  insert into auth.users (id, instance_id, aud, role, email, email_confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
  values (v, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', p_email,
          case when p_confirmed then now() end, '{}', '{}', now(), now());
  perform tests.put(p_k, v::text);
  return v;
end $$;

-- Impersonate a user for the rest of the transaction (call while running as postgres).
create function tests.login(p_k text) returns void language plpgsql as $$
begin
  perform set_config('request.jwt.claims', json_build_object('sub', tests.id(p_k), 'role', 'authenticated')::text, true);
  perform set_config('role', 'authenticated', true);
end $$;

-- Forget the impersonated user's claims (run `reset role;` first).
create function tests.clear_claims() returns void language sql as $$
  select set_config('request.jwt.claims', '', true); select null::void
$$;


select no_plan();
select tests.new_user('a', 'region-a@ucl.ac.uk');
select tests.new_user('b', 'region-b@ucl.ac.uk');

select is(normalize_region(' South Ken '), 'London / South Kensington / Chelsea', 'short alias maps to coarse region');
select is(normalize_region('SOUTH KENSINGTON'), normalize_region('South Ken'), 'case and aliases share one option');
select is(normalize_region('SW7 2AZ'), null, 'postal code is never exposed as a region');
select is(normalize_region('unknown'), null, 'unknown region does not become unrestricted');

select tests.login('a');
select throws_ok($$ update profiles set region = '123 Example Street' where id = tests.id('a') $$,
  'P0001', 'region_invalid', 'direct API writes cannot store free text');
select throws_ok($$ update profiles set onboarded = true where id = tests.id('a') $$,
  'P0001', 'region_required', 'completed profiles must have a region');
select lives_ok($$ update profiles set region = 'South Ken', onboarded = true where id = tests.id('a') $$,
  'known alias can complete onboarding');
select is((select region from profiles where id = tests.id('a')), 'London / South Kensington / Chelsea', 'stored profile uses canonical option');
select throws_ok($$ update profiles set region = null where id = tests.id('a') $$,
  'P0001', 'region_required', 'completed profile cannot clear region');

-- Storage insertion is the permission needed by the non-upsert upload path.
select lives_ok($$ insert into storage.objects (bucket_id, name) values ('avatars', tests.id('a') || '/region-test-1.png') $$,
  'avatar insert in own folder succeeds without SELECT policy');
select lives_ok($$ insert into storage.objects (bucket_id, name) values ('avatars', tests.id('a') || '/region-test-2.png') $$,
  'a replacement avatar uses another object and also succeeds');
select throws_ok($$ insert into storage.objects (bucket_id, name) values ('avatars', tests.id('b') || '/forbidden.png') $$,
  '42501', null, 'avatar upload to someone else''s folder is still denied');
reset role;

update profiles set region = 'South Kensington', visibility = '{"region":"hidden","bio":"hidden"}' where id = tests.id('b');
insert into intents (user_id, activity_type, window_start, window_end, region, expires_at) values
(tests.id('a'), 'region-test', now(), now() + interval '2 hours', 'South Ken', now() + interval '1 hour'),
(tests.id('b'), 'region-test', now(), now() + interval '2 hours', 'South Kensington', now() + interval '1 hour');
select tests.put('ia', (select id::text from intents where user_id = tests.id('a')));
select tests.put('ib', (select id::text from intents where user_id = tests.id('b')));
select tests.login('a');
select is(get_profile_card(tests.id('b'))->>'region', 'London / South Kensington / Chelsea', 'general card ignores legacy hidden region');
select is((select card->>'region' from match_candidates(tests.id('ia'))), 'London / South Kensington / Chelsea', 'aliases match and intent card shows region');
select throws_ok($$ update intents set region = 'unknown' where id = tests.id('ia') $$,
  'P0001', 'region_invalid', 'intent API cannot bypass fixed options');
reset role;
update intents set region = 'Oxford' where id = tests.id('ib');
select ok(not intents_compatible(tests.id('ia'), tests.id('ib')), 'different options do not match');
update intents set region = '' where id = tests.id('ib');
select ok(intents_compatible(tests.id('ia'), tests.id('ib')), 'explicit unrestricted intent still matches');

-- Event opt-in grants discovery, but cannot remove the mandatory coarse region.
insert into events (host_user_id, title, category, starts_at, status, checkin_mode)
values (tests.id('a'), 'Region regression', '运动', now() + interval '1 hour', 'published', 'none');
select tests.put('event', (select id::text from events where title = 'Region regression'));
select tests.login('a');
select join_event(tests.id('event'));
reset role;
select tests.login('b');
select join_event(tests.id('event'));
select set_event_optin(tests.id('event'), true, array['interests']);
reset role;
select tests.login('a');
select is(get_profile_card(tests.id('b'), 'event', tests.id('event'))->>'region', 'London / South Kensington / Chelsea', 'event opt-in cannot hide region');
reset role;
-- nearby_card is internal, so exercise it as database owner with the viewer claims retained.
select is(nearby_card(tests.id('b'))->>'region', 'London / South Kensington / Chelsea', 'nearby card includes coarse region');
insert into blocks (blocker_id, blocked_id) values (tests.id('a'), tests.id('b'));
select is(nearby_card(tests.id('b')), null, 'nearby card respects blocking');
select tests.login('a');
select is(get_profile_card(tests.id('b')), null, 'mandatory region does not bypass blocking');
reset role;

select * from finish();
rollback;
