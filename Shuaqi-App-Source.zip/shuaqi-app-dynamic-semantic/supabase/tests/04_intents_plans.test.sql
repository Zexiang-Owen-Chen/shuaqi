begin;
create extension if not exists pgtap with schema extensions;
set local search_path = public, extensions;

-- ---- test helpers (rolled back with the transaction) ----
create schema tests;
grant usage on schema tests to anon, authenticated;
create table tests.ids (k text primary key, v text not null);
grant all on tests.ids to anon, authenticated;

create function tests.put(p_k text, p_v text) returns text language sql as $$
  insert into tests.ids (k, v) values (p_k, p_v) on conflict (k) do update set v = excluded.v returning v
$$;
create function tests.id(p_k text) returns uuid language sql stable as $$ select v::uuid from tests.ids where k = p_k $$;
create function tests.txt(p_k text) returns text language sql stable as $$ select v from tests.ids where k = p_k $$;

-- Creates an auth user (the sign-up trigger creates the profile) and stores its id under p_k.
create function tests.new_user(p_k text, p_email text, p_confirmed boolean default true) returns uuid
language plpgsql as $$
declare v uuid := gen_random_uuid();
begin
  insert into auth.users (id, instance_id, aud, role, email, email_confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
  values (v, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', p_email,
          case when p_confirmed then now() end, '{}', '{}', now(), now());
  perform tests.put(p_k, v::text);
  return v;
end $$;

-- Impersonate a user for the rest of the transaction (call while running as postgres).
create function tests.login(p_k text) returns void language plpgsql as $$
begin
  perform set_config('request.jwt.claims', json_build_object('sub', tests.id(p_k), 'role', 'authenticated')::text, true);
  perform set_config('role', 'authenticated', true);
end $$;

-- Forget the impersonated user's claims (run `reset role;` first).
create function tests.clear_claims() returns void language sql as $$
  select set_config('request.jwt.claims', '', true); select null::void
$$;

select plan(34);

select tests.new_user('a', 'a@imperial.ac.uk');
select tests.new_user('b', 'b@ucl.ac.uk');
select tests.new_user('c', 'c@lse.ac.uk');   -- different activity
select tests.new_user('d', 'd@cam.ac.uk');   -- expired intent
select tests.new_user('e', 'e@ox.ac.uk');    -- blocked by A
select tests.new_user('f', 'f@ox.ac.uk');    -- different region
select tests.new_user('g', 'g@ox.ac.uk');    -- withdrawn intent
select tests.new_user('unverified', 'nov@ucl.ac.uk', false);
update profiles set interests = '{badminton,coffee}', gender = 'male', region = 'Camden', birth_year = 2003 where id = tests.id('a');
update profiles set interests = '{coffee}', gender = 'female', region = 'Camden', birth_year = 2004,
       visibility = '{"bio":"hidden","interests":"public","photos":"public","gender":"hidden","age":"hidden","region":"hidden"}'
 where id = tests.id('b');

-- ===========================================================================
-- B-04: create / withdraw intents
-- ===========================================================================
select tests.login('a');
select lives_ok($$
  with i as (insert into intents (user_id, activity_type, window_start, window_end, region, expires_at)
             values (tests.id('a'), 'Badminton', now() + interval '30 minutes', now() + interval '3 hours', 'London', now() + interval '2 hours')
             returning id)
  select tests.put('ia', id::text) from i $$, 'B-04: A creates an intent');
select lives_ok($$
  with i as (insert into intents (user_id, activity_type, window_start, window_end, region, expires_at)
             values (tests.id('a'), 'cinema', now() + interval '1 hour', now() + interval '3 hours', '', now() + interval '2 hours')
             returning id)
  select tests.put('ia_wd', id::text) from i $$, 'B-04: A creates a second intent');
select lives_ok($$ update intents set status = 'withdrawn' where id = tests.id('ia_wd') $$, 'B-04: A withdraws an intent');
select is((select status::text from intents where id = tests.id('ia_wd')), 'withdrawn', 'B-04: intent is withdrawn');
select throws_ok($$ insert into intents (user_id, activity_type, window_start, window_end, expires_at)
                    values (tests.id('b'), 'x', now(), now() + interval '1 hour', now() + interval '1 hour') $$,
  '42501', null, 'B-04: cannot create an intent for someone else');
reset role;
select tests.login('unverified');
select throws_ok($$ insert into intents (user_id, activity_type, window_start, window_end, expires_at)
                    values (tests.id('unverified'), 'x', now(), now() + interval '1 hour', now() + interval '1 hour') $$,
  '42501', null, 'B-04: unverified user cannot create an intent');
reset role;

-- Other people's intents (written as postgres for brevity).
insert into intents (user_id, activity_type, window_start, window_end, region, expires_at) values
  (tests.id('b'), 'badminton', now() + interval '20 minutes', now() + interval '2 hours', 'london', now() + interval '90 minutes'),
  (tests.id('c'), 'tennis',    now() + interval '30 minutes', now() + interval '3 hours', 'London', now() + interval '2 hours'),
  (tests.id('d'), 'badminton', now() - interval '2 hours',    now() + interval '3 hours', 'London', now() - interval '1 minute'),
  (tests.id('e'), 'badminton', now() + interval '30 minutes', now() + interval '3 hours', 'London', now() + interval '2 hours'),
  (tests.id('f'), 'badminton', now() + interval '30 minutes', now() + interval '3 hours', 'Oxford', now() + interval '2 hours'),
  (tests.id('g'), 'badminton', now() + interval '30 minutes', now() + interval '3 hours', 'London', now() + interval '2 hours');
select tests.put('i' || k, (select id::text from intents where user_id = tests.id(k))) from unnest(array['b','c','d','e','f','g']) k;
update intents set status = 'withdrawn' where id = tests.id('ig');
insert into blocks (blocker_id, blocked_id) values (tests.id('a'), tests.id('e'));

-- ===========================================================================
-- B-04: matching
-- ===========================================================================
select tests.login('a');
select set_eq($$ select intent_id from match_candidates(tests.id('ia')) $$, array[tests.id('ib')],
  'B-04: only the compatible intent is a candidate (not other activity/expired/blocked/other region/withdrawn)');
select is((select shared_interests from match_candidates(tests.id('ia'))), '{coffee}'::text[], 'B-04: shared interests computed');
select is((select card ->> 'gender' from match_candidates(tests.id('ia'))), 'female',
  'B-04: intent card always shows gender to a compatible match');
select ok(not (select card ? 'bio' from match_candidates(tests.id('ia'))), 'B-04: intent card still hides hidden bio');
select is((select count(*)::int from intents), 2, 'B-04: A cannot read other people''s intents');
select throws_ok($$ select * from match_candidates(tests.id('ib')) $$, 'P0001', 'intent_not_found',
  'B-04: cannot run matching on someone else''s intent');
select throws_ok($$ select send_match_invitation(tests.id('ia'), tests.id('ic')) $$, 'P0001', 'not_compatible',
  'B-04: cannot invite an incompatible intent');
select throws_ok($$ select send_match_invitation(tests.id('ia'), tests.id('ie')) $$, 'P0001', 'not_compatible',
  'B-04: cannot invite a blocked user''s intent');
select lives_ok($$ select tests.put('inv', (select id::text from send_match_invitation(tests.id('ia'), tests.id('ib'), 'play?'))) $$,
  'B-04: A invites B');
select is((select id from send_match_invitation(tests.id('ia'), tests.id('ib'))), tests.id('inv'), 'B-04: repeat invitation is idempotent');
reset role;

-- ===========================================================================
-- B-04: accept -> shared plan -> confirm -> report met
-- ===========================================================================
select tests.login('a');
select throws_ok($$ select respond_match_invitation(tests.id('inv'), true) $$, 'P0001', 'invitation_not_found',
  'B-04: sender cannot accept own invitation');
reset role;
select tests.login('b');
select lives_ok($$ select tests.put('plan', respond_match_invitation(tests.id('inv'), true)::text) $$, 'B-04: B accepts');
select is(respond_match_invitation(tests.id('inv'), true), tests.id('plan'), 'B-04: repeat accept returns the same plan');
select is((select status::text from shared_plans where id = tests.id('plan')), 'proposed', 'B-04: accept creates a proposed shared_plan');
reset role;
select is((select count(*)::int from shared_plans where invitation_id = tests.id('inv')), 1, 'B-04: exactly one plan per invitation');
select is((select array_agg(status::text order by status::text) from intents where id in (tests.id('ia'), tests.id('ib'))),
  '{matched,matched}'::text[], 'B-04: both two-person intents become matched');

select tests.login('c');
select throws_ok($$ select confirm_shared_plan(tests.id('plan')) $$, 'P0001', 'plan_not_found', 'B-04: outsider cannot confirm the plan');
select is((select count(*)::int from shared_plans), 0, 'B-04: outsider cannot read the plan');
reset role;

select tests.login('a');
select is((select status::text from confirm_shared_plan(tests.id('plan'))), 'proposed', 'B-04: one confirmation keeps it proposed');
select throws_ok($$ select report_met(tests.id('plan')) $$, 'P0001', 'plan_not_confirmed', 'B-04: cannot report met before both confirm');
reset role;
select tests.login('b');
select is((select status::text from confirm_shared_plan(tests.id('plan'))), 'confirmed', 'B-04: both confirmations -> confirmed');
select lives_ok($$ select report_met(tests.id('plan')) $$, 'B-04: B reports met');
reset role;
select is((select count(*)::int from participation_evidence where shared_plan_id = tests.id('plan')), 0,
  'B-04: one-sided report creates no evidence');
select tests.login('a');
select lives_ok($$ select report_met(tests.id('plan')) $$, 'B-04: A reports met');
select lives_ok($$ select report_met(tests.id('plan')) $$, 'B-04: repeat report is harmless');
reset role;
select is((select count(*)::int from participation_evidence
           where shared_plan_id = tests.id('plan') and type = 'mutually_reported_interaction'
             and source = 'mutual_report' and verification_status = 'verified'), 2,
  'B-04: both reports -> one mutually_reported_interaction record per person');
select tests.login('a');
select is((trust_summary() ->> 'mutually_reported_interaction')::int, 1, 'B-04: trust summary counts the interaction');
select is((select context::text from send_connection_request(tests.id('b'), 'intent')), 'intent',
  'B-04: plan partners may send an intent-context connection request');
reset role;

select * from finish();
rollback;
