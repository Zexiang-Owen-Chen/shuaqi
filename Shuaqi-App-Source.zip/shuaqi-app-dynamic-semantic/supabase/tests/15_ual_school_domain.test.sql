begin;
create extension if not exists pgtap with schema extensions;
set local search_path = public, extensions;

select plan(15);
select ok((select active and allow_subdomains and school_name = 'University of the Arts London'
  from allowed_school_domains where domain = 'ual.ac.uk'), 'UAL is an active supported school');
select is(school_domain_for_email('student@ual.ac.uk'), 'ual.ac.uk', 'UAL domain is accepted');
select is(school_domain_for_email('Student@UAL.AC.UK'), 'ual.ac.uk', 'UAL domain is case insensitive');
select is(school_domain_for_email('student@students.ual.ac.uk'), 'ual.ac.uk', 'UAL subdomains share the same school');
select is(school_domain_for_email('student@fakeual.ac.uk'), null, 'look-alike UAL domain is rejected');
select is(school_domain_for_email('student@ual.ac.uk.evil.com'), null, 'UAL suffix spoof is rejected');
select is(school_domain_for_email('student@gmail.com'), null, 'unrelated domains remain rejected');

select lives_ok($$
  insert into auth.users (id, instance_id, aud, role, email, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
  values ('d7f4b4df-f1ca-4676-9563-81c27b622dce', '00000000-0000-0000-0000-000000000000',
    'authenticated', 'authenticated', 'ual-registration-regression@ual.ac.uk', '{}', '{}', now(), now())
$$, 'Auth sign-up gate accepts UAL');
select is((select school_domain from profiles where id = 'd7f4b4df-f1ca-4676-9563-81c27b622dce'),
  'ual.ac.uk', 'UAL profile has the correct school identity');
select is((select school_verified_at from profiles where id = 'd7f4b4df-f1ca-4676-9563-81c27b622dce'),
  null, 'UAL registration still needs email verification');
update auth.users set email_confirmed_at = now() where id = 'd7f4b4df-f1ca-4676-9563-81c27b622dce';
select ok((select school_verified_at is not null and school_domain = 'ual.ac.uk'
  from profiles where id = 'd7f4b4df-f1ca-4676-9563-81c27b622dce'), 'UAL email confirmation verifies the school');

select throws_ok($$
  insert into auth.users (id, instance_id, aud, role, email, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
  values ('ae9d1b38-4e79-4db4-8ad3-79bbf986fcab', '00000000-0000-0000-0000-000000000000',
    'authenticated', 'authenticated', 'spoof@fakeual.ac.uk', '{}', '{}', now(), now())
$$, 'P0001', 'school_email_required', 'Auth itself rejects a look-alike UAL signup');
select throws_ok($$
  insert into auth.users (id, instance_id, aud, role, email, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
  values ('fe35c071-57f2-4af9-a80b-a7d3a90d8315', '00000000-0000-0000-0000-000000000000',
    'authenticated', 'authenticated', 'spoof@ual.ac.uk.evil.com', '{}', '{}', now(), now())
$$, 'P0001', 'school_email_required', 'Auth itself rejects a suffix-spoofed UAL signup');

update allowed_school_domains set active = false where domain = 'ual.ac.uk';
select is(school_domain_for_email('student@ual.ac.uk'), null, 'disabled UAL is rejected');
select is(school_domain_for_email('student@students.ual.ac.uk'), null, 'disabled UAL subdomains are rejected');
select * from finish();
rollback;
