begin;
create extension if not exists pgtap with schema extensions;
set local search_path = public, extensions;
select no_plan();
select has_table('public', 'recommendation_observations', 'feature snapshots exist');
select has_function('public', 'recommendation_weight_observations', array[]::text[], 'own learning history RPC exists');
select ok(not has_table_privilege('authenticated', 'public.recommendation_observations', 'INSERT'), 'browser cannot forge features');
select ok(not has_table_privilege('anon', 'public.recommendation_observations', 'SELECT'), 'anonymous snapshots are private');
select ok(not has_function_privilege('anon', 'public.recommendation_weight_observations()', 'EXECUTE'), 'anonymous history RPC forbidden');
select ok(has_function_privilege('authenticated', 'public.recommendation_weight_observations()', 'EXECUTE'), 'signed-in history RPC available');

create temporary table adaptive_ids(k text primary key, v uuid default gen_random_uuid());
grant select on adaptive_ids to authenticated;
insert into adaptive_ids(k) values ('a'), ('b'), ('event'), ('r1'), ('r2'), ('r3');
insert into auth.users(id, instance_id, aud, role, email, email_confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
select v, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
  'adaptive-' || k || '@imperial.ac.uk', now(), '{}', '{}', now(), now()
from adaptive_ids where k in ('a','b');
insert into public.events(id, host_user_id, category, title, starts_at, checkin_mode, status, visibility)
values ((select v from adaptive_ids where k='event'), (select v from adaptive_ids where k='a'),
 '运动', 'Adaptive test', now()+interval '1 day', 'none', 'published', 'public');
insert into public.recommendation_observations(user_id,event_id,request_id,shown_at,position,features,algorithm_version)
select (select v from adaptive_ids where k=case when r.k='r3' then 'b' else 'a' end),
 (select v from adaptive_ids where k='event'), r.v,
 now()-case when r.k='r1' then interval '2 hours' else interval '1 hour' end, 0,
 '{"time":0.8,"distance":0.9}', 'reco-v2-adaptive'
from adaptive_ids r where r.k in ('r1','r2','r3');
insert into public.recommendation_events(user_id,event_id,request_id,kind,at)
values ((select v from adaptive_ids where k='a'),(select v from adaptive_ids where k='event'),
 (select v from adaptive_ids where k='r1'),'click',now()-interval '90 minutes');
insert into public.event_rsvps(user_id,event_id,status)
values ((select v from adaptive_ids where k='a'),(select v from adaptive_ids where k='event'),'going');

select set_config('request.jwt.claims', json_build_object('sub',(select v from adaptive_ids where k='a'),'role','authenticated')::text,true);
set local role authenticated;
select is((select count(*)::int from public.recommendation_observations),2,'RLS reads only own snapshots');
select is((select count(*)::int from public.recommendation_weight_observations()),2,'RPC reads only own history');
select is((select feedback from public.recommendation_weight_observations() where request_id=(select v from adaptive_ids where k='r1')),'click','older request retains its own click');
select is((select feedback from public.recommendation_weight_observations() where request_id=(select v from adaptive_ids where k='r2')),'join','RSVP attributed only to latest preceding snapshot');
select throws_ok($$ insert into public.recommendation_observations(user_id,event_id,request_id,position,features,algorithm_version)
  select (select v from adaptive_ids where k='a'),(select v from adaptive_ids where k='event'),gen_random_uuid(),0,'{}','forged' $$,
  '42501', null, 'client snapshot writes refused');
reset role;
select set_config('request.jwt.claims', json_build_object('sub',(select v from adaptive_ids where k='b'),'role','authenticated')::text,true);
set local role authenticated;
select is((select count(*)::int from public.recommendation_weight_observations()),1,'second user sees only their own row');
select ok((select feedback is null from public.recommendation_weight_observations()),'second user does not inherit first user feedback');
reset role;
select * from finish();
rollback;
