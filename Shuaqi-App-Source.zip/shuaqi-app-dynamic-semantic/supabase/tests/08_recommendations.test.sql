begin;
create extension if not exists pgtap with schema extensions;
set local search_path = public, extensions;

-- ---- test helpers (rolled back with the transaction) ----
create schema tests;
grant usage on schema tests to anon, authenticated;
create table tests.ids (k text primary key, v text not null);
grant all on tests.ids to anon, authenticated;

create function tests.put(p_k text, p_v text) returns text language sql as $$
  insert into tests.ids (k, v) values (p_k, p_v) on conflict (k) do update set v = excluded.v returning v
$$;
create function tests.id(p_k text) returns uuid language sql stable as $$ select v::uuid from tests.ids where k = p_k $$;

create function tests.new_user(p_k text, p_email text) returns uuid
language plpgsql as $$
declare v uuid := gen_random_uuid();
begin
  insert into auth.users (id, instance_id, aud, role, email, email_confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
  values (v, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', p_email, now(), '{}', '{}', now(), now());
  perform tests.put(p_k, v::text);
  return v;
end $$;

create function tests.login(p_k text) returns void language plpgsql as $$
begin
  perform set_config('request.jwt.claims', json_build_object('sub', tests.id(p_k), 'role', 'authenticated')::text, true);
  perform set_config('role', 'authenticated', true);
end $$;

create function tests.clear_claims() returns void language sql as $$
  select set_config('request.jwt.claims', '', true); select null::void
$$;

-- Events as postgres (no auth.uid(), so the insert guard's per-user checks are skipped).
create function tests.event(p_k text, p_host text, p_title text, p_starts interval, p_status text default 'published',
                            p_visibility text default 'public', p_capacity int default null) returns uuid
language plpgsql as $$
declare v uuid;
begin
  insert into public.events (host_user_id, category, title, starts_at, checkin_mode, status, visibility, capacity)
  values (tests.id(p_host), '运动', p_title, now() + interval '1 day', 'none', 'published',
          p_visibility::public.event_visibility, p_capacity)
  returning id into v;
  -- Inserts must be future drafts or published events; set the rest afterwards.
  update public.events set starts_at = now() + p_starts, status = p_status::public.event_status where id = v;
  perform tests.put(p_k, v::text);
  return v;
end $$;

-- Keys of this test's events among the candidates (seed data may add others).
create function tests.candidates(p_from timestamptz default null, p_to timestamptz default null) returns setof text
language sql as $$
  select i.k from public.recommendation_candidates(p_from, p_to) c join tests.ids i on i.v = c.id::text
$$;

select plan(31);

select tests.new_user('host', 'host@imperial.ac.uk');
select tests.new_user('other_host', 'oh@ucl.ac.uk');
select tests.new_user('me', 'me@imperial.ac.uk');
select tests.new_user('stranger', 's@lse.ac.uk');
select tests.new_user('admin', 'admin@ucl.ac.uk');
update profiles set role = 'admin' where id = tests.id('admin');

select tests.event('open', 'host', 'Badminton', interval '1 day');
select tests.event('later', 'host', 'Football', interval '10 days');
select tests.event('draft', 'host', 'Draft', interval '1 day', 'draft');
select tests.event('cancelled', 'host', 'Cancelled', interval '1 day', 'cancelled');
select tests.event('full', 'host', 'Full', interval '1 day', 'published', 'public', 2);
select tests.event('school', 'other_host', 'UCL only', interval '1 day', 'published', 'school');
select tests.event('blocked', 'other_host', 'Blocked host', interval '1 day');
select tests.event('joined', 'host', 'Already going', interval '1 day');
select tests.event('dismissed', 'host', 'Dismissed', interval '1 day');
select tests.event('ongoing', 'host', 'Ongoing', interval '-30 minutes');
select tests.event('ended', 'host', 'Ended', interval '-5 hours');
insert into event_rsvps (event_id, user_id, status) values (tests.id('full'), tests.id('stranger'), 'going');
insert into event_rsvps (event_id, user_id, status) values (tests.id('joined'), tests.id('me'), 'going');
insert into blocks (blocker_id, blocked_id) values (tests.id('other_host'), tests.id('me'));

-- ===========================================================================
-- Candidate retrieval: hard constraints live in the database
-- ===========================================================================
select tests.login('me');
insert into recommendation_events (event_id, kind) values (tests.id('dismissed'), 'dismiss');
select set_eq($$ select * from tests.candidates() $$, array['open', 'later', 'ongoing'],
  'candidates: only published, visible, open, not-full, not-joined, not-dismissed, not-blocked events');
select is((select going from recommendation_candidates() where id = tests.id('open')), 1,
  'candidates: going count includes the host');
select set_eq($$ select * from tests.candidates(now() + interval '5 days', now() + interval '20 days') $$,
  array['later'], 'candidates: time window keeps only overlapping events');
select is((select count(*)::int from recommendation_candidates(p_limit => 1)), 1, 'candidates: limit is applied');
reset role;

select tests.login('stranger');
select ok(tests.id('school') not in (select id from recommendation_candidates()),
  'candidates: school-only event is hidden from another school');
reset role;
select tests.clear_claims();

select throws_ok($$ select * from recommendation_candidates() $$, 'P0001', 'not_authenticated',
  'candidates: anonymous calls are refused');

-- Semantic similarity from cached embeddings, only for the matching model and dimension.
insert into event_embeddings (event_id, model, content_hash, embedding) values
  (tests.id('open'), 'openai:test', 'h1', '[1,0,0]'),
  (tests.id('later'), 'openai:test', 'h2', '[0,1,0]'),
  (tests.id('ongoing'), 'other:model', 'h3', '[1,0,0]');
select tests.login('me');
select is((select round(similarity::numeric, 3) from recommendation_candidates(null, null, 'openai:test', '[1,0,0]') where id = tests.id('open')),
  1.000, 'similarity: identical vectors score 1');
select is((select round(similarity::numeric, 3) from recommendation_candidates(null, null, 'openai:test', '[1,0,0]') where id = tests.id('later')),
  0.000, 'similarity: orthogonal vectors score 0');
select is((select similarity from recommendation_candidates(null, null, 'openai:test', '[1,0,0]') where id = tests.id('ongoing')),
  null, 'similarity: other model''s vectors are ignored');
select is((select embedding_hash from recommendation_candidates(null, null, 'openai:test') where id = tests.id('open')),
  'h1', 'candidates: cached embedding hash is returned');
select is((select similarity from recommendation_candidates(null, null, 'openai:test', '[1,0]') where id = tests.id('open')),
  null, 'similarity: a vector of a different dimension is ignored');
select throws_ok($$ select * from event_embeddings $$, '42501', null, 'embeddings: clients cannot read the cache');
reset role;

-- ===========================================================================
-- Interaction events
-- ===========================================================================
select tests.login('me');
select lives_ok($$ insert into recommendation_events (event_id, kind, position, algorithm_version)
                   values (tests.id('open'), 'click', 0, 'test') $$, 'events: user records a click');
select is((select user_id from recommendation_events where kind = 'click'), tests.id('me'),
  'events: user_id comes from the session');
select throws_ok($$ insert into recommendation_events (user_id, event_id, kind) values (tests.id('stranger'), tests.id('open'), 'click') $$,
  '42501', null, 'events: cannot write a row for someone else');
select throws_ok($$ insert into recommendation_events (event_id, kind) values (tests.id('school'), 'click') $$,
  '42501', null, 'events: cannot record an event the user cannot see');
select throws_ok($$ insert into recommendation_events (event_id, kind) values (tests.id('open'), 'join') $$,
  '22P02', null, 'events: joins are not client-recordable');
reset role;
select tests.login('stranger');
select is((select count(*)::int from recommendation_events), 0, 'events: others'' interactions are not readable');
reset role;

-- ===========================================================================
-- Signals for interest weights: own history only
-- ===========================================================================
insert into participation_evidence (event_id, subject_user_id, type, source, verification_status)
values (tests.id('joined'), tests.id('me'), 'self_reported_presence', 'qr_geo', 'geo_verified');
select tests.login('me');
select set_eq($$ select signal from recommendation_signals() $$, array['join', 'attend', 'click', 'dismiss'],
  'signals: joins, attendance, clicks and dismissals of the user');
reset role;
select tests.login('stranger');
select set_eq($$ select signal from recommendation_signals() $$, array['join'],
  'signals: another user only sees their own');
reset role;

-- ===========================================================================
-- Rate limits and the feature flag
-- ===========================================================================
select tests.login('me');
select ok((start_recommendation_request(true) ->> 'llm_allowed')::boolean, 'requests: language model allowed under the daily cap');
select ok(not (start_recommendation_request(false) ->> 'llm_allowed')::boolean, 'requests: llm_allowed follows the request');
select lives_ok($$ select start_recommendation_request() from generate_series(1, 8) $$, 'requests: ten in a minute are fine');
select throws_ok($$ select start_recommendation_request() $$, 'P0001', 'rate_limited', 'requests: the eleventh in a minute is refused');
select throws_ok($$ select * from recommendation_requests $$, '42501', null, 'requests: the log is not readable');
reset role;
update feature_flags set enabled = false where key = 'recommendations';
select tests.login('stranger');
select throws_ok($$ select start_recommendation_request() $$, 'P0001', 'feature_disabled', 'flag off: requests are refused');
select throws_ok($$ select * from recommendation_candidates() $$, 'P0001', 'feature_disabled', 'flag off: candidates are refused');
reset role;

-- ===========================================================================
-- Model settings: readable by users, changeable by admins only
-- ===========================================================================
select tests.login('me');
update recommendation_settings set llm_provider = 'openai';
select is((select llm_provider from recommendation_settings), 'none', 'settings: a normal user cannot change the model');
reset role;
select tests.login('admin');
select lives_ok($$ update recommendation_settings set llm_provider = 'anthropic', llm_model = 'claude-haiku-5-5' $$,
  'settings: admin picks a provider and model');
select throws_ok($$ update recommendation_settings set llm_provider = 'gemini' $$, '23514', null,
  'settings: unknown providers are rejected');
reset role;
select is((select updated_by from recommendation_settings), tests.id('admin'), 'settings: records who changed them');

select * from finish();
rollback;
