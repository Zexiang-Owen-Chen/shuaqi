begin;
create extension if not exists pgtap with schema extensions;
set local search_path = public, extensions;

select plan(13);
select ok((select active and allow_subdomains and school_name = 'King''s College London'
  from allowed_school_domains where domain = 'kcl.ac.uk'), 'KCL is an active supported school');
select is(school_domain_for_email('student@kcl.ac.uk'), 'kcl.ac.uk', 'KCL domain is accepted');
select is(school_domain_for_email('Student@KCL.AC.UK'), 'kcl.ac.uk', 'KCL domain is case insensitive');
select is(school_domain_for_email('student@students.kcl.ac.uk'), 'kcl.ac.uk', 'KCL subdomains share the same school');
select is(school_domain_for_email('student@fakekcl.ac.uk'), null, 'look-alike KCL domain is rejected');
select is(school_domain_for_email('student@kcl.ac.uk.evil.com'), null, 'KCL suffix spoof is rejected');
select is(school_domain_for_email('student@gmail.com'), null, 'unrelated domains remain rejected');

select lives_ok($$
  insert into auth.users (id, instance_id, aud, role, email, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
  values ('9d76f676-ab95-4db8-bc24-96ee5ad9572e', '00000000-0000-0000-0000-000000000000',
    'authenticated', 'authenticated', 'kcl-registration-regression@kcl.ac.uk', '{}', '{}', now(), now())
$$, 'Auth sign-up gate accepts KCL');
select is((select school_domain from profiles where id = '9d76f676-ab95-4db8-bc24-96ee5ad9572e'),
  'kcl.ac.uk', 'KCL profile has the correct school identity');
select is((select school_verified_at from profiles where id = '9d76f676-ab95-4db8-bc24-96ee5ad9572e'),
  null, 'KCL registration still needs email verification');
update auth.users set email_confirmed_at = now() where id = '9d76f676-ab95-4db8-bc24-96ee5ad9572e';
select ok((select school_verified_at is not null and school_domain = 'kcl.ac.uk'
  from profiles where id = '9d76f676-ab95-4db8-bc24-96ee5ad9572e'), 'KCL email confirmation verifies the school');

update allowed_school_domains set active = false where domain = 'kcl.ac.uk';
select is(school_domain_for_email('student@kcl.ac.uk'), null, 'disabled KCL is rejected');
select is(school_domain_for_email('student@students.kcl.ac.uk'), null, 'disabled KCL subdomains are rejected');
select * from finish();
rollback;
