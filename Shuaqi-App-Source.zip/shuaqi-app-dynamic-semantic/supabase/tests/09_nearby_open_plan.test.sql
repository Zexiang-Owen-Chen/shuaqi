begin;
create extension if not exists pgtap with schema extensions;
set local search_path = public, extensions;

-- ---- test helpers (rolled back with the transaction) ----
create schema tests;
grant usage on schema tests to anon, authenticated;
create table tests.ids (k text primary key, v text not null);
grant all on tests.ids to anon, authenticated;

create function tests.put(p_k text, p_v text) returns text language sql as $$
  insert into tests.ids (k, v) values (p_k, p_v) on conflict (k) do update set v = excluded.v returning v
$$;
create function tests.id(p_k text) returns uuid language sql stable as $$ select v::uuid from tests.ids where k = p_k $$;
create function tests.txt(p_k text) returns text language sql stable as $$ select v from tests.ids where k = p_k $$;

-- Creates an auth user (the sign-up trigger creates the profile) and stores its id under p_k.
create function tests.new_user(p_k text, p_email text, p_confirmed boolean default true) returns uuid
language plpgsql as $$
declare v uuid := gen_random_uuid();
begin
  insert into auth.users (id, instance_id, aud, role, email, email_confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
  values (v, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', p_email,
          case when p_confirmed then now() end, '{}', '{}', now(), now());
  perform tests.put(p_k, v::text);
  return v;
end $$;

-- Impersonate a user for the rest of the transaction (call while running as postgres).
create function tests.login(p_k text) returns void language plpgsql as $$
begin
  perform set_config('request.jwt.claims', json_build_object('sub', tests.id(p_k), 'role', 'authenticated')::text, true);
  perform set_config('role', 'authenticated', true);
end $$;

-- Forget the impersonated user's claims (run `reset role;` first).
create function tests.clear_claims() returns void language sql as $$
  select set_config('request.jwt.claims', '', true); select null::void
$$;


select plan(29);

-- Russell Square (51.5226, -0.1257); 0.00027 deg lat ~ 30 m, 0.00072 ~ 80 m.
select tests.new_user('a', 'a@ucl.ac.uk');
select tests.new_user('b', 'b@ucl.ac.uk');
select tests.new_user('c', 'c@lse.ac.uk');
select tests.new_user('far', 'far@imperial.ac.uk');
select tests.new_user('unverified', 'nov@ucl.ac.uk', false);
select tests.clear_claims();

-- ===========================================================================
-- Standalone "add friends nearby" (no event)
-- ===========================================================================
select tests.login('a');
select throws_ok($$ select update_open_presence(51.5226, -0.1257, 10) $$, 'P0001', 'location_consent_required',
  'open: sharing needs location consent');
select grant_location_consent('nearby', 'test');
select throws_ok($$ select update_open_presence(51.5226, -0.1257, 150) $$, 'P0001', 'location_inaccurate',
  'open: accuracy worse than 100 m is rejected');
select throws_ok($$ select * from list_open_nearby() $$, 'P0001', 'nearby_not_active',
  'open: must share own position before seeing others');
select lives_ok($$ select update_open_presence(51.5226, -0.1257, 10) $$, 'open: A shares position');
select throws_ok($$ select * from open_presence $$, '42501', null, 'open: positions table is not readable by clients');
select throws_ok($$ select open_distance(tests.id('a'), tests.id('b')) $$, '42501', null,
  'open: distance helper cannot be called directly');
reset role;

select tests.login('b');
select grant_location_consent('nearby', 'test');
select lives_ok($$ select update_open_presence(51.5226 + 0.00027, -0.1257, 10) $$, 'open: B shares ~30 m away');
reset role;
select tests.login('far');
select grant_location_consent('nearby', 'test');
select lives_ok($$ select update_open_presence(51.5226 + 0.00072, -0.1257, 10) $$, 'open: far shares ~80 m away');
reset role;
select tests.login('c');
select grant_location_consent('nearby', 'test');
reset role;
select tests.login('unverified');
select grant_location_consent('nearby', 'test');
select throws_ok($$ select update_open_presence(51.5226, -0.1257, 10) $$, 'P0001', 'school_verification_required',
  'open: unverified users cannot appear');
reset role;

select tests.login('a');
select set_eq($$ select (card ->> 'id')::uuid from list_open_nearby() $$, array[tests.id('b')],
  'open: list shows only people within 50 m');
select is((select distance_m from list_open_nearby()), 30, 'open: distance rounded to 10 m');
select throws_ok($$ select send_connection_request(tests.id('far'), 'nearby') $$, 'P0001', 'not_nearby',
  'open: request to someone > 50 m fails');
select throws_ok($$ select send_connection_request(tests.id('c'), 'nearby') $$, 'P0001', 'not_nearby',
  'open: request to someone not sharing fails');
select is((select context::text from send_connection_request(tests.id('b'), 'nearby')), 'nearby',
  'open: request within 50 m succeeds without any event');
select is((select request_status from list_open_nearby()), 'pending', 'open: list shows the pending request');
reset role;

-- Stale positions stop counting after 2 minutes and are deleted after 5.
update open_presence set updated_at = now() - interval '3 minutes' where user_id = tests.id('b');
select tests.login('a');
select is((select count(*)::int from list_open_nearby()), 0, 'open: position older than 2 minutes is not shown');
select stop_open_presence();
reset role;
select is((select count(*)::int from open_presence where user_id = tests.id('a')), 0, 'open: switching off deletes the position');
update open_presence set updated_at = now() - interval '6 minutes' where user_id = tests.id('b');
select is(purge_nearby_presence() >= 1, true, 'open: purge removes positions older than 5 minutes');
select is((select count(*)::int from open_presence where user_id = tests.id('b')), 0, 'open: B''s old position is gone');

select tests.login('far');
select withdraw_location_consent('nearby');
reset role;
select is((select count(*)::int from open_presence where user_id = tests.id('far')), 0,
  'open: withdrawing consent deletes the position');

-- ===========================================================================
-- Shared plan meetup prompt
-- ===========================================================================
insert into intents (user_id, activity_type, window_start, window_end, region, expires_at) values
  (tests.id('a'), 'coffee', now(), now() + interval '2 hours', 'London', now() + interval '1 hour'),
  (tests.id('c'), 'coffee', now(), now() + interval '2 hours', 'London', now() + interval '1 hour');
with i as (insert into match_invitations (from_intent_id, to_intent_id, from_user, to_user, status)
           select (select id from intents where user_id = tests.id('a')), (select id from intents where user_id = tests.id('c')),
                  tests.id('a'), tests.id('c'), 'accepted' returning id)
select tests.put('inv', id::text) from i;
with s as (insert into shared_plans (invitation_id, user_a, user_b, title, planned_at, place, status)
           values (tests.id('inv'), tests.id('a'), tests.id('c'), 'Coffee', now() + interval '3 hours', 'Russell Square', 'proposed')
           returning id)
select tests.put('plan', id::text) from s;

select tests.login('a');
select throws_ok($$ select update_plan_presence(tests.id('plan'), 51.5226, -0.1257, 10) $$, 'P0001', 'plan_not_confirmed',
  'plan: meetup check needs a confirmed plan');
reset role;
update shared_plans set status = 'confirmed' where id = tests.id('plan');
select tests.login('a');
select throws_ok($$ select update_plan_presence(tests.id('plan'), 51.5226, -0.1257, 10) $$, 'P0001', 'meetup_not_open',
  'plan: too early (more than 1 hour before)');
reset role;
update shared_plans set planned_at = now() + interval '10 minutes' where id = tests.id('plan');

select tests.login('b');
select throws_ok($$ select update_plan_presence(tests.id('plan'), 51.5226, -0.1257, 10) $$, 'P0001', 'plan_not_found',
  'plan: outsider cannot share position for the plan');
reset role;

select tests.login('a');
select is(update_plan_presence(tests.id('plan'), 51.5226, -0.1257, 10) -> 'nearby', 'false'::jsonb,
  'plan: other person not here yet');
reset role;
select tests.login('c');
select is(update_plan_presence(tests.id('plan'), 51.5226 + 0.00072, -0.1257, 10),
  '{"nearby": false, "distance_m": null}'::jsonb, 'plan: ~80 m apart is not nearby and hides the distance');
select is(update_plan_presence(tests.id('plan'), 51.5226 + 0.00027, -0.1257, 10),
  '{"nearby": true, "distance_m": 30}'::jsonb, 'plan: ~30 m apart is nearby');
reset role;
select tests.login('a');
select is(update_plan_presence(tests.id('plan'), 51.5226, -0.1257, 10) -> 'nearby', 'true'::jsonb,
  'plan: both sides see the prompt');
select is((select context::text from send_connection_request(tests.id('c'), 'intent', tests.id('plan'))), 'intent',
  'plan: friend request from the prompt succeeds');
select stop_plan_presence(tests.id('plan'));
reset role;
select is((select count(*)::int from plan_presence where user_id = tests.id('a')), 0, 'plan: stopping deletes the position');

select * from finish();
rollback;
