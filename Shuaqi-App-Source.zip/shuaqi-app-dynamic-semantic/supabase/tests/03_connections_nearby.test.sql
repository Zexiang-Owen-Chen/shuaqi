begin;
create extension if not exists pgtap with schema extensions;
set local search_path = public, extensions;

-- ---- test helpers (rolled back with the transaction) ----
create schema tests;
grant usage on schema tests to anon, authenticated;
create table tests.ids (k text primary key, v text not null);
grant all on tests.ids to anon, authenticated;

create function tests.put(p_k text, p_v text) returns text language sql as $$
  insert into tests.ids (k, v) values (p_k, p_v) on conflict (k) do update set v = excluded.v returning v
$$;
create function tests.id(p_k text) returns uuid language sql stable as $$ select v::uuid from tests.ids where k = p_k $$;
create function tests.txt(p_k text) returns text language sql stable as $$ select v from tests.ids where k = p_k $$;

-- Creates an auth user (the sign-up trigger creates the profile) and stores its id under p_k.
create function tests.new_user(p_k text, p_email text, p_confirmed boolean default true) returns uuid
language plpgsql as $$
declare v uuid := gen_random_uuid();
begin
  insert into auth.users (id, instance_id, aud, role, email, email_confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
  values (v, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', p_email,
          case when p_confirmed then now() end, '{}', '{}', now(), now());
  perform tests.put(p_k, v::text);
  return v;
end $$;

-- Impersonate a user for the rest of the transaction (call while running as postgres).
create function tests.login(p_k text) returns void language plpgsql as $$
begin
  perform set_config('request.jwt.claims', json_build_object('sub', tests.id(p_k), 'role', 'authenticated')::text, true);
  perform set_config('role', 'authenticated', true);
end $$;

-- Forget the impersonated user's claims (run `reset role;` first).
create function tests.clear_claims() returns void language sql as $$
  select set_config('request.jwt.claims', '', true); select null::void
$$;

select plan(40);

select tests.new_user('host', 'host@imperial.ac.uk');
select tests.new_user('a', 'a@imperial.ac.uk');
select tests.new_user('b', 'b@ucl.ac.uk');
select tests.new_user('c', 'c@lse.ac.uk');
select tests.new_user('d', 'd@cam.ac.uk');
select tests.new_user('stranger', 'stranger@cam.ac.uk');

-- Event used as the connection context; everybody joins and opts in.
with e as (insert into events (host_user_id, type, category, title, starts_at, checkin_mode)
           values (tests.id('host'), 'group', 'social', 'Mixer', now() + interval '1 day', 'none') returning id)
select tests.put('ev', id::text) from e;
insert into event_rsvps (event_id, user_id) select tests.id('ev'), tests.id(k) from unnest(array['a','b','c','d']) k;
insert into event_social_optin (event_id, user_id, opted_in) select tests.id('ev'), tests.id(k), true from unnest(array['a','b','c','d']) k;

-- ===========================================================================
-- B-03: connection request state machine
-- ===========================================================================
select tests.login('a');
select lives_ok($$ select tests.put('r1', (select id::text from send_connection_request(tests.id('b'), 'event', tests.id('ev'), 'hi'))) $$,
  'B-03: A sends a request to B');
select is((select status::text from connection_requests where id = tests.id('r1')), 'pending', 'B-03: request is pending');
select is((select id from send_connection_request(tests.id('b'), 'event', tests.id('ev'))), tests.id('r1'),
  'B-03: duplicate send returns the same request');
select is((select count(*)::int from connection_requests where from_user = tests.id('a') and to_user = tests.id('b')), 1,
  'B-03: duplicate send creates no second row');
select throws_ok($$ select respond_connection_request(tests.id('r1'), true) $$, 'P0001', 'request_not_found',
  'B-03: sender cannot accept their own request');
select throws_ok($$ select send_connection_request(tests.id('stranger'), 'event', tests.id('ev')) $$, 'P0001', 'not_discoverable',
  'B-03: cannot request someone who is not opted in to the event');
select throws_ok($$ select send_connection_request(tests.id('stranger'), 'profile') $$, 'P0001', 'context_not_allowed',
  'B-03: profile context is not allowed in V0');
reset role;

select tests.login('b');
select throws_ok($$ select send_connection_request(tests.id('a'), 'event', tests.id('ev')) $$, 'P0001', 'incoming_request_pending',
  'B-03: reverse send while A->B pending raises incoming_request_pending');
select is((select status::text from respond_connection_request(tests.id('r1'), false)), 'declined', 'B-03: B declines');
select is((select status::text from respond_connection_request(tests.id('r1'), false)), 'declined', 'B-03: repeat decline is idempotent');
select throws_ok($$ select respond_connection_request(tests.id('r1'), true) $$, 'P0001', 'request_not_pending',
  'B-03: declined request cannot be accepted later');
select is((select count(*)::int from connections), 0, 'B-03: decline creates no connection');
reset role;

select tests.login('a');
select lives_ok($$ select tests.put('r2', (select id::text from send_connection_request(tests.id('b'), 'event', tests.id('ev')))) $$,
  'B-03: A can send again after a decline');
reset role;
select tests.login('b');
select is((select status::text from respond_connection_request(tests.id('r2'), true)), 'accepted', 'B-03: B accepts');
select is((select status::text from respond_connection_request(tests.id('r2'), true)), 'accepted', 'B-03: repeat accept is idempotent');
reset role;
select is((select count(*)::int from connections
           where user_a = least(tests.id('a'), tests.id('b')) and user_b = greatest(tests.id('a'), tests.id('b'))), 1,
  'B-03: accept creates exactly one connections row');
select is((select count(*)::int from connections
           where user_a::text in (select v from tests.ids) or user_b::text in (select v from tests.ids)), 1,
  'B-03: no other connection rows exist');
select tests.login('a');
select throws_ok($$ select send_connection_request(tests.id('b'), 'event', tests.id('ev')) $$, 'P0001', 'already_connected',
  'B-03: sending to an existing connection raises already_connected');
select is((select count(*)::int from list_my_connections()), 1, 'B-03: A lists one connection');

-- One-sided send never creates a connection.
select lives_ok($$ select tests.put('r3', (select id::text from send_connection_request(tests.id('c'), 'event', tests.id('ev')))) $$,
  'B-03: A sends to C');
reset role;
select is((select count(*)::int from connections where tests.id('c') in (user_a, user_b)), 0,
  'B-03: one-sided request creates no connection');
select tests.login('c');
select is((select count(*)::int from connection_requests where id = tests.id('r1')), 0, 'B-03: C cannot read the A-B request');
select throws_ok($$ insert into connections (user_a, user_b) values (least(tests.id('a'), tests.id('c')), greatest(tests.id('a'), tests.id('c'))) $$,
  '42501', null, 'B-03: clients cannot insert connections directly');
select throws_ok($$ update connection_requests set status = 'accepted' where id = tests.id('r3') $$,
  '42501', null, 'B-03: clients cannot update requests directly');
reset role;

-- Blocked users cannot send in either direction; blocking withdraws pending requests.
select tests.login('a');
select lives_ok($$ select tests.put('r4', (select id::text from send_connection_request(tests.id('d'), 'event', tests.id('ev')))) $$,
  'B-03: A sends to D');
reset role;
select tests.login('d');
select lives_ok($$ select block_user(tests.id('a')) $$, 'B-03: D blocks A');
select is((select status::text from connection_requests where id = tests.id('r4')), 'withdrawn', 'B-03: blocking withdraws the pending request');
select throws_ok($$ select send_connection_request(tests.id('a'), 'event', tests.id('ev')) $$, 'P0001', 'blocked',
  'B-03: blocker cannot send to blocked user');
reset role;
select tests.login('a');
select throws_ok($$ select send_connection_request(tests.id('d'), 'event', tests.id('ev')) $$, 'P0001', 'blocked',
  'B-03: blocked user cannot send to blocker');
reset role;

-- ===========================================================================
-- B-18: nearby requests need both people sharing a fresh position <= 50 m apart (no check-in needed)
-- Imperial College (51.4988, -0.1749); 0.00027 deg lat ~ 30 m, 0.00072 ~ 80 m.
-- ===========================================================================
select tests.new_user('p1', 'p1@imperial.ac.uk');
select tests.new_user('p2', 'p2@imperial.ac.uk');
select tests.new_user('p3', 'p3@imperial.ac.uk');
select tests.new_user('p4', 'p4@imperial.ac.uk');
select tests.clear_claims();
with e as (insert into events (host_user_id, type, category, title, starts_at, checkin_mode, location_lat, location_lng)
           values (tests.id('host'), 'group', 'social', 'Nearby night', now(), 'qr_geo', 51.4988, -0.1749) returning id)
select tests.put('nev', id::text) from e;
insert into event_rsvps (event_id, user_id) select tests.id('nev'), tests.id(k) from unnest(array['p1','p2','p3','p4']) k;

select tests.login('p1');
select grant_location_consent('nearby', 'test');
select lives_ok($$ select update_nearby_presence(tests.id('nev'), 51.4988, -0.1749, 10) $$, 'B-18: p1 shares position');
select throws_ok($$ select send_connection_request(tests.id('p2'), 'nearby', tests.id('nev')) $$, 'P0001', 'not_nearby',
  'B-18: cannot send before the other person is visible');
reset role;
select tests.login('p2');
select grant_location_consent('nearby', 'test');
select lives_ok($$ select update_nearby_presence(tests.id('nev'), 51.4988 + 0.00027, -0.1749, 10) $$, 'B-18: p2 shares position ~30 m away');
reset role;
select tests.login('p4');
select grant_location_consent('nearby', 'test');
select lives_ok($$ select update_nearby_presence(tests.id('nev'), 51.4988 + 0.00072, -0.1749, 10) $$, 'B-18: p4 shares position ~80 m away');
reset role;
select tests.login('p3');
select throws_ok($$ select update_nearby_presence(tests.id('nev'), 51.4988, -0.1749, 10) $$, 'P0001', 'location_consent_required',
  'nearby: sharing position requires separate location consent');
select grant_location_consent('nearby', 'test');
select lives_ok($$ select update_nearby_presence(tests.id('nev'), 51.4988 + 0.002, -0.1749, 10) $$,
  'B-18: no check-in needed to share position (p3 ~220 m away)');
reset role;

select tests.login('p1');
select set_eq($$ select (card ->> 'id')::uuid from list_nearby(tests.id('nev')) $$, array[tests.id('p2')],
  'B-18: list_nearby shows only people within 50 m');
select throws_ok($$ select send_connection_request(tests.id('p4'), 'nearby', tests.id('nev')) $$, 'P0001', 'not_nearby',
  'B-18: request to someone > 50 m away fails');
select throws_ok($$ select send_connection_request(tests.id('p3'), 'nearby', tests.id('nev')) $$, 'P0001', 'not_nearby',
  'B-18: request to someone far away fails');
select is((select context::text from send_connection_request(tests.id('p2'), 'nearby', tests.id('nev'))), 'nearby',
  'B-18: request within 50 m succeeds');
reset role;
select tests.login('p3');
select throws_ok($$ select send_connection_request(tests.id('p1'), 'nearby', tests.id('nev')) $$, 'P0001', 'not_nearby',
  'B-18: far-away sender fails');
reset role;

select * from finish();
rollback;
