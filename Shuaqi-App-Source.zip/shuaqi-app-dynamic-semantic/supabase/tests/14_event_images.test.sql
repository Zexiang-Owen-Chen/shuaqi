begin;
create extension if not exists pgtap with schema extensions;
set local search_path = public, extensions;

-- ---- test helpers (rolled back with the transaction) ----
create schema tests;
grant usage on schema tests to anon, authenticated;
create table tests.ids (k text primary key, v text not null);
grant all on tests.ids to anon, authenticated;

create function tests.put(p_k text, p_v text) returns text language sql as $$
  insert into tests.ids (k, v) values (p_k, p_v) on conflict (k) do update set v = excluded.v returning v
$$;
create function tests.id(p_k text) returns uuid language sql stable as $$ select v::uuid from tests.ids where k = p_k $$;
create function tests.txt(p_k text) returns text language sql stable as $$ select v from tests.ids where k = p_k $$;

-- Creates an auth user (the sign-up trigger creates the profile) and stores its id under p_k.
create function tests.new_user(p_k text, p_email text, p_confirmed boolean default true) returns uuid
language plpgsql as $$
declare v uuid := gen_random_uuid();
begin
  insert into auth.users (id, instance_id, aud, role, email, email_confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
  values (v, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', p_email,
          case when p_confirmed then now() end, '{}', '{}', now(), now());
  perform tests.put(p_k, v::text);
  return v;
end $$;

-- Impersonate a user for the rest of the transaction (call while running as postgres).
create function tests.login(p_k text) returns void language plpgsql as $$
begin
  perform set_config('request.jwt.claims', json_build_object('sub', tests.id(p_k), 'role', 'authenticated')::text, true);
  perform set_config('role', 'authenticated', true);
end $$;

-- Forget the impersonated user's claims (run `reset role;` first).
create function tests.clear_claims() returns void language sql as $$
  select set_config('request.jwt.claims', '', true); select null::void
$$;


select no_plan();
select tests.new_user('host', 'media-host@ucl.ac.uk');
select tests.new_user('peer', 'media-peer@ucl.ac.uk');
select tests.new_user('other', 'media-other@imperial.ac.uk');
select tests.put('a', tests.id('host') || '/00000000-0000-4000-8000-000000000001.png');
select tests.put('b', tests.id('host') || '/00000000-0000-4000-8000-000000000002.png');
select tests.put('c', tests.id('host') || '/00000000-0000-4000-8000-000000000003.png');
select tests.put('d', tests.id('host') || '/00000000-0000-4000-8000-000000000004.png');
select tests.put('foreign', tests.id('other') || '/00000000-0000-4000-8000-000000000005.png');
select ok((select not public and file_size_limit=5242880 from storage.buckets where id='event-images'), 'event images use a private size-limited bucket');
select tests.login('host');
select lives_ok($$ insert into storage.objects (bucket_id,name) values ('event-images',tests.txt('a')),('event-images',tests.txt('b')),('event-images',tests.txt('c')),('event-images',tests.txt('d')) $$, 'uploader can insert own event images');
select throws_ok($$ insert into storage.objects (bucket_id,name) values ('event-images',tests.txt('foreign')) $$,'42501',null,'uploading into another user folder is denied');
select lives_ok($$ insert into events (host_user_id,title,category,starts_at,checkin_mode,image_paths)
 values (tests.id('host'),'Media public','运动',now()+interval '1 day','none',array[tests.txt('a')]) $$,'host can publish an event with own uploaded image');
select tests.put('public',(select id::text from events where title='Media public'));
insert into events (host_user_id,title,category,starts_at,checkin_mode,visibility,image_paths)
 values (tests.id('host'),'Media school','运动',now()+interval '1 day','none','school',array[tests.txt('b')]);
insert into events (host_user_id,title,category,starts_at,checkin_mode,image_paths)
 values (tests.id('host'),'Media draft','运动',now()+interval '1 day','none',array[tests.txt('c')]);
update events set status='draft' where title='Media draft';
select is((select count(*)::int from storage.objects where bucket_id='event-images' and name=any(array[tests.txt('a'),tests.txt('b'),tests.txt('c'),tests.txt('d')])),4,'uploader can preview linked and unlinked own files');
select throws_ok($$ update events set image_paths=array_fill(tests.txt('a'),array[7]) where id=tests.id('public') $$,'P0001','event_images_limit','more than six images are rejected');
select throws_ok($$ update events set image_paths=array[tests.txt('a'),tests.txt('a')] where id=tests.id('public') $$,'P0001','event_images_invalid','duplicate images are rejected');
select throws_ok($$ update events set image_paths=array[tests.id('host') || '/00000000-0000-4000-8000-000000000099.png'] where id=tests.id('public') $$,'P0001','event_images_invalid','unuploaded image paths are rejected');
reset role;
select tests.clear_claims();
set local role anon;
select is((select count(*)::int from storage.objects where bucket_id='event-images' and name=any(array[tests.txt('a'),tests.txt('b'),tests.txt('c'),tests.txt('d')])),1,'anonymous viewers see only the published public event image');
reset role;
select tests.login('peer');
select is((select count(*)::int from storage.objects where bucket_id='event-images' and name=any(array[tests.txt('a'),tests.txt('b'),tests.txt('c'),tests.txt('d')])),2,'same-school viewers can also read the school-only image');
update events set image_paths='{}' where id=tests.id('public');
reset role;
select is((select image_paths from events where id=tests.id('public')),array[tests.txt('a')],'non-manager cannot modify image associations');
select tests.login('other');
select is((select count(*)::int from storage.objects where bucket_id='event-images' and name=any(array[tests.txt('a'),tests.txt('b'),tests.txt('c'),tests.txt('d')])),1,'other school cannot read school-only, draft or unlinked images');
insert into storage.objects (bucket_id,name) values ('event-images',tests.txt('foreign'));
reset role;
select tests.login('host');
select throws_ok($$ update events set image_paths=array[tests.txt('foreign')] where id=tests.id('public') $$,'P0001','event_image_not_owned','manager cannot attach another user private image');
update events set visibility='school' where id=tests.id('public');
reset role;
select tests.clear_claims();
set local role anon;
select is((select count(*)::int from storage.objects where bucket_id='event-images' and name=any(array[tests.txt('a'),tests.txt('b'),tests.txt('c'),tests.txt('d')])),0,'changing public event to school-only removes anonymous signing access');
reset role;
insert into organisations (name) values ('Media organisation');
select tests.put('org',(select id::text from organisations where name='Media organisation'));
insert into org_members (org_id,user_id,role) values
(tests.id('org'),tests.id('host'),'owner'),(tests.id('org'),tests.id('other'),'organiser'),(tests.id('org'),tests.id('peer'),'staff');
select tests.login('host');
insert into events (host_user_id,org_id,title,category,starts_at,checkin_mode,visibility,image_paths)
 values (tests.id('host'),tests.id('org'),'Media organisation event','运动',now()+interval '1 day','none','school',array[tests.txt('c')]);
select tests.put('org_event',(select id::text from events where title='Media organisation event'));
reset role;
select tests.login('other');
select is((select count(*)::int from storage.objects where bucket_id='event-images' and name=tests.txt('c')),1,'organisation manager can view the event image despite a different school');
select lives_ok($$ update events set image_paths=array[tests.txt('c'),tests.txt('foreign')] where id=tests.id('org_event') $$,'manager can retain host image and add own uploaded image');
reset role;
select tests.login('peer');
update events set image_paths='{}' where id=tests.id('org_event');
reset role;
select is((select cardinality(image_paths) from events where id=tests.id('org_event')),2,'staff cannot edit event pictures');
select * from finish();
rollback;
