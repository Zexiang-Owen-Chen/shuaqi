begin;
create extension if not exists pgtap with schema extensions;
set local search_path = public, extensions;

-- ---- test helpers (rolled back with the transaction) ----
create schema tests;
grant usage on schema tests to anon, authenticated;
create table tests.ids (k text primary key, v text not null);
grant all on tests.ids to anon, authenticated;

create function tests.put(p_k text, p_v text) returns text language sql as $$
  insert into tests.ids (k, v) values (p_k, p_v) on conflict (k) do update set v = excluded.v returning v
$$;
create function tests.id(p_k text) returns uuid language sql stable as $$ select v::uuid from tests.ids where k = p_k $$;
create function tests.txt(p_k text) returns text language sql stable as $$ select v from tests.ids where k = p_k $$;

-- Creates an auth user (the sign-up trigger creates the profile) and stores its id under p_k.
create function tests.new_user(p_k text, p_email text, p_confirmed boolean default true) returns uuid
language plpgsql as $$
declare v uuid := gen_random_uuid();
begin
  insert into auth.users (id, instance_id, aud, role, email, email_confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
  values (v, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', p_email,
          case when p_confirmed then now() end, '{}', '{}', now(), now());
  perform tests.put(p_k, v::text);
  return v;
end $$;

-- Impersonate a user for the rest of the transaction (call while running as postgres).
create function tests.login(p_k text) returns void language plpgsql as $$
begin
  perform set_config('request.jwt.claims', json_build_object('sub', tests.id(p_k), 'role', 'authenticated')::text, true);
  perform set_config('role', 'authenticated', true);
end $$;

-- Forget the impersonated user's claims (run `reset role;` first).
create function tests.clear_claims() returns void language sql as $$
  select set_config('request.jwt.claims', '', true); select null::void
$$;

select plan(30);

select tests.new_user('host', 'host@lse.ac.uk');
select tests.new_user('u', 'u@lse.ac.uk');
select tests.new_user('v', 'v@lse.ac.uk');
select tests.new_user('w', 'w@lse.ac.uk');
select tests.new_user('admin', 'admin@lse.ac.uk');
update profiles set role = 'admin' where id = tests.id('admin');

with e as (insert into events (host_user_id, category, title, starts_at, checkin_mode)
           values (tests.id('host'), 'talk', 'Careers talk', now(), 'none') returning id)
select tests.put('ev', id::text) from e;
insert into event_rsvps (event_id, user_id) values (tests.id('ev'), tests.id('u'));
-- Seed evidence as the system would (postgres bypasses client restrictions).
with x as (insert into participation_evidence (event_id, subject_user_id, type, source, operator_id, verification_status)
           values (tests.id('ev'), tests.id('u'), 'self_reported_presence', 'qr_geo', tests.id('u'), 'geo_verified') returning id)
select tests.put('evi', id::text) from x;

-- ===========================================================================
-- B-11: corrections resolved by admin change evidence and trust summary
-- ===========================================================================
select tests.login('u');
select is(trust_summary() ->> 'self_reported_presence', '1', 'B-11: before: one self-reported presence');
select is(trust_summary() ->> 'disputed', '0', 'B-11: before: nothing disputed');
select lives_ok($$ with c as (insert into evidence_corrections (evidence_id, requested_by, reason)
                              values (tests.id('evi'), tests.id('u'), 'I was not there') returning id)
                   select tests.put('corr', id::text) from c $$, 'B-11: subject files a correction');
select throws_ok($$ select admin_resolve_correction(tests.id('corr'), true, 'disputed', 'self-approve') $$, 'P0001', 'forbidden',
  'B-11: user cannot resolve corrections');
select throws_ok($$ select admin_set_evidence_status(tests.id('evi'), 'verified', 'please') $$, 'P0001', 'forbidden',
  'B-11: user cannot set evidence status');
reset role;
select tests.login('v');
select throws_ok($$ insert into evidence_corrections (evidence_id, requested_by, reason) values (tests.id('evi'), tests.id('v'), 'meddling') $$,
  '42501', null, 'B-11: non-subject cannot file a correction on someone else''s evidence');
select is((select count(*)::int from evidence_corrections), 0, 'B-11: other users cannot read the correction');
reset role;

select tests.login('admin');
select lives_ok($$ select admin_resolve_correction(tests.id('corr'), true, 'disputed', 'confirmed with organiser') $$,
  'B-11: admin approves the correction');
select throws_ok($$ select admin_resolve_correction(tests.id('corr'), false) $$, 'P0001', 'correction_not_pending',
  'B-11: a resolved correction cannot be resolved again');
reset role;
select is((select verification_status::text from participation_evidence where id = tests.id('evi')), 'disputed',
  'B-11: evidence status updated');
select is((select status::text || '/' || (resolved_by = tests.id('admin'))::text from evidence_corrections where id = tests.id('corr')),
  'approved/true', 'B-11: correction marked approved by admin');
select tests.login('u');
select is(trust_summary() ->> 'self_reported_presence', '0', 'B-11: after: presence no longer counted');
select is(trust_summary() ->> 'disputed', '1', 'B-11: after: disputed counted');
select is((select correction_status from my_participation_history() where evidence_id = tests.id('evi')), 'approved',
  'B-11: history shows the correction outcome');
-- A rejected correction leaves the evidence untouched.
with c as (insert into evidence_corrections (evidence_id, requested_by, reason)
           values (tests.id('evi'), tests.id('u'), 'second thoughts') returning id)
select tests.put('corr2', id::text) from c;
reset role;
select tests.login('admin');
select lives_ok($$ select admin_resolve_correction(tests.id('corr2'), false, 'verified', 'no') $$, 'B-11: admin rejects a correction');
select ok((select count(*) > 0 from audit_log where table_name = 'participation_evidence' and row_id = tests.txt('evi')),
  'B-11: evidence changes are audited and admin can read the audit log');
reset role;
select is((select verification_status::text from participation_evidence where id = tests.id('evi')), 'disputed',
  'B-11: rejected correction does not change evidence');
select tests.login('u');
select is((select count(*)::int from audit_log), 0, 'B-11: ordinary user cannot read the audit log');
reset role;

-- ===========================================================================
-- B-12: reports are private to the reporter and admins
-- ===========================================================================
select tests.login('u');
select lives_ok($$ insert into reports (reporter_id, target_type, target_id, reason, details)
                   values (tests.id('u'), 'user', tests.id('v'), 'harassment', 'details') $$, 'B-12: user files a report');
select throws_ok($$ insert into reports (reporter_id, target_type, target_id, reason)
                    values (tests.id('v'), 'user', tests.id('w'), 'spoof') $$, '42501', null,
  'B-12: cannot file a report in someone else''s name');
select throws_ok($$ insert into reports (reporter_id, target_type, target_id, reason, status)
                    values (tests.id('u'), 'user', tests.id('w'), 'x', 'resolved') $$, '42501', null,
  'B-12: cannot file a pre-resolved report');
select is((select count(*)::int from reports), 1, 'B-12: reporter sees own report');
reset role;
select tests.login('v');
select is((select count(*)::int from reports), 0, 'B-12: reported user cannot read the report');
select throws_ok($$ update reports set status = 'dismissed' $$, '42501', null, 'B-12: user cannot update reports');
select throws_ok($$ select admin_update_report((select id from reports limit 1), 'dismissed') $$, 'P0001', 'forbidden',
  'B-12: user cannot call admin_update_report');
reset role;
select tests.login('w');
select is((select count(*)::int from reports), 0, 'B-12: unrelated user cannot read reports');
reset role;
select tests.login('admin');
select is((select count(*)::int from reports where reporter_id::text in (select v from tests.ids)), 1, 'B-12: admin reads all reports');
reset role;

-- ===========================================================================
-- Function privileges: anon gets only the public helpers; internal helpers are not callable
-- ===========================================================================
select set_eq($$ select p.proname::text from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                 where n.nspname = 'public' and has_function_privilege('anon', p.oid, 'execute') $$,
  array['can_view_event', 'flag_enabled', 'lookup_checkin_code'], 'anon can execute only public helpers');
select ok(not has_function_privilege('authenticated', 'public.nearby_distance(uuid, uuid, uuid)', 'execute'),
  'authenticated cannot call nearby_distance (would leak positions)');
select ok(not has_function_privilege('authenticated', 'public.is_blocked(uuid, uuid)', 'execute'),
  'authenticated cannot call is_blocked');

select * from finish();
rollback;
