-- SHUAQI V0 种子数据：只用于本地和 staging，禁止在 production 执行。
--
-- 本地：`npx supabase db reset` 会在迁移后自动执行本文件（config.toml 的 [db.seed]）。
-- staging：用 psql 连 staging 库执行 `psql "$STAGING_DB_URL" -f supabase/seed.sql`（`supabase db push` 不会执行种子）。
-- 可以重复执行：固定 UUID + on conflict；每次执行都会把活动时间重新对齐到“现在”，
-- 所以 staging 上“正在进行的活动”过期后再跑一次即可。
--
-- 测试账号邮箱都在 `shuaqi-seed.<学校域名>` 子域下（命中 G5 的子域规则），没有真实收件箱。
-- 本地登录：在 /login 输入邮箱，验证码在 Mailpit（http://localhost:54324）里看。
-- staging 登录：用 service key 调 Admin API 生成验证码，不会发邮件（见 code/seed/README.md）。
--
-- 场景一览（坐标见各活动）：
--   e01 正在进行，可签到（Imperial，qr_geo，签到码 seed-live-boardgames），附近功能已有 5 人签到并在 50m 内
--   e02 今晚 3 小时后开始，签到窗口未开（outside_window），LSE 组织
--   e03 已满员（capacity 3），报名会返回 event_full
--   e04 仅本校可见（UCL）
--   e05 已取消
--   e06 草稿（只有组织成员和 admin 能看到）
--   e07 上周已结束，有到场证据（含 verified / geo_verified / 申诉中）
--   e08 人工签到（checkin_mode = manual）
--   e09–e12 下周的公开活动，填满首页
-- 附近 50m 的位置 2 分钟后失效。需要时用 postgres 执行 `select dev.simulate_nearby('e0000000-0000-4000-8000-000000000001');`
-- 刷新种子用户的位置；也可以传入你自己的坐标，让种子用户出现在你身边。

-- Supabase 预览分支把整个文件作为一批语句先全部 prepare 再执行，后面的语句会因为
-- seed_users 等临时表还不存在而失败。所以数据部分放在一个 DO 块里（作为一条语句 prepare）。

begin;

create schema if not exists dev;
revoke all on schema dev from public;

-- 刷新 e01（或任意活动）中已签到、已同意定位的种子用户的位置，围绕 (p_lat, p_lng) 分布。
-- 只有 postgres 能调用（SQL 编辑器或 psql），不经过 API 暴露。
create or replace function dev.simulate_nearby(p_event uuid,
                                               p_lat double precision default null,
                                               p_lng double precision default null)
returns int
language plpgsql security definer set search_path = '' as $$
declare
  v_lat double precision;
  v_lng double precision;
  n int;
begin
  select coalesce(p_lat, e.location_lat), coalesce(p_lng, e.location_lng) into v_lat, v_lng
    from public.events e where e.id = p_event;
  if v_lat is null then raise exception 'event has no location'; end if;
  -- 1e-4 度纬度约 11m；经度在伦敦约 7m。
  insert into public.nearby_presence (event_id, user_id, lat, lng, accuracy_m, updated_at)
  select p_event, o.id, v_lat + o.dlat, v_lng + o.dlng, o.acc, now()
  from (values
    ('a0000000-0000-4000-8000-000000000011'::uuid, 0.0001, 0.0000, 12.0),   -- alice ~11m
    ('a0000000-0000-4000-8000-000000000012'::uuid, 0.0000, 0.0003, 20.0),   -- ben ~21m
    ('a0000000-0000-4000-8000-000000000016'::uuid, -0.0002, 0.0001, 8.0),   -- fei ~24m
    ('a0000000-0000-4000-8000-000000000019'::uuid, 0.0003, -0.0003, 15.0),  -- ivy ~40m
    ('a0000000-0000-4000-8000-000000000018'::uuid, 0.0007, 0.0002, 30.0)    -- harry ~80m（不在 50m 内）
  ) as o(id, dlat, dlng, acc)
  where public.is_checked_in(p_event, o.id) and public.has_location_consent(o.id, 'nearby')
  on conflict (event_id, user_id) do update
    set lat = excluded.lat, lng = excluded.lng, accuracy_m = excluded.accuracy_m, updated_at = now();
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function dev.simulate_nearby(uuid, double precision, double precision) from public;

do $seed$
begin
  -- ---------------------------------------------------------------------------
  -- 用户（auth.users 触发器会建 profiles，并按邮件确认时间写 school_verified_at）
  -- ---------------------------------------------------------------------------
  create temp table seed_users (
    key text primary key,
    id uuid not null,
    email text not null,
    confirmed boolean not null,
    display_name text not null,
    gender text,
    birth_year int,
    region text,
    bio text,
    interests text[],
    visibility jsonb,
    role public.app_role not null default 'user'
  ) on commit drop;

  insert into seed_users (key, id, email, confirmed, display_name, gender, birth_year, region, bio, interests, visibility, role) values
    ('admin',  'a0000000-0000-4000-8000-000000000001', 'admin@shuaqi-seed.ucl.ac.uk',      true,  'SHUAQI 管理员', null, null, 'London', '平台管理员（种子账号）', '{}', null, 'admin'),
    ('owner',  'a0000000-0000-4000-8000-000000000002', 'owner@shuaqi-seed.imperial.ac.uk', true,  '王社长', 'male', 2001, 'South Kensington', 'ICL 桌游社社长', '{桌游,剧本杀,咖啡}', null, 'user'),
    ('org',    'a0000000-0000-4000-8000-000000000003', 'organiser@shuaqi-seed.imperial.ac.uk', true, '李组织', 'female', 2002, 'South Kensington', '桌游社活动负责人', '{桌游,派对}', null, 'user'),
    ('staff',  'a0000000-0000-4000-8000-000000000004', 'staff@shuaqi-seed.imperial.ac.uk', true,  '赵志愿', 'male', 2003, 'South Kensington', '桌游社志愿者，负责现场签到', '{桌游}', null, 'user'),
    ('lseorg', 'a0000000-0000-4000-8000-000000000005', 'organiser@shuaqi-seed.lse.ac.uk',  true,  'Priya (LSE)', 'female', 2000, 'Holborn', 'LSE Networking Club organiser', '{创业,咖啡}', null, 'user'),
    ('alice',  'a0000000-0000-4000-8000-000000000011', 'alice@shuaqi-seed.imperial.ac.uk', true,  'Alice 陈', 'female', 2002, 'South Kensington', '化工硕士，周末想打羽毛球', '{羽毛球,咖啡,桌游,看展}', null, 'user'),
    ('ben',    'a0000000-0000-4000-8000-000000000012', 'ben@shuaqi-seed.ucl.ac.uk',        true,  'Ben 刘', 'male', 2001, 'Bloomsbury', 'CS PhD，喜欢运动和编程', '{羽毛球,编程,篮球,桌游}', null, 'user'),
    ('chloe',  'a0000000-0000-4000-8000-000000000013', 'chloe@shuaqi-seed.lse.ac.uk',      true,  'Chloe 张', 'female', 2003, 'Holborn', '经济学本科，爱喝咖啡', '{咖啡,读书,创业}', null, 'user'),
    ('daniel', 'a0000000-0000-4000-8000-000000000014', 'daniel@shuaqi-seed.queens.ox.ac.uk', true, 'Daniel 吴', 'male', 2000, 'Oxford', '牛津 Queen''s College，徒步爱好者', '{徒步,摄影,旅行}', null, 'user'),
    ('emma',   'a0000000-0000-4000-8000-000000000015', 'emma@shuaqi-seed.cam.ac.uk',       true,  'Emma 林', 'female', 2002, 'London', '剑桥数学，周末常来伦敦', '{羽毛球,音乐,电影}', null, 'user'),
    ('fei',    'a0000000-0000-4000-8000-000000000016', 'fei@shuaqi-seed.imperial.ac.uk',   true,  '飞飞', 'non_binary', 2003, 'South Kensington', '设计工程，喜欢桌游和摄影', '{桌游,摄影,咖啡}',
               '{"bio":"public","interests":"public","photos":"connections","gender":"hidden","age":"hidden","region":"connections"}', 'user'),
    ('grace',  'a0000000-0000-4000-8000-000000000017', 'grace@shuaqi-seed.ucl.ac.uk',      true,  'Grace 周', 'female', 2001, 'Bloomsbury', '建筑学，资料只对好友公开', '{羽毛球,看展,桌游}',
               '{"bio":"connections","interests":"connections","photos":"hidden","gender":"hidden","age":"hidden","region":"hidden"}', 'user'),
    ('harry',  'a0000000-0000-4000-8000-000000000018', 'harry@shuaqi-seed.imperial.ac.uk', true,  'Harry 何', 'male', 2002, 'South Kensington', '被 Grace 拉黑、被 Ben 举报的测试账号', '{桌游,派对}', null, 'user'),
    ('ivy',    'a0000000-0000-4000-8000-000000000019', 'ivy@shuaqi-seed.imperial.ac.uk',   true,  'Ivy 孙', 'female', 2004, 'South Kensington', '本科新生，第一次来桌游社', '{桌游,音乐}', null, 'user'),
    ('unverified', 'a0000000-0000-4000-8000-000000000020', 'pending@shuaqi-seed.ucl.ac.uk', false, '', null, null, null, null, '{}', null, 'user');

  insert into auth.users (id, instance_id, aud, role, email, encrypted_password, email_confirmed_at,
                          raw_app_meta_data, raw_user_meta_data, created_at, updated_at,
                          confirmation_token, recovery_token, email_change_token_new, email_change_token_current,
                          email_change, phone_change, phone_change_token, reauthentication_token)
  select id, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', email, '',
         case when confirmed then now() - interval '14 days' end,
         '{"provider":"email","providers":["email"]}', '{}', now() - interval '14 days', now(),
         '', '', '', '', '', '', '', ''
  from seed_users
  on conflict (id) do nothing;

  insert into auth.identities (id, user_id, provider_id, provider, identity_data, last_sign_in_at, created_at, updated_at)
  select id, id, id::text, 'email',
         jsonb_build_object('sub', id::text, 'email', email, 'email_verified', confirmed, 'phone_verified', false),
         now(), now(), now()
  from seed_users
  on conflict do nothing;

  update public.profiles p
     set display_name = s.display_name,
         gender = s.gender,
         birth_year = s.birth_year,
         region = s.region,
         bio = s.bio,
         interests = s.interests,
         visibility = coalesce(s.visibility, p.visibility),
         role = s.role,
         onboarded = s.confirmed
    from seed_users s
   where p.id = s.id;

  -- ---------------------------------------------------------------------------
  -- 组织
  -- ---------------------------------------------------------------------------
  insert into public.organisations (id, name, verified) values
    ('b0000000-0000-4000-8000-000000000001', 'ICL 桌游社', true),
    ('b0000000-0000-4000-8000-000000000002', 'LSE Networking Club', true),
    ('b0000000-0000-4000-8000-000000000003', 'UCL 羽毛球俱乐部（待认证）', false)
  on conflict (id) do nothing;

  insert into public.org_members (org_id, user_id, role) values
    ('b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000002', 'owner'),
    ('b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000003', 'organiser'),
    ('b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000004', 'staff'),
    ('b0000000-0000-4000-8000-000000000002', 'a0000000-0000-4000-8000-000000000005', 'owner'),
    ('b0000000-0000-4000-8000-000000000003', 'a0000000-0000-4000-8000-000000000012', 'owner')
  on conflict do nothing;

  -- ---------------------------------------------------------------------------
  -- 活动：先按占位时间插入（events_guard 不允许插入过去的活动），再统一更新为相对“现在”的时间。
  -- 插入后触发器会生成签到码，并让主办人自动报名。
  -- 坐标：Imperial 51.4988,-0.1749；LSE 51.5144,-0.1165；UCL 51.5246,-0.1340
  -- ---------------------------------------------------------------------------
  create temp table seed_events (
    id uuid primary key,
    host text not null,
    org_id uuid,
    type public.event_type not null,
    category text not null,
    title text not null,
    description text not null,
    starts_at timestamptz not null,
    ends_at timestamptz,
    location_text text not null,
    lat double precision,
    lng double precision,
    radius int not null default 100,
    checkin_mode public.checkin_mode not null,
    require_checkin boolean not null default false,
    capacity int,
    visibility public.event_visibility not null default 'public',
    status public.event_status not null default 'published',
    code text
  ) on commit drop;

  insert into seed_events values
    ('e0000000-0000-4000-8000-000000000001', 'org', 'b0000000-0000-4000-8000-000000000001', 'group', '桌游',
     '【进行中】ICL 桌游之夜', '狼人杀、阿瓦隆、卡坦岛。到场后扫门口的二维码签到，签到后可以用“附近的人”加好友。',
     date_trunc('minute', now()) - interval '30 minutes', date_trunc('minute', now()) + interval '3 hours',
     'Imperial College Union, Beit Quad', 51.4988, -0.1749, 100, 'qr_geo', true, 40, 'public', 'published', 'seed-live-boardgames'),
    ('e0000000-0000-4000-8000-000000000002', 'lseorg', 'b0000000-0000-4000-8000-000000000002', 'group', '派对',
     'LSE 华人职场 Networking', '金融、咨询、科技行业校友分享 + 自由交流。签到在开始前 1 小时开放。',
     date_trunc('hour', now()) + interval '3 hours', date_trunc('hour', now()) + interval '6 hours',
     'LSE Marshall Building, 44 Lincoln''s Inn Fields', 51.5144, -0.1165, 150, 'qr_geo', false, 120, 'public', 'published', 'seed-lse-networking'),
    ('e0000000-0000-4000-8000-000000000003', 'alice', null, 'peer', '美食',
     '周六下午茶（已满）', '南肯一家小店，4 个人刚好一桌。',
     date_trunc('day', now()) + interval '5 days 15 hours', date_trunc('day', now()) + interval '5 days 17 hours',
     'South Kensington', 51.4941, -0.1738, 100, 'qr_geo', false, 3, 'public', 'published', null),
    ('e0000000-0000-4000-8000-000000000004', 'ben', null, 'peer', '学习',
     'UCL 期中自习小组（仅 UCL）', '图书馆三楼，互相监督，仅 UCL 同学可见。',
     date_trunc('day', now()) + interval '2 days 10 hours', date_trunc('day', now()) + interval '2 days 16 hours',
     'UCL Main Library', 51.5246, -0.1340, 100, 'qr_geo', false, 8, 'school', 'published', null),
    ('e0000000-0000-4000-8000-000000000005', 'org', 'b0000000-0000-4000-8000-000000000001', 'group', '桌游',
     '剧本杀专场（已取消）', '场地问题取消，改期另行通知。',
     date_trunc('day', now()) + interval '3 days 19 hours', date_trunc('day', now()) + interval '3 days 23 hours',
     'Imperial College Union', 51.4988, -0.1749, 100, 'qr_geo', false, 12, 'public', 'cancelled', null),
    ('e0000000-0000-4000-8000-000000000006', 'org', 'b0000000-0000-4000-8000-000000000001', 'group', '桌游',
     '新生桌游入门（草稿）', '还在定时间和场地。',
     date_trunc('day', now()) + interval '10 days 18 hours', date_trunc('day', now()) + interval '10 days 21 hours',
     'Imperial College Union', 51.4988, -0.1749, 100, 'qr_geo', false, 30, 'public', 'draft', null),
    ('e0000000-0000-4000-8000-000000000007', 'org', 'b0000000-0000-4000-8000-000000000001', 'group', '桌游',
     '上周桌游之夜', '已结束的活动，用来测试到场记录、信任卡和申诉。',
     date_trunc('day', now()) - interval '7 days' + interval '19 hours', date_trunc('day', now()) - interval '7 days' + interval '22 hours',
     'Imperial College Union, Beit Quad', 51.4988, -0.1749, 100, 'qr_geo', false, 40, 'public', 'ended', 'seed-past-boardgames'),
    ('e0000000-0000-4000-8000-000000000008', 'chloe', null, 'peer', '学习',
     '读书会：《思考，快与慢》', '人工签到：到场后由发起人确认。',
     date_trunc('day', now()) + interval '4 days 18 hours', date_trunc('day', now()) + interval '4 days 20 hours',
     'LSE Library 咖啡区', 51.5144, -0.1165, 100, 'manual', false, 10, 'public', 'published', null),
    ('e0000000-0000-4000-8000-000000000009', 'ben', 'b0000000-0000-4000-8000-000000000003', 'group', '运动',
     '周日羽毛球双打', '自带球拍，场地费平摊约 £6。',
     date_trunc('day', now()) + interval '7 days 14 hours', date_trunc('day', now()) + interval '7 days 16 hours',
     'Bloomsbury Fitness Centre', 51.5226, -0.1310, 100, 'qr_geo', false, 16, 'public', 'published', null),
    ('e0000000-0000-4000-8000-000000000010', 'daniel', null, 'peer', '户外',
     'Chiltern Hills 徒步 15km', '早上从 Marylebone 出发，中级难度。',
     date_trunc('day', now()) + interval '8 days 8 hours', date_trunc('day', now()) + interval '8 days 17 hours',
     'Marylebone Station', 51.5225, -0.1631, 200, 'qr_geo', false, 12, 'public', 'published', null),
    ('e0000000-0000-4000-8000-000000000011', 'emma', null, 'peer', '音乐',
     'Southbank 爵士夜', '一起去听免费的周五爵士演出。',
     date_trunc('day', now()) + interval '6 days 20 hours', date_trunc('day', now()) + interval '6 days 23 hours',
     'Southbank Centre', 51.5069, -0.1167, 100, 'qr_geo', false, null, 'public', 'published', null),
    ('e0000000-0000-4000-8000-000000000012', 'fei', null, 'peer', '美食',
     '唐人街火锅局', '人均 £25 左右，吃完可以续桌游。',
     date_trunc('day', now()) + interval '9 days 19 hours', date_trunc('day', now()) + interval '9 days 22 hours',
     'Chinatown, Gerrard Street', 51.5115, -0.1318, 100, 'qr_geo', false, 6, 'public', 'published', null);

  insert into public.events (id, host_user_id, org_id, type, category, title, description, starts_at, ends_at,
                             location_text, location_lat, location_lng, checkin_radius_m, checkin_mode,
                             require_checkin_for_connect, capacity, visibility, status)
  select e.id, u.id, e.org_id, e.type, e.category, e.title, e.description,
         now() + interval '30 days', now() + interval '30 days 3 hours',
         e.location_text, e.lat, e.lng, e.radius, e.checkin_mode, e.require_checkin, e.capacity, e.visibility, 'published'
  from seed_events e join seed_users u on u.key = e.host
  on conflict (id) do nothing;

  update public.events ev
     set starts_at = e.starts_at, ends_at = e.ends_at, status = e.status,
         checkin_opens_at = null, checkin_closes_at = null
    from seed_events e
   where ev.id = e.id;

  -- 固定签到码，方便打印测试二维码：${origin}/checkin/<code>
  update public.event_checkin_codes c set code = e.code, rotated_at = now()
    from seed_events e
   where c.event_id = e.id and e.code is not null and c.code <> e.code;

  -- ---------------------------------------------------------------------------
  -- 报名（主办人已由触发器自动报名；种子直接写表，人数按容量控制）
  -- ---------------------------------------------------------------------------
  insert into public.event_rsvps (event_id, user_id, status, created_at)
  select ('e0000000-0000-4000-8000-0000000000' || r.ev)::uuid, u.id, r.status::public.rsvp_status, now() - interval '2 days'
  from (values
    ('01', 'alice', 'going'), ('01', 'ben', 'going'), ('01', 'fei', 'going'), ('01', 'grace', 'going'),
    ('01', 'harry', 'going'), ('01', 'ivy', 'going'), ('01', 'emma', 'going'), ('01', 'chloe', 'cancelled'),
    ('02', 'chloe', 'going'), ('02', 'alice', 'going'), ('02', 'daniel', 'going'),
    ('03', 'fei', 'going'), ('03', 'grace', 'going'),
    ('04', 'grace', 'going'),
    ('05', 'alice', 'going'), ('05', 'ivy', 'going'),
    ('07', 'alice', 'going'), ('07', 'ben', 'going'), ('07', 'fei', 'going'), ('07', 'daniel', 'going'), ('07', 'harry', 'going'),
    ('08', 'emma', 'going'),
    ('09', 'alice', 'going'), ('09', 'emma', 'going'), ('09', 'grace', 'going'),
    ('10', 'emma', 'going'),
    ('11', 'chloe', 'going'), ('11', 'fei', 'going'),
    ('12', 'alice', 'going'), ('12', 'ivy', 'going')
  ) as r(ev, who, status)
  join seed_users u on u.key = r.who
  on conflict (event_id, user_id) do update set status = excluded.status;

  -- 活动内发现（Opt-in）：e01 中 fei、grace 不公开，用来测试参与者列表过滤
  insert into public.event_social_optin (event_id, user_id, opted_in, visible_fields)
  select 'e0000000-0000-4000-8000-000000000001', u.id, o.opted_in, o.fields
  from (values
    ('alice', true, '{interests,bio}'::text[]), ('ben', true, '{interests}'::text[]), ('ivy', true, '{interests,bio}'::text[]),
    ('emma', true, '{interests}'::text[]), ('harry', true, '{interests}'::text[]), ('fei', false, '{interests}'::text[])
  ) as o(who, opted_in, fields)
  join seed_users u on u.key = o.who
  on conflict (event_id, user_id) do update set opted_in = excluded.opted_in, visible_fields = excluded.visible_fields;

  -- ---------------------------------------------------------------------------
  -- 到场证据
  -- e01：alice、ben、fei、harry、ivy 已扫码签到（geo_verified），staff 已人工确认 alice（verified）；
  --      grace、emma 已报名未签到（用来测试签到流程和 checkin_required）。
  -- e07：上周活动，留下 verified / geo_verified 记录；daniel 的记录申诉中。
  -- ---------------------------------------------------------------------------
  insert into public.participation_evidence
    (event_id, subject_user_id, type, source, operator_id, verification_status, geo_distance_m, geo_accuracy_m, occurred_at)
  select ('e0000000-0000-4000-8000-0000000000' || x.ev)::uuid, u.id, x.type::public.evidence_type, x.source::public.evidence_source,
         case when x.source = 'organiser_manual' then st.id else u.id end,
         x.status::public.verification_status, x.dist, x.acc,
         case when x.ev = '01' then now() - interval '20 minutes'
              else date_trunc('day', now()) - interval '7 days' + interval '19 hours 15 minutes' end
  from (values
    ('01', 'alice', 'self_reported_presence', 'qr_geo', 'geo_verified', 18.0, 12.0),
    ('01', 'ben',   'self_reported_presence', 'qr_geo', 'geo_verified', 25.0, 20.0),
    ('01', 'fei',   'self_reported_presence', 'qr_geo', 'geo_verified', 9.0, 8.0),
    ('01', 'harry', 'self_reported_presence', 'qr_geo', 'geo_verified', 40.0, 35.0),
    ('01', 'ivy',   'self_reported_presence', 'qr_geo', 'geo_verified', 30.0, 15.0),
    ('01', 'alice', 'organiser_confirmed_attendance', 'organiser_manual', 'verified', null, null),
    ('07', 'alice', 'self_reported_presence', 'qr_geo', 'geo_verified', 12.0, 10.0),
    ('07', 'alice', 'organiser_confirmed_attendance', 'organiser_manual', 'verified', null, null),
    ('07', 'ben',   'self_reported_presence', 'qr_geo', 'geo_verified', 22.0, 18.0),
    ('07', 'ben',   'organiser_confirmed_attendance', 'organiser_manual', 'verified', null, null),
    ('07', 'fei',   'self_reported_presence', 'qr_geo', 'geo_verified', 35.0, 25.0),
    ('07', 'daniel','self_reported_presence', 'qr_geo', 'disputed', 95.0, 80.0)
  ) as x(ev, who, type, source, status, dist, acc)
  join seed_users u on u.key = x.who
  join seed_users st on st.key = 'staff'
  on conflict do nothing;

  insert into public.evidence_corrections (id, evidence_id, requested_by, reason, status, created_at)
  select 'c0000000-0000-4000-8000-000000000001', pe.id, pe.subject_user_id,
         '我当晚在场，只是室内定位偏了，主办方可以作证。', 'pending', now() - interval '5 days'
  from public.participation_evidence pe
  where pe.event_id = 'e0000000-0000-4000-8000-000000000007'
    and pe.subject_user_id = 'a0000000-0000-4000-8000-000000000014'
    and pe.type = 'self_reported_presence'
  on conflict (id) do nothing;

  -- ---------------------------------------------------------------------------
  -- 附近 50m：e01 已签到的人同意定位并上报位置（Beit Quad 周围 10–40m；harry 在 ~80m 外，不应出现）
  -- ---------------------------------------------------------------------------
  insert into public.location_consents (user_id, purpose, policy_version, granted_at)
  select u.id, 'nearby', 'seed-2026-10', now() - interval '1 day'
  from seed_users u where u.key in ('alice', 'ben', 'fei', 'harry', 'ivy')
  on conflict (user_id, purpose) do update set withdrawn_at = null;

  perform dev.simulate_nearby('e0000000-0000-4000-8000-000000000001');

  -- ---------------------------------------------------------------------------
  -- 连接：alice–ben 已是好友；chloe→alice 待处理；harry→emma 被拒；ivy→fei 待处理（附近 50m 场景）
  -- grace 拉黑 harry
  -- ---------------------------------------------------------------------------
  insert into public.connection_requests (id, from_user, to_user, context, context_id, message, status, created_at, responded_at) values
    ('d0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000011', 'a0000000-0000-4000-8000-000000000012',
     'event', 'e0000000-0000-4000-8000-000000000007', '上周一起玩阿瓦隆的！', 'accepted', now() - interval '6 days', now() - interval '6 days'),
    ('d0000000-0000-4000-8000-000000000002', 'a0000000-0000-4000-8000-000000000013', 'a0000000-0000-4000-8000-000000000011',
     'event', 'e0000000-0000-4000-8000-000000000002', '今晚 networking 见？', 'pending', now() - interval '3 hours', null),
    ('d0000000-0000-4000-8000-000000000003', 'a0000000-0000-4000-8000-000000000018', 'a0000000-0000-4000-8000-000000000015',
     'event', 'e0000000-0000-4000-8000-000000000001', null, 'declined', now() - interval '2 days', now() - interval '2 days'),
    ('d0000000-0000-4000-8000-000000000004', 'a0000000-0000-4000-8000-000000000019', 'a0000000-0000-4000-8000-000000000016',
     'nearby', 'e0000000-0000-4000-8000-000000000001', '刚才同桌的～', 'pending', now() - interval '10 minutes', null)
  on conflict (id) do nothing;

  insert into public.connections (user_a, user_b, source_request_id, created_at) values
    ('a0000000-0000-4000-8000-000000000011', 'a0000000-0000-4000-8000-000000000012', 'd0000000-0000-4000-8000-000000000001', now() - interval '6 days')
  on conflict do nothing;

  insert into public.blocks (blocker_id, blocked_id) values
    ('a0000000-0000-4000-8000-000000000017', 'a0000000-0000-4000-8000-000000000018')
  on conflict do nothing;

  -- ---------------------------------------------------------------------------
  -- 找搭子
  -- 已完成：chloe 和 fei 上周喝咖啡，双方都确认见面 → 两条 mutually_reported_interaction
  -- 已确认：alice 和 ben 后天打羽毛球（shared plan confirmed）
  -- 待回应：emma → grace 的羽毛球邀请
  -- 无匹配：daniel 的徒步需求
  -- ---------------------------------------------------------------------------
  insert into public.intents (id, user_id, activity_type, window_start, window_end, region, group_size, budget_max, note, expires_at, status, created_at)
  select x.id::uuid, u.id, x.act, x.ws, x.we, x.region, x.size, x.budget, x.note, x.we, x.status::public.intent_status, x.ws - interval '3 days'
  from (values
    ('f0000000-0000-4000-8000-000000000001', 'chloe', '咖啡', date_trunc('day', now()) - interval '6 days' + interval '14 hours', date_trunc('day', now()) - interval '6 days' + interval '17 hours', 'Holborn', 2, 10, '想找人一起试新开的咖啡店', 'matched'),
    ('f0000000-0000-4000-8000-000000000002', 'fei',   '咖啡', date_trunc('day', now()) - interval '6 days' + interval '15 hours', date_trunc('day', now()) - interval '6 days' + interval '18 hours', '', 2, null, '', 'matched'),
    ('f0000000-0000-4000-8000-000000000003', 'alice', '羽毛球', date_trunc('day', now()) + interval '2 days 13 hours', date_trunc('day', now()) + interval '2 days 17 hours', 'London', 2, 15, '中级水平，自带拍', 'matched'),
    ('f0000000-0000-4000-8000-000000000004', 'ben',   '羽毛球', date_trunc('day', now()) + interval '2 days 14 hours', date_trunc('day', now()) + interval '2 days 18 hours', 'London', 2, 20, '', 'matched'),
    ('f0000000-0000-4000-8000-000000000005', 'emma',  '羽毛球', date_trunc('day', now()) + interval '3 days 10 hours', date_trunc('day', now()) + interval '3 days 14 hours', 'London', 2, null, '周末来伦敦，找人打两小时', 'open'),
    ('f0000000-0000-4000-8000-000000000006', 'grace', '羽毛球', date_trunc('day', now()) + interval '3 days 12 hours', date_trunc('day', now()) + interval '3 days 16 hours', '', 4, 10, '可以凑双打', 'open'),
    ('f0000000-0000-4000-8000-000000000007', 'daniel','徒步', date_trunc('day', now()) + interval '12 days 8 hours', date_trunc('day', now()) + interval '12 days 18 hours', 'Oxford', 3, null, 'Cotswolds 方向', 'open'),
    ('f0000000-0000-4000-8000-000000000008', 'ivy',   '看展', date_trunc('day', now()) + interval '1 day 11 hours', date_trunc('day', now()) + interval '1 day 17 hours', 'South Kensington', 2, 0, 'V&A 或自然史博物馆', 'open')
  ) as x(id, who, act, ws, we, region, size, budget, note, status)
  join seed_users u on u.key = x.who
  on conflict (id) do update
    set window_start = excluded.window_start, window_end = excluded.window_end, expires_at = excluded.expires_at;

  insert into public.match_invitations (id, from_intent_id, to_intent_id, from_user, to_user, message, status, created_at, responded_at) values
    ('f1000000-0000-4000-8000-000000000001', 'f0000000-0000-4000-8000-000000000001', 'f0000000-0000-4000-8000-000000000002',
     'a0000000-0000-4000-8000-000000000013', 'a0000000-0000-4000-8000-000000000016', '一起去 Holborn 那家？', 'accepted', now() - interval '8 days', now() - interval '8 days'),
    ('f1000000-0000-4000-8000-000000000002', 'f0000000-0000-4000-8000-000000000003', 'f0000000-0000-4000-8000-000000000004',
     'a0000000-0000-4000-8000-000000000011', 'a0000000-0000-4000-8000-000000000012', '老地方打球？', 'accepted', now() - interval '1 day', now() - interval '1 day'),
    ('f1000000-0000-4000-8000-000000000003', 'f0000000-0000-4000-8000-000000000005', 'f0000000-0000-4000-8000-000000000006',
     'a0000000-0000-4000-8000-000000000015', 'a0000000-0000-4000-8000-000000000017', '我周六中午有空～', 'pending', now() - interval '2 hours', null)
  on conflict (id) do nothing;

  insert into public.shared_plans (id, invitation_id, user_a, user_b, title, planned_at, place, status,
                                   a_confirmed_at, b_confirmed_at, a_met_at, b_met_at, created_at) values
    ('f2000000-0000-4000-8000-000000000001', 'f1000000-0000-4000-8000-000000000001',
     'a0000000-0000-4000-8000-000000000013', 'a0000000-0000-4000-8000-000000000016', '咖啡',
     date_trunc('day', now()) - interval '6 days' + interval '15 hours', 'Holborn, Fleet Street 一带', 'confirmed',
     now() - interval '7 days', now() - interval '7 days', now() - interval '6 days', now() - interval '6 days', now() - interval '8 days'),
    ('f2000000-0000-4000-8000-000000000002', 'f1000000-0000-4000-8000-000000000002',
     'a0000000-0000-4000-8000-000000000011', 'a0000000-0000-4000-8000-000000000012', '羽毛球',
     date_trunc('day', now()) + interval '2 days 14 hours', 'Ethos Sports Centre (Imperial)', 'confirmed',
     now() - interval '20 hours', now() - interval '18 hours', null, null, now() - interval '1 day')
  on conflict (id) do update set planned_at = excluded.planned_at;

  insert into public.participation_evidence (shared_plan_id, subject_user_id, type, source, verification_status, occurred_at)
  select 'f2000000-0000-4000-8000-000000000001', u, 'mutually_reported_interaction', 'mutual_report', 'verified',
         now() - interval '6 days'
  from unnest(array['a0000000-0000-4000-8000-000000000013', 'a0000000-0000-4000-8000-000000000016']::uuid[]) as u
  on conflict do nothing;

  -- ---------------------------------------------------------------------------
  -- 举报：ben 举报 harry（待处理）；alice 举报一个活动（已由 admin 处理）
  -- ---------------------------------------------------------------------------
  insert into public.reports (id, reporter_id, target_type, target_id, reason, details, status, handled_by, handled_at, admin_note, created_at) values
    ('90000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000012', 'user', 'a0000000-0000-4000-8000-000000000018',
     '骚扰', '活动结束后反复私信要联系方式。', 'open', null, null, null, now() - interval '1 day'),
    ('90000000-0000-4000-8000-000000000002', 'a0000000-0000-4000-8000-000000000011', 'event', 'e0000000-0000-4000-8000-000000000005',
     '虚假信息', '活动地点写错了。', 'resolved', 'a0000000-0000-4000-8000-000000000001', now() - interval '12 hours',
     '已联系主办方，活动已取消。', now() - interval '2 days')
  on conflict (id) do nothing;

end $seed$;

commit;
