-- Web push notifications for the PWA: new chat messages, friend requests, buddy matches, and a
-- reminder before events the user is going to.
--
-- Flow: database triggers write rows to push_outbox (only for users who switched notifications on
-- for that category and have at least one device subscribed). A statement trigger asks the app to
-- deliver them right away (pg_net → POST /api/push/dispatch), and a pg_cron job every minute adds
-- event reminders and retries anything left over. The app claims rows with claim_push_batch(),
-- encrypts and sends them with the VAPID keys (server-only env vars), then reports back with
-- complete_push_batch(), which also drops subscriptions the push service says are gone.
--
-- Per environment (not schema, so not in this file): enable pg_net and pg_cron, and store the
-- dispatch URL and secret in Vault; see docs/push-notifications.md. Without them nothing is sent
-- and nothing else breaks.

insert into public.feature_flags (key, description)
values ('push', 'Web push notifications (messages, friend requests, buddy matches, event reminders)')
on conflict (key) do nothing;

-- ---------------------------------------------------------------------------
-- Tables
-- ---------------------------------------------------------------------------
-- One row per browser/device that allowed notifications. The endpoint identifies the device; if
-- another account signs in on the same device and subscribes, the row moves to that account.
create table public.push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  endpoint text not null unique check (char_length(endpoint) <= 1000 and endpoint like 'https://%'),
  p256dh text not null check (char_length(p256dh) between 1 and 200),
  auth text not null check (char_length(auth) between 1 and 100),
  user_agent text not null default '' check (char_length(user_agent) <= 300),
  created_at timestamptz not null default now(),
  last_success_at timestamptz
);
create index on public.push_subscriptions (user_id);

-- Which kinds of notification a user wants, for all their devices. No row means all on.
create table public.notification_preferences (
  user_id uuid primary key references public.profiles (id) on delete cascade,
  message boolean not null default true,
  friend_request boolean not null default true,
  buddy boolean not null default true,
  event_reminder boolean not null default true,
  updated_at timestamptz not null default now()
);
create trigger notification_preferences_updated_at before update on public.notification_preferences
  for each row execute function public.set_updated_at();

create table public.push_outbox (
  id bigint generated always as identity primary key,
  user_id uuid not null references public.profiles (id) on delete cascade,
  category text not null check (category in ('message', 'friend_request', 'buddy', 'event_reminder', 'test')),
  -- {title, body, url, tag, count}
  payload jsonb not null,
  -- Pending rows with the same key are merged (several messages in one chat become one notification).
  collapse_key text,
  -- A key that is never enqueued twice for the same user (one reminder per event).
  dedupe_key text,
  status text not null default 'pending' check (status in ('pending', 'sending', 'sent', 'failed', 'skipped')),
  attempts int not null default 0,
  created_at timestamptz not null default now(),
  claimed_at timestamptz,
  sent_at timestamptz
);
create unique index push_outbox_collapse on public.push_outbox (user_id, collapse_key)
  where status = 'pending' and collapse_key is not null;
create unique index push_outbox_dedupe on public.push_outbox (user_id, dedupe_key) where dedupe_key is not null;
create index on public.push_outbox (status, created_at);
create index on public.push_outbox (created_at);

-- No direct access: users go through the functions below, the dispatcher uses the service role.
alter table public.push_subscriptions enable row level security;
alter table public.notification_preferences enable row level security;
alter table public.push_outbox enable row level security;
revoke all on public.push_subscriptions, public.notification_preferences, public.push_outbox from anon, authenticated;

-- ---------------------------------------------------------------------------
-- Enqueueing
-- ---------------------------------------------------------------------------
create or replace function public.push_wanted(p_user uuid, p_category text) returns boolean
language sql stable security definer set search_path = '' as $$
  select public.flag_enabled('push')
     and exists (select 1 from public.push_subscriptions where user_id = p_user)
     and coalesce((select case p_category
                            when 'message' then p.message
                            when 'friend_request' then p.friend_request
                            when 'buddy' then p.buddy
                            when 'event_reminder' then p.event_reminder
                            else true end
                    from public.notification_preferences p where p.user_id = p_user), true)
$$;

create or replace function public.push_enqueue(p_user uuid, p_category text, p_title text, p_body text, p_url text,
                                               p_collapse_key text default null, p_dedupe_key text default null)
returns void
language plpgsql security definer set search_path = '' as $$
declare
  v_payload jsonb := jsonb_build_object('title', left(p_title, 80), 'body', left(coalesce(p_body, ''), 200),
                                        'url', p_url, 'tag', coalesce(p_collapse_key, p_dedupe_key, p_category), 'count', 1);
begin
  if p_user is null or not public.push_wanted(p_user, p_category) then return; end if;
  if p_dedupe_key is not null then
    insert into public.push_outbox (user_id, category, payload, dedupe_key)
    values (p_user, p_category, v_payload, p_dedupe_key)
    on conflict (user_id, dedupe_key) where dedupe_key is not null do nothing;
  elsif p_collapse_key is not null then
    insert into public.push_outbox (user_id, category, payload, collapse_key)
    values (p_user, p_category, v_payload, p_collapse_key)
    on conflict (user_id, collapse_key) where status = 'pending' and collapse_key is not null
    do update set payload = excluded.payload
                    || jsonb_build_object('count', coalesce((public.push_outbox.payload->>'count')::int, 1) + 1),
                  created_at = now();
  else
    insert into public.push_outbox (user_id, category, payload) values (p_user, p_category, v_payload);
  end if;
end $$;

create or replace function public.push_name(p_user uuid) returns text
language sql stable security definer set search_path = '' as $$
  select coalesce(nullif(trim((select display_name from public.profiles where id = p_user)), ''), '有人')
$$;

-- London time, as the app shows it.
create or replace function public.push_time(p_at timestamptz) returns text
language sql stable set search_path = '' as $$
  select to_char(p_at at time zone 'Europe/London', 'FMMM月FMDD日 HH24:MI')
$$;

-- Triggers never block the write that fired them: a failure here only loses the notification.
create or replace function public.push_on_message() returns trigger
language plpgsql security definer set search_path = '' as $$
declare
  c public.conversations;
begin
  select * into c from public.conversations where id = new.conversation_id;
  perform public.push_enqueue(case when c.user_a = new.sender_id then c.user_b else c.user_a end, 'message',
    public.push_name(new.sender_id), new.body, '/messages/' || new.sender_id, 'msg:' || new.conversation_id);
  return null;
exception when others then
  raise warning 'push_on_message: %', sqlerrm;
  return null;
end $$;
create trigger messages_push after insert on public.messages
  for each row execute function public.push_on_message();

create or replace function public.push_on_connection_request() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'INSERT' and new.status = 'pending' then
    perform public.push_enqueue(new.to_user, 'friend_request', '新的好友请求',
      public.push_name(new.from_user) || ' 想加你为好友' || coalesce('：' || new.message, ''),
      '/me/requests', 'friend-request:' || new.from_user);
  elsif tg_op = 'UPDATE' and old.status = 'pending' and new.status = 'accepted' then
    perform public.push_enqueue(new.from_user, 'friend_request', '好友请求已通过',
      public.push_name(new.to_user) || ' 通过了你的好友请求', '/u/' || new.to_user, 'friend-accepted:' || new.to_user);
  end if;
  return null;
exception when others then
  raise warning 'push_on_connection_request: %', sqlerrm;
  return null;
end $$;
create trigger connection_requests_push after insert or update of status on public.connection_requests
  for each row execute function public.push_on_connection_request();

create or replace function public.push_on_match_invitation() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if new.status = 'pending' then
    perform public.push_enqueue(new.to_user, 'buddy', '有人想和你搭子',
      public.push_name(new.from_user) || ' 邀请你一起「'
        || (select activity_type from public.intents where id = new.from_intent_id) || '」'
        || coalesce('：' || new.message, ''),
      '/buddy', 'buddy-invite:' || new.id);
  end if;
  return null;
exception when others then
  raise warning 'push_on_match_invitation: %', sqlerrm;
  return null;
end $$;
create trigger match_invitations_push after insert on public.match_invitations
  for each row execute function public.push_on_match_invitation();

-- A shared plan is created when an invitation is accepted (user_a sent it): tell the sender.
-- When both people have confirmed the time and place: tell the one who did not confirm last.
create or replace function public.push_on_shared_plan() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'INSERT' then
    perform public.push_enqueue(new.user_a, 'buddy', '搭子匹配成功',
      public.push_name(new.user_b) || ' 接受了你的「' || new.title || '」邀请，去定时间和地点吧',
      '/buddy/plans/' || new.id, 'buddy-plan:' || new.id);
  elsif old.status <> 'confirmed' and new.status = 'confirmed' then
    perform public.push_enqueue(u, 'buddy', '搭子计划已确定',
      '「' || new.title || '」' || coalesce(public.push_time(new.planned_at), '')
        || coalesce(' · ' || nullif(new.place, ''), ''),
      '/buddy/plans/' || new.id, 'buddy-plan:' || new.id)
    from unnest(array[new.user_a, new.user_b]) u
    where u is distinct from auth.uid();
  end if;
  return null;
exception when others then
  raise warning 'push_on_shared_plan: %', sqlerrm;
  return null;
end $$;
create trigger shared_plans_push after insert or update of status on public.shared_plans
  for each row execute function public.push_on_shared_plan();

-- About an hour before an event starts, everyone going gets one reminder.
-- Runs every minute from pg_cron (push_tick); the dedupe key stops repeats.
create or replace function public.enqueue_event_reminders() returns int
language plpgsql security definer set search_path = '' as $$
declare
  r record;
  n int := 0;
begin
  if not public.flag_enabled('push') then return 0; end if;
  for r in
    select e.id, e.title, e.starts_at, e.location_text, v.user_id
      from public.events e
      join public.event_rsvps v on v.event_id = e.id and v.status = 'going'
     where e.status = 'published'
       and e.starts_at > now() + interval '10 minutes'
       and e.starts_at <= now() + interval '60 minutes'
  loop
    perform public.push_enqueue(r.user_id, 'event_reminder', '活动快开始了',
      '「' || r.title || '」' || to_char(r.starts_at at time zone 'Europe/London', 'HH24:MI') || ' 开始'
        || coalesce(' · ' || nullif(r.location_text, ''), ''),
      '/events/' || r.id, null, 'event-reminder:' || r.id);
    n := n + 1;
  end loop;
  return n;
end $$;

-- ---------------------------------------------------------------------------
-- Waking the dispatcher
-- ---------------------------------------------------------------------------
-- POSTs to the app's /api/push/dispatch with the shared secret, both read from Vault. Does nothing
-- until pg_net is enabled and both secrets exist. pg_net sends after the transaction commits.
create or replace function public.push_kick() returns void
language plpgsql security definer set search_path = '' as $$
declare
  v_url text;
  v_secret text;
begin
  if not exists (select 1 from pg_extension where extname = 'pg_net')
     or to_regclass('vault.decrypted_secrets') is null then
    return;
  end if;
  execute 'select decrypted_secret from vault.decrypted_secrets where name = $1' into v_url using 'push_dispatch_url';
  execute 'select decrypted_secret from vault.decrypted_secrets where name = $1' into v_secret using 'push_dispatch_secret';
  if v_url is null or v_secret is null then return; end if;
  execute 'select net.http_post(url := $1, body := $2, headers := $3, timeout_milliseconds := 10000)'
    using v_url, '{}'::jsonb,
          jsonb_build_object('Content-Type', 'application/json', 'Authorization', 'Bearer ' || v_secret);
exception when others then
  raise warning 'push_kick: %', sqlerrm;
end $$;

create or replace function public.push_outbox_kick() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  perform public.push_kick();
  return null;
end $$;
create trigger push_outbox_kick after insert on public.push_outbox
  for each statement execute function public.push_outbox_kick();

-- Every minute: queue event reminders, retry what is left, and clear old rows.
create or replace function public.push_tick() returns void
language plpgsql security definer set search_path = '' as $$
begin
  perform public.enqueue_event_reminders();
  delete from public.push_outbox where created_at < now() - interval '7 days';
  if exists (select 1 from public.push_outbox where status in ('pending', 'sending')) then
    perform public.push_kick();
  end if;
end $$;

-- Re-run after enabling pg_cron on a project: select public.schedule_push_jobs();
create or replace function public.schedule_push_jobs() returns boolean
language plpgsql security definer set search_path = '' as $$
begin
  if not exists (select 1 from pg_extension where extname = 'pg_cron') then return false; end if;
  execute $q$select cron.unschedule(jobid) from cron.job where jobname = 'push_tick'$q$;
  execute $q$select cron.schedule('push_tick', '* * * * *', 'select public.push_tick()')$q$;
  return true;
end $$;
select public.schedule_push_jobs();

-- ---------------------------------------------------------------------------
-- Dispatcher (service role only)
-- ---------------------------------------------------------------------------
-- Claims up to p_limit rows with the devices to send them to. A row stuck in 'sending' for two
-- minutes (dispatcher crashed) is claimed again; anything older than 6 hours is dropped as stale.
create or replace function public.claim_push_batch(p_limit int default 100)
returns table (id bigint, payload jsonb, subscriptions jsonb)
language plpgsql security definer set search_path = '' as $$
begin
  update public.push_outbox o set status = 'skipped'
   where o.status in ('pending', 'sending')
     and (o.created_at < now() - interval '6 hours' or not public.flag_enabled('push'));
  update public.push_outbox o set status = 'failed'
   where o.status = 'sending' and o.claimed_at < now() - interval '2 minutes' and o.attempts >= 3;

  return query
  with c as (
    select o.id from public.push_outbox o
     where o.status = 'pending' or (o.status = 'sending' and o.claimed_at < now() - interval '2 minutes')
     order by o.created_at
     limit least(greatest(coalesce(p_limit, 100), 1), 500)
     for update skip locked
  ), u as (
    update public.push_outbox o
       set status = 'sending', claimed_at = now(), attempts = o.attempts + 1
      from c where o.id = c.id
    returning o.id, o.user_id, o.payload
  )
  select u.id, u.payload,
         coalesce((select jsonb_agg(jsonb_build_object('endpoint', s.endpoint, 'p256dh', s.p256dh, 'auth', s.auth))
                     from public.push_subscriptions s where s.user_id = u.user_id), '[]'::jsonb)
    from u;
end $$;

-- p_done: delivered (or nothing to deliver to). p_retry: try again later (up to 3 attempts).
-- p_gone: endpoints the push service rejected for good (404/410). p_ok: endpoints that accepted.
create or replace function public.complete_push_batch(p_done bigint[], p_retry bigint[], p_gone text[], p_ok text[])
returns void
language plpgsql security definer set search_path = '' as $$
begin
  update public.push_outbox set status = 'sent', sent_at = now()
   where id = any(coalesce(p_done, '{}')) and status = 'sending';
  update public.push_outbox set status = case when attempts >= 3 then 'failed' else 'pending' end
   where id = any(coalesce(p_retry, '{}')) and status = 'sending';
  delete from public.push_subscriptions where endpoint = any(coalesce(p_gone, '{}'));
  update public.push_subscriptions set last_success_at = now() where endpoint = any(coalesce(p_ok, '{}'));
end $$;

-- ---------------------------------------------------------------------------
-- Functions for the app
-- ---------------------------------------------------------------------------
-- Registers this device for the signed-in user. Keeps the 10 most recent devices per user.
create or replace function public.save_push_subscription(p_endpoint text, p_p256dh text, p_auth text,
                                                         p_user_agent text default '')
returns void
language plpgsql security definer set search_path = '' as $$
declare
  v_me uuid := auth.uid();
begin
  if v_me is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  if not public.flag_enabled('push') then raise exception 'feature_disabled' using errcode = 'P0001'; end if;
  if p_endpoint is null or p_endpoint not like 'https://%' or char_length(p_endpoint) > 1000
     or coalesce(p_p256dh, '') = '' or coalesce(p_auth, '') = '' then
    raise exception 'invalid_subscription' using errcode = 'P0001';
  end if;
  insert into public.push_subscriptions (user_id, endpoint, p256dh, auth, user_agent)
  values (v_me, p_endpoint, left(p_p256dh, 200), left(p_auth, 100), left(coalesce(p_user_agent, ''), 300))
  on conflict (endpoint) do update
    set user_id = excluded.user_id, p256dh = excluded.p256dh, auth = excluded.auth,
        user_agent = excluded.user_agent,
        created_at = case when public.push_subscriptions.user_id = excluded.user_id
                          then public.push_subscriptions.created_at else now() end;
  delete from public.push_subscriptions
   where user_id = v_me
     and id not in (select id from public.push_subscriptions where user_id = v_me order by created_at desc limit 10);
end $$;

-- Only removes the caller's own device.
create or replace function public.delete_push_subscription(p_endpoint text) returns void
language sql security definer set search_path = '' as $$
  delete from public.push_subscriptions where endpoint = p_endpoint and user_id = auth.uid()
$$;

-- Whether this device is registered for the signed-in user.
create or replace function public.has_push_subscription(p_endpoint text) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.push_subscriptions where endpoint = p_endpoint and user_id = auth.uid())
$$;

create or replace function public.my_notification_preferences() returns jsonb
language sql stable security definer set search_path = '' as $$
  select jsonb_build_object(
    'message', coalesce(p.message, true), 'friend_request', coalesce(p.friend_request, true),
    'buddy', coalesce(p.buddy, true), 'event_reminder', coalesce(p.event_reminder, true))
  from (select auth.uid() as uid) me
  left join public.notification_preferences p on p.user_id = me.uid
  where me.uid is not null
$$;

create or replace function public.set_notification_preference(p_category text, p_enabled boolean) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  v_me uuid := auth.uid();
begin
  if v_me is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  if p_category not in ('message', 'friend_request', 'buddy', 'event_reminder') or p_enabled is null then
    raise exception 'invalid_category' using errcode = 'P0001';
  end if;
  insert into public.notification_preferences (user_id) values (v_me) on conflict (user_id) do nothing;
  update public.notification_preferences
     set message = case when p_category = 'message' then p_enabled else message end,
         friend_request = case when p_category = 'friend_request' then p_enabled else friend_request end,
         buddy = case when p_category = 'buddy' then p_enabled else buddy end,
         event_reminder = case when p_category = 'event_reminder' then p_enabled else event_reminder end
   where user_id = v_me;
  return public.my_notification_preferences();
end $$;

-- Sends a test notification to all of the caller's devices, at most once a minute.
create or replace function public.send_test_push() returns boolean
language plpgsql security definer set search_path = '' as $$
declare
  v_me uuid := auth.uid();
begin
  if v_me is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  if not public.flag_enabled('push') then raise exception 'feature_disabled' using errcode = 'P0001'; end if;
  if not exists (select 1 from public.push_subscriptions where user_id = v_me) then
    raise exception 'push_not_subscribed' using errcode = 'P0001';
  end if;
  if exists (select 1 from public.push_outbox
              where user_id = v_me and category = 'test' and created_at > now() - interval '1 minute') then
    raise exception 'rate_limited' using errcode = 'P0001';
  end if;
  perform public.push_enqueue(v_me, 'test', 'SHUAQI 通知已开启', '以后有新消息、好友请求和活动提醒会这样通知你。',
                              '/me/notifications', null, 'test:' || gen_random_uuid());
  return true;
end $$;

-- ---------------------------------------------------------------------------
-- Grants
-- ---------------------------------------------------------------------------
revoke execute on function public.push_wanted(uuid, text), public.push_enqueue(uuid, text, text, text, text, text, text),
  public.push_name(uuid), public.push_time(timestamptz), public.push_on_message(), public.push_on_connection_request(),
  public.push_on_match_invitation(), public.push_on_shared_plan(), public.enqueue_event_reminders(), public.push_kick(),
  public.push_outbox_kick(), public.push_tick(), public.schedule_push_jobs(), public.claim_push_batch(int),
  public.complete_push_batch(bigint[], bigint[], text[], text[]), public.save_push_subscription(text, text, text, text),
  public.delete_push_subscription(text), public.has_push_subscription(text), public.my_notification_preferences(),
  public.set_notification_preference(text, boolean), public.send_test_push()
  from public, anon, authenticated;
grant execute on function public.save_push_subscription(text, text, text, text), public.delete_push_subscription(text),
  public.has_push_subscription(text), public.my_notification_preferences(), public.set_notification_preference(text, boolean),
  public.send_test_push()
  to authenticated;
grant execute on function public.claim_push_batch(int), public.complete_push_batch(bigint[], bigint[], text[], text[])
  to service_role;
