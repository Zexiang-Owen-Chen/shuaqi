-- People within 50 m, three ways (product decision 2026-10-19):
--   1. Event "nearby": check-in is no longer required; GPS within 50 m is enough.
--   2. Standalone "add friends nearby": not tied to any event; everyone who has it switched on
--      sees others within 50 m and can send a request (context 'nearby', no context id).
--   3. Shared plan meetup: once a plan is confirmed, around the planned time both people can share
--      their position; when they are within 50 m the plan page prompts them to add each other.
-- Privacy rules are unchanged for all three: separate 'nearby' location consent, last fix only,
-- deleted after 5 minutes, only fixes <= 2 minutes old and <= 100 m accuracy count, rounded distances.

-- ---------------------------------------------------------------------------
-- Tables
-- ---------------------------------------------------------------------------
create table public.open_presence (
  user_id uuid primary key references public.profiles (id) on delete cascade,
  lat double precision not null check (lat between -90 and 90),
  lng double precision not null check (lng between -180 and 180),
  accuracy_m double precision not null check (accuracy_m > 0),
  updated_at timestamptz not null default now()
);
create index on public.open_presence (updated_at);

create table public.plan_presence (
  plan_id uuid not null references public.shared_plans (id) on delete cascade,
  user_id uuid not null references public.profiles (id) on delete cascade,
  lat double precision not null check (lat between -90 and 90),
  lng double precision not null check (lng between -180 and 180),
  accuracy_m double precision not null check (accuracy_m > 0),
  updated_at timestamptz not null default now(),
  primary key (plan_id, user_id)
);
create index on public.plan_presence (updated_at);

-- No client access at all; only the functions below read or write positions.
revoke all on public.open_presence, public.plan_presence from anon, authenticated;
alter table public.open_presence enable row level security;
alter table public.plan_presence enable row level security;

-- ---------------------------------------------------------------------------
-- Distance helpers (null = not comparable, treated as "not nearby")
-- ---------------------------------------------------------------------------
create or replace function public.open_distance(p_a uuid, p_b uuid) returns double precision
language sql stable security definer set search_path = '' as $$
  select public.distance_m(a.lat, a.lng, b.lat, b.lng)
  from public.open_presence a, public.open_presence b
  where a.user_id = p_a and b.user_id = p_b
    and a.updated_at > now() - interval '2 minutes' and b.updated_at > now() - interval '2 minutes'
    and a.accuracy_m <= 100 and b.accuracy_m <= 100
    and public.has_location_consent(p_a, 'nearby') and public.has_location_consent(p_b, 'nearby')
$$;

create or replace function public.plan_distance(p_plan uuid, p_a uuid, p_b uuid) returns double precision
language sql stable security definer set search_path = '' as $$
  select public.distance_m(a.lat, a.lng, b.lat, b.lng)
  from public.plan_presence a, public.plan_presence b
  where a.plan_id = p_plan and b.plan_id = p_plan and a.user_id = p_a and b.user_id = p_b
    and a.updated_at > now() - interval '2 minutes' and b.updated_at > now() - interval '2 minutes'
    and a.accuracy_m <= 100 and b.accuracy_m <= 100
    and public.has_location_consent(p_a, 'nearby') and public.has_location_consent(p_b, 'nearby')
$$;

-- Shared checks for any position report.
create or replace function public.check_position(p_lat double precision, p_lng double precision, p_accuracy double precision)
returns void
language plpgsql stable security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  if not public.flag_enabled('nearby') then raise exception 'feature_disabled' using errcode = 'P0001'; end if;
  if not public.has_location_consent(auth.uid(), 'nearby') then
    raise exception 'location_consent_required' using errcode = 'P0001';
  end if;
  if p_lat is null or p_lng is null or p_lat not between -90 and 90 or p_lng not between -180 and 180 then
    raise exception 'location_required' using errcode = 'P0001';
  end if;
  if p_accuracy is null or p_accuracy <= 0 or p_accuracy > 100 then
    raise exception 'location_inaccurate' using errcode = 'P0001';
  end if;
end $$;

-- ---------------------------------------------------------------------------
-- 1. Event nearby without check-in
-- ---------------------------------------------------------------------------
create or replace function public.update_nearby_presence(p_event uuid, p_lat double precision, p_lng double precision, p_accuracy double precision)
returns void
language plpgsql security definer set search_path = '' as $$
declare
  e public.events;
begin
  perform public.check_position(p_lat, p_lng, p_accuracy);
  select * into e from public.events where id = p_event;
  if not found or not public.can_view_event(p_event) then raise exception 'event_not_found' using errcode = 'P0001'; end if;
  if e.status <> 'published' or now() > coalesce(e.ends_at, e.starts_at + interval '6 hours') then
    raise exception 'event_not_active' using errcode = 'P0001';
  end if;
  insert into public.nearby_presence (event_id, user_id, lat, lng, accuracy_m, updated_at)
  values (p_event, auth.uid(), p_lat, p_lng, p_accuracy, now())
  on conflict (event_id, user_id) do update
    set lat = excluded.lat, lng = excluded.lng, accuracy_m = excluded.accuracy_m, updated_at = now();
end $$;

create or replace function public.list_nearby(p_event uuid)
returns table (card jsonb, distance_m int, request_status text)
language plpgsql stable security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  if not exists (select 1 from public.nearby_presence
                 where event_id = p_event and user_id = auth.uid() and updated_at > now() - interval '2 minutes') then
    raise exception 'nearby_not_active' using errcode = 'P0001';
  end if;
  return query
    select public.nearby_card(p.id), (greatest(10, round(d.dist / 10) * 10))::int, public.latest_request_status(p.id)
    from public.nearby_presence n
    join public.profiles p on p.id = n.user_id
    cross join lateral (select public.nearby_distance(p_event, auth.uid(), n.user_id) as dist) d
    where n.event_id = p_event and n.user_id <> auth.uid()
      and d.dist <= 50
      and not public.is_blocked(auth.uid(), n.user_id)
    order by d.dist;
end $$;

-- Card and request status shown for a nearby person (event list and open list share them).
create or replace function public.nearby_card(p_user uuid) returns jsonb
language sql stable security definer set search_path = '' as $$
  select jsonb_build_object(
           'id', p.id, 'display_name', p.display_name, 'avatar_url', p.avatar_url,
           'school_domain', p.school_domain, 'school_verified', p.school_verified_at is not null,
           'connected', public.are_connected(auth.uid(), p.id))
  from public.profiles p where p.id = p_user
$$;

create or replace function public.latest_request_status(p_other uuid) returns text
language sql stable security definer set search_path = '' as $$
  select cr.status::text from public.connection_requests cr
  where least(cr.from_user, cr.to_user) = least(auth.uid(), p_other)
    and greatest(cr.from_user, cr.to_user) = greatest(auth.uid(), p_other)
  order by cr.created_at desc limit 1
$$;

-- ---------------------------------------------------------------------------
-- 2. Standalone "add friends nearby"
-- ---------------------------------------------------------------------------
create or replace function public.update_open_presence(p_lat double precision, p_lng double precision, p_accuracy double precision)
returns void
language plpgsql security definer set search_path = '' as $$
begin
  perform public.check_position(p_lat, p_lng, p_accuracy);
  if not public.is_school_verified() then raise exception 'school_verification_required' using errcode = 'P0001'; end if;
  insert into public.open_presence (user_id, lat, lng, accuracy_m, updated_at)
  values (auth.uid(), p_lat, p_lng, p_accuracy, now())
  on conflict (user_id) do update
    set lat = excluded.lat, lng = excluded.lng, accuracy_m = excluded.accuracy_m, updated_at = now();
end $$;

create or replace function public.stop_open_presence() returns void
language sql security definer set search_path = '' as $$
  delete from public.open_presence where user_id = auth.uid()
$$;

create or replace function public.list_open_nearby()
returns table (card jsonb, distance_m int, request_status text)
language plpgsql stable security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  if not exists (select 1 from public.open_presence
                 where user_id = auth.uid() and updated_at > now() - interval '2 minutes') then
    raise exception 'nearby_not_active' using errcode = 'P0001';
  end if;
  return query
    select public.nearby_card(p.id), (greatest(10, round(d.dist / 10) * 10))::int, public.latest_request_status(p.id)
    from public.open_presence n
    join public.profiles p on p.id = n.user_id
    cross join lateral (select public.open_distance(auth.uid(), n.user_id) as dist) d
    where n.user_id <> auth.uid()
      and p.school_verified_at is not null
      and d.dist <= 50
      and not public.is_blocked(auth.uid(), n.user_id)
    order by d.dist;
end $$;

-- ---------------------------------------------------------------------------
-- 3. Shared plan meetup
-- ---------------------------------------------------------------------------
-- Open from 1 hour before the planned time (same as report_met) until 6 hours after.
-- Returns {nearby: bool, distance_m: int|null}; the distance is only given when within 50 m.
create or replace function public.update_plan_presence(p_plan uuid, p_lat double precision, p_lng double precision, p_accuracy double precision)
returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  s public.shared_plans;
  v_other uuid;
  v_dist double precision;
begin
  perform public.check_position(p_lat, p_lng, p_accuracy);
  select * into s from public.shared_plans where id = p_plan;
  if not found or auth.uid() not in (s.user_a, s.user_b) then raise exception 'plan_not_found' using errcode = 'P0001'; end if;
  if s.status <> 'confirmed' then raise exception 'plan_not_confirmed' using errcode = 'P0001'; end if;
  if s.planned_at is null or now() < s.planned_at - interval '1 hour' or now() > s.planned_at + interval '6 hours' then
    raise exception 'meetup_not_open' using errcode = 'P0001';
  end if;
  insert into public.plan_presence (plan_id, user_id, lat, lng, accuracy_m, updated_at)
  values (p_plan, auth.uid(), p_lat, p_lng, p_accuracy, now())
  on conflict (plan_id, user_id) do update
    set lat = excluded.lat, lng = excluded.lng, accuracy_m = excluded.accuracy_m, updated_at = now();

  v_other := case when auth.uid() = s.user_a then s.user_b else s.user_a end;
  v_dist := public.plan_distance(p_plan, auth.uid(), v_other);
  if v_dist is not null and v_dist <= 50 then
    return jsonb_build_object('nearby', true, 'distance_m', greatest(10, round(v_dist / 10) * 10)::int);
  end if;
  return jsonb_build_object('nearby', false, 'distance_m', null);
end $$;

create or replace function public.stop_plan_presence(p_plan uuid) returns void
language sql security definer set search_path = '' as $$
  delete from public.plan_presence where plan_id = p_plan and user_id = auth.uid()
$$;

-- ---------------------------------------------------------------------------
-- Connection requests: 'nearby' with an event id = event nearby, without = standalone.
-- Only the 'nearby' branch changes (no check-in); the rest is as in 20261019000003_rpc.sql.
-- ---------------------------------------------------------------------------
create or replace function public.send_connection_request(p_to uuid, p_context public.request_context,
                                                          p_context_id uuid default null, p_message text default null)
returns public.connection_requests
language plpgsql security definer set search_path = '' as $$
declare
  v_me uuid := auth.uid();
  e public.events;
  r public.connection_requests;
begin
  if v_me is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  if p_to = v_me then raise exception 'cannot_connect_self' using errcode = 'P0001'; end if;
  if not public.is_school_verified() then raise exception 'school_verification_required' using errcode = 'P0001'; end if;
  if public.is_blocked(v_me, p_to) then raise exception 'blocked' using errcode = 'P0001'; end if;
  if public.are_connected(v_me, p_to) then raise exception 'already_connected' using errcode = 'P0001'; end if;

  select * into r from public.connection_requests
    where status = 'pending' and least(from_user, to_user) = least(v_me, p_to) and greatest(from_user, to_user) = greatest(v_me, p_to);
  if found then
    if r.from_user = v_me then return r; end if;  -- idempotent repeat click
    raise exception 'incoming_request_pending' using errcode = 'P0001';
  end if;

  if p_context = 'event' then
    select * into e from public.events where id = p_context_id;
    if not found or not public.is_going(p_context_id, v_me) or not public.is_going(p_context_id, p_to)
       or not exists (select 1 from public.event_social_optin where event_id = p_context_id and user_id = p_to and opted_in) then
      raise exception 'not_discoverable' using errcode = 'P0001';
    end if;
    if e.require_checkin_for_connect and not (public.is_checked_in(p_context_id, v_me) and public.is_checked_in(p_context_id, p_to)) then
      raise exception 'checkin_required' using errcode = 'P0001';
    end if;
  elsif p_context = 'nearby' then
    if coalesce(case when p_context_id is null then public.open_distance(v_me, p_to)
                     else public.nearby_distance(p_context_id, v_me, p_to) end, 1e9) > 50 then
      raise exception 'not_nearby' using errcode = 'P0001';
    end if;
  elsif p_context = 'intent' then
    if not exists (select 1 from public.shared_plans
                   where (user_a = v_me and user_b = p_to) or (user_a = p_to and user_b = v_me)) then
      raise exception 'not_discoverable' using errcode = 'P0001';
    end if;
  else
    raise exception 'context_not_allowed' using errcode = 'P0001';
  end if;

  insert into public.connection_requests (from_user, to_user, context, context_id, message)
  values (v_me, p_to, p_context, p_context_id, nullif(trim(p_message), ''))
  returning * into r;
  return r;
end $$;

-- ---------------------------------------------------------------------------
-- Clean-up covers the new tables
-- ---------------------------------------------------------------------------
create or replace function public.withdraw_location_consent(p_purpose text) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  update public.location_consents set withdrawn_at = now()
   where user_id = auth.uid() and purpose = p_purpose and withdrawn_at is null;
  if p_purpose = 'nearby' then
    delete from public.nearby_presence where user_id = auth.uid();
    delete from public.open_presence where user_id = auth.uid();
    delete from public.plan_presence where user_id = auth.uid();
  end if;
end $$;

create or replace function public.purge_nearby_presence() returns int
language plpgsql security definer set search_path = '' as $$
declare n int; m int; k int;
begin
  delete from public.nearby_presence where updated_at < now() - interval '5 minutes';
  get diagnostics n = row_count;
  delete from public.open_presence where updated_at < now() - interval '5 minutes';
  get diagnostics m = row_count;
  delete from public.plan_presence where updated_at < now() - interval '5 minutes';
  get diagnostics k = row_count;
  return n + m + k;
end $$;

-- ---------------------------------------------------------------------------
-- Grants
-- ---------------------------------------------------------------------------
revoke execute on function
  public.open_distance(uuid, uuid), public.plan_distance(uuid, uuid, uuid),
  public.check_position(double precision, double precision, double precision),
  public.nearby_card(uuid), public.latest_request_status(uuid),
  public.purge_nearby_presence()
from public, anon, authenticated;

revoke execute on function
  public.update_open_presence(double precision, double precision, double precision), public.stop_open_presence(),
  public.list_open_nearby(),
  public.update_plan_presence(uuid, double precision, double precision, double precision), public.stop_plan_presence(uuid)
from public, anon;
grant execute on function
  public.update_open_presence(double precision, double precision, double precision), public.stop_open_presence(),
  public.list_open_nearby(),
  public.update_plan_presence(uuid, double precision, double precision, double precision), public.stop_plan_presence(uuid)
to authenticated;
