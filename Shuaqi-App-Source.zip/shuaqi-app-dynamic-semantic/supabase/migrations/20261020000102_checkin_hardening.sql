-- Hardening found while merging the check-in and organiser modules.
-- 1. Organisers cannot confirm their own attendance (would self-issue 'verified' evidence).
-- 2. event_checkin rejects non-positive accuracy and out-of-range coordinates, and reports
--    "already checked in" even after the check-in window has closed.
-- 3. is_checked_in() runs as the caller, so RLS limits clients to their own record or events
--    they staff; security-definer callers (connections, nearby) still see everyone.
-- 4. Events can be created directly as drafts.

create or replace function public.organiser_confirm_attendance(p_event uuid, p_user uuid, p_confirm boolean default true)
returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_event_staff(p_event) then raise exception 'forbidden' using errcode = 'P0001'; end if;
  -- Nobody upgrades their own attendance to 'verified'.
  if p_user = auth.uid() then raise exception 'cannot_confirm_self' using errcode = 'P0001'; end if;
  if not public.is_going(p_event, p_user) then raise exception 'not_registered' using errcode = 'P0001'; end if;
  if p_confirm then
    insert into public.participation_evidence
      (event_id, subject_user_id, type, source, operator_id, verification_status)
    values (p_event, p_user, 'organiser_confirmed_attendance', 'organiser_manual', auth.uid(), 'verified')
    on conflict (event_id, subject_user_id, type) where event_id is not null and verification_status <> 'revoked'
    do nothing;
  else
    update public.participation_evidence
       set verification_status = 'revoked', meta = meta || jsonb_build_object('revoked_by', auth.uid())
     where event_id = p_event and subject_user_id = p_user
       and type = 'organiser_confirmed_attendance' and verification_status <> 'revoked';
  end if;
end $$;

create or replace function public.event_checkin(p_code text, p_lat double precision, p_lng double precision, p_accuracy double precision)
returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  v_me uuid := auth.uid();
  e public.events;
  v_opens timestamptz;
  v_closes timestamptz;
  v_dist double precision;
  v_existing public.participation_evidence;
begin
  if v_me is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  if not public.flag_enabled('qr_checkin') then return jsonb_build_object('ok', false, 'reason', 'checkin_disabled'); end if;

  select ev.* into e from public.event_checkin_codes c join public.events ev on ev.id = c.event_id where c.code = p_code;
  if not found then return jsonb_build_object('ok', false, 'reason', 'invalid_code'); end if;
  if e.status <> 'published' then return jsonb_build_object('ok', false, 'reason', 'event_not_active', 'event_id', e.id); end if;
  if e.checkin_mode <> 'qr_geo' then return jsonb_build_object('ok', false, 'reason', 'checkin_disabled', 'event_id', e.id); end if;

  select * into v_existing from public.participation_evidence
    where event_id = e.id and subject_user_id = v_me and type = 'self_reported_presence' and verification_status <> 'revoked';
  if found then  -- also after the window closes, a repeat scan just says "already"
    return jsonb_build_object('ok', true, 'already', true, 'event_id', e.id, 'status', v_existing.verification_status);
  end if;

  v_opens := coalesce(e.checkin_opens_at, e.starts_at - interval '1 hour');
  v_closes := coalesce(e.checkin_closes_at, e.ends_at, e.starts_at + interval '6 hours');
  if now() < v_opens or now() > v_closes then
    return jsonb_build_object('ok', false, 'reason', 'outside_window', 'event_id', e.id, 'opens_at', v_opens, 'closes_at', v_closes);
  end if;
  if not public.is_going(e.id, v_me) then return jsonb_build_object('ok', false, 'reason', 'not_registered', 'event_id', e.id); end if;

  if p_lat is null or p_lng is null or p_accuracy is null
     or p_lat not between -90 and 90 or p_lng not between -180 and 180 or p_accuracy <= 0 then
    return jsonb_build_object('ok', false, 'reason', 'location_required', 'event_id', e.id);
  end if;
  v_dist := public.distance_m(p_lat, p_lng, e.location_lat, e.location_lng);
  if p_accuracy > 100 then
    return jsonb_build_object('ok', false, 'reason', 'location_inaccurate', 'event_id', e.id, 'accuracy_m', round(p_accuracy));
  end if;
  if v_dist > e.checkin_radius_m then
    return jsonb_build_object('ok', false, 'reason', 'too_far', 'event_id', e.id, 'distance_m', round(v_dist));
  end if;

  insert into public.participation_evidence
    (event_id, subject_user_id, type, source, operator_id, verification_status, geo_distance_m, geo_accuracy_m)
  values (e.id, v_me, 'self_reported_presence', 'qr_geo', v_me, 'geo_verified', v_dist, p_accuracy)
  on conflict (event_id, subject_user_id, type) where event_id is not null and verification_status <> 'revoked'
  do nothing;

  return jsonb_build_object('ok', true, 'already', false, 'event_id', e.id, 'status', 'geo_verified', 'distance_m', round(v_dist));
end $$;

create or replace function public.is_checked_in(p_event uuid, p_user uuid) returns boolean
language sql stable security invoker set search_path = '' as $$
  select exists (
    select 1 from public.participation_evidence
    where event_id = p_event and subject_user_id = p_user
      and verification_status in ('geo_verified', 'verified')
  )
$$;

grant insert (status) on public.events to authenticated;

create or replace function public.events_status_on_insert() returns trigger
language plpgsql as $$
begin
  if new.status not in ('draft', 'published') then
    raise exception 'invalid_status' using errcode = 'P0001';
  end if;
  return new;
end $$;

create trigger events_status_on_insert before insert on public.events
  for each row execute function public.events_status_on_insert();
revoke all on function public.events_status_on_insert() from public, anon, authenticated;
revoke all on function public.list_org_members(uuid) from public, anon;
grant execute on function public.list_org_members(uuid) to authenticated;
