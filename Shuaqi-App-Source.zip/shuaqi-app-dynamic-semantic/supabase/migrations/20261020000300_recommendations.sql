-- Personalised event recommendations (server/api/recommendations.post.ts).
-- The server route calls these functions with the signed-in user's own session, so visibility,
-- blocks and rate limits are enforced here, not trusted from the request.

create extension if not exists vector with schema extensions;

insert into public.feature_flags (key, description) values
  ('recommendations', 'Personalised recommendations and natural-language event search')
on conflict (key) do nothing;

-- ---------------------------------------------------------------------------
-- Which AI models the recommender uses (one row, chosen by an admin).
-- API keys stay in server environment variables; this row only picks among them.
-- ---------------------------------------------------------------------------
create table public.recommendation_settings (
  id boolean primary key default true check (id),
  llm_provider text not null default 'none'
    check (llm_provider in ('none', 'openai', 'anthropic', 'openai_compatible')),
  llm_model text not null default '' check (llm_model ~ '^[A-Za-z0-9._:/-]{0,80}$'),
  embedding_provider text not null default 'none'
    check (embedding_provider in ('none', 'openai', 'openai_compatible')),
  embedding_model text not null default '' check (embedding_model ~ '^[A-Za-z0-9._:/-]{0,80}$'),
  updated_by uuid references public.profiles (id) on delete set null,
  updated_at timestamptz not null default now()
);
insert into public.recommendation_settings default values;

create or replace function public.recommendation_settings_stamp() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  new.updated_at := now();
  new.updated_by := auth.uid();
  return new;
end $$;
create trigger recommendation_settings_stamp before update on public.recommendation_settings
  for each row execute function public.recommendation_settings_stamp();
create trigger audit_recommendation_settings after update on public.recommendation_settings
  for each row execute function public.audit_row();

-- Supabase grants every new public table to anon and authenticated by default; start from nothing.
alter table public.recommendation_settings enable row level security;
revoke all on public.recommendation_settings from anon, authenticated;
grant select on public.recommendation_settings to authenticated;
grant update (llm_provider, llm_model, embedding_provider, embedding_model)
  on public.recommendation_settings to authenticated;
create policy "reco settings readable" on public.recommendation_settings for select to authenticated using (true);
create policy "reco settings admin update" on public.recommendation_settings for update to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- ---------------------------------------------------------------------------
-- What users did with recommendations. Joins, cancellations and attendance are read from
-- event_rsvps and participation_evidence instead, so they cannot be faked here.
-- ---------------------------------------------------------------------------
create type public.recommendation_event_kind as enum ('impression', 'click', 'dismiss');

create table public.recommendation_events (
  id bigint generated always as identity primary key,
  user_id uuid not null default auth.uid() references public.profiles (id) on delete cascade,
  event_id uuid not null references public.events (id) on delete cascade,
  kind public.recommendation_event_kind not null,
  request_id uuid,
  position int check (position between 0 and 100),
  algorithm_version text not null default '' check (char_length(algorithm_version) <= 40),
  at timestamptz not null default now()
);
create index on public.recommendation_events (user_id, kind, at desc);
create index on public.recommendation_events (event_id);

alter table public.recommendation_events enable row level security;
revoke all on public.recommendation_events from anon, authenticated;
grant select on public.recommendation_events to authenticated;
-- user_id is not grantable: it always comes from the default auth.uid().
grant insert (event_id, kind, request_id, position, algorithm_version) on public.recommendation_events to authenticated;
create policy "reco events own read" on public.recommendation_events for select to authenticated
  using (user_id = auth.uid());
create policy "reco events own insert" on public.recommendation_events for insert to authenticated
  with check (user_id = auth.uid() and public.can_view_event(event_id));

-- ---------------------------------------------------------------------------
-- Per-user request log for rate limits. Only reachable through start_recommendation_request().
-- ---------------------------------------------------------------------------
create table public.recommendation_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  llm_used boolean not null default false,
  at timestamptz not null default now()
);
create index on public.recommendation_requests (user_id, at desc);
alter table public.recommendation_requests enable row level security;
revoke all on public.recommendation_requests from anon, authenticated;

-- ---------------------------------------------------------------------------
-- Cached embeddings of event text, one per model. Written by the server with the service role.
-- ---------------------------------------------------------------------------
create table public.event_embeddings (
  event_id uuid not null references public.events (id) on delete cascade,
  model text not null check (char_length(model) between 1 and 120),
  content_hash text not null,
  embedding extensions.vector not null,
  updated_at timestamptz not null default now(),
  primary key (event_id, model)
);
alter table public.event_embeddings enable row level security;
revoke all on public.event_embeddings from anon, authenticated;

-- ---------------------------------------------------------------------------
-- Functions
-- ---------------------------------------------------------------------------

-- Records one recommendation request. Raises rate_limited past 10 a minute or 300 a day;
-- llm_allowed is false once the user has used the language model 100 times today.
create or replace function public.start_recommendation_request(p_want_llm boolean default false)
returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare
  v_uid uuid := auth.uid();
  v_minute int;
  v_day int;
  v_llm int;
  v_llm_ok boolean;
  v_id uuid;
begin
  if v_uid is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  if not public.flag_enabled('recommendations') then raise exception 'feature_disabled' using errcode = 'P0001'; end if;
  -- One request at a time per user, so parallel calls cannot all pass the count.
  perform pg_advisory_xact_lock(hashtextextended('recommendations:' || v_uid::text, 0));
  select count(*) filter (where r.at > now() - interval '1 minute'), count(*), count(*) filter (where r.llm_used)
    into v_minute, v_day, v_llm
    from public.recommendation_requests r
   where r.user_id = v_uid and r.at > now() - interval '1 day';
  if v_minute >= 10 or v_day >= 300 then raise exception 'rate_limited' using errcode = 'P0001'; end if;
  v_llm_ok := coalesce(p_want_llm, false) and v_llm < 100;
  insert into public.recommendation_requests (user_id, llm_used) values (v_uid, v_llm_ok) returning id into v_id;
  delete from public.recommendation_requests where user_id = v_uid and at < now() - interval '2 days';
  return jsonb_build_object('request_id', v_id, 'llm_allowed', v_llm_ok);
end $$;

-- The signed-in user's own history, as category signals for the interest weights.
create or replace function public.recommendation_signals()
returns table (category text, signal text, at timestamptz)
language sql stable security definer set search_path = '' as $$
  select s.category, s.signal, s.at from (
    select e.category, case r.status when 'going' then 'join' else 'cancel_join' end as signal, r.updated_at as at
      from public.event_rsvps r join public.events e on e.id = r.event_id
     where r.user_id = auth.uid()
    union all
    select e.category, 'attend', pe.occurred_at
      from public.participation_evidence pe join public.events e on e.id = pe.event_id
     where pe.subject_user_id = auth.uid() and pe.verification_status in ('geo_verified', 'verified')
    union all
    select e.category, re.kind::text, re.at
      from public.recommendation_events re join public.events e on e.id = re.event_id
     where re.user_id = auth.uid() and re.kind in ('click', 'dismiss') and re.at > now() - interval '180 days'
  ) s
  order by s.at desc
  limit 500
$$;

-- Events the signed-in user could join: published, visible to them, not ended, not full,
-- not hosted by someone they blocked (or who blocked them), not already joined, not dismissed.
-- Optional time window (overlap). similarity is cosine similarity to p_query_embedding when an
-- embedding for p_embedding_model is cached; embedding_hash lets the server refresh stale ones.
create or replace function public.recommendation_candidates(
  p_from timestamptz default null,
  p_to timestamptz default null,
  p_embedding_model text default null,
  p_query_embedding text default null,
  p_limit int default 300
)
returns table (
  id uuid, title text, category text, description text, starts_at timestamptz, ends_at timestamptz,
  location_text text, location_lat double precision, location_lng double precision, capacity int,
  going int, org_verified boolean, embedding_hash text, similarity double precision
)
language plpgsql stable security definer set search_path = '' as $$
declare
  v_uid uuid := auth.uid();
  v_q extensions.vector;
begin
  if v_uid is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  if not public.flag_enabled('recommendations') then raise exception 'feature_disabled' using errcode = 'P0001'; end if;
  if p_query_embedding is not null then v_q := p_query_embedding::extensions.vector; end if;
  return query
    select e.id, e.title, e.category, e.description, e.starts_at, e.ends_at, e.location_text,
           e.location_lat, e.location_lng, e.capacity, g.going, coalesce(o.verified, false),
           emb.content_hash,
           case when v_q is not null and emb.embedding is not null
                     and extensions.vector_dims(emb.embedding) = extensions.vector_dims(v_q)
                then (1 - (emb.embedding operator(extensions.<=>) v_q))::double precision end
      from public.events e
      cross join lateral (select count(*)::int as going from public.event_rsvps r
                           where r.event_id = e.id and r.status = 'going') g
      left join public.organisations o on o.id = e.org_id
      left join public.event_embeddings emb on emb.event_id = e.id and emb.model = p_embedding_model
     where e.status = 'published'
       and coalesce(e.ends_at, e.starts_at + interval '3 hours') > now()
       and (p_to is null or e.starts_at <= p_to)
       and (p_from is null or coalesce(e.ends_at, e.starts_at + interval '3 hours') >= p_from)
       and (e.capacity is null or g.going < e.capacity)
       and public.can_view_event(e.id)
       and not public.is_blocked(v_uid, e.host_user_id)
       and not public.is_going(e.id, v_uid)
       and not exists (select 1 from public.recommendation_events d
                        where d.user_id = v_uid and d.event_id = e.id and d.kind = 'dismiss')
     order by e.starts_at, e.id
     limit greatest(1, least(coalesce(p_limit, 300), 500));
end $$;

-- New functions are executable by PUBLIC (and anon/authenticated on Supabase) by default.
revoke execute on function public.recommendation_settings_stamp() from public, anon, authenticated;
revoke execute on function public.start_recommendation_request(boolean), public.recommendation_signals(),
  public.recommendation_candidates(timestamptz, timestamptz, text, text, int) from public, anon;
grant execute on function public.start_recommendation_request(boolean), public.recommendation_signals(),
  public.recommendation_candidates(timestamptz, timestamptz, text, text, int) to authenticated;
