-- Business operations. Every function checks the caller with auth.uid() and raises
-- `P0001` with a short snake_case code as the message; the app maps codes to UI text.

-- ---------------------------------------------------------------------------
-- Profile cards
-- ---------------------------------------------------------------------------
-- context: 'general' | 'event' | 'intent'. Returns null when the viewer may not see the person.
create or replace function public.get_profile_card(p_target uuid, p_context text default 'general', p_context_id uuid default null)
returns jsonb
language plpgsql stable security definer set search_path = '' as $$
declare
  v_me uuid := auth.uid();
  p public.profiles;
  v_connected boolean;
  v_fields text[] := '{}';
  v_optin public.event_social_optin;
  v_key text;
  v_scope text;
  v_out jsonb;
begin
  if v_me is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  select * into p from public.profiles where id = p_target;
  if not found then return null; end if;

  if p_target = v_me then
    v_fields := array['bio', 'interests', 'photos', 'gender', 'age', 'region'];
  else
    if public.is_blocked(v_me, p_target) then return null; end if;
    v_connected := public.are_connected(v_me, p_target);

    for v_key, v_scope in select key, value from jsonb_each_text(p.visibility) loop
      if v_scope = 'public' or (v_scope = 'connections' and v_connected) then
        v_fields := v_fields || v_key;
      end if;
    end loop;

    if p_context = 'event' then
      select * into v_optin from public.event_social_optin
        where event_id = p_context_id and user_id = p_target and opted_in;
      if found and public.is_going(p_context_id, p_target)
         and (public.is_going(p_context_id, v_me) or public.is_event_staff(p_context_id, v_me)) then
        -- In a group event the person chooses exactly what to show.
        v_fields := case when v_connected then v_fields || v_optin.visible_fields else v_optin.visible_fields end;
      elsif not v_connected then
        return null;
      end if;
    elsif p_context = 'intent' then
      -- One-to-one matching: gender, age and region are always shown (founder rule).
      if exists (select 1 from public.match_invitations i
                 where (i.from_user = v_me and i.to_user = p_target) or (i.from_user = p_target and i.to_user = v_me))
         or exists (select 1 from public.intents a, public.intents b
                    where a.user_id = v_me and b.user_id = p_target
                      and public.intents_compatible(a.id, b.id)) then
        v_fields := v_fields || array['gender', 'age', 'region'];
      elsif not v_connected then
        return null;
      end if;
    end if;
  end if;

  v_out := jsonb_build_object(
    'id', p.id,
    'display_name', p.display_name,
    'avatar_url', p.avatar_url,
    'school_domain', p.school_domain,
    'school_verified', p.school_verified_at is not null,
    'connected', coalesce(v_connected, false),
    'is_me', p_target = v_me
  );
  if 'bio' = any (v_fields) then v_out := v_out || jsonb_build_object('bio', p.bio); end if;
  if 'interests' = any (v_fields) then v_out := v_out || jsonb_build_object('interests', p.interests); end if;
  if 'gender' = any (v_fields) then v_out := v_out || jsonb_build_object('gender', p.gender); end if;
  if 'region' = any (v_fields) then v_out := v_out || jsonb_build_object('region', p.region); end if;
  if 'age' = any (v_fields) and p.birth_year is not null then
    v_out := v_out || jsonb_build_object('age', extract(year from now())::int - p.birth_year);
  end if;
  if 'photos' = any (v_fields) then
    v_out := v_out || jsonb_build_object('photos', coalesce(
      (select jsonb_agg(storage_path order by sort) from public.profile_photos where user_id = p.id), '[]'));
  end if;
  return v_out;
end $$;

-- ---------------------------------------------------------------------------
-- Events: RSVP, opt-in, participants, attendees
-- ---------------------------------------------------------------------------
create or replace function public.join_event(p_event uuid) returns public.event_rsvps
language plpgsql security definer set search_path = '' as $$
declare
  v_me uuid := auth.uid();
  e public.events;
  v_going int;
  r public.event_rsvps;
begin
  if v_me is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  if not public.is_school_verified() then raise exception 'school_verification_required' using errcode = 'P0001'; end if;
  -- Row lock serialises concurrent joins so capacity cannot be exceeded.
  select * into e from public.events where id = p_event for update;
  if not found or not public.can_view_event(p_event) then raise exception 'event_not_found' using errcode = 'P0001'; end if;
  if e.status = 'cancelled' then raise exception 'event_cancelled' using errcode = 'P0001'; end if;
  if e.status <> 'published' or coalesce(e.ends_at, e.starts_at + interval '6 hours') < now() then
    raise exception 'event_closed' using errcode = 'P0001';
  end if;

  select * into r from public.event_rsvps where event_id = p_event and user_id = v_me;
  if found and r.status = 'going' then return r; end if;

  if e.capacity is not null then
    select count(*) into v_going from public.event_rsvps where event_id = p_event and status = 'going';
    if v_going >= e.capacity then raise exception 'event_full' using errcode = 'P0001'; end if;
  end if;

  insert into public.event_rsvps (event_id, user_id, status) values (p_event, v_me, 'going')
  on conflict (event_id, user_id) do update set status = 'going'
  returning * into r;
  return r;
end $$;

create or replace function public.leave_event(p_event uuid) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  if exists (select 1 from public.events where id = p_event and host_user_id = auth.uid()) then
    raise exception 'host_cannot_leave' using errcode = 'P0001';
  end if;
  update public.event_rsvps set status = 'cancelled' where event_id = p_event and user_id = auth.uid();
  update public.event_social_optin set opted_in = false where event_id = p_event and user_id = auth.uid();
  delete from public.nearby_presence where event_id = p_event and user_id = auth.uid();
end $$;

create or replace function public.cancel_event(p_event uuid) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not (public.is_event_manager(p_event) or public.is_admin()) then
    raise exception 'forbidden' using errcode = 'P0001';
  end if;
  update public.events set status = 'cancelled' where id = p_event;
  delete from public.nearby_presence where event_id = p_event;
end $$;

-- visible_fields subset of: bio, interests, photos, gender, age, region
create or replace function public.set_event_optin(p_event uuid, p_opted_in boolean, p_visible_fields text[] default '{interests}')
returns public.event_social_optin
language plpgsql security definer set search_path = '' as $$
declare
  o public.event_social_optin;
begin
  if auth.uid() is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  if p_opted_in and not public.is_going(p_event) then raise exception 'not_registered' using errcode = 'P0001'; end if;
  if not (p_visible_fields <@ array['bio', 'interests', 'photos', 'gender', 'age', 'region']) then
    raise exception 'invalid_fields' using errcode = 'P0001';
  end if;
  insert into public.event_social_optin (event_id, user_id, opted_in, visible_fields, updated_at)
  values (p_event, auth.uid(), p_opted_in, p_visible_fields, now())
  on conflict (event_id, user_id) do update
    set opted_in = excluded.opted_in, visible_fields = excluded.visible_fields, updated_at = now()
  returning * into o;
  return o;
end $$;

-- People who opted in to this event, as the viewer is allowed to see them.
create or replace function public.list_event_participants(p_event uuid)
returns table (card jsonb, request_status text)
language plpgsql stable security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  if not public.flag_enabled('event_discovery') then raise exception 'feature_disabled' using errcode = 'P0001'; end if;
  if not (public.is_going(p_event) or public.is_event_staff(p_event)) then
    raise exception 'not_registered' using errcode = 'P0001';
  end if;
  return query
    select public.get_profile_card(o.user_id, 'event', p_event),
           (select cr.status::text from public.connection_requests cr
             where least(cr.from_user, cr.to_user) = least(auth.uid(), o.user_id)
               and greatest(cr.from_user, cr.to_user) = greatest(auth.uid(), o.user_id)
             order by cr.created_at desc limit 1)
    from public.event_social_optin o
    join public.event_rsvps r on r.event_id = o.event_id and r.user_id = o.user_id and r.status = 'going'
    where o.event_id = p_event and o.opted_in and o.user_id <> auth.uid()
      and not public.is_blocked(auth.uid(), o.user_id)
    order by o.updated_at desc;
end $$;

-- Organiser view: minimal registration info plus check-in state.
create or replace function public.list_event_attendees(p_event uuid)
returns table (user_id uuid, display_name text, avatar_url text, school_domain text, rsvp_status text,
               rsvp_at timestamptz, self_checkin text, organiser_confirmed boolean)
language plpgsql stable security definer set search_path = '' as $$
begin
  if not (public.is_event_staff(p_event) or public.is_admin()) then
    raise exception 'forbidden' using errcode = 'P0001';
  end if;
  return query
    select r.user_id, p.display_name, p.avatar_url, p.school_domain, r.status::text, r.created_at,
           (select pe.verification_status::text from public.participation_evidence pe
             where pe.event_id = p_event and pe.subject_user_id = r.user_id
               and pe.type = 'self_reported_presence' and pe.verification_status <> 'revoked'),
           exists (select 1 from public.participation_evidence pe
                   where pe.event_id = p_event and pe.subject_user_id = r.user_id
                     and pe.type = 'organiser_confirmed_attendance' and pe.verification_status = 'verified')
    from public.event_rsvps r join public.profiles p on p.id = r.user_id
    where r.event_id = p_event
    order by r.created_at;
end $$;

-- ---------------------------------------------------------------------------
-- Check-in: static event QR + GPS
-- ---------------------------------------------------------------------------
create or replace function public.get_checkin_code(p_event uuid) returns text
language plpgsql stable security definer set search_path = '' as $$
begin
  if not public.is_event_staff(p_event) then raise exception 'forbidden' using errcode = 'P0001'; end if;
  return (select code from public.event_checkin_codes where event_id = p_event);
end $$;

create or replace function public.rotate_checkin_code(p_event uuid) returns text
language plpgsql security definer set search_path = '' as $$
declare
  v_code text := encode(extensions.gen_random_bytes(16), 'hex');
begin
  if not public.is_event_manager(p_event) then raise exception 'forbidden' using errcode = 'P0001'; end if;
  insert into public.event_checkin_codes (event_id, code, rotated_at) values (p_event, v_code, now())
  on conflict (event_id) do update set code = excluded.code, rotated_at = now();
  insert into public.audit_log (actor_id, action, table_name, row_id) values (auth.uid(), 'rotate', 'event_checkin_codes', p_event::text);
  return v_code;
end $$;

-- Public info for the page a scanned code opens (no personal data).
create or replace function public.lookup_checkin_code(p_code text)
returns table (event_id uuid, title text, starts_at timestamptz, location_text text, checkin_radius_m int)
language sql stable security definer set search_path = '' as $$
  select e.id, e.title, e.starts_at, e.location_text, e.checkin_radius_m
  from public.event_checkin_codes c join public.events e on e.id = c.event_id
  where c.code = p_code and e.status = 'published'
$$;

-- Returns {ok, reason?, already?, distance_m?, status?}. Reasons: invalid_code, event_not_active,
-- checkin_disabled, outside_window, not_registered, location_required, location_inaccurate, too_far.
create or replace function public.event_checkin(p_code text, p_lat double precision, p_lng double precision, p_accuracy double precision)
returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  v_me uuid := auth.uid();
  e public.events;
  v_opens timestamptz;
  v_closes timestamptz;
  v_dist double precision;
  v_existing public.participation_evidence;
begin
  if v_me is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  if not public.flag_enabled('qr_checkin') then return jsonb_build_object('ok', false, 'reason', 'checkin_disabled'); end if;

  select ev.* into e from public.event_checkin_codes c join public.events ev on ev.id = c.event_id where c.code = p_code;
  if not found then return jsonb_build_object('ok', false, 'reason', 'invalid_code'); end if;
  if e.status <> 'published' then return jsonb_build_object('ok', false, 'reason', 'event_not_active', 'event_id', e.id); end if;
  if e.checkin_mode <> 'qr_geo' then return jsonb_build_object('ok', false, 'reason', 'checkin_disabled', 'event_id', e.id); end if;

  v_opens := coalesce(e.checkin_opens_at, e.starts_at - interval '1 hour');
  v_closes := coalesce(e.checkin_closes_at, e.ends_at, e.starts_at + interval '6 hours');
  if now() < v_opens or now() > v_closes then
    return jsonb_build_object('ok', false, 'reason', 'outside_window', 'event_id', e.id, 'opens_at', v_opens, 'closes_at', v_closes);
  end if;
  if not public.is_going(e.id, v_me) then return jsonb_build_object('ok', false, 'reason', 'not_registered', 'event_id', e.id); end if;

  select * into v_existing from public.participation_evidence
    where event_id = e.id and subject_user_id = v_me and type = 'self_reported_presence' and verification_status <> 'revoked';
  if found then
    return jsonb_build_object('ok', true, 'already', true, 'event_id', e.id, 'status', v_existing.verification_status);
  end if;

  if p_lat is null or p_lng is null or p_accuracy is null then
    return jsonb_build_object('ok', false, 'reason', 'location_required', 'event_id', e.id);
  end if;
  v_dist := public.distance_m(p_lat, p_lng, e.location_lat, e.location_lng);
  if p_accuracy > 100 then
    return jsonb_build_object('ok', false, 'reason', 'location_inaccurate', 'event_id', e.id, 'accuracy_m', round(p_accuracy));
  end if;
  if v_dist > e.checkin_radius_m then
    return jsonb_build_object('ok', false, 'reason', 'too_far', 'event_id', e.id, 'distance_m', round(v_dist));
  end if;

  insert into public.participation_evidence
    (event_id, subject_user_id, type, source, operator_id, verification_status, geo_distance_m, geo_accuracy_m)
  values (e.id, v_me, 'self_reported_presence', 'qr_geo', v_me, 'geo_verified', v_dist, p_accuracy)
  on conflict (event_id, subject_user_id, type) where event_id is not null and verification_status <> 'revoked'
  do nothing;

  return jsonb_build_object('ok', true, 'already', false, 'event_id', e.id, 'status', 'geo_verified', 'distance_m', round(v_dist));
end $$;

-- Organiser confirmation is the only path to 'verified' attendance.
create or replace function public.organiser_confirm_attendance(p_event uuid, p_user uuid, p_confirm boolean default true)
returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_event_staff(p_event) then raise exception 'forbidden' using errcode = 'P0001'; end if;
  if not public.is_going(p_event, p_user) then raise exception 'not_registered' using errcode = 'P0001'; end if;
  if p_confirm then
    insert into public.participation_evidence
      (event_id, subject_user_id, type, source, operator_id, verification_status)
    values (p_event, p_user, 'organiser_confirmed_attendance', 'organiser_manual', auth.uid(), 'verified')
    on conflict (event_id, subject_user_id, type) where event_id is not null and verification_status <> 'revoked'
    do nothing;
  else
    update public.participation_evidence
       set verification_status = 'revoked', meta = meta || jsonb_build_object('revoked_by', auth.uid())
     where event_id = p_event and subject_user_id = p_user
       and type = 'organiser_confirmed_attendance' and verification_status <> 'revoked';
  end if;
end $$;

-- ---------------------------------------------------------------------------
-- People within 50m (geolocation stand-in for Bluetooth)
-- ---------------------------------------------------------------------------
create or replace function public.is_checked_in(p_event uuid, p_user uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.participation_evidence
    where event_id = p_event and subject_user_id = p_user
      and verification_status in ('geo_verified', 'verified')
  )
$$;

create or replace function public.update_nearby_presence(p_event uuid, p_lat double precision, p_lng double precision, p_accuracy double precision)
returns void
language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  if not public.flag_enabled('nearby') then raise exception 'feature_disabled' using errcode = 'P0001'; end if;
  if not public.is_checked_in(p_event, auth.uid()) then raise exception 'checkin_required' using errcode = 'P0001'; end if;
  delete from public.nearby_presence where updated_at < now() - interval '5 minutes';
  insert into public.nearby_presence (event_id, user_id, lat, lng, accuracy_m, updated_at)
  values (p_event, auth.uid(), p_lat, p_lng, p_accuracy, now())
  on conflict (event_id, user_id) do update
    set lat = excluded.lat, lng = excluded.lng, accuracy_m = excluded.accuracy_m, updated_at = now();
end $$;

create or replace function public.stop_nearby(p_event uuid) returns void
language sql security definer set search_path = '' as $$
  delete from public.nearby_presence where event_id = p_event and user_id = auth.uid()
$$;

create or replace function public.nearby_distance(p_event uuid, p_a uuid, p_b uuid) returns double precision
language sql stable security definer set search_path = '' as $$
  select public.distance_m(a.lat, a.lng, b.lat, b.lng)
  from public.nearby_presence a, public.nearby_presence b
  where a.event_id = p_event and b.event_id = p_event and a.user_id = p_a and b.user_id = p_b
    and a.updated_at > now() - interval '5 minutes' and b.updated_at > now() - interval '5 minutes'
$$;

create or replace function public.list_nearby(p_event uuid)
returns table (card jsonb, distance_m int, request_status text)
language plpgsql stable security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  if not exists (select 1 from public.nearby_presence
                 where event_id = p_event and user_id = auth.uid() and updated_at > now() - interval '5 minutes') then
    raise exception 'nearby_not_active' using errcode = 'P0001';
  end if;
  return query
    select jsonb_build_object(
             'id', p.id, 'display_name', p.display_name, 'avatar_url', p.avatar_url,
             'school_domain', p.school_domain, 'school_verified', p.school_verified_at is not null,
             'connected', public.are_connected(auth.uid(), p.id)),
           (round(d.dist / 10) * 10)::int,
           (select cr.status::text from public.connection_requests cr
             where least(cr.from_user, cr.to_user) = least(auth.uid(), p.id)
               and greatest(cr.from_user, cr.to_user) = greatest(auth.uid(), p.id)
             order by cr.created_at desc limit 1)
    from public.nearby_presence n
    join public.profiles p on p.id = n.user_id
    cross join lateral (select public.nearby_distance(p_event, auth.uid(), n.user_id) as dist) d
    where n.event_id = p_event and n.user_id <> auth.uid()
      and n.updated_at > now() - interval '5 minutes'
      and d.dist <= 50
      and not public.is_blocked(auth.uid(), n.user_id)
    order by d.dist;
end $$;

-- ---------------------------------------------------------------------------
-- Connections
-- ---------------------------------------------------------------------------
create or replace function public.send_connection_request(p_to uuid, p_context public.request_context,
                                                          p_context_id uuid default null, p_message text default null)
returns public.connection_requests
language plpgsql security definer set search_path = '' as $$
declare
  v_me uuid := auth.uid();
  e public.events;
  r public.connection_requests;
begin
  if v_me is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  if p_to = v_me then raise exception 'cannot_connect_self' using errcode = 'P0001'; end if;
  if not public.is_school_verified() then raise exception 'school_verification_required' using errcode = 'P0001'; end if;
  if public.is_blocked(v_me, p_to) then raise exception 'blocked' using errcode = 'P0001'; end if;
  if public.are_connected(v_me, p_to) then raise exception 'already_connected' using errcode = 'P0001'; end if;

  select * into r from public.connection_requests
    where status = 'pending' and least(from_user, to_user) = least(v_me, p_to) and greatest(from_user, to_user) = greatest(v_me, p_to);
  if found then
    if r.from_user = v_me then return r; end if;  -- idempotent repeat click
    raise exception 'incoming_request_pending' using errcode = 'P0001';
  end if;

  if p_context = 'event' then
    select * into e from public.events where id = p_context_id;
    if not found or not public.is_going(p_context_id, v_me) or not public.is_going(p_context_id, p_to)
       or not exists (select 1 from public.event_social_optin where event_id = p_context_id and user_id = p_to and opted_in) then
      raise exception 'not_discoverable' using errcode = 'P0001';
    end if;
    if e.require_checkin_for_connect and not (public.is_checked_in(p_context_id, v_me) and public.is_checked_in(p_context_id, p_to)) then
      raise exception 'checkin_required' using errcode = 'P0001';
    end if;
  elsif p_context = 'nearby' then
    if not (public.is_checked_in(p_context_id, v_me) and public.is_checked_in(p_context_id, p_to))
       or coalesce(public.nearby_distance(p_context_id, v_me, p_to), 1e9) > 50 then
      raise exception 'not_nearby' using errcode = 'P0001';
    end if;
  elsif p_context = 'intent' then
    if not exists (select 1 from public.shared_plans
                   where (user_a = v_me and user_b = p_to) or (user_a = p_to and user_b = v_me)) then
      raise exception 'not_discoverable' using errcode = 'P0001';
    end if;
  else
    raise exception 'context_not_allowed' using errcode = 'P0001';
  end if;

  insert into public.connection_requests (from_user, to_user, context, context_id, message)
  values (v_me, p_to, p_context, p_context_id, nullif(trim(p_message), ''))
  returning * into r;
  return r;
end $$;

create or replace function public.respond_connection_request(p_request uuid, p_accept boolean)
returns public.connection_requests
language plpgsql security definer set search_path = '' as $$
declare
  r public.connection_requests;
begin
  select * into r from public.connection_requests where id = p_request for update;
  if not found or r.to_user <> auth.uid() then raise exception 'request_not_found' using errcode = 'P0001'; end if;
  if r.status <> 'pending' then
    -- Repeat clicks return the settled state instead of failing.
    if (p_accept and r.status = 'accepted') or (not p_accept and r.status = 'declined') then return r; end if;
    raise exception 'request_not_pending' using errcode = 'P0001';
  end if;
  if p_accept and public.is_blocked(r.from_user, r.to_user) then raise exception 'blocked' using errcode = 'P0001'; end if;

  update public.connection_requests
     set status = case when p_accept then 'accepted' else 'declined' end::public.request_status, responded_at = now()
   where id = p_request returning * into r;
  if p_accept then
    insert into public.connections (user_a, user_b, source_request_id)
    values (least(r.from_user, r.to_user), greatest(r.from_user, r.to_user), r.id)
    on conflict do nothing;
  end if;
  return r;
end $$;

create or replace function public.withdraw_connection_request(p_request uuid) returns void
language plpgsql security definer set search_path = '' as $$
begin
  update public.connection_requests set status = 'withdrawn', responded_at = now()
   where id = p_request and from_user = auth.uid() and status = 'pending';
  if not found then raise exception 'request_not_found' using errcode = 'P0001'; end if;
end $$;

create or replace function public.remove_connection(p_other uuid) returns void
language sql security definer set search_path = '' as $$
  delete from public.connections where user_a = least(auth.uid(), p_other) and user_b = greatest(auth.uid(), p_other)
$$;

create or replace function public.list_my_connections()
returns table (card jsonb, connected_at timestamptz)
language sql stable security definer set search_path = '' as $$
  select public.get_profile_card(case when c.user_a = auth.uid() then c.user_b else c.user_a end, 'general', null), c.created_at
  from public.connections c
  where c.user_a = auth.uid() or c.user_b = auth.uid()
  order by c.created_at desc
$$;

-- Pending requests to and from me, with the other person's card.
create or replace function public.list_my_requests()
returns table (id uuid, direction text, status text, context text, context_id uuid, message text,
               created_at timestamptz, card jsonb)
language sql stable security definer set search_path = '' as $$
  select r.id, case when r.from_user = auth.uid() then 'outgoing' else 'incoming' end, r.status::text,
         r.context::text, r.context_id, r.message, r.created_at,
         public.get_profile_card(case when r.from_user = auth.uid() then r.to_user else r.from_user end,
                                 case when r.context = 'event' then 'event' else 'general' end, r.context_id)
           || jsonb_build_object('display_name', p.display_name, 'avatar_url', p.avatar_url)
  from public.connection_requests r
  join public.profiles p on p.id = case when r.from_user = auth.uid() then r.to_user else r.from_user end
  where (r.from_user = auth.uid() or r.to_user = auth.uid()) and r.status = 'pending'
    and not public.is_blocked(r.from_user, r.to_user)
  order by r.created_at desc
$$;

create or replace function public.block_user(p_target uuid) returns void
language plpgsql security definer set search_path = '' as $$
declare
  v_me uuid := auth.uid();
begin
  if v_me is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  if p_target = v_me then raise exception 'cannot_block_self' using errcode = 'P0001'; end if;
  insert into public.blocks (blocker_id, blocked_id) values (v_me, p_target) on conflict do nothing;
  update public.connection_requests set status = 'withdrawn', responded_at = now()
   where status = 'pending' and least(from_user, to_user) = least(v_me, p_target) and greatest(from_user, to_user) = greatest(v_me, p_target);
  update public.match_invitations set status = 'withdrawn', responded_at = now()
   where status = 'pending' and ((from_user = v_me and to_user = p_target) or (from_user = p_target and to_user = v_me));
  delete from public.connections where user_a = least(v_me, p_target) and user_b = greatest(v_me, p_target);
end $$;

-- ---------------------------------------------------------------------------
-- Intents and matching (rule-based v0; /server/api/match can swap in A's algorithm later)
-- ---------------------------------------------------------------------------
create or replace function public.intents_compatible(p_a uuid, p_b uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.intents a, public.intents b
    where a.id = p_a and b.id = p_b and a.user_id <> b.user_id
      and a.status = 'open' and b.status = 'open'
      and a.expires_at > now() and b.expires_at > now()
      and lower(a.activity_type) = lower(b.activity_type)
      and tstzrange(a.window_start, a.window_end) && tstzrange(b.window_start, b.window_end)
      and (a.region = '' or b.region = '' or lower(a.region) = lower(b.region))
      and not public.is_blocked(a.user_id, b.user_id)
  )
$$;

create or replace function public.match_candidates(p_intent uuid)
returns table (intent_id uuid, card jsonb, activity_type text, window_start timestamptz, window_end timestamptz,
               region text, group_size int, budget_max int, note text, overlap_minutes int,
               shared_interests text[], score numeric, invitation_status text)
language plpgsql stable security definer set search_path = '' as $$
declare
  me public.intents;
begin
  select * into me from public.intents where id = p_intent and user_id = auth.uid();
  if not found then raise exception 'intent_not_found' using errcode = 'P0001'; end if;
  if not public.flag_enabled('intents') then raise exception 'feature_disabled' using errcode = 'P0001'; end if;
  return query
    with c as (
      select b.*,
             (extract(epoch from (least(me.window_end, b.window_end) - greatest(me.window_start, b.window_start))) / 60)::int as ov,
             array(select unnest(pa.interests) intersect select unnest(pb.interests)) as si
      from public.intents b
      join public.profiles pa on pa.id = me.user_id
      join public.profiles pb on pb.id = b.user_id
      where public.intents_compatible(me.id, b.id)
    )
    select c.id, public.get_profile_card(c.user_id, 'intent', c.id), c.activity_type, c.window_start, c.window_end,
           c.region, c.group_size, c.budget_max, c.note, c.ov, c.si,
           round((least(c.ov, 240) / 60.0 + coalesce(array_length(c.si, 1), 0) * 1.5
                  + case when c.group_size = me.group_size then 1 else 0 end)::numeric, 2),
           (select i.status::text from public.match_invitations i
             where least(i.from_intent_id, i.to_intent_id) = least(me.id, c.id)
               and greatest(i.from_intent_id, i.to_intent_id) = greatest(me.id, c.id)
             order by i.created_at desc limit 1)
    from c
    order by 12 desc, c.created_at desc
    limit 30;
end $$;

create or replace function public.send_match_invitation(p_from_intent uuid, p_to_intent uuid, p_message text default null)
returns public.match_invitations
language plpgsql security definer set search_path = '' as $$
declare
  a public.intents;
  b public.intents;
  i public.match_invitations;
begin
  select * into a from public.intents where id = p_from_intent and user_id = auth.uid();
  if not found then raise exception 'intent_not_found' using errcode = 'P0001'; end if;
  select * into b from public.intents where id = p_to_intent;
  if not found or not public.intents_compatible(a.id, b.id) then raise exception 'not_compatible' using errcode = 'P0001'; end if;

  select * into i from public.match_invitations
    where status = 'pending' and least(from_intent_id, to_intent_id) = least(a.id, b.id)
      and greatest(from_intent_id, to_intent_id) = greatest(a.id, b.id);
  if found then
    if i.from_user = auth.uid() then return i; end if;
    raise exception 'incoming_invitation_pending' using errcode = 'P0001';
  end if;

  insert into public.match_invitations (from_intent_id, to_intent_id, from_user, to_user, message)
  values (a.id, b.id, a.user_id, b.user_id, nullif(trim(p_message), ''))
  returning * into i;
  return i;
end $$;

create or replace function public.respond_match_invitation(p_invitation uuid, p_accept boolean)
returns uuid  -- shared plan id when accepted
language plpgsql security definer set search_path = '' as $$
declare
  i public.match_invitations;
  a public.intents;
  b public.intents;
  v_plan uuid;
begin
  select * into i from public.match_invitations where id = p_invitation for update;
  if not found or i.to_user <> auth.uid() then raise exception 'invitation_not_found' using errcode = 'P0001'; end if;
  if i.status = 'accepted' and p_accept then
    return (select id from public.shared_plans where invitation_id = i.id);
  end if;
  if i.status <> 'pending' then raise exception 'invitation_not_pending' using errcode = 'P0001'; end if;

  if not p_accept then
    update public.match_invitations set status = 'declined', responded_at = now() where id = i.id;
    return null;
  end if;

  select * into a from public.intents where id = i.from_intent_id;
  select * into b from public.intents where id = i.to_intent_id;
  if not public.intents_compatible(a.id, b.id) then raise exception 'not_compatible' using errcode = 'P0001'; end if;

  update public.match_invitations set status = 'accepted', responded_at = now() where id = i.id;
  insert into public.shared_plans (invitation_id, user_a, user_b, title, planned_at, place)
  values (i.id, i.from_user, i.to_user, a.activity_type, greatest(a.window_start, b.window_start),
          coalesce(nullif(a.region, ''), b.region))
  returning id into v_plan;
  -- Two-person intents are fulfilled; group intents stay open for more people.
  update public.intents set status = 'matched' where id in (a.id, b.id) and group_size = 2;
  return v_plan;
end $$;

create or replace function public.withdraw_match_invitation(p_invitation uuid) returns void
language plpgsql security definer set search_path = '' as $$
begin
  update public.match_invitations set status = 'withdrawn', responded_at = now()
   where id = p_invitation and from_user = auth.uid() and status = 'pending';
  if not found then raise exception 'invitation_not_found' using errcode = 'P0001'; end if;
end $$;

-- Changing time or place clears the other person's confirmation.
create or replace function public.update_shared_plan(p_plan uuid, p_planned_at timestamptz, p_place text)
returns public.shared_plans
language plpgsql security definer set search_path = '' as $$
declare
  s public.shared_plans;
begin
  select * into s from public.shared_plans where id = p_plan for update;
  if not found or auth.uid() not in (s.user_a, s.user_b) then raise exception 'plan_not_found' using errcode = 'P0001'; end if;
  if s.status = 'cancelled' then raise exception 'plan_cancelled' using errcode = 'P0001'; end if;
  update public.shared_plans
     set planned_at = p_planned_at, place = coalesce(p_place, ''), status = 'proposed',
         a_confirmed_at = case when auth.uid() = s.user_a then now() else null end,
         b_confirmed_at = case when auth.uid() = s.user_b then now() else null end
   where id = p_plan returning * into s;
  return s;
end $$;

create or replace function public.confirm_shared_plan(p_plan uuid) returns public.shared_plans
language plpgsql security definer set search_path = '' as $$
declare
  s public.shared_plans;
begin
  select * into s from public.shared_plans where id = p_plan for update;
  if not found or auth.uid() not in (s.user_a, s.user_b) then raise exception 'plan_not_found' using errcode = 'P0001'; end if;
  if s.status = 'cancelled' then raise exception 'plan_cancelled' using errcode = 'P0001'; end if;
  if s.planned_at is null then raise exception 'plan_time_required' using errcode = 'P0001'; end if;
  update public.shared_plans
     set a_confirmed_at = case when auth.uid() = user_a then coalesce(a_confirmed_at, now()) else a_confirmed_at end,
         b_confirmed_at = case when auth.uid() = user_b then coalesce(b_confirmed_at, now()) else b_confirmed_at end
   where id = p_plan returning * into s;
  if s.a_confirmed_at is not null and s.b_confirmed_at is not null and s.status <> 'confirmed' then
    update public.shared_plans set status = 'confirmed' where id = p_plan returning * into s;
  end if;
  return s;
end $$;

create or replace function public.cancel_shared_plan(p_plan uuid) returns void
language plpgsql security definer set search_path = '' as $$
begin
  update public.shared_plans set status = 'cancelled'
   where id = p_plan and auth.uid() in (user_a, user_b) and status <> 'cancelled';
  if not found then raise exception 'plan_not_found' using errcode = 'P0001'; end if;
end $$;

-- Both people report they met -> one mutually_reported_interaction record each.
create or replace function public.report_met(p_plan uuid) returns public.shared_plans
language plpgsql security definer set search_path = '' as $$
declare
  s public.shared_plans;
begin
  select * into s from public.shared_plans where id = p_plan for update;
  if not found or auth.uid() not in (s.user_a, s.user_b) then raise exception 'plan_not_found' using errcode = 'P0001'; end if;
  if s.status <> 'confirmed' then raise exception 'plan_not_confirmed' using errcode = 'P0001'; end if;
  if s.planned_at > now() + interval '1 hour' then raise exception 'plan_not_started' using errcode = 'P0001'; end if;
  update public.shared_plans
     set a_met_at = case when auth.uid() = user_a then coalesce(a_met_at, now()) else a_met_at end,
         b_met_at = case when auth.uid() = user_b then coalesce(b_met_at, now()) else b_met_at end
   where id = p_plan returning * into s;
  if s.a_met_at is not null and s.b_met_at is not null then
    insert into public.participation_evidence (shared_plan_id, subject_user_id, type, source, verification_status, occurred_at)
    values (s.id, s.user_a, 'mutually_reported_interaction', 'mutual_report', 'verified', greatest(s.a_met_at, s.b_met_at)),
           (s.id, s.user_b, 'mutually_reported_interaction', 'mutual_report', 'verified', greatest(s.a_met_at, s.b_met_at))
    on conflict (shared_plan_id, subject_user_id, type) where shared_plan_id is not null and verification_status <> 'revoked'
    do nothing;
  end if;
  return s;
end $$;

-- ---------------------------------------------------------------------------
-- Trust card: explainable facts only, no score.
-- ---------------------------------------------------------------------------
create or replace function public.trust_summary(p_user uuid default auth.uid()) returns jsonb
language plpgsql stable security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  if p_user <> auth.uid() and (public.is_blocked(auth.uid(), p_user) or not public.flag_enabled('trust_card')) then
    return null;
  end if;
  return jsonb_build_object(
    'intended_participation', (select count(*) from public.intents where user_id = p_user),
    'confirmed_rsvp', (select count(*) from public.event_rsvps r join public.events e on e.id = r.event_id
                        where r.user_id = p_user and r.status = 'going' and e.status <> 'cancelled'),
    'self_reported_presence', (select count(*) from public.participation_evidence
                               where subject_user_id = p_user and type = 'self_reported_presence'
                                 and verification_status in ('geo_verified', 'verified')),
    'organiser_confirmed_attendance', (select count(*) from public.participation_evidence
                                       where subject_user_id = p_user and type = 'organiser_confirmed_attendance'
                                         and verification_status = 'verified'),
    'mutually_reported_interaction', (select count(*) from public.participation_evidence
                                      where subject_user_id = p_user and type = 'mutually_reported_interaction'
                                        and verification_status = 'verified'),
    'disputed', (select count(*) from public.participation_evidence
                 where subject_user_id = p_user and verification_status = 'disputed')
  );
end $$;

-- My participation history for the profile page.
create or replace function public.my_participation_history()
returns table (evidence_id uuid, event_id uuid, event_title text, shared_plan_id uuid, type text, source text,
               verification_status text, occurred_at timestamptz, correction_status text)
language sql stable security definer set search_path = '' as $$
  select pe.id, pe.event_id, e.title, pe.shared_plan_id, pe.type::text, pe.source::text,
         pe.verification_status::text, pe.occurred_at,
         (select c.status::text from public.evidence_corrections c where c.evidence_id = pe.id order by c.created_at desc limit 1)
  from public.participation_evidence pe
  left join public.events e on e.id = pe.event_id
  where pe.subject_user_id = auth.uid()
  order by pe.occurred_at desc
$$;

-- ---------------------------------------------------------------------------
-- Admin
-- ---------------------------------------------------------------------------
create or replace function public.admin_resolve_correction(p_correction uuid, p_approve boolean,
                                                           p_new_status public.verification_status default null,
                                                           p_note text default null)
returns void
language plpgsql security definer set search_path = '' as $$
declare
  c public.evidence_corrections;
begin
  if not public.is_admin() then raise exception 'forbidden' using errcode = 'P0001'; end if;
  select * into c from public.evidence_corrections where id = p_correction for update;
  if not found or c.status <> 'pending' then raise exception 'correction_not_pending' using errcode = 'P0001'; end if;
  update public.evidence_corrections
     set status = case when p_approve then 'approved' else 'rejected' end::public.correction_status,
         resolved_by = auth.uid(), resolved_at = now(), resolution_note = p_note
   where id = p_correction;
  if p_approve and p_new_status is not null then
    update public.participation_evidence set verification_status = p_new_status where id = c.evidence_id;
  end if;
end $$;

create or replace function public.admin_set_evidence_status(p_evidence uuid, p_status public.verification_status, p_note text)
returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_admin() then raise exception 'forbidden' using errcode = 'P0001'; end if;
  if coalesce(trim(p_note), '') = '' then raise exception 'note_required' using errcode = 'P0001'; end if;
  update public.participation_evidence
     set verification_status = p_status, meta = meta || jsonb_build_object('admin_note', p_note)
   where id = p_evidence;
end $$;

create or replace function public.admin_update_report(p_report uuid, p_status public.report_status, p_note text default null)
returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_admin() then raise exception 'forbidden' using errcode = 'P0001'; end if;
  update public.reports set status = p_status, admin_note = p_note, handled_by = auth.uid(), handled_at = now()
   where id = p_report;
end $$;

-- Owners (or admins) add members to an organisation by e-mail.
create or replace function public.add_org_member(p_org uuid, p_email text, p_role public.org_role)
returns void
language plpgsql security definer set search_path = '' as $$
declare
  v_user uuid;
begin
  if not (public.is_admin() or public.org_role_of(p_org) = 'owner') then raise exception 'forbidden' using errcode = 'P0001'; end if;
  select id into v_user from auth.users where lower(email) = lower(trim(p_email));
  if v_user is null then raise exception 'user_not_found' using errcode = 'P0001'; end if;
  insert into public.org_members (org_id, user_id, role) values (p_org, v_user, p_role)
  on conflict (org_id, user_id) do update set role = excluded.role;
end $$;

create or replace function public.remove_org_member(p_org uuid, p_user uuid) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not (public.is_admin() or public.org_role_of(p_org) = 'owner') then raise exception 'forbidden' using errcode = 'P0001'; end if;
  delete from public.org_members where org_id = p_org and user_id = p_user;
end $$;

-- Organisations where I can create events.
create or replace function public.my_organisations()
returns table (org_id uuid, name text, role text)
language sql stable security definer set search_path = '' as $$
  select o.id, o.name, m.role::text from public.org_members m join public.organisations o on o.id = m.org_id
  where m.user_id = auth.uid() order by o.name
$$;

-- ---------------------------------------------------------------------------
-- Client access to RPCs
-- ---------------------------------------------------------------------------
-- Functions created above get EXECUTE for PUBLIC/anon by default (e.g. nearby_distance would let
-- anyone compute the distance between two users). Start from nothing again, then grant precisely.
revoke all on all functions in schema public from anon, authenticated, public;
grant execute on function public.is_admin(), public.is_school_verified(uuid), public.org_role_of(uuid, uuid),
  public.is_event_manager(uuid, uuid), public.is_event_staff(uuid, uuid), public.can_view_event(uuid),
  public.flag_enabled(text), public.is_going(uuid, uuid)
  to authenticated;
grant execute on function public.can_view_event(uuid), public.flag_enabled(text) to anon;
grant execute on function
  public.get_profile_card(uuid, text, uuid),
  public.join_event(uuid), public.leave_event(uuid), public.cancel_event(uuid),
  public.set_event_optin(uuid, boolean, text[]), public.list_event_participants(uuid), public.list_event_attendees(uuid),
  public.get_checkin_code(uuid), public.rotate_checkin_code(uuid), public.lookup_checkin_code(text),
  public.event_checkin(text, double precision, double precision, double precision),
  public.organiser_confirm_attendance(uuid, uuid, boolean),
  public.is_checked_in(uuid, uuid),
  public.update_nearby_presence(uuid, double precision, double precision, double precision), public.stop_nearby(uuid),
  public.list_nearby(uuid),
  public.send_connection_request(uuid, public.request_context, uuid, text), public.respond_connection_request(uuid, boolean),
  public.withdraw_connection_request(uuid), public.remove_connection(uuid), public.list_my_connections(),
  public.list_my_requests(), public.block_user(uuid),
  public.intents_compatible(uuid, uuid), public.match_candidates(uuid), public.send_match_invitation(uuid, uuid, text),
  public.respond_match_invitation(uuid, boolean), public.withdraw_match_invitation(uuid),
  public.update_shared_plan(uuid, timestamptz, text), public.confirm_shared_plan(uuid), public.cancel_shared_plan(uuid),
  public.report_met(uuid),
  public.trust_summary(uuid), public.my_participation_history(),
  public.admin_resolve_correction(uuid, boolean, public.verification_status, text),
  public.admin_set_evidence_status(uuid, public.verification_status, text),
  public.admin_update_report(uuid, public.report_status, text),
  public.add_org_member(uuid, text, public.org_role), public.remove_org_member(uuid, uuid),
  public.my_organisations()
to authenticated;
grant execute on function public.lookup_checkin_code(text) to anon;
