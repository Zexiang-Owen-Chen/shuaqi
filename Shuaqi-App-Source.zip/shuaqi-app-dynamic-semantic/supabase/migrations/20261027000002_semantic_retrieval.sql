create or replace function public.recommendation_search_candidates(
  p_from timestamptz default null,
  p_to timestamptz default null,
  p_embedding_model text default null,
  p_query_embedding text default null,
  p_limit int default 300,
  p_terms text[] default '{}',
  p_category text default null
)
returns table (
  id uuid, title text, category text, description text, starts_at timestamptz, ends_at timestamptz,
  location_text text, location_lat double precision, location_lng double precision, capacity int,
  going int, org_verified boolean, embedding_hash text, similarity double precision
)
language plpgsql stable security definer set search_path = '' as $$
declare
  v_uid uuid := auth.uid();
  v_q extensions.vector;
  v_terms text[];
begin
  if v_uid is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  if not public.flag_enabled('recommendations') then raise exception 'feature_disabled' using errcode = 'P0001'; end if;
  if p_query_embedding is not null then v_q := p_query_embedding::extensions.vector; end if;
  select coalesce(array_agg(t), '{}'::text[]) into v_terms
    from (select distinct left(btrim(x), 30) as t from unnest(p_terms) x
          where length(btrim(x)) between 2 and 30 limit 40) bounded;
  return query
    select e.id, e.title, e.category, e.description, e.starts_at, e.ends_at, e.location_text,
           e.location_lat, e.location_lng, e.capacity, g.going, coalesce(o.verified, false),
           emb.content_hash,
           case when v_q is not null and emb.embedding is not null
                     and extensions.vector_dims(emb.embedding) = extensions.vector_dims(v_q)
                then (1 - (emb.embedding operator(extensions.<=>) v_q))::double precision end
      from public.events e
      cross join lateral (select count(*)::int as going from public.event_rsvps r
                           where r.event_id = e.id and r.status = 'going') g
      left join public.organisations o on o.id = e.org_id
      left join public.event_embeddings emb on emb.event_id = e.id and emb.model = p_embedding_model
     where e.status = 'published'
       and (p_category is null or e.category = p_category)
       and coalesce(e.ends_at, e.starts_at + interval '3 hours') > now()
       and (p_to is null or e.starts_at <= p_to)
       and (p_from is null or coalesce(e.ends_at, e.starts_at + interval '3 hours') >= p_from)
       and (e.capacity is null or g.going < e.capacity)
       and public.can_view_event(e.id)
       and not public.is_blocked(v_uid, e.host_user_id)
       and not public.is_going(e.id, v_uid)
       and not exists (select 1 from public.recommendation_events d
                        where d.user_id = v_uid and d.event_id = e.id and d.kind = 'dismiss')
     -- Rank across all visible eligible events BEFORE limiting the candidate pool.
     order by greatest(
       coalesce((select max(case when strpos(lower(e.title || ' ' || e.category || ' ' || e.description), lower(t)) > 0 then 0.7 else 0 end)
                 from unnest(v_terms) t), 0),
       case when v_q is not null and emb.embedding is not null
                  and extensions.vector_dims(emb.embedding) = extensions.vector_dims(v_q)
            then greatest(0, 1 - (emb.embedding operator(extensions.<=>) v_q)) else 0 end
     ) desc, e.starts_at, e.id
     limit greatest(1, least(coalesce(p_limit, 300), 500));
end $$;
revoke execute on function public.recommendation_search_candidates(timestamptz,timestamptz,text,text,int,text[],text) from public, anon;
grant execute on function public.recommendation_search_candidates(timestamptz,timestamptz,text,text,int,text[],text) to authenticated;
