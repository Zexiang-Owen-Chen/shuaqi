-- KCL students use the same verified-school registration flow as the G5 schools.
insert into public.allowed_school_domains (domain, school_name, allow_subdomains, active)
values ('kcl.ac.uk', 'King''s College London', true, true)
on conflict (domain) do update set
  school_name = excluded.school_name,
  allow_subdomains = excluded.allow_subdomains,
  active = excluded.active;
