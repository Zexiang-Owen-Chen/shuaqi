-- UAL follows the existing verified-school flow, including school subdomains.
insert into public.allowed_school_domains (domain, school_name, allow_subdomains, active)
values ('ual.ac.uk', 'University of the Arts London', true, true)
on conflict (domain) do update set
  school_name = excluded.school_name,
  allow_subdomains = excluded.allow_subdomains,
  active = excluded.active;
