-- 附近 50m：补齐隐私与精度要求（迁移草稿，交核心线程合并，放在 20261019000003_rpc.sql 之后）
--
-- 1. 定位单独同意（UK GDPR）：新增 location_consents，未同意或已撤回时不接受位置；撤回立即删除位置。
-- 2. 位置 5 分钟后真正删除：原来只在有人上报时顺手清理，最后一个人离开后会残留；改为每分钟定时清理。
-- 3. 精度：精度差于 100m 的定位不参与 50m 判断（否则 500m 误差的定位也能“在 50m 内”）。
-- 4. 新鲜度：判断距离只用 2 分钟内的位置（页面每 30 秒上报一次），已经走开的人不再显示。
-- 5. 收回 nearby_distance 的直接调用权限（原来任何人都能查任意两人的距离）。
-- 新增错误码：location_consent_required（errors.ts 需加一行：'使用“附近的人”需要先同意使用你的位置'）。

-- ---------------------------------------------------------------------------
-- 定位同意记录
-- ---------------------------------------------------------------------------
create table public.location_consents (
  user_id uuid not null references public.profiles (id) on delete cascade,
  purpose text not null check (purpose in ('nearby')),
  policy_version text not null check (char_length(policy_version) between 1 and 40),
  granted_at timestamptz not null default now(),
  withdrawn_at timestamptz,
  primary key (user_id, purpose)
);

alter table public.location_consents enable row level security;
grant select on public.location_consents to authenticated;
create policy "own location consents" on public.location_consents for select to authenticated
  using (user_id = auth.uid());

create or replace function public.has_location_consent(p_user uuid, p_purpose text) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.location_consents
                 where user_id = p_user and purpose = p_purpose and withdrawn_at is null)
$$;

create or replace function public.grant_location_consent(p_purpose text, p_policy_version text) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  insert into public.location_consents (user_id, purpose, policy_version)
  values (auth.uid(), p_purpose, p_policy_version)
  on conflict (user_id, purpose) do update
    set policy_version = excluded.policy_version, granted_at = now(), withdrawn_at = null;
end $$;

create or replace function public.withdraw_location_consent(p_purpose text) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  update public.location_consents set withdrawn_at = now()
   where user_id = auth.uid() and purpose = p_purpose and withdrawn_at is null;
  if p_purpose = 'nearby' then
    delete from public.nearby_presence where user_id = auth.uid();
  end if;
end $$;

-- ---------------------------------------------------------------------------
-- 上报位置：加同意、坐标、精度、活动状态校验
-- ---------------------------------------------------------------------------
create or replace function public.update_nearby_presence(p_event uuid, p_lat double precision, p_lng double precision, p_accuracy double precision)
returns void
language plpgsql security definer set search_path = '' as $$
declare
  e public.events;
begin
  if auth.uid() is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  if not public.flag_enabled('nearby') then raise exception 'feature_disabled' using errcode = 'P0001'; end if;
  if not public.has_location_consent(auth.uid(), 'nearby') then
    raise exception 'location_consent_required' using errcode = 'P0001';
  end if;
  select * into e from public.events where id = p_event;
  if not found or e.status <> 'published' or now() > coalesce(e.ends_at, e.starts_at + interval '6 hours') then
    raise exception 'event_not_active' using errcode = 'P0001';
  end if;
  if not public.is_checked_in(p_event, auth.uid()) then raise exception 'checkin_required' using errcode = 'P0001'; end if;
  if p_lat is null or p_lng is null or p_lat not between -90 and 90 or p_lng not between -180 and 180 then
    raise exception 'location_required' using errcode = 'P0001';
  end if;
  if p_accuracy is null or p_accuracy <= 0 or p_accuracy > 100 then
    raise exception 'location_inaccurate' using errcode = 'P0001';
  end if;
  insert into public.nearby_presence (event_id, user_id, lat, lng, accuracy_m, updated_at)
  values (p_event, auth.uid(), p_lat, p_lng, p_accuracy, now())
  on conflict (event_id, user_id) do update
    set lat = excluded.lat, lng = excluded.lng, accuracy_m = excluded.accuracy_m, updated_at = now();
end $$;

-- ---------------------------------------------------------------------------
-- 距离：只用双方 2 分钟内、精度 ≤100m、同意仍有效的位置；否则返回 null（视为不在附近）。
-- send_connection_request(…, 'nearby', …) 和 list_nearby 都通过它判断，规则一处生效。
-- ---------------------------------------------------------------------------
create or replace function public.nearby_distance(p_event uuid, p_a uuid, p_b uuid) returns double precision
language sql stable security definer set search_path = '' as $$
  select public.distance_m(a.lat, a.lng, b.lat, b.lng)
  from public.nearby_presence a, public.nearby_presence b
  where a.event_id = p_event and b.event_id = p_event and a.user_id = p_a and b.user_id = p_b
    and a.updated_at > now() - interval '2 minutes' and b.updated_at > now() - interval '2 minutes'
    and a.accuracy_m <= 100 and b.accuracy_m <= 100
    and public.has_location_consent(p_a, 'nearby') and public.has_location_consent(p_b, 'nearby')
$$;

create or replace function public.list_nearby(p_event uuid)
returns table (card jsonb, distance_m int, request_status text)
language plpgsql stable security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  if not exists (select 1 from public.nearby_presence
                 where event_id = p_event and user_id = auth.uid() and updated_at > now() - interval '2 minutes') then
    raise exception 'nearby_not_active' using errcode = 'P0001';
  end if;
  return query
    select jsonb_build_object(
             'id', p.id, 'display_name', p.display_name, 'avatar_url', p.avatar_url,
             'school_domain', p.school_domain, 'school_verified', p.school_verified_at is not null,
             'connected', public.are_connected(auth.uid(), p.id)),
           (greatest(10, round(d.dist / 10) * 10))::int,
           (select cr.status::text from public.connection_requests cr
             where least(cr.from_user, cr.to_user) = least(auth.uid(), p.id)
               and greatest(cr.from_user, cr.to_user) = greatest(auth.uid(), p.id)
             order by cr.created_at desc limit 1)
    from public.nearby_presence n
    join public.profiles p on p.id = n.user_id
    cross join lateral (select public.nearby_distance(p_event, auth.uid(), n.user_id) as dist) d
    where n.event_id = p_event and n.user_id <> auth.uid()
      and d.dist <= 50
      and public.is_checked_in(p_event, n.user_id)
      and not public.is_blocked(auth.uid(), n.user_id)
    order by d.dist;
end $$;

-- ---------------------------------------------------------------------------
-- 5 分钟后删除（不保存轨迹）
-- ---------------------------------------------------------------------------
create or replace function public.purge_nearby_presence() returns int
language plpgsql security definer set search_path = '' as $$
declare n int;
begin
  delete from public.nearby_presence where updated_at < now() - interval '5 minutes';
  get diagnostics n = row_count;
  return n;
end $$;

-- Supabase 上需先在 Dashboard → Database → Extensions 开启 pg_cron；未开启时跳过，不影响迁移。
do $$
begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    perform cron.unschedule(jobid) from cron.job where jobname = 'purge_nearby_presence';
    perform cron.schedule('purge_nearby_presence', '* * * * *', 'select public.purge_nearby_presence()');
  end if;
end $$;

-- ---------------------------------------------------------------------------
-- 权限
-- ---------------------------------------------------------------------------
-- Postgres 默认把函数执行权授予 PUBLIC，Supabase 还会默认授予 anon/authenticated。
-- nearby_distance 是 security definer，若可直接调用，任何人都能查任意两人之间的距离，必须收回。
revoke execute on function public.nearby_distance(uuid, uuid, uuid), public.has_location_consent(uuid, text),
  public.purge_nearby_presence()
  from public, anon, authenticated;
revoke execute on function public.grant_location_consent(text, text), public.withdraw_location_consent(text)
  from public, anon;
grant execute on function public.grant_location_consent(text, text), public.withdraw_location_consent(text)
  to authenticated;
