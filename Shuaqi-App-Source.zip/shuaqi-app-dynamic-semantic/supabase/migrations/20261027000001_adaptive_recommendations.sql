-- Trusted point-in-time features. No raw GPS coordinates or search text are stored here.
create table public.recommendation_observations (
  user_id uuid not null references public.profiles(id) on delete cascade,
  event_id uuid not null references public.events(id) on delete cascade,
  request_id uuid not null,
  shown_at timestamptz not null default now(),
  position integer not null check (position between 0 and 100),
  features jsonb not null check (jsonb_typeof(features) = 'object'),
  algorithm_version text not null,
  primary key (user_id, request_id, event_id)
);
-- request_id deliberately has no FK: recommendation_requests are retained for only two days.
create index on public.recommendation_observations(user_id, shown_at desc);
create index on public.recommendation_observations(user_id, event_id, shown_at desc);
alter table public.recommendation_observations enable row level security;
revoke all on public.recommendation_observations from anon, authenticated;
grant select on public.recommendation_observations to authenticated;
grant select, insert, update, delete on public.recommendation_observations to service_role;
create policy "own recommendation snapshots" on public.recommendation_observations
  for select to authenticated using (user_id = auth.uid());

create function public.recommendation_weight_observations()
returns table(request_id uuid, event_id uuid, shown_at timestamptz, "position" integer,
              features jsonb, feedback text, feedback_at timestamptz)
language sql stable security definer set search_path = '' as $$
  with snapshots as (
    select s.* from public.recommendation_observations s
    where s.user_id = auth.uid() and s.shown_at > now() - interval '90 days'
    order by s.shown_at desc, s.request_id, s.position limit 1000
  )
  select s.request_id, s.event_id, s.shown_at, s.position, s.features, f.kind, f.at
  from snapshots s
  left join lateral (
    select a.kind, a.at from (
      -- Repeated clicks collapse to one outcome. Dismiss is stronger than click.
      select re.kind::text as kind, min(re.at) as at,
             case re.kind when 'dismiss' then 3 else 1 end as priority
      from public.recommendation_events re
      where re.user_id = auth.uid() and re.event_id = s.event_id and re.request_id = s.request_id
        and re.kind in ('click', 'dismiss') and re.at >= s.shown_at
        and re.at <= s.shown_at + interval '30 days' and re.at <= now()
      group by re.kind
      union all
      select case r.status when 'going' then 'join' else 'cancel_join' end, r.updated_at, 4
      from public.event_rsvps r
      where r.user_id = auth.uid() and r.event_id = s.event_id
        and r.updated_at >= s.shown_at and r.updated_at <= s.shown_at + interval '30 days'
        and r.updated_at <= now()
        and not exists (
          select 1 from public.recommendation_observations newer
          where newer.user_id = s.user_id and newer.event_id = s.event_id
            and newer.shown_at <= r.updated_at
            and (newer.shown_at, newer.request_id) > (s.shown_at, s.request_id)
        )
      union all
      select 'attend', pe.occurred_at, 5
      from public.participation_evidence pe
      where pe.subject_user_id = auth.uid() and pe.event_id = s.event_id
        and pe.verification_status in ('geo_verified', 'verified')
        and pe.occurred_at >= s.shown_at and pe.occurred_at <= s.shown_at + interval '30 days'
        and pe.occurred_at <= now()
        and not exists (
          select 1 from public.recommendation_observations newer
          where newer.user_id = s.user_id and newer.event_id = s.event_id
            and newer.shown_at <= pe.occurred_at
            and (newer.shown_at, newer.request_id) > (s.shown_at, s.request_id)
        )
    ) a order by a.priority desc, a.at desc limit 1
  ) f on true
$$;
revoke all on function public.recommendation_weight_observations() from public, anon;
grant execute on function public.recommendation_weight_observations() to authenticated;
