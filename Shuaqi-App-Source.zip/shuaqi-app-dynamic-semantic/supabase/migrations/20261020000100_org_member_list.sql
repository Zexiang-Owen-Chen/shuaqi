-- 主办方后台：组织成员名单。
-- org_members 只暴露 user_id，而 profiles 只有本人和 admin 可读，
-- 所以组织页面需要这个函数才能显示成员昵称。邮箱只返回给组织 owner 和 admin。
create or replace function public.list_org_members(p_org uuid)
returns table (user_id uuid, display_name text, avatar_url text, email text, role text, joined_at timestamptz)
language plpgsql stable security definer set search_path = '' as $$
declare
  v_can_see_email boolean := public.is_admin() or public.org_role_of(p_org) = 'owner';
begin
  if not (public.is_admin() or public.org_role_of(p_org) is not null) then
    raise exception 'forbidden' using errcode = 'P0001';
  end if;
  return query
    select m.user_id, p.display_name, p.avatar_url,
           case when v_can_see_email then u.email::text end,
           m.role::text, m.created_at
    from public.org_members m
    join public.profiles p on p.id = m.user_id
    join auth.users u on u.id = m.user_id
    where m.org_id = p_org
    order by case m.role when 'owner' then 0 when 'organiser' then 1 else 2 end, m.created_at;
end $$;

grant execute on function public.list_org_members(uuid) to authenticated;
