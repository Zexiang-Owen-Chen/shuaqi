-- Keep one canonical school identity for Imperial's full and short email domains.
-- The login page also normalizes the email before requesting/verifying an OTP.
create or replace function public.school_domain_for_email(p_email text)
returns text
language sql stable security definer set search_path = '' as $$
  select d.domain
  from public.allowed_school_domains d,
       lateral (
         select case lower(split_part(p_email, '@', 2))
           when 'ic.ac.uk' then 'imperial.ac.uk'
           else lower(split_part(p_email, '@', 2))
         end as host
       ) h
  where d.active
    and (h.host = d.domain or (d.allow_subdomains and h.host like '%.' || d.domain))
  order by length(d.domain) desc
  limit 1
$$;
