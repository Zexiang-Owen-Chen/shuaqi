-- Private event media: visible only to the uploader or viewers of the linked event.
alter table public.events add column image_paths text[] not null default '{}';
alter table public.events add constraint events_image_count check (cardinality(image_paths) <= 6);
grant insert (image_paths), update (image_paths) on public.events to authenticated;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('event-images', 'event-images', false, 5242880, array['image/jpeg', 'image/png', 'image/webp']);

create policy "event images upload own" on storage.objects for insert to authenticated
  with check (bucket_id = 'event-images' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "event images read visible" on storage.objects for select to anon, authenticated
  using (bucket_id = 'event-images' and (
    (storage.foldername(name))[1] = auth.uid()::text
    or exists (select 1 from public.events e where storage.objects.name = any(e.image_paths))
  ));

create or replace function public.validate_event_images() returns trigger
language plpgsql security definer set search_path = '' as $$
declare
  v_path text;
  v_previous text[] := '{}';
begin
  if tg_op = 'UPDATE' then
    if new.image_paths is not distinct from old.image_paths then return new; end if;
    v_previous := old.image_paths;
  end if;
  if cardinality(new.image_paths) > 6 then
    raise exception 'event_images_limit' using errcode = 'P0001';
  end if;
  if array_position(new.image_paths, null) is not null
     or (select count(distinct p) from unnest(new.image_paths) p) <> cardinality(new.image_paths) then
    raise exception 'event_images_invalid' using errcode = 'P0001';
  end if;
  foreach v_path in array new.image_paths loop
    if v_path !~ '^[0-9a-f-]{36}/[0-9a-f-]{36}\.(jpg|png|webp)$' then
      raise exception 'event_images_invalid' using errcode = 'P0001';
    end if;
    if auth.uid() is not null and not (v_path = any(v_previous))
       and split_part(v_path, '/', 1) <> auth.uid()::text then
      raise exception 'event_image_not_owned' using errcode = 'P0001';
    end if;
    if not exists (select 1 from storage.objects where bucket_id = 'event-images' and name = v_path) then
      raise exception 'event_images_invalid' using errcode = 'P0001';
    end if;
  end loop;
  return new;
end $$;
revoke all on function public.validate_event_images() from public, anon, authenticated;
create trigger events_images_validate before insert or update of image_paths on public.events
for each row execute function public.validate_event_images();
