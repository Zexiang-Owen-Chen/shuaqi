-- SHUAQI V0 core schema: types, tables, indexes.
-- Every write that creates or upgrades evidence, connections or plans goes through
-- security-definer functions (see 20261019000003_rpc.sql); tables only expose reads via RLS.

create extension if not exists pgcrypto with schema extensions;

-- ---------------------------------------------------------------------------
-- Enums
-- ---------------------------------------------------------------------------
create type public.app_role as enum ('user', 'admin');
create type public.event_type as enum ('peer', 'group');
create type public.event_visibility as enum ('public', 'school');
create type public.event_status as enum ('draft', 'published', 'cancelled', 'ended');
create type public.checkin_mode as enum ('none', 'qr_geo', 'manual');
create type public.rsvp_status as enum ('going', 'cancelled');
create type public.org_role as enum ('owner', 'organiser', 'staff');
create type public.request_status as enum ('pending', 'accepted', 'declined', 'withdrawn');
create type public.request_context as enum ('event', 'nearby', 'intent', 'profile');
create type public.intent_status as enum ('open', 'matched', 'withdrawn');
create type public.invitation_status as enum ('pending', 'accepted', 'declined', 'withdrawn');
create type public.plan_status as enum ('proposed', 'confirmed', 'cancelled');
create type public.evidence_type as enum (
  'self_reported_presence',
  'organiser_confirmed_attendance',
  'mutually_reported_interaction'
);
create type public.evidence_source as enum ('qr_geo', 'organiser_manual', 'mutual_report');
create type public.verification_status as enum ('unverified', 'geo_verified', 'verified', 'disputed', 'revoked');
create type public.correction_status as enum ('pending', 'approved', 'rejected');
create type public.report_status as enum ('open', 'reviewing', 'resolved', 'dismissed');
create type public.report_target as enum ('user', 'event', 'intent', 'evidence');

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------
create or replace function public.set_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

-- Great-circle distance in metres.
create or replace function public.distance_m(lat1 double precision, lng1 double precision,
                                             lat2 double precision, lng2 double precision)
returns double precision
language sql immutable parallel safe as $$
  select 2 * 6371000 * asin(sqrt(
    power(sin(radians(lat2 - lat1) / 2), 2) +
    cos(radians(lat1)) * cos(radians(lat2)) * power(sin(radians(lng2 - lng1) / 2), 2)
  ))
$$;

-- ---------------------------------------------------------------------------
-- Schools and profiles
-- ---------------------------------------------------------------------------
create table public.allowed_school_domains (
  domain text primary key check (domain = lower(domain)),
  school_name text not null,
  allow_subdomains boolean not null default true,
  active boolean not null default true
);

-- UK G5 (confirmed by the founder). Oxford student mail often uses college subdomains.
insert into public.allowed_school_domains (domain, school_name) values
  ('ox.ac.uk', 'University of Oxford'),
  ('cam.ac.uk', 'University of Cambridge'),
  ('imperial.ac.uk', 'Imperial College London'),
  ('ucl.ac.uk', 'University College London'),
  ('lse.ac.uk', 'London School of Economics');

create table public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  display_name text not null default '' check (char_length(display_name) <= 40),
  avatar_url text,
  gender text check (gender in ('female', 'male', 'non_binary', 'prefer_not_to_say')),
  birth_year int check (birth_year between 1900 and 2100),
  region text check (char_length(region) <= 60),
  bio text check (char_length(bio) <= 500),
  interests text[] not null default '{}',
  -- Per-field visibility: public | connections | hidden. Keys: bio, interests, photos, gender, age, region.
  visibility jsonb not null default
    '{"bio":"public","interests":"public","photos":"public","gender":"public","age":"public","region":"public"}',
  school_domain text references public.allowed_school_domains (domain),
  school_verified_at timestamptz,
  role public.app_role not null default 'user',
  onboarded boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger profiles_updated_at before update on public.profiles
  for each row execute function public.set_updated_at();

create table public.profile_photos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  storage_path text not null,
  sort int not null default 0,
  created_at timestamptz not null default now()
);
create index on public.profile_photos (user_id, sort);

create table public.blocks (
  blocker_id uuid not null references public.profiles (id) on delete cascade,
  blocked_id uuid not null references public.profiles (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id),
  check (blocker_id <> blocked_id)
);
create index on public.blocks (blocked_id);

-- ---------------------------------------------------------------------------
-- Organisations and events
-- ---------------------------------------------------------------------------
create table public.organisations (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 80),
  verified boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.org_members (
  org_id uuid not null references public.organisations (id) on delete cascade,
  user_id uuid not null references public.profiles (id) on delete cascade,
  role public.org_role not null,
  created_at timestamptz not null default now(),
  primary key (org_id, user_id)
);
create index on public.org_members (user_id);

create table public.events (
  id uuid primary key default gen_random_uuid(),
  host_user_id uuid not null references public.profiles (id),
  org_id uuid references public.organisations (id),
  type public.event_type not null default 'peer',
  category text not null check (char_length(category) between 1 and 30),
  title text not null check (char_length(title) between 1 and 80),
  description text not null default '' check (char_length(description) <= 2000),
  starts_at timestamptz not null,
  ends_at timestamptz,
  location_text text not null default '' check (char_length(location_text) <= 200),
  location_lat double precision check (location_lat between -90 and 90),
  location_lng double precision check (location_lng between -180 and 180),
  checkin_radius_m int not null default 100 check (checkin_radius_m between 20 and 1000),
  checkin_mode public.checkin_mode not null default 'qr_geo',
  checkin_opens_at timestamptz,
  checkin_closes_at timestamptz,
  require_checkin_for_connect boolean not null default false,
  capacity int check (capacity is null or capacity between 2 and 5000),
  visibility public.event_visibility not null default 'public',
  status public.event_status not null default 'published',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (ends_at is null or ends_at > starts_at),
  check (checkin_mode <> 'qr_geo' or (location_lat is not null and location_lng is not null))
);
create index on public.events (status, starts_at);
create index on public.events (host_user_id);
create index on public.events (org_id);
create trigger events_updated_at before update on public.events
  for each row execute function public.set_updated_at();

create table public.event_rsvps (
  event_id uuid not null references public.events (id) on delete cascade,
  user_id uuid not null references public.profiles (id) on delete cascade,
  status public.rsvp_status not null default 'going',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (event_id, user_id)
);
create index on public.event_rsvps (user_id);
create trigger event_rsvps_updated_at before update on public.event_rsvps
  for each row execute function public.set_updated_at();

-- Opt-in to in-event social discovery. Off unless a row says opted_in = true.
create table public.event_social_optin (
  event_id uuid not null references public.events (id) on delete cascade,
  user_id uuid not null references public.profiles (id) on delete cascade,
  opted_in boolean not null default false,
  visible_fields text[] not null default '{interests}',
  updated_at timestamptz not null default now(),
  primary key (event_id, user_id)
);

-- One static check-in code per event; organisers can rotate it.
create table public.event_checkin_codes (
  event_id uuid primary key references public.events (id) on delete cascade,
  code text not null unique,
  rotated_at timestamptz not null default now()
);

-- Last known position for "people within 50m". Rows older than 5 minutes are ignored and purged.
create table public.nearby_presence (
  event_id uuid not null references public.events (id) on delete cascade,
  user_id uuid not null references public.profiles (id) on delete cascade,
  lat double precision not null,
  lng double precision not null,
  accuracy_m double precision not null,
  updated_at timestamptz not null default now(),
  primary key (event_id, user_id)
);

-- ---------------------------------------------------------------------------
-- Connections
-- ---------------------------------------------------------------------------
create table public.connection_requests (
  id uuid primary key default gen_random_uuid(),
  from_user uuid not null references public.profiles (id) on delete cascade,
  to_user uuid not null references public.profiles (id) on delete cascade,
  context public.request_context not null,
  context_id uuid,
  message text check (char_length(message) <= 200),
  status public.request_status not null default 'pending',
  created_at timestamptz not null default now(),
  responded_at timestamptz,
  check (from_user <> to_user)
);
-- At most one pending request per unordered pair.
create unique index connection_requests_one_pending
  on public.connection_requests (least(from_user, to_user), greatest(from_user, to_user))
  where status = 'pending';
create index on public.connection_requests (to_user, status);
create index on public.connection_requests (from_user, status);

create table public.connections (
  user_a uuid not null references public.profiles (id) on delete cascade,
  user_b uuid not null references public.profiles (id) on delete cascade,
  source_request_id uuid references public.connection_requests (id),
  created_at timestamptz not null default now(),
  primary key (user_a, user_b),
  check (user_a < user_b)
);
create index on public.connections (user_b);

-- ---------------------------------------------------------------------------
-- Intents, invitations, shared plans
-- ---------------------------------------------------------------------------
create table public.intents (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  activity_type text not null check (char_length(activity_type) between 1 and 30),
  window_start timestamptz not null,
  window_end timestamptz not null,
  region text not null default '' check (char_length(region) <= 60),
  group_size int not null default 2 check (group_size between 2 and 20),
  budget_max int check (budget_max is null or budget_max >= 0),
  note text not null default '' check (char_length(note) <= 300),
  expires_at timestamptz not null,
  status public.intent_status not null default 'open',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (window_end > window_start),
  check (expires_at <= window_end)
);
create index on public.intents (status, activity_type, expires_at);
create index on public.intents (user_id);
create trigger intents_updated_at before update on public.intents
  for each row execute function public.set_updated_at();

create table public.match_invitations (
  id uuid primary key default gen_random_uuid(),
  from_intent_id uuid not null references public.intents (id) on delete cascade,
  to_intent_id uuid not null references public.intents (id) on delete cascade,
  from_user uuid not null references public.profiles (id) on delete cascade,
  to_user uuid not null references public.profiles (id) on delete cascade,
  message text check (char_length(message) <= 200),
  status public.invitation_status not null default 'pending',
  created_at timestamptz not null default now(),
  responded_at timestamptz,
  check (from_user <> to_user)
);
create unique index match_invitations_one_pending
  on public.match_invitations (least(from_intent_id, to_intent_id), greatest(from_intent_id, to_intent_id))
  where status = 'pending';
create index on public.match_invitations (to_user, status);
create index on public.match_invitations (from_user, status);

create table public.shared_plans (
  id uuid primary key default gen_random_uuid(),
  invitation_id uuid not null unique references public.match_invitations (id),
  user_a uuid not null references public.profiles (id) on delete cascade,
  user_b uuid not null references public.profiles (id) on delete cascade,
  title text not null,
  planned_at timestamptz,
  place text not null default '',
  status public.plan_status not null default 'proposed',
  a_confirmed_at timestamptz,
  b_confirmed_at timestamptz,
  a_met_at timestamptz,
  b_met_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on public.shared_plans (user_a);
create index on public.shared_plans (user_b);
create trigger shared_plans_updated_at before update on public.shared_plans
  for each row execute function public.set_updated_at();

-- ---------------------------------------------------------------------------
-- Participation evidence
-- ---------------------------------------------------------------------------
create table public.participation_evidence (
  id uuid primary key default gen_random_uuid(),
  event_id uuid references public.events (id) on delete cascade,
  shared_plan_id uuid references public.shared_plans (id) on delete cascade,
  subject_user_id uuid not null references public.profiles (id) on delete cascade,
  type public.evidence_type not null,
  source public.evidence_source not null,
  operator_id uuid references public.profiles (id),
  verification_status public.verification_status not null,
  geo_distance_m double precision,
  geo_accuracy_m double precision,
  occurred_at timestamptz not null default now(),
  meta jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (event_id is not null or shared_plan_id is not null)
);
-- Repeated check-ins never create a second live record.
create unique index participation_evidence_event_once
  on public.participation_evidence (event_id, subject_user_id, type)
  where event_id is not null and verification_status <> 'revoked';
create unique index participation_evidence_plan_once
  on public.participation_evidence (shared_plan_id, subject_user_id, type)
  where shared_plan_id is not null and verification_status <> 'revoked';
create index on public.participation_evidence (subject_user_id);
create trigger participation_evidence_updated_at before update on public.participation_evidence
  for each row execute function public.set_updated_at();

create table public.evidence_corrections (
  id uuid primary key default gen_random_uuid(),
  evidence_id uuid not null references public.participation_evidence (id) on delete cascade,
  requested_by uuid not null references public.profiles (id) on delete cascade,
  reason text not null check (char_length(reason) between 1 and 1000),
  status public.correction_status not null default 'pending',
  resolved_by uuid references public.profiles (id),
  resolved_at timestamptz,
  resolution_note text,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- Safety and admin
-- ---------------------------------------------------------------------------
create table public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles (id) on delete cascade,
  target_type public.report_target not null,
  target_id uuid not null,
  reason text not null check (char_length(reason) between 1 and 60),
  details text not null default '' check (char_length(details) <= 2000),
  status public.report_status not null default 'open',
  handled_by uuid references public.profiles (id),
  handled_at timestamptz,
  admin_note text,
  created_at timestamptz not null default now()
);
create index on public.reports (status, created_at);

create table public.audit_log (
  id bigint generated always as identity primary key,
  actor_id uuid,
  action text not null,
  table_name text not null,
  row_id text,
  before jsonb,
  after jsonb,
  at timestamptz not null default now()
);
create index on public.audit_log (table_name, row_id);

create table public.feature_flags (
  key text primary key,
  enabled boolean not null default true,
  description text not null default ''
);
insert into public.feature_flags (key, description) values
  ('intents', 'Intent posting and buddy matching'),
  ('event_discovery', 'In-event opt-in participant list'),
  ('nearby', 'People within 50m (geolocation)'),
  ('qr_checkin', 'Static QR + GPS self check-in'),
  ('trust_card', 'Participation facts on profiles'),
  ('peer_event_creation', 'Ordinary users can create events');
