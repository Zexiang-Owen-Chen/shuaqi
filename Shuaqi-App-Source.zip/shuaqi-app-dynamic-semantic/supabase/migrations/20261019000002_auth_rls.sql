-- Sign-up gate, permission helpers, row level security, grants, storage buckets, audit triggers.

-- ---------------------------------------------------------------------------
-- School e-mail gate on auth.users
-- ---------------------------------------------------------------------------
create or replace function public.school_domain_for_email(p_email text)
returns text
language sql stable security definer set search_path = '' as $$
  select d.domain
  from public.allowed_school_domains d,
       lateral (select lower(split_part(p_email, '@', 2)) as host) h
  where d.active
    and (h.host = d.domain or (d.allow_subdomains and h.host like '%.' || d.domain))
  order by length(d.domain) desc
  limit 1
$$;

create or replace function public.auth_user_before_insert() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if new.email is null or public.school_domain_for_email(new.email) is null then
    raise exception 'school_email_required' using errcode = 'P0001';
  end if;
  return new;
end $$;

create or replace function public.auth_user_after_insert() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, school_domain, school_verified_at)
  values (new.id, public.school_domain_for_email(new.email), new.email_confirmed_at)
  on conflict (id) do nothing;
  return new;
end $$;

-- Verified only once the e-mail OTP / link has been confirmed by Supabase Auth.
create or replace function public.auth_user_after_update() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if new.email_confirmed_at is not null and old.email_confirmed_at is distinct from new.email_confirmed_at then
    update public.profiles
       set school_verified_at = new.email_confirmed_at,
           school_domain = public.school_domain_for_email(new.email)
     where id = new.id;
  end if;
  return new;
end $$;

create trigger shuaqi_before_insert before insert on auth.users
  for each row execute function public.auth_user_before_insert();
create trigger shuaqi_after_insert after insert on auth.users
  for each row execute function public.auth_user_after_insert();
create trigger shuaqi_after_update after update of email_confirmed_at on auth.users
  for each row execute function public.auth_user_after_update();

-- ---------------------------------------------------------------------------
-- Permission helpers (security definer so policies can call them without recursion)
-- ---------------------------------------------------------------------------
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
$$;

create or replace function public.is_school_verified(p_user uuid default auth.uid()) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.profiles where id = p_user and school_verified_at is not null)
$$;

create or replace function public.org_role_of(p_org uuid, p_user uuid default auth.uid())
returns public.org_role
language sql stable security definer set search_path = '' as $$
  select role from public.org_members where org_id = p_org and user_id = p_user
$$;

-- Host, or owner/organiser of the event's organisation.
create or replace function public.is_event_manager(p_event uuid, p_user uuid default auth.uid()) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.events e
    where e.id = p_event
      and (e.host_user_id = p_user
           or (e.org_id is not null and exists (
                 select 1 from public.org_members m
                 where m.org_id = e.org_id and m.user_id = p_user and m.role in ('owner', 'organiser'))))
  )
$$;

-- Managers plus organisation staff.
create or replace function public.is_event_staff(p_event uuid, p_user uuid default auth.uid()) returns boolean
language sql stable security definer set search_path = '' as $$
  select public.is_event_manager(p_event, p_user) or exists (
    select 1 from public.events e
    join public.org_members m on m.org_id = e.org_id
    where e.id = p_event and m.user_id = p_user
  )
$$;

create or replace function public.is_blocked(p_a uuid, p_b uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.blocks
    where (blocker_id = p_a and blocked_id = p_b) or (blocker_id = p_b and blocked_id = p_a)
  )
$$;

create or replace function public.are_connected(p_a uuid, p_b uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.connections
    where user_a = least(p_a, p_b) and user_b = greatest(p_a, p_b)
  )
$$;

create or replace function public.is_going(p_event uuid, p_user uuid default auth.uid()) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.event_rsvps where event_id = p_event and user_id = p_user and status = 'going'
  )
$$;

-- Whether the viewer may see an event at all.
create or replace function public.can_view_event(p_event uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.events e
    where e.id = p_event
      and (
        (e.status <> 'draft' and (
           e.visibility = 'public'
           or (e.visibility = 'school' and exists (
                 select 1 from public.profiles me, public.profiles host
                 where me.id = auth.uid() and host.id = e.host_user_id
                   and me.school_domain = host.school_domain))))
        or e.host_user_id = auth.uid()
        or (e.org_id is not null and public.org_role_of(e.org_id) is not null)
        or public.is_admin()
      )
  )
$$;

create or replace function public.flag_enabled(p_key text) returns boolean
language sql stable security definer set search_path = '' as $$
  select coalesce((select enabled from public.feature_flags where key = p_key), false)
$$;

-- ---------------------------------------------------------------------------
-- Audit
-- ---------------------------------------------------------------------------
create or replace function public.audit_row() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  insert into public.audit_log (actor_id, action, table_name, row_id, before, after)
  values (
    auth.uid(),
    lower(tg_op),
    tg_table_name,
    coalesce((case when tg_op = 'DELETE' then to_jsonb(old) else to_jsonb(new) end) ->> 'id',
             (case when tg_op = 'DELETE' then to_jsonb(old) else to_jsonb(new) end) ->> 'event_id'),
    case when tg_op = 'INSERT' then null else to_jsonb(old) end,
    case when tg_op = 'DELETE' then null else to_jsonb(new) end
  );
  return coalesce(new, old);
end $$;

create trigger audit_participation_evidence after insert or update or delete on public.participation_evidence
  for each row execute function public.audit_row();
create trigger audit_evidence_corrections after update on public.evidence_corrections
  for each row execute function public.audit_row();
create trigger audit_org_members after insert or update or delete on public.org_members
  for each row execute function public.audit_row();
create trigger audit_reports after update on public.reports
  for each row execute function public.audit_row();
create trigger audit_feature_flags after update on public.feature_flags
  for each row execute function public.audit_row();
create trigger audit_profile_role after update of role on public.profiles
  for each row when (old.role is distinct from new.role) execute function public.audit_row();
create trigger audit_event_status after update of status on public.events
  for each row when (old.status is distinct from new.status) execute function public.audit_row();

-- ---------------------------------------------------------------------------
-- Event write guards
-- ---------------------------------------------------------------------------
create or replace function public.events_guard() returns trigger
language plpgsql security definer set search_path = '' as $$
declare
  v_going int;
begin
  if tg_op = 'INSERT' then
    if auth.uid() is not null and not public.is_admin() then
      if new.host_user_id <> auth.uid() then
        raise exception 'host_must_be_self' using errcode = 'P0001';
      end if;
      if not public.is_school_verified() then
        raise exception 'school_verification_required' using errcode = 'P0001';
      end if;
      if new.org_id is not null and coalesce(public.org_role_of(new.org_id)::text, '') not in ('owner', 'organiser') then
        raise exception 'not_org_organiser' using errcode = 'P0001';
      end if;
      if new.org_id is null and not public.flag_enabled('peer_event_creation') then
        raise exception 'feature_disabled' using errcode = 'P0001';
      end if;
    end if;
    if new.starts_at < now() - interval '1 hour' then
      raise exception 'starts_in_past' using errcode = 'P0001';
    end if;
    return new;
  end if;

  -- UPDATE
  if not public.is_admin() then
    if new.host_user_id <> old.host_user_id or new.org_id is distinct from old.org_id then
      raise exception 'immutable_owner' using errcode = 'P0001';
    end if;
  end if;
  if old.status = 'cancelled' and new.status <> 'cancelled' then
    raise exception 'event_cancelled' using errcode = 'P0001';
  end if;
  if new.capacity is not null and new.capacity is distinct from old.capacity then
    select count(*) into v_going from public.event_rsvps where event_id = new.id and status = 'going';
    if v_going > new.capacity then
      raise exception 'capacity_below_going' using errcode = 'P0001';
    end if;
  end if;
  return new;
end $$;

create trigger events_guard before insert or update on public.events
  for each row execute function public.events_guard();

create or replace function public.events_after_insert() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  insert into public.event_checkin_codes (event_id, code)
  values (new.id, encode(extensions.gen_random_bytes(16), 'hex'));
  -- The host attends their own event.
  insert into public.event_rsvps (event_id, user_id, status) values (new.id, new.host_user_id, 'going')
  on conflict do nothing;
  return new;
end $$;

create trigger events_after_insert after insert on public.events
  for each row execute function public.events_after_insert();

-- ---------------------------------------------------------------------------
-- Row level security
-- ---------------------------------------------------------------------------
alter table public.allowed_school_domains enable row level security;
alter table public.profiles enable row level security;
alter table public.profile_photos enable row level security;
alter table public.blocks enable row level security;
alter table public.organisations enable row level security;
alter table public.org_members enable row level security;
alter table public.events enable row level security;
alter table public.event_rsvps enable row level security;
alter table public.event_social_optin enable row level security;
alter table public.event_checkin_codes enable row level security;
alter table public.nearby_presence enable row level security;
alter table public.connection_requests enable row level security;
alter table public.connections enable row level security;
alter table public.intents enable row level security;
alter table public.match_invitations enable row level security;
alter table public.shared_plans enable row level security;
alter table public.participation_evidence enable row level security;
alter table public.evidence_corrections enable row level security;
alter table public.reports enable row level security;
alter table public.audit_log enable row level security;
alter table public.feature_flags enable row level security;

-- Start from nothing for clients, then grant precisely.
revoke all on all tables in schema public from anon, authenticated;
revoke all on all functions in schema public from anon, authenticated, public;

grant select on public.allowed_school_domains, public.feature_flags to anon, authenticated;
create policy "domains readable" on public.allowed_school_domains for select using (true);
create policy "flags readable" on public.feature_flags for select using (true);
grant update (enabled) on public.feature_flags to authenticated;
create policy "flags admin update" on public.feature_flags for update to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- Profiles: a user reads and edits their own row; others go through get_profile_card().
grant select on public.profiles to authenticated;
grant update (display_name, avatar_url, gender, birth_year, region, bio, interests, visibility, onboarded)
  on public.profiles to authenticated;
create policy "own profile read" on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_admin());
create policy "own profile update" on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

grant select, insert, delete on public.profile_photos to authenticated;
create policy "own photos" on public.profile_photos for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

grant select, insert, delete on public.blocks to authenticated;
create policy "own blocks read" on public.blocks for select to authenticated using (blocker_id = auth.uid());
create policy "own blocks delete" on public.blocks for delete to authenticated using (blocker_id = auth.uid());
-- Inserts go through block_user() so pending requests and connections are cleaned up.

grant select on public.organisations to authenticated;
create policy "orgs readable" on public.organisations for select to authenticated using (true);
grant insert, update on public.organisations to authenticated;
create policy "orgs admin insert" on public.organisations for insert to authenticated with check (public.is_admin());
create policy "orgs admin update" on public.organisations for update to authenticated
  using (public.is_admin()) with check (public.is_admin());

grant select on public.org_members to authenticated;
create policy "org members readable by members" on public.org_members for select to authenticated
  using (user_id = auth.uid() or public.org_role_of(org_id) is not null or public.is_admin());

grant select on public.events to anon, authenticated;
grant insert (host_user_id, org_id, type, category, title, description, starts_at, ends_at, location_text,
              location_lat, location_lng, checkin_radius_m, checkin_mode, checkin_opens_at, checkin_closes_at,
              require_checkin_for_connect, capacity, visibility)
  on public.events to authenticated;
grant update (category, title, description, starts_at, ends_at, location_text, location_lat, location_lng,
              checkin_radius_m, checkin_mode, checkin_opens_at, checkin_closes_at, require_checkin_for_connect,
              capacity, visibility, status)
  on public.events to authenticated;
create policy "events public to anon" on public.events for select to anon
  using (status <> 'draft' and visibility = 'public');
-- host_user_id is checked inline because can_view_event() re-reads events and cannot see a row
-- inserted by the same statement (insert ... returning / .insert().select() would fail RLS).
create policy "events visible" on public.events for select to authenticated
  using (host_user_id = auth.uid() or public.can_view_event(id));
create policy "events create" on public.events for insert to authenticated with check (host_user_id = auth.uid());
create policy "events manage" on public.events for update to authenticated
  using (public.is_event_manager(id) or public.is_admin())
  with check (public.is_event_manager(id) or public.is_admin());

-- RSVPs are written by join_event()/leave_event() only.
grant select on public.event_rsvps to authenticated;
create policy "rsvps own or staff" on public.event_rsvps for select to authenticated
  using (user_id = auth.uid() or public.is_event_staff(event_id) or public.is_admin());

grant select on public.event_social_optin to authenticated;
create policy "optin own" on public.event_social_optin for select to authenticated using (user_id = auth.uid());

grant select on public.event_checkin_codes to authenticated;
create policy "checkin code staff" on public.event_checkin_codes for select to authenticated
  using (public.is_event_staff(event_id));

-- nearby_presence: no client access; list_nearby() reads it.

grant select on public.connection_requests to authenticated;
create policy "requests own" on public.connection_requests for select to authenticated
  using (from_user = auth.uid() or to_user = auth.uid());

grant select on public.connections to authenticated;
create policy "connections own" on public.connections for select to authenticated
  using (user_a = auth.uid() or user_b = auth.uid());

grant select, insert on public.intents to authenticated;
grant update (activity_type, window_start, window_end, region, group_size, budget_max, note, expires_at, status)
  on public.intents to authenticated;
create policy "intents own read" on public.intents for select to authenticated using (user_id = auth.uid());
create policy "intents own insert" on public.intents for insert to authenticated
  with check (user_id = auth.uid() and public.is_school_verified() and public.flag_enabled('intents'));
create policy "intents own update" on public.intents for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

grant select on public.match_invitations to authenticated;
create policy "invitations own" on public.match_invitations for select to authenticated
  using (from_user = auth.uid() or to_user = auth.uid());

grant select on public.shared_plans to authenticated;
create policy "plans own" on public.shared_plans for select to authenticated
  using (user_a = auth.uid() or user_b = auth.uid());

-- Evidence is read-only for every client role.
grant select on public.participation_evidence to authenticated;
create policy "evidence subject or staff" on public.participation_evidence for select to authenticated
  using (subject_user_id = auth.uid()
         or (event_id is not null and public.is_event_staff(event_id))
         or public.is_admin());

grant select, insert on public.evidence_corrections to authenticated;
create policy "corrections own read" on public.evidence_corrections for select to authenticated
  using (requested_by = auth.uid() or public.is_admin());
create policy "corrections own insert" on public.evidence_corrections for insert to authenticated
  with check (requested_by = auth.uid() and status = 'pending' and exists (
    select 1 from public.participation_evidence pe
    where pe.id = evidence_id and pe.subject_user_id = auth.uid()));

grant select, insert on public.reports to authenticated;
create policy "reports own read" on public.reports for select to authenticated
  using (reporter_id = auth.uid() or public.is_admin());
create policy "reports own insert" on public.reports for insert to authenticated
  with check (reporter_id = auth.uid() and status = 'open' and handled_by is null);

grant select on public.audit_log to authenticated;
create policy "audit admin" on public.audit_log for select to authenticated using (public.is_admin());

-- Helper functions used inside policies must be callable by clients.
grant execute on function public.is_admin(), public.is_school_verified(uuid), public.org_role_of(uuid, uuid),
  public.is_event_manager(uuid, uuid), public.is_event_staff(uuid, uuid), public.can_view_event(uuid),
  public.flag_enabled(text), public.is_going(uuid, uuid)
  to authenticated;
grant execute on function public.can_view_event(uuid), public.flag_enabled(text) to anon;

-- ---------------------------------------------------------------------------
-- Storage: avatars and photos, one folder per user ({uid}/file)
-- ---------------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('avatars', 'avatars', true, 5242880, array['image/jpeg', 'image/png', 'image/webp']),
  ('photos', 'photos', true, 5242880, array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do nothing;

create policy "users upload own images" on storage.objects for insert to authenticated
  with check (bucket_id in ('avatars', 'photos') and (storage.foldername(name))[1] = auth.uid()::text);
create policy "users replace own images" on storage.objects for update to authenticated
  using (bucket_id in ('avatars', 'photos') and (storage.foldername(name))[1] = auth.uid()::text);
create policy "users delete own images" on storage.objects for delete to authenticated
  using (bucket_id in ('avatars', 'photos') and (storage.foldername(name))[1] = auth.uid()::text);
