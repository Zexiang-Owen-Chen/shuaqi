-- Standard coarse regions; unknown legacy text must never become public or a wildcard.
create or replace function public.normalize_region(p_region text) returns text
language sql immutable set search_path = '' as $$
  select case lower(trim(p_region))
    when 'london / south kensington / chelsea' then 'London / South Kensington / Chelsea'
    when 'south kensington' then 'London / South Kensington / Chelsea'
    when 'south ken' then 'London / South Kensington / Chelsea'
    when 'chelsea' then 'London / South Kensington / Chelsea'
    when 'south kensington / chelsea' then 'London / South Kensington / Chelsea'
    when '南肯辛顿' then 'London / South Kensington / Chelsea'
    when 'london / bloomsbury / king''s cross' then 'London / Bloomsbury / King''s Cross'
    when 'bloomsbury' then 'London / Bloomsbury / King''s Cross'
    when 'king''s cross' then 'London / Bloomsbury / King''s Cross'
    when 'kings cross' then 'London / Bloomsbury / King''s Cross'
    when 'bloomsbury / king''s cross' then 'London / Bloomsbury / King''s Cross'
    when 'london / holborn / covent garden' then 'London / Holborn / Covent Garden'
    when 'holborn' then 'London / Holborn / Covent Garden'
    when 'covent garden' then 'London / Holborn / Covent Garden'
    when 'holborn / covent garden' then 'London / Holborn / Covent Garden'
    when 'london / camden' then 'London / Camden'
    when 'camden' then 'London / Camden'
    when 'london / city / shoreditch' then 'London / City / Shoreditch'
    when 'city' then 'London / City / Shoreditch'
    when 'city of london' then 'London / City / Shoreditch'
    when 'shoreditch' then 'London / City / Shoreditch'
    when 'city / shoreditch' then 'London / City / Shoreditch'
    when 'london / canary wharf / east' then 'London / Canary Wharf / East'
    when 'canary wharf' then 'London / Canary Wharf / East'
    when 'east london' then 'London / Canary Wharf / East'
    when 'canary wharf / east' then 'London / Canary Wharf / East'
    when 'london / south bank / southwark' then 'London / South Bank / Southwark'
    when 'south bank' then 'London / South Bank / Southwark'
    when 'southwark' then 'London / South Bank / Southwark'
    when 'south bank / southwark' then 'London / South Bank / Southwark'
    when 'london / west' then 'London / West'
    when 'west' then 'London / West'
    when 'west london' then 'London / West'
    when 'hammersmith' then 'London / West'
    when 'london / other' then 'London / Other'
    when 'london' then 'London / Other'
    when '伦敦' then 'London / Other'
    when '伦敦其他' then 'London / Other'
    when 'london other' then 'London / Other'
    when 'oxford' then 'Oxford'
    when '牛津' then 'Oxford'
    when 'cambridge' then 'Cambridge'
    when '剑桥' then 'Cambridge'
    else null
  end
$$;
revoke all on function public.normalize_region(text) from public, anon;
grant execute on function public.normalize_region(text) to authenticated;

-- Only exact known aliases are mapped. Unrecognized profile locations are cleared,
-- and existing onboarding middleware asks the owner to choose again.
update public.profiles
set region = public.normalize_region(region),
    onboarded = onboarded and public.normalize_region(region) is not null,
    visibility = visibility - 'region';
alter table public.profiles alter column visibility set default
  '{"bio":"public","interests":"public","photos":"public","gender":"public","age":"public"}';

-- Preserve unrecognized historical intent text, but stop open intents from matching.
-- Do not convert an unrecognized restriction into the unrestricted empty string.
update public.intents set status = 'withdrawn'
where status = 'open' and trim(region) <> '' and public.normalize_region(region) is null;
update public.intents set region = public.normalize_region(region)
where public.normalize_region(region) is not null;
update public.intents set region = '' where trim(region) = '';

create or replace function public.enforce_region() returns trigger
language plpgsql set search_path = '' as $$
declare v_region text := public.normalize_region(new.region);
begin
  if nullif(trim(new.region), '') is not null and v_region is null then
    raise exception 'region_invalid' using errcode = 'P0001';
  end if;
  if tg_table_name = 'profiles' then
    if new.onboarded and v_region is null then
      raise exception 'region_required' using errcode = 'P0001';
    end if;
    new.region := v_region;
  else
    new.region := coalesce(v_region, '');
  end if;
  return new;
end $$;
revoke all on function public.enforce_region() from public, anon, authenticated;
create trigger profiles_region before insert or update of region, onboarded on public.profiles
for each row execute function public.enforce_region();
create trigger intents_region before insert or update of region on public.intents
for each row execute function public.enforce_region();

create or replace function public.get_profile_card(p_target uuid, p_context text default 'general', p_context_id uuid default null)
returns jsonb
language plpgsql stable security definer set search_path = '' as $$
declare
  v_me uuid := auth.uid();
  p public.profiles;
  v_connected boolean;
  v_fields text[] := '{}';
  v_optin public.event_social_optin;
  v_key text;
  v_scope text;
  v_out jsonb;
begin
  if v_me is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  select * into p from public.profiles where id = p_target;
  if not found then return null; end if;

  if p_target = v_me then
    v_fields := array['bio', 'interests', 'photos', 'gender', 'age', 'region'];
  else
    if public.is_blocked(v_me, p_target) then return null; end if;
    v_connected := public.are_connected(v_me, p_target);

    for v_key, v_scope in select key, value from jsonb_each_text(p.visibility) loop
      if v_scope = 'public' or (v_scope = 'connections' and v_connected) then
        v_fields := v_fields || v_key;
      end if;
    end loop;

    if p_context = 'event' then
      select * into v_optin from public.event_social_optin
        where event_id = p_context_id and user_id = p_target and opted_in;
      if found and public.is_going(p_context_id, p_target)
         and (public.is_going(p_context_id, v_me) or public.is_event_staff(p_context_id, v_me)) then
        -- The person chooses optional fields; coarse region is always included below.
        v_fields := case when v_connected then v_fields || v_optin.visible_fields else v_optin.visible_fields end;
      elsif not v_connected then
        return null;
      end if;
    elsif p_context = 'intent' then
      -- One-to-one matching: gender, age and region are always shown (founder rule).
      if exists (select 1 from public.match_invitations i
                 where (i.from_user = v_me and i.to_user = p_target) or (i.from_user = p_target and i.to_user = v_me))
         or exists (select 1 from public.intents a, public.intents b
                    where a.user_id = v_me and b.user_id = p_target
                      and public.intents_compatible(a.id, b.id)) then
        v_fields := v_fields || array['gender', 'age', 'region'];
      elsif not v_connected then
        return null;
      end if;
    end if;
  end if;

  v_out := jsonb_build_object(
    'id', p.id,
    'display_name', p.display_name,
    'avatar_url', p.avatar_url,
    'school_domain', p.school_domain,
    'school_verified', p.school_verified_at is not null,
    'connected', coalesce(v_connected, false),
    'is_me', p_target = v_me,
    'region', public.normalize_region(p.region)
  );
  if 'bio' = any (v_fields) then v_out := v_out || jsonb_build_object('bio', p.bio); end if;
  if 'interests' = any (v_fields) then v_out := v_out || jsonb_build_object('interests', p.interests); end if;
  if 'gender' = any (v_fields) then v_out := v_out || jsonb_build_object('gender', p.gender); end if;
  if 'age' = any (v_fields) and p.birth_year is not null then
    v_out := v_out || jsonb_build_object('age', extract(year from now())::int - p.birth_year);
  end if;
  if 'photos' = any (v_fields) then
    v_out := v_out || jsonb_build_object('photos', coalesce(
      (select jsonb_agg(storage_path order by sort) from public.profile_photos where user_id = p.id), '[]'));
  end if;
  return v_out;
end $$;

create or replace function public.intents_compatible(p_a uuid, p_b uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.intents a, public.intents b
    where a.id = p_a and b.id = p_b and a.user_id <> b.user_id
      and a.status = 'open' and b.status = 'open'
      and a.expires_at > now() and b.expires_at > now()
      and lower(a.activity_type) = lower(b.activity_type)
      and tstzrange(a.window_start, a.window_end) && tstzrange(b.window_start, b.window_end)
      and (a.region = '' or public.normalize_region(a.region) is not null)
      and (b.region = '' or public.normalize_region(b.region) is not null)
      and (a.region = '' or b.region = '' or a.region = b.region)
      and not public.is_blocked(a.user_id, b.user_id)
  )
$$;

create or replace function public.nearby_card(p_user uuid) returns jsonb
language sql stable security definer set search_path = '' as $$
  select jsonb_build_object(
           'id', p.id, 'display_name', p.display_name, 'avatar_url', p.avatar_url,
           'school_domain', p.school_domain, 'school_verified', p.school_verified_at is not null,
           'region', public.normalize_region(p.region),
           'connected', public.are_connected(auth.uid(), p.id))
  from public.profiles p where p.id = p_user
    and auth.uid() is not null and not public.is_blocked(auth.uid(), p.id)
$$;

