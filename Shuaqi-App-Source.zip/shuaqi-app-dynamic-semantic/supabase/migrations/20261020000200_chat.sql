-- One-to-one text chat between connections (friends).
-- Only two people who are connected and have not blocked each other can read or write a conversation;
-- unfriending or blocking hides it at once. Messages are written by send_message() only.
-- Retention: messages are deleted 12 months after they were sent, and with either account
-- (profiles cascade). V0 has no offline push; the app uses Supabase Realtime while it is open.

insert into public.feature_flags (key, description)
values ('chat', 'One-to-one chat between connections')
on conflict (key) do nothing;

-- Reported messages. Compared as text below: a new enum value cannot be used in the transaction that adds it.
alter type public.report_target add value if not exists 'message';
-- What the reporter saw (the message and the few before it), so admins can act after it is deleted.
alter table public.reports add column snapshot jsonb;

-- ---------------------------------------------------------------------------
-- Tables
-- ---------------------------------------------------------------------------
create table public.conversations (
  id uuid primary key default gen_random_uuid(),
  user_a uuid not null references public.profiles (id) on delete cascade,
  user_b uuid not null references public.profiles (id) on delete cascade,
  created_at timestamptz not null default now(),
  last_message_at timestamptz,
  user_a_read_at timestamptz,
  user_b_read_at timestamptz,
  unique (user_a, user_b),
  check (user_a < user_b)
);
create index on public.conversations (user_b);

create table public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations (id) on delete cascade,
  sender_id uuid not null references public.profiles (id) on delete cascade,
  body text not null check (char_length(body) between 1 and 1000),
  created_at timestamptz not null default now()
);
create index on public.messages (conversation_id, created_at desc);
create index on public.messages (sender_id, created_at desc);
create index on public.messages (created_at);

-- ---------------------------------------------------------------------------
-- Permission helpers
-- ---------------------------------------------------------------------------
create or replace function public.can_chat(p_a uuid, p_b uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select public.are_connected(p_a, p_b) and not public.is_blocked(p_a, p_b)
$$;

-- The caller is one of the two people and they can still chat.
create or replace function public.can_read_conversation(p_conversation uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.conversations c
    where c.id = p_conversation
      and auth.uid() in (c.user_a, c.user_b)
      and public.can_chat(c.user_a, c.user_b)
  )
$$;

-- ---------------------------------------------------------------------------
-- Row level security: read only; writes go through the functions below.
-- ---------------------------------------------------------------------------
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
revoke all on public.conversations, public.messages from anon, authenticated;

grant select on public.conversations to authenticated;
create policy "conversations own" on public.conversations for select to authenticated
  using (public.can_read_conversation(id));

grant select on public.messages to authenticated;
create policy "messages in own conversations" on public.messages for select to authenticated
  using (public.can_read_conversation(conversation_id));

-- Message reports must go through report_message() so the snapshot cannot be forged.
drop policy "reports own insert" on public.reports;
create policy "reports own insert" on public.reports for insert to authenticated
  with check (reporter_id = auth.uid() and status = 'open' and handled_by is null
              and target_type::text <> 'message' and snapshot is null);

-- ---------------------------------------------------------------------------
-- Functions
-- ---------------------------------------------------------------------------
-- Returns the conversation with a friend, creating it on first use.
create or replace function public.open_conversation(p_other uuid) returns uuid
language plpgsql security definer set search_path = '' as $$
declare
  v_me uuid := auth.uid();
  v_id uuid;
begin
  if v_me is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  if not public.flag_enabled('chat') then raise exception 'feature_disabled' using errcode = 'P0001'; end if;
  if p_other is null or p_other = v_me or not public.can_chat(v_me, p_other) then
    raise exception 'not_connected' using errcode = 'P0001';
  end if;
  insert into public.conversations (user_a, user_b) values (least(v_me, p_other), greatest(v_me, p_other))
  on conflict (user_a, user_b) do nothing;
  select id into v_id from public.conversations where user_a = least(v_me, p_other) and user_b = greatest(v_me, p_other);
  return v_id;
end $$;

-- Limits: 20 messages a minute and 500 a day per sender.
create or replace function public.send_message(p_to uuid, p_body text) returns public.messages
language plpgsql security definer set search_path = '' as $$
declare
  v_me uuid := auth.uid();
  v_body text := trim(coalesce(p_body, ''));
  v_conv uuid;
  m public.messages;
begin
  if v_me is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  if not public.is_school_verified() then raise exception 'school_verification_required' using errcode = 'P0001'; end if;
  if v_body = '' then raise exception 'message_empty' using errcode = 'P0001'; end if;
  if char_length(v_body) > 1000 then raise exception 'message_too_long' using errcode = 'P0001'; end if;
  v_conv := public.open_conversation(p_to);

  -- Serialise one sender's sends so concurrent requests cannot slip past the limit.
  perform pg_advisory_xact_lock(hashtextextended('send_message:' || v_me::text, 0));
  if (select count(*) from public.messages where sender_id = v_me and created_at > now() - interval '1 minute') >= 20
     or (select count(*) from public.messages where sender_id = v_me and created_at > now() - interval '1 day') >= 500 then
    raise exception 'rate_limited' using errcode = 'P0001';
  end if;

  insert into public.messages (conversation_id, sender_id, body) values (v_conv, v_me, v_body) returning * into m;
  update public.conversations
     set last_message_at = m.created_at,
         user_a_read_at = case when user_a = v_me then m.created_at else user_a_read_at end,
         user_b_read_at = case when user_b = v_me then m.created_at else user_b_read_at end
   where id = v_conv;
  return m;
end $$;

create or replace function public.mark_conversation_read(p_conversation uuid) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.can_read_conversation(p_conversation) then
    raise exception 'conversation_not_found' using errcode = 'P0001';
  end if;
  update public.conversations
     set user_a_read_at = case when user_a = auth.uid() then now() else user_a_read_at end,
         user_b_read_at = case when user_b = auth.uid() then now() else user_b_read_at end
   where id = p_conversation;
end $$;

-- My conversations that have messages, newest first, with the friend's card and my unread count.
create or replace function public.list_my_conversations()
returns table (conversation_id uuid, other_id uuid, card jsonb, last_body text, last_sender_id uuid,
               last_message_at timestamptz, unread int)
language sql stable security definer set search_path = '' as $$
  select c.id, o.other, public.get_profile_card(o.other, 'general', null),
         l.body, l.sender_id, c.last_message_at,
         (select count(*)::int from public.messages m
           where m.conversation_id = c.id and m.sender_id <> auth.uid()
             and m.created_at > coalesce(case when c.user_a = auth.uid() then c.user_a_read_at else c.user_b_read_at end, '-infinity'))
  from public.conversations c
  cross join lateral (select case when c.user_a = auth.uid() then c.user_b else c.user_a end as other) o
  cross join lateral (select m.body, m.sender_id from public.messages m
                      where m.conversation_id = c.id order by m.created_at desc limit 1) l
  where auth.uid() in (c.user_a, c.user_b) and public.can_chat(c.user_a, c.user_b)
  order by c.last_message_at desc
$$;

create or replace function public.unread_message_count() returns int
language sql stable security definer set search_path = '' as $$
  select coalesce(sum(unread), 0)::int from public.list_my_conversations()
$$;

-- Reports a message received from the other person, keeping a copy of it and the 10 messages before it.
-- Works after unfriending or blocking, so the reporter can block first and report next.
create or replace function public.report_message(p_message uuid, p_reason text, p_details text default '')
returns uuid
language plpgsql security definer set search_path = '' as $$
declare
  v_me uuid := auth.uid();
  m public.messages;
  v_id uuid;
begin
  if v_me is null then raise exception 'not_authenticated' using errcode = 'P0001'; end if;
  select msg.* into m from public.messages msg join public.conversations c on c.id = msg.conversation_id
   where msg.id = p_message and v_me in (c.user_a, c.user_b);
  if not found then raise exception 'message_not_found' using errcode = 'P0001'; end if;
  if m.sender_id = v_me then raise exception 'cannot_report_own_message' using errcode = 'P0001'; end if;

  -- Repeat clicks return the open report.
  select id into v_id from public.reports
   where reporter_id = v_me and target_type::text = 'message' and target_id = p_message and status in ('open', 'reviewing');
  if found then return v_id; end if;

  insert into public.reports (reporter_id, target_type, target_id, reason, details, snapshot)
  values (v_me, 'message'::text::public.report_target, p_message, p_reason, coalesce(trim(p_details), ''),
          jsonb_build_object(
            'conversation_id', m.conversation_id,
            'reported_user_id', m.sender_id,
            'message', jsonb_build_object('id', m.id, 'sender_id', m.sender_id, 'body', m.body, 'created_at', m.created_at),
            'context', coalesce((
              select jsonb_agg(jsonb_build_object('id', x.id, 'sender_id', x.sender_id, 'body', x.body, 'created_at', x.created_at)
                               order by x.created_at)
              from (select * from public.messages
                     where conversation_id = m.conversation_id and created_at <= m.created_at and id <> m.id
                     order by created_at desc limit 10) x), '[]')))
  returning id into v_id;
  return v_id;
end $$;

-- ---------------------------------------------------------------------------
-- Retention: messages after 12 months; report snapshots 12 months after the report is closed.
-- ---------------------------------------------------------------------------
create or replace function public.purge_old_messages() returns int
language plpgsql security definer set search_path = '' as $$
declare n int;
begin
  delete from public.messages where created_at < now() - interval '12 months';
  get diagnostics n = row_count;
  update public.reports set snapshot = null
   where snapshot is not null and status in ('resolved', 'dismissed') and handled_at < now() - interval '12 months';
  return n;
end $$;

-- Needs pg_cron (Dashboard → Database → Extensions); skipped when it is not enabled.
do $$
begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    perform cron.unschedule(jobid) from cron.job where jobname = 'purge_old_messages';
    perform cron.schedule('purge_old_messages', '17 3 * * *', 'select public.purge_old_messages()');
  end if;
end $$;

-- ---------------------------------------------------------------------------
-- Realtime: new messages reach open chats; RLS above decides who receives them.
-- ---------------------------------------------------------------------------
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    alter publication supabase_realtime add table public.messages;
  end if;
end $$;

-- ---------------------------------------------------------------------------
-- Grants
-- ---------------------------------------------------------------------------
revoke execute on function public.can_chat(uuid, uuid), public.can_read_conversation(uuid), public.open_conversation(uuid),
  public.send_message(uuid, text), public.mark_conversation_read(uuid), public.list_my_conversations(),
  public.unread_message_count(), public.report_message(uuid, text, text), public.purge_old_messages()
  from public, anon, authenticated;
-- can_read_conversation is used inside policies, so the client role needs it. It only answers for the
-- caller's own conversations; can_chat stays private (it would tell anyone who is friends with whom).
grant execute on function public.can_read_conversation(uuid), public.open_conversation(uuid),
  public.send_message(uuid, text), public.mark_conversation_read(uuid), public.list_my_conversations(),
  public.unread_message_count(), public.report_message(uuid, text, text)
  to authenticated;
